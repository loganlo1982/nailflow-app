#!/usr/bin/env python3
# LAMWEB 618-B.1 - "co tinh lam hong" (mutation): each mutation breaks ONE important line in a COPY of the app, then runs the suite that must catch it.
# The suite MUST show a NEW FAIL (not in baseline/). Still all old -> that test is useless (written in the report).
#   python3 mutate.py <app folder>        -> run/MUTATION.txt
import sys, os, shutil, subprocess, re, time
K = os.path.dirname(os.path.abspath(__file__)); APP = os.path.abspath(sys.argv[1]); W = K + '/mut'; os.makedirs(W, exist_ok=True)
# (id, what is broken, file, old, new, suite)
M = [
 ('M01', 'chong trung dat hen (B1) bi bo', 'inc/calls-job.php', "if ($dup) { q('UPDATE calls SET appt_id", "if (false && $dup) { q('UPDATE calls SET appt_id", 'telnyx615'),
 ('M02', 'kiem tho / gio trong (cl_free) luon "trong"', 'inc/calls-job.php', "    $busy = busy_appts($date); $out = staff_out_at($date);", "    return ''; $busy = busy_appts($date); $out = staff_out_at($date);", 'telnyx615'),
 ('M03', 'khoa dat hen (book_lock) khong khoa', 'api.php', "function book_lock(): bool {\n", "function book_lock(): bool { $GLOBALS['book_locked'] = true; return true;\n", 'telnyx615'),
 ('M04', 'kiem chu ky webhook luon OK', 'inc/calls-tx.php', "    $pub = tx_pub(); if ($pub === '') return '';", "    return ''; $pub = tx_pub();", 'aicall'),
 ('M05', 'huy theo appt_id bi bo (huy nham hen trung)', 'inc/calls-job.php', "    if ($aid > 0) foreach ($up as $a) if ((int)$a['id'] === $aid) return [$a];", "", 'telnyx615'),
 ('M06', 'chuyen AI 1 lan (tx_claim) luon true', 'inc/calls-tx.php', "(screen IS NULL OR screen NOT IN ('vmai', 'person'))\", [$sid])->rowCount() === 1;", "(screen IS NULL OR screen NOT IN ('vmai', 'person'))\", [$sid])->rowCount() >= 0;", 'telnyx'),
 ('M07', 'chuyen may ve lai iPhone (cl_ivr_owner_tx)', 'inc/calls-tx.php', "return strlen($o) === 12 && $o !== norm_phone(cl_fwd()) ? $o : ''; }", "return strlen($o) === 12 ? $o : cl_fwd(); }", 'aicall telnyx'),
 ('M08', 'tin missed call: bo luat 30 phut', 'inc/calls-job.php', "return $skip('texted < 30 min ago');", "{}", 'sw590'),
 ('M09', 'missed call Telnyx (cup truoc AI) khong hen tin', 'inc/calls-tx.php', "rowCount()) cl_tb_wait($sid, 0);", "rowCount()) {}", 'aicall telnyx'),
 ('M10', 'log lai so dien thoai day du', 'inc/calls-tx.php', "preg_replace('/\\+1\\d{6}(\\d{4})/', '+1******$1', ", "preg_replace('/^\\b$/', '', ", 'aicall'),
 ('M11', 'chon mau: mau moi KHONG thay mau cu (chon nhieu)', 'assets/book-colors.js', "if (b.hasAttribute('data-hok') && handC) { picked = [handC];", "if (b.hasAttribute('data-hok') && handC) { picked = picked.filter(p => p.code !== handC.code).concat([handC]);", 'book611a'),
 ('M12', 'Done < 5 phut khong hoi lai (609)', 'inc/api/techapp.php', "($sec = time() - (int)strtotime((string)$a['started_at'])) < 300)", "($sec = time() - (int)strtotime((string)$a['started_at'])) < 0)", 'turn609'),
 ('M13', 'so goi den lay tu body AI (khong phai CallSid)', 'inc/calls-tx.php', "'caller_id_num' => (string)$c['from_phone'],", "'caller_id_num' => (string)($body['phone'] ?? $c['from_phone']),", 'aicall'),
 ('M14', 'AI dat lich khi THIEU ten (ca 2 lop: tool + cl_decide)', 'inc/calls-agent.php', "if ($name === '') return $out('NOT_BOOKED – ask the caller\\'s name.');", "if ($name === '') $name = 'X';", 'aicall', ('inc/calls-job.php', "    if ($name === '' && $file && trim((string)$file['name']) !== '') $name = mb_strtoupper(trim((string)$file['name']));\n    if ($name === '') $why[] = 'no name';", "    if ($name === '' && $file && trim((string)$file['name']) !== '') $name = mb_strtoupper(trim((string)$file['name']));")),
]
only = sys.argv[2:]
out = []; t0 = time.time()
for mm in M:
    mid, what, f, old, new, suite = mm[:6]; extra = mm[6:]
    if only and mid not in only: continue
    d = W + '/app'; shutil.rmtree(d, ignore_errors=True); shutil.copytree(APP, d, symlinks=True)
    p = d + '/' + f; s = open(p, encoding='utf-8').read(); n = s.count(old)
    if n != 1: out.append('%s  ?? ANCHOR %d lan – khong chay (%s)' % (mid, n, what)); print(out[-1]); continue
    open(p, 'w', encoding='utf-8').write(s.replace(old, new))
    for f2, o2, n2 in extra:
        p2 = d + '/' + f2; s2 = open(p2, encoding='utf-8').read(); assert s2.count(o2) == 1, (mid, f2); open(p2, 'w', encoding='utf-8').write(s2.replace(o2, n2))
    r = subprocess.run([K + '/run-tests.sh', d] + suite.split(), capture_output=True, text=True); sm = r.stdout
    nm = sum(int(x) for x in re.findall(r'FAIL MOI (\d+)\)', sm)) if 'FAIL MOI' in sm else -1
    caught = [l.strip()[5:90] for l in sm.splitlines() if l.strip().startswith('MOI:')][:3]
    out.append('%s  %-6s %-45s bo %-9s FAIL MOI %2d  %s' % (mid, 'BAT DUOC' if nm > 0 else 'LOT !!', what, suite, nm, ' | '.join(caught)))
    print(out[-1], flush=True)
shutil.rmtree(W, ignore_errors=True)
txt = '== MUTATION (618-B.1) %s · app %s · %ds\n' % (time.strftime('%Y-%m-%d %H:%M'), APP, time.time() - t0) + '\n'.join(out) + '\n== BAT DUOC %d / %d\n' % (sum('BAT DUOC' in x for x in out), len(out))
os.makedirs(K + '/run', exist_ok=True); open(K + '/MUTATION.txt', 'w').write(txt); print(txt.splitlines()[-1])
