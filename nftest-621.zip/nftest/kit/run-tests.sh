#!/bin/bash
# LAMWEB 618 - one command for ALL the tests on a local copy (nothing real: fake Telnyx / SignalWire / STT / AI, texts to a table, SQLite of its own).
#   ./run-tests.sh <app folder>            all suites
#   ./run-tests.sh <app folder> telnyx sw  some suites (names below)
# Each suite gets its OWN fresh copy of the app (the app folder itself is never changed). Results: run/logs/<suite>.txt + run/SUMMARY.txt
# A FAIL line that is in baseline/<suite>.txt is an OLD known one (it fails on LIVE 2.99.613 too, written down there with the reason);
# any other FAIL = NEW -> exit code 1 (the package is not sent).
set -u
K=$(cd "$(dirname "$0")" && pwd); [ $# -ge 1 ] || { echo "usage: $0 <app folder> [suite...]"; exit 2; }
APP=$(cd "$1" && pwd) || exit 2; shift
ALL="aicall telnyx telnyx615 review622 sw605b sw602b sw590 book611a turn609"; SU=${*:-$ALL}
R=$K/run; rm -rf "$R"; mkdir -p "$R/logs"; cp -a "$K/s/." "$R/"
grep -rl --include='*.py' --include='*.js' --include='*.php' '/tmp/claude-0' "$R" | xargs sed -i "s#/tmp/claude-0#$R#g"
export TZ=America/Chicago
# (621 A3) DONG HO GIA: moi test thay CUNG 1 gio co dinh (mac dinh Thu Tu 2026-11-04 10:00 CST, doi bang NF_TEST_NOW="YYYY-MM-DD HH:MM"), khong phu thuoc gio may
CK="$K/clock/nfclock.so"; [ -f "$CK" ] || gcc -shared -fPIC -O2 -o "$CK" "$K/clock/nfclock.c" -ldl 2>/dev/null
if [ -f "$CK" ]; then export NF_FAKE_T0=$(date +%s) NF_FAKE_NOW=$(date -d "${NF_TEST_NOW:-2026-11-04 10:00}" +%s) LD_PRELOAD="$CK"; CLK="gio gia ${NF_TEST_NOW:-2026-11-04 10:00}"; else CLK="!! KHONG co gcc: dung GIO MAY (vai test phu thuoc ngay)"; fi
mk() { local d="$R/app-$1"; rm -rf "$d"; cp -a "$APP" "$d"; sed -i "s#'/usr/bin/mpg123'#'$R/T616/mpg123'#g" "$d/inc/calls-tx.php" 2>/dev/null; echo "$d"; }
run() { local n=$1; shift; local t0=$(date +%s); timeout 300 "$@" > "$R/logs/$n.txt" 2>&1; local rc=$?; local dt=$(( $(date +%s) - t0 ))
  local pass=$(grep -c '^✓' "$R/logs/$n.txt"); local fail=$(grep -c '^✗' "$R/logs/$n.txt"); local new=0
  if [ -f "$K/baseline/$n.txt" ]; then new=$(grep '^✗' "$R/logs/$n.txt" | cut -c1-80 | grep -vxF -f <(cut -c1-80 "$K/baseline/$n.txt") | wc -l); else new=$fail; fi
  [ $((pass + fail)) -eq 0 ] && new=1
  printf '%-10s PASS %3d  FAIL %3d  (FAIL MOI %d)  %3ds%s\n' "$n" "$pass" "$fail" "$new" "$dt" "$([ $rc -ne 0 ] && echo "  rc=$rc")" | tee -a "$R/SUMMARY.txt"
  [ "$new" -eq 0 ] || grep '^✗' "$R/logs/$n.txt" | cut -c1-80 | grep -vxF -f <(cut -c1-80 "$K/baseline/$n.txt" 2>/dev/null || true) | sed 's/^/      MOI: /' | tee -a "$R/SUMMARY.txt"
  TOTNEW=$((TOTNEW + new)); TOTP=$((TOTP + pass)); TOTF=$((TOTF + fail)); }
TOTNEW=0; TOTP=0; TOTF=0
echo "== run-tests $(LD_PRELOAD= date '+%Y-%m-%d %H:%M %Z') · $CLK · app: $APP · version: $(grep -o "APP_VERSION', '[^']*" "$APP/inc/core.php" 2>/dev/null | cut -d"'" -f3)" | tee "$R/SUMMARY.txt"
echo "   sha calls-tx $(sha256sum "$APP/inc/calls-tx.php" | cut -c1-8) · calls-job $(sha256sum "$APP/inc/calls-job.php" | cut -c1-8) · calls-agent $(sha256sum "$APP/inc/calls-agent.php" | cut -c1-8) · call_tx $(sha256sum "$APP/call_tx.php" | cut -c1-8)" | tee -a "$R/SUMMARY.txt"
for s in $SU; do case $s in
  aicall)    a=$(mk $s); cd "$R/T612" && rm -rf calls/txg-* conv "$a-salonB"; run aicall python3 "$R/T618/sim.py" "$a"; cd "$K" ;;
  telnyx)    a=$(mk $s); cd "$R/T612" && rm -f calls/txg-* calls/txh-* calls/.tx-clean; run telnyx python3 "$R/T616/t616full.py" "$a"; cd "$K" ;;
  telnyx615) a=$(mk $s); rm -f "$R"/T612/calls/txg-*; run telnyx615 python3 "$R/T615/t616.py" "$a" ;;
  review622) a=$(mk $s); run review622 python3 "$R/T622/t622.py" "$a" ;;
  sw605)     a=$(mk $s); run sw605 python3 "$R/T605/t605.py" "$a" ;;
  sw605b)    a=$(mk $s); run sw605b python3 "$R/T605B/t605b.py" "$a" ;;
  sw602b)    a=$(mk $s); run sw602b python3 "$R/T586/t602b.py" "$a" ;;
  sw590)     a=$(mk $s); run sw590 python3 "$R/T586/t590.py" "$a" ;;
  book611a)  a=$(mk $s); b=$(mk $s-base); run book611a node "$R/T611A/t611a.js" "$a" "$b" 19960 "$R/out611a" ;;
  turn609)   a=$(mk $s); run turn609 node "$R/T609/ui609.js" "$a" ;;
  *) echo "unknown suite $s (known: $ALL)" ;;
esac; done
echo "== TONG: PASS $TOTP · FAIL $TOTF · FAIL MOI $TOTNEW  -> $([ $TOTNEW -eq 0 ] && echo 'OK (chi con FAIL cu da biet)' || echo 'CO FAIL MOI - KHONG GUI GOI')" | tee -a "$R/SUMMARY.txt"
[ $TOTNEW -eq 0 ]
