#!/bin/bash
# LENH-621 muc 6 – moi 10 phut (cron root: */10 * * * * /root/nftest/errwatch.sh): doc error_log cua app TU LAN TRUOC -> "PHP Fatal" / "Uncaught" /
# Telnyx loi lien tiep -> 1 push gop "⚠️ Loi web: <file:dong> (x lan)", toi da 1 push / 30 phut / loai loi. Khong noi dung khach / so dien thoai.
set -u
N=$(cd "$(dirname "$0")" && pwd); . "$N/nftest.conf"
exec 9>"$N/.errwatch.lock"; flock -n 9 || exit 0
ST="$N/errwatch.state"; touch "$ST"; NEW=""
for L in $ERROR_LOGS; do
  [ -f "$L" ] || continue; key=$(echo "$L" | md5sum | cut -c1-8); sz=$(stat -c %s "$L"); last=$(grep "^off $key " "$ST" | awk '{print $3}'); last=${last:-$sz}
  [ "$sz" -lt "$last" ] && last=0                                   # log xoay vong
  NEW="$NEW$(tail -c +$((last + 1)) "$L" | head -c 2000000)"$'\n'; sed -i "/^off $key /d" "$ST"; echo "off $key $sz" >> "$ST"
done
now=$(date +%s)
send() { local typ=$1 msg=$2; local t=$(grep "^sent $typ " "$ST" | awk '{print $3}'); [ -n "$t" ] && [ $((now - t)) -lt 1800 ] && return
  "$PHP" "$N/push.php" "$PUSH_APP" "$msg" error >> "$N/errwatch.log" 2>&1; sed -i "/^sent $typ /d" "$ST"; echo "sent $typ $now" >> "$ST"; }
F=$(printf '%s' "$NEW" | grep -E 'PHP Fatal|Uncaught' | grep -oE '[A-Za-z0-9_./-]+\.php(:| on line )[0-9]+' | sed -E 's#.*/##; s/ on line /:/' | sort | uniq -c | sort -rn)
if [ -n "$F" ]; then top=$(echo "$F" | head -1 | awk '{print $2}'); cnt=$(echo "$F" | awk '{s+=$1} END {print s}'); send "fatal-$top" "⚠️ Loi web: $top (${cnt} lan)"; fi
T=$(printf '%s' "$NEW" | grep -cE '612 tx (redirect http|conv|messages|rec #|post)|Telnyx (GET|POST|PATCH|DELETE) .*: [45][0-9][0-9]')
[ "${T:-0}" -ge 3 ] && send telnyx "⚠️ Loi web: Telnyx that bai ${T} lan / 10 phut"
exit 0
