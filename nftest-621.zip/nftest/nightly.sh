#!/bin/bash
# LENH-621 – bo test 618 chay moi dem (cron root: 0 3 * * * /root/nftest/nightly.sh). Chi DOC code live; test tren ban sao + SQLite rieng + dich vu GIA (khong mang that).
# Gioi han: toi da 10 phut, nice 19 / ionice idle, flock (khong chay chong). Ket qua: /root/nftest/ket-qua/YYYY-MM-DD.txt (giu 30 ngay) + 1 push cho chu.
set -u
N=$(cd "$(dirname "$0")" && pwd); . "$N/nftest.conf"
exec 9>"$N/.nightly.lock"; flock -n 9 || { echo "dang chay - bo qua"; exit 0; }
D=$(date +%F); mkdir -p "$N/ket-qua"; OUT="$N/ket-qua/$D.txt"
rm -rf "$N/app"; mkdir -p "$N/app"
cp -a "$APP_LIVE/." "$N/app/"                                    # release LIVE (chi doc)
for f in index.php api.php call_tx.php; do [ -f "$AN_PUBLIC/$f" ] && [ ! -L "$AN_PUBLIC/$f" ] && cp "$AN_PUBLIC/$f" "$N/app/$f"; done   # file rieng cua AN
rm -f "$N/app/inc/config.php" "$N/app/error_log"; find "$N/app" -name '*.sqlite' -delete 2>/dev/null   # KHONG mang config / DB that sang ban test
SU=$(grep -o '^ALL="[^"]*"' "$N/kit/run-tests.sh" | cut -d'"' -f2)                     # every suite of the kit
command -v node >/dev/null && node -e "require('playwright')" 2>/dev/null || SU=$(echo "$SU" | sed 's/book611a//; s/turn609//')   # no node / playwright: the 2 browser suites run on LAMWEB's machine
PATH="$(dirname "$PHP"):$PATH" timeout 600 nice -n 19 ionice -c3 "$N/kit/run-tests.sh" "$N/app" $SU > "$OUT" 2>&1; rc=$?
[ $rc -eq 124 ] && echo "!! QUA 10 PHUT - dung" >> "$OUT"
command -v node >/dev/null || echo "(khong co node / playwright tren server: bo book611a + turn609 – chay o may LAMWEB)" >> "$OUT"
cp "$N/kit/run/logs/"*.txt "$N/ket-qua/" 2>/dev/null; mkdir -p "$N/ket-qua/$D-logs"; mv "$N/ket-qua/"[a-z]*.txt "$N/ket-qua/$D-logs/" 2>/dev/null
find "$N/ket-qua" -maxdepth 1 -mtime +30 -exec rm -rf {} + 2>/dev/null    # giu 30 ngay
P=$(grep -o 'PASS [0-9]* · FAIL [0-9]* · FAIL MOI [0-9]*' "$OUT" | tail -1); NEWN=$(echo "$P" | grep -o 'MOI [0-9]*' | grep -o '[0-9]*'); PASSN=$(echo "$P" | grep -o '^PASS [0-9]*' | grep -o '[0-9]*')
PREV=$(ls "$N/ket-qua/"20*.txt 2>/dev/null | grep -v "$D" | tail -1); PP=$(grep -o 'PASS [0-9]*' "$PREV" 2>/dev/null | tail -1 | grep -o '[0-9]*')
MODS=$(grep -E '^[a-z0-9]+ +PASS .*FAIL MOI [1-9]' "$OUT" | awk '{print $1}' | head -4 | paste -sd, -)
if [ -z "$P" ] || [ $rc -eq 124 ]; then MSG="⚠️ Test dem $(date +%-m/%-d): KHONG chay xong (xem /root/nftest/ket-qua/$D.txt)"
elif [ "${NEWN:-0}" -eq 0 ]; then MSG="🧪 Test dem $(date +%-m/%-d): ${PASSN} PASS · 0 loi moi${PP:+ (hom qua $PP)}"
else MSG="⚠️ Test dem $(date +%-m/%-d): ${NEWN} loi MOI (${MODS})"; fi
echo "$MSG" >> "$OUT"
"$PHP" "$N/push.php" "$PUSH_APP" "$MSG" >> "$OUT" 2>&1
