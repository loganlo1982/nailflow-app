<?php
/* LENH-621 – 1 push ngan cho chu tiem qua co che push SAN CO cua app (push_notify 'admin'). Khong SMS, khong noi dung khach.
   php push.php <app> "<text>" [kind]   (ghi 1 dong push_log cua app – nhu moi thong bao khac) */
declare(strict_types=1);
[$_, $app, $text] = $argv + [null, '', '']; $kind = $argv[3] ?? 'test';
if ($app === '' || $text === '') { fwrite(STDERR, "usage: php push.php <app> <text>\n"); exit(2); }
chdir($app); require $app . '/inc/core.php'; settings(); require_once $app . '/inc/push.php';
$text = mb_substr(preg_replace('/\+?\d[\d\s().-]{8,}\d/', '…', $text), 0, 160);   /* no phone number in a push */
try { $r = push_notify('admin', 'system', $text, ['title' => $kind === 'error' ? '⚠️ NailFlow' : '🧪 NailFlow', 'body' => $text, 'href' => '../admin/', 'tag' => 'nftest-' . $kind]); echo 'push: ' . json_encode($r) . "\n"; }
catch (Throwable $e) { echo 'push loi: ' . $e->getMessage() . "\n"; exit(1); }
