# LAMWEB test 635 – the 3 things LENH-632 missed (found by CHAT on the server), so they never come back:
#  B1 a salon web folder with its OWN api.php (AN public_html, ~/lovenails): every API action of the release must be reachable there too
#  B2 Love Nails behind this server's proxy: the setup link's host check reads X-Forwarded-Host ONLY from 72.167.37.112 / 127.0.0.1
#  B3 /setup/: a "VD:" example under EVERY choice (static check – no browser needed, runs on the server too)
#   python3 t635.py <app folder>      env NF_WEB_APIS="<AN public_html/api.php> <lovenails/api.php>" = check the REAL files (server); default = the kit's copies
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, re
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T635'; T5 = '/tmp/claude-0/T586'; PORT = 19961
R = []; out = open(D + '/test-635.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
APIS = (os.environ.get('NF_WEB_APIS') or (D + '/AN_api.php ' + D + '/LN_api.php')).split()
say('== LAMWEB test 635 – 632 cross-check (web api.php copies, proxy host, examples) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · api copies: ' + ' '.join(APIS))
def routes(p):
    s = open(p, encoding='utf-8').read(); m = re.search(r'const API_ROUTES = \[(.*?)\];', s, re.S)
    return set(re.findall(r"'([a-z0-9_]+)' => '[a-z0-9_]+'", m.group(1))) if m else set()
rel = routes(A0 + '/api.php')
for p in APIS:
    miss = sorted(rel - routes(p)); ms = [a for a in miss if a.startswith('setup_')]; mo = [a for a in miss if not a.startswith('setup_')]
    ok('B1 %s: has the 9 setup_* actions of the release api.php (632)' % os.path.basename(p), not ms, 'missing: ' + ' '.join(ms))
    ok('B1 %s: every other action of the release api.php is there too%s' % (os.path.basename(p), (' – MISSING ' + ' '.join(mo[:12])) if mo else ''), not mo, 'a package that adds an action must patch this copy too')
# B1 live: a web folder = links to the app + its own api.php file -> the setup actions answer (403 link / 401 login), never "Unknown action"
app = D + '/app'; db = D + '/db.sqlite'; shutil.rmtree(app, ignore_errors=True); shutil.copytree(A0, app, symlinks=True); shutil.copy('/tmp/claude-0/tdb/base.sqlite', db)
sh('php', T5 + '/seed.php', app, db, str(PORT))
srv = []
for k, p in enumerate(APIS):
    w = D + '/web%d' % k; shutil.rmtree(w, ignore_errors=True); os.makedirs(w)
    for e in os.listdir(app):
        if e != 'api.php': os.symlink(app + '/' + e, w + '/' + e)
    shutil.copy(p, w + '/api.php')
    srv.append(subprocess.Popen(['php', '-S', '127.0.0.1:%d' % (PORT + 1 + k), '-t', w, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php%d.log' % k, 'w')))
atexit.register(lambda: [s.terminate() for s in srv]); time.sleep(1.2)
def call(port, action, body=None):
    rq = urllib.request.Request('http://127.0.0.1:%d/api.php?action=%s' % (port, action), data=None if body is None else json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    try: r = urllib.request.urlopen(rq, timeout=30); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
for k, p in enumerate(APIS):
    res = {a: call(PORT + 1 + k, a, None if a == 'setup_info' else {}) for a in ['setup_info', 'setup_turn', 'setup_shop', 'setup_staff_one', 'setup_staff_off', 'setup_staff_end', 'setup_new', 'setup_prev', 'setup_prev_clear']}
    bad = {a: (c, b[:60]) for a, (c, b) in res.items() if c == 404 or 'Unknown action' in b}
    ok('B1 web folder with %s: all 9 setup actions reach the link code (403 bad link / 401 owner login), none "Unknown action"' % os.path.basename(p), not bad, bad)
# B2 the host check behind the proxy (CHAT tpx632: 5 cases)
php = r'''$A = $argv[1]; require "$A/inc/core.php"; settings(); require_once "$A/inc/audit.php"; require_once "$A/inc/setuplink.php";
set_setting("setup_link", json_encode(["h" => hash("sha256", str_repeat("a", 64)), "exp" => time() + 3600, "made" => now_str(), "done" => []]));
$T = str_repeat("a", 64); $o = [];
foreach (json_decode($argv[2], true) as [$name, $srv, $want]) { $_SERVER = array_merge(["REMOTE_ADDR" => "", "HTTP_HOST" => "", "HTTP_X_FORWARDED_HOST" => ""], $srv); $o[] = [$name, setup_check($T) !== null, $want]; }
echo json_encode($o);'''
app2 = D + '/app2'; db2 = D + '/db2.sqlite'; shutil.rmtree(app2, ignore_errors=True); shutil.copytree(A0, app2, symlinks=True); shutil.copy('/tmp/claude-0/tdb/base.sqlite', db2)
sh('php', T5 + '/seed.php', app2, db2, '19999')
open(app2 + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'https://lovenails.nailflowapp.com');\n" % db2)
CASES = [['direct on the salon address', {'REMOTE_ADDR': '9.9.9.9', 'HTTP_HOST': 'lovenails.nailflowapp.com'}, True],
         ['through this server\'s proxy (Host = app address, X-Forwarded-Host = salon address)', {'REMOTE_ADDR': '72.167.37.112', 'HTTP_HOST': 'lovenails.american-nails-and-spa.com', 'HTTP_X_FORWARDED_HOST': 'lovenails.nailflowapp.com'}, True],
         ['X-Forwarded-Host sent by an outside client is NOT trusted', {'REMOTE_ADDR': '9.9.9.9', 'HTTP_HOST': 'lovenails.american-nails-and-spa.com', 'HTTP_X_FORWARDED_HOST': 'lovenails.nailflowapp.com'}, False],
         ['the proxy but another forwarded host', {'REMOTE_ADDR': '72.167.37.112', 'HTTP_HOST': 'lovenails.american-nails-and-spa.com', 'HTTP_X_FORWARDED_HOST': 'evil.example'}, False],
         ['a wrong host', {'REMOTE_ADDR': '9.9.9.9', 'HTTP_HOST': 'evil.example'}, False]]
r = sh('php', '-r', php, app2, json.dumps(CASES))
try: res = json.loads(r.stdout)
except Exception: res = []; say('   !! ' + (r.stdout + r.stderr)[-300:])
for name, got, want in res: ok('B2 proxy host: %s -> %s' % (name, 'OK' if want else '403'), got == want, (got, want))
if len(res) != 5: ok('B2 the 5 proxy cases ran', False, r.stdout[-200:] + r.stderr[-200:])
# B3 every choice of /setup/ has an example line
pg = open(A0 + '/setup/index.php', encoding='utf-8').read()
m = re.search(r'const EX = (\{.*?\});\n', pg, re.S); EX = json.loads(m.group(1)) if m else {}
qs = re.search(r'const QS = \(\) => \[(.*?)\n\];', pg, re.S); qsrc = qs.group(1) if qs else ''
need = []
for blk in re.split(r"\n  \{ id: '", qsrc)[1:]:
    qid = blk.split("'")[0]
    if 'num: [' in blk.split('\n')[0] or re.match(r"[^\n]*num: \[", blk): need.append(qid + ':'); continue
    ob = blk.split('extra:')[0]   # the choices only (not the selects of "extra")
    for v in re.findall(r"\[\s*'([^']+)'\s*,\s*V\(", ob): need.append(qid + ':' + v)
miss = [k for k in need if k not in EX or not all(x.strip() for x in EX[k])]
ok('B3 /setup/: %d choices found, each has a "VD:" / "E.g." example (VI + EN)' % len(need), len(need) >= 35 and not miss, 'missing: ' + ' '.join(miss[:15]) + (' (EX table not found)' if not EX else ''))
ok('B3 the examples are shown under each choice (ex() in the option line + the number question)', '${ex(q.id, v)}' in pg and "${ex(q.id, '')}" in pg, 'ex() not used')
logs = ''.join(open(D + '/php%d.log' % k).read() for k in range(len(APIS)))
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
