# LAMWEB test 612 – Telnyx (test) next to SignalWire: fake Telnyx requests (TeXML form posts, AI webhooks JSON) + fake Telnyx API. Test numbers 555-01xx only.
import subprocess, json, os, sys, time, urllib.request, urllib.parse, shutil, atexit, re, datetime as _dt
A = sys.argv[1]; D = '/tmp/claude-0/T612'; T5 = '/tmp/claude-0/T586'; PORT = 19878; DB = D + '/db.sqlite'
R = []; out = open('/tmp/claude-0/T616/test-615-on-' + os.path.basename(sys.argv[1]) + '.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:600]))
import glob
[os.remove(x) for x in glob.glob(D + '/calls/txg-*.json')]
os.makedirs(D + '/calls', exist_ok=True); open(D + '/fake_tx.log', 'w').close()
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SHARED_DIR': T5 + '/shared', 'NF_CALLS_DIR': D + '/calls', 'NF_TX_BASE': 'http://127.0.0.1:19872/v2',
       'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SW_BASE': 'http://127.0.0.1:19870'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(T5 + '/shared/call-ai.json', 'w'))
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']
H = D + '/h612.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/calls-tx.php'; tx_table(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'tok') echo tx_token();
if ($a === 'cfg') echo json_encode(tx_cfg());
if ($a === 'save') { try { echo json_encode(tx_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
if ($a === 'setup') { require_once '%s/inc/calls-agent.php'; require_once '%s/inc/calls-ivr.php'; echo json_encode(tx_setup($argv[2] ?? '')); }
if ($a === 'kp') { $k = sodium_crypto_sign_keypair(); echo json_encode(['pub' => base64_encode(sodium_crypto_sign_publickey($k)), 'sec' => base64_encode(sodium_crypto_sign_secretkey($k))]); }
if ($a === 'sign') { echo base64_encode(sodium_crypto_sign_detached($argv[3] . '|' . file_get_contents($argv[4]), base64_decode($argv[2]))); }
if ($a === 'swtool') { require '%s/call_tx.php.lib'; }
if ($a === 'mk') { [$_, $_, $ph, $name, $date, $start, $staff] = $argv; upsert_customer($ph, $name);
  q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt','',?)", [$date, (int)$start, 45, (int)$staff, '%d', $name, $ph, now_str()]); echo (int)db()->lastInsertId(); }
""" % (A, A, A, A, A, A, S['Pedicure']))
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
ALLDAY = json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)})
h('set', json.dumps({'hours': ALLDAY, 'call_owner': '5155550177', 'call_fwd': '+15155550176', 'salon_name': 'AMERICAN NAILS AND SPA', 'call_on': '1'}))
TOK = h('tok')
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.2)
fk = subprocess.Popen(['python3', T5 + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ft = subprocess.Popen(['python3', D + '/fake_tx.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
atexit.register(lambda: (sv.terminate(), fk.terminate(), ft.terminate())); time.sleep(0.8)
B = 'http://127.0.0.1:%d/call_tx.php' % PORT
SIGN = None
def req(a, body, form=False, tok=None, extra='', hdr=None, sign=True):
    raw = urllib.parse.urlencode(body).encode() if form else json.dumps(body).encode()
    hd = {'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json', **(hdr or {})}
    if SIGN and sign and 'telnyx-signature-ed25519' not in hd:
        ts = str(int(time.time())); open(D + '/.b', 'wb').write(raw); hd['telnyx-timestamp'] = ts; hd['telnyx-signature-ed25519'] = h('sign', SIGN, ts, D + '/.b')
    u = B + '?a=' + a + '&t=' + (TOK if tok is None else tok) + extra
    try: r = urllib.request.urlopen(urllib.request.Request(u, data=raw, headers=hd), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, ''
def row(cid): x = sql("SELECT * FROM calls WHERE call_sid = '%s'" % cid); return x[0] if x else {}
_t = _dt.date.today(); TOM = (_t + _dt.timedelta(days=1)).isoformat()
say('== LAMWEB test 615 (setup) 2.99.612 – LENH 612 Telnyx (test) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake Telnyx (docs shapes: TeXML form posts, assistant webhooks JSON, REST /v2) · nothing real called')
# 0 settings
r = h('save', json.dumps({'key': 'KEY0123456789abcdefTEST_tx_key_99', 'number': '(515) 513-6667', 'on': True}))
ok('0 Settings: key saved encrypted, shown only "…y_99" (never the key)', r.get('keySet') and r.get('keyTail') == 'y_99' and 'KEY0123' not in json.dumps(r) and 'KEY0123' not in json.dumps(sql("SELECT v FROM settings WHERE k = 'tx_key'")), r)
r = h('save', json.dumps({'pub': 'not-a-key'})); ok('0 a wrong Public Key → a clear error', 'Public Key' in r.get('err', ''), r)
r = h('save', json.dumps({'number': '123'})); ok('0 a wrong number → error', 'digits' in r.get('err', ''), r)
# 1 setup against the fake Telnyx API
st = h('setup'); ok('1 "Set up automatically" (TELNYX-API-612 order): key checked (GET /phone_numbers?filter[phone_number]=15155136667, no +) · outbound voice profile (none → created) · TeXML Application · number put on it · AI assistant – each step OK', isinstance(st, list) and [x['t'] for x in st] == ['API key', 'Outbound voice profile', 'TeXML Application', 'Number +15155136667', 'AI assistant'] and all(x['ok'] for x in st), st)
ab = json.load(open(D + '/last-_v__ai_assistants.json'))
ins = ab.get('instructions', '')
ok('1 assistant: the SAME prompt as SignalWire (cl_agent_prompt) with the facts as {{now}} {{days}} {{menu}} {{techs}} {{caller_name}} {{upcoming}}; no "ALREADY played" line; greeting "Thank you for calling American Nails And Spa. Sorry we missed you – how can I help?"',
   all(v in ins for v in ['{{now}}', '{{days}}', '{{menu}}', '{{techs}}', '{{caller_name}}', '{{upcoming}}', 'Never say a price', 'find_appointments']) and 'ALREADY' not in ins and ab.get('greeting') == 'Thank you for calling American Nails And Spa. Sorry we missed you – how can I help?', (ins[:300], ab.get('greeting')))
tl = ab.get('tools', []); wh = [t['webhook']['name'] for t in tl if t['type'] == 'webhook']
ok('1 (616 doi y) tools: 10 webhook tools (cl_agent_ai + transfer_owner CUA MINH) + hangup, KHONG co transfer Telnyx', wh == ['find_appointments', 'check_times', 'book', 'cancel', 'move', 'add_person', 'change_services', 'late', 'add_note', 'transfer_owner']
   and not any(t['type'] == 'transfer' for t in tl) and any(t['type'] == 'hangup' for t in tl), wh)
w0 = [t for t in tl if t['type'] == 'webhook' and t['webhook']['name'] == 'book'][0]['webhook']
ok('1 tool URL = call_tx.php?a=tool&t=<secret>&fn=book, POST, body = the same JSON schema, preset_query_params {"ccid": "{{call_control_id}}"} (the AI cannot change it), timeout 8 s', w0['url'].endswith('a=tool&t=' + TOK + '&fn=book') and w0['method'] == 'POST' and 'persons' in w0['body_parameters']['properties'] and w0.get('preset_query_params') == {'ccid': '{{call_control_id}}'} and [t for t in tl if t['type'] == 'webhook'][0]['timeout_ms'] == 8000, w0)
ok('1 assistant settings (CHAT F/G): model zai-org/GLM-5.3-Flash · voice = Maeve from GET /v2/text-to-speech/voices (no voice set; kept in tx_voice) · STT deepgram/flux en + keyterms (services, techs) · 300 s · idle 30 s · krisp · its own recording ON (2.99.646 anh Logan 05/11: the AI part is recorded as proof) · data_retention on · barge-in (not the greeting) · vars webhook a=vars 4000 ms + defaults "(no data)"',
   ab.get('model') == 'zai-org/GLM-5.3-Flash' and ab['voice_settings']['voice'] == 'Telnyx.Ultra.02a924f6-1111-2222-3333-444455556666' and ab['transcription']['model'] == 'deepgram/flux' and 'pedicure' in ab['transcription']['settings']['keyterm'] and 'tammy' in ab['transcription']['settings']['keyterm']
   and ab['telephony_settings'] == {'time_limit_secs': 300, 'noise_suppression': 'krisp', 'user_idle_timeout_secs': 30, 'recording_settings': {'enabled': True, 'channels': 'dual', 'format': 'mp3'}} and ab['privacy_settings'] == {'data_retention': True}
   and ab['interruption_settings'] == {'enable': True, 'disable_greeting_interruption': True} and ab.get('dynamic_variables_webhook_url', '').endswith('a=vars&t=' + TOK) and ab.get('dynamic_variables_webhook_timeout_ms') == 4000 and ab['dynamic_variables']['days'] == '(no data)', {k: ab.get(k) for k in ['model', 'voice_settings', 'transcription', 'telephony_settings', 'privacy_settings']})
ap = json.load(open(D + '/last-_v__texml_applications.json'))
ok('1 TeXML Application: Voice URL = call_tx.php?a=in&t=<secret> POST + outbound_voice_profile_id (the Dial to the iPhone is an outbound call)', ap.get('voice_url', '').endswith('/call_tx.php?a=in&t=' + TOK) and ap.get('voice_method') == 'post' and ap.get('outbound') == {'outbound_voice_profile_id': 'OVP-1'}, ap)
fl = open(D + '/fake_tx.log').read(); ok('1 the number got the application (PATCH /phone_numbers/PN-1 connection_id APP-1)', 'PATCH /v2/phone_numbers/PN-1 {"connection_id": "APP-1"}' in fl, fl[-400:])
st = h('setup', 'ai'); ok('1 "Update AI" → POST /ai/assistants/assistant-test-1 (update, not a new one)', len(st) == 1 and st[0]['ok'] and 'updated assistant-test-1' in st[0]['msg'], st)
ok('1 (2.99.613) the voice picked once is kept (setting tx_voice), not asked again', 'GET /v2/text-to-speech/voices' in open(D + '/fake_tx.log').read() and open(D + '/fake_tx.log').read().count('GET /v2/text-to-speech/voices') == 1, open(D + '/fake_tx.log').read().count('GET /v2/text-to-speech/voices'))

import threading
def call(sid, frm):
    req('in', {'CallSid': sid, 'From': frm, 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True, sign=False, hdr={'X-Dummy': '1'})
    req('after', {'CallSid': sid, 'DialCallStatus': 'no-answer'}, form=True, extra='&sid=' + urllib.parse.quote(sid))
def tool(sid, fn, **args):
    c, x = req('tool', args, extra='&fn=' + fn + '&ccid=' + urllib.parse.quote(sid))
    try: return json.loads(x).get('result', '')
    except Exception: return x
def booked(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, status FROM appointments WHERE phone = '%s' AND status = 'booked' ORDER BY id" % ph)
TA, HA, SI = seed['T']['TAMMY'], seed['T']['HANA'], seed['T']['SISI']; GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
D3 = (_dt.date.today() + _dt.timedelta(days=3)).isoformat()
SIGN = None
say('== LENH-615 KIEM TELNYX (chi kiem, mo phong) – ban ' + os.path.basename(A) + ' · fake Telnyx · 3 tho TAMMY/HANA/SISI, 3 dich vu')
# 1 groups / full
call('v3:K1', '+15555550121')
r = tool('v3:K1', 'check_times', date=D3, time='14:00', persons=[{'name': 'A', 'service_ids': [PD], 'tech_id': 0}, {'name': 'B', 'service_ids': [PD], 'tech_id': 0}])
ok('1a check_times 2 nguoi Any tech 2:00 PM (con 3 tho) -> OPEN', r.startswith('OPEN'), r)
r = tool('v3:K1', 'book', name='An', date=D3, time='14:00', persons=[{'name': 'An', 'service_ids': [PD], 'tech_id': 0}, {'name': 'Binh', 'service_ids': [PD], 'tech_id': 0}])
b = booked('+15555550121'); ok('1b book 2 nguoi Any tech -> 2 hen cung gio', len(b) == 2 and len({x['start_min'] for x in b}) == 1, (r, b))
call('v3:K2', '+15555550122')
r = tool('v3:K2', 'book', name='Chi', date=D3, time='14:00', persons=[{'name': 'Chi', 'service_ids': [PD], 'tech_id': TA}, {'name': 'Dao', 'service_ids': [PD], 'tech_id': HA}])
b2 = booked('+15555550122'); ok('1c 2 nguoi 2 tho khac nhau (TAMMY, HANA) cung 2:00 PM nhung 3 tho chi con 1 cho -> KHONG dat, de nghi gio khac', not b2 and ('FULL' in r or 'NOT' in r or 'taken' in r.lower() or 'Offer' in r or 'offer' in r), (r, b2))
r = tool('v3:K2', 'check_times', date=D3, time='14:00', persons=[{'name': 'Chi', 'service_ids': [PD], 'tech_id': 0}, {'name': 'Dao', 'service_ids': [PD], 'tech_id': 0}])
import re as _re2; times = _re2.findall(r'\d{1,2}:\d{2}', r)
ok('1d het tho luc 2:00 PM -> tra 2 gio khac (khong dat sai)', not r.startswith('OPEN') and len(times) >= 2, r)
# 2 specific tech busy / skill
sh('php', '-r', "require '%s/inc/core.php'; settings(); q(\"UPDATE staff SET skills = '%d,%d' WHERE id = %d\");" % (A, GM, PD, TA))
call('v3:K3', '+15555550123')
r = tool('v3:K3', 'check_times', date=D3, time='10:00', persons=[{'name': 'E', 'service_ids': [FS], 'tech_id': TA}])
ok('2a xin TAMMY lam Full Set (co ay khong lam – skills) -> khong OPEN, ly do + de nghi', not r.startswith('OPEN'), r)
r2 = tool('v3:K3', 'book', name='E', date=D3, time='10:00', persons=[{'name': 'E', 'service_ids': [FS], 'tech_id': TA}])
ok('2b book van bi tu choi (khong dat cho TAMMY)', not booked('+15555550123'), r2)
r = tool('v3:K3', 'check_times', date=seed['d1'], time='16:00', persons=[{'name': 'E', 'service_ids': [PD], 'tech_id': SI}])
ok('2c xin SISI ngay mai 4:00 PM (SISI ban – da co hen ROSA 4–5 PM) -> khong OPEN + gio khac', not r.startswith('OPEN') and len(_re2.findall(r'\d{1,2}:\d{2}', r)) >= 1, r)
sh('php', '-r', "require '%s/inc/core.php'; settings(); q(\"UPDATE staff SET skills = ''\");" % A)
# 3 duplicate appointments cancel by appt_id
ids = []
for k in range(2): ids.append(int(sh('php', '-r', "require '%s/inc/core.php'; settings(); q(\"INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES ('%s', 900, 45, %d, '%d', 'GIA', '+15555550124', 'booked', 'admin', 'appt', '', '%s')\"); echo db()->lastInsertId();" % (A, D3, [TA, HA][k], PD, time.strftime('%%Y-%%m-%%d %%H:%%M:%%S'))).stdout))
call('v3:K4', '+15555550124'); fa = tool('v3:K4', 'find_appointments')
r = tool('v3:K4', 'cancel', appt_id=ids[1], said_date=D3, said_time='15:00')
st = {x['id']: x['status'] for x in sql("SELECT id, status FROM appointments WHERE phone = '+15555550124'")}
ok('3a 2 hen giong het (cung ngay + 3:00 PM) -> huy appt_id %d: CANCELLED dung hen do, hen kia giu' % ids[1], r.startswith('CANCELLED') and st[ids[1]] == 'cancelled' and st[ids[0]] == 'booked', (r, st))
r = tool('v3:K4', 'cancel', appt_id=ids[0], said_date=D3, said_time='15:00'); st = {x['id']: x['status'] for x in sql("SELECT id, status FROM appointments WHERE phone = '+15555550124'")}
ok('3b huy not hen con lai -> CANCELLED, khong lap', r.startswith('CANCELLED') and st[ids[0]] == 'cancelled', (r, st))
# 4 transfer target
ab = json.load(open('/tmp/claude-0/T612/last-_v__ai_assistants.json')); tr = [t for t in ab['tools'] if t['type'] == 'transfer']
wt0 = [t for t in ab['tools'] if t['type'] == 'webhook' and t['webhook']['name'] == 'transfer_owner']
ok('4a (616) transfer = tool transfer_owner CUA MINH (khong con transfer Telnyx); so nhan = "Owner phone for questions" (+15155550177) luc goi', not tr and wt0, [t['type'] for t in ab['tools']])
h('set', json.dumps({'call_owner': ''})); st1 = h('setup', 'ai'); import glob as _g; fs = sorted(_g.glob('/tmp/claude-0/T612/last-_v__ai_assistants_assistant*.json'), key=os.path.getmtime); ab = json.load(open(fs[-1])) if fs else {}
tr = [t for t in ab.get('tools', []) if t['type'] == 'transfer']
wt = [t for t in ab.get('tools', []) if t['type'] == 'webhook' and t['webhook']['name'] == 'transfer_owner']
ok('4b (616) "Owner phone" de trong -> KHONG co transfer ve iPhone (+15155550176); thay bang tool transfer_owner cua minh', not tr and wt and 'fn=transfer_owner' in wt[0]['webhook']['url'], (tr, [w['webhook']['url'][-40:] for w in wt]))
call('v3:K4b', '+15555550129'); r = tool('v3:K4b', 'transfer_owner'); pl = open(D + '/php.log').read()
ok('4c (616) transfer_owner khi khong co ai -> AI noi "The salon will call you back soon" + hangup; push "Call back" cho chu', 'call you back' in r and 'hang up' in r, r)
c, x = req('aiend', {'CallSid': 'v3:K4b', 'Reason': 'service_error'}, form=True, extra='&sid=v3%3AK4b')
ok('4d (616) aiend loi + khong co ai -> <Say> salon will call you back + Hangup (khong Dial iPhone)', 'call you back' in x and '<Dial' not in x, x)
h('set', json.dumps({'call_owner': '5155550177'}))
# 5 guard + duplicate booking + race
call('v3:K5', '+15555550125'); args = dict(name='Gia', date=D3, time='11:00', persons=[{'name': 'Gia', 'service_ids': [GM], 'tech_id': 0}])
r1 = tool('v3:K5', 'book', **args); r2 = tool('v3:K5', 'book', **args); r3 = tool('v3:K5', 'book', **args)
ok('5a book 2 lan cung tham so -> 1 hen (lan 2 ALREADY_HAS / da co), lan 3 -> tx_guard "STOP… transfer"', len(booked('+15555550125')) == 1 and 'STOP' in r3, (r1[:60], r2[:80], r3[:60], booked('+15555550125')))
call('v3:K6', '+15555550126'); a6 = dict(name='Hoa', date=D3, time='12:00', persons=[{'name': 'Hoa', 'service_ids': [GM], 'tech_id': 0}], new_ok=True)
r1 = tool('v3:K6', 'book', **a6); r2 = tool('v3:K6', 'book', **a6)
n6 = len(booked('+15555550126'))
ok('5b book new_ok=true 2 lan cung tham so -> CHI 1 hen (khong nhan doi)', n6 == 1, (n6, r1[:80], r2[:80]))
call('v3:K7', '+15555550127'); call('v3:K8', '+15555550127'); a7 = dict(name='Lan', date=D3, time='17:00', persons=[{'name': 'Lan', 'service_ids': [GM], 'tech_id': 0}], new_ok=True)
res = [None, None]; ev = threading.Event()
def go(i, sid): ev.wait(); res[i] = tool(sid, 'book', **a7)
th = [threading.Thread(target=go, args=(0, 'v3:K7')), threading.Thread(target=go, args=(1, 'v3:K8'))]; [t.start() for t in th]; time.sleep(0.3); ev.set(); [t.join() for t in th]
n7 = len(booked('+15555550127'))
ok('5c 2 cuoc goi song song CUNG so CUNG gio (race, new_ok) -> 1 hen', n7 == 1, (n7, [x[:70] for x in res]))
call('v3:K9', '+15555550128'); call('v3:K10', '+15555550128'); a9 = dict(name='My', date=D3, time='18:00', persons=[{'name': 'My', 'service_ids': [GM], 'tech_id': 0}])
res = [None, None]; ev = threading.Event()
def go2(i, sid): ev.wait(); res[i] = tool(sid, 'book', **a9)
th = [threading.Thread(target=go2, args=(0, 'v3:K9')), threading.Thread(target=go2, args=(1, 'v3:K10'))]; [t.start() for t in th]; time.sleep(0.3); ev.set(); [t.join() for t in th]
n9 = len(booked('+15555550128'))
ok('5d 2 cuoc goi song song CUNG so CUNG gio, KHONG new_ok (race) -> 1 hen', n9 == 1, (n9, [x[:70] for x in res]))

# 8 DB double booking: 2 processes in parallel, 2 DIFFERENT callers, the SAME tech + the SAME time (10 rounds) + Any tech with 1 tech left (5 rounds)
D4 = (_dt.date.today() + _dt.timedelta(days=4)).isoformat(); bad = []; refused = 0
for k in range(10):
    hh = '%02d:00' % (9 + k); sa, sb = 'v3:R%da' % k, 'v3:R%db' % k; pa, pb = '+155555501%02d' % (40 + k), '+155555501%02d' % (60 + k)
    call(sa, pa); call(sb, pb); res = [None, None]; ev = threading.Event()
    def g8(i, sid, nm): ev.wait(); res[i] = tool(sid, 'book', name=nm, date=D4, time=hh, persons=[{'name': nm, 'service_ids': [GM], 'tech_id': SI}])
    th = [threading.Thread(target=g8, args=(0, sa, 'Xa%d' % k)), threading.Thread(target=g8, args=(1, sb, 'Xb%d' % k))]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
    n = sql("SELECT COUNT(*) AS n FROM appointments WHERE appt_date = '%s' AND start_min = %d AND staff_id = %d AND status = 'booked'" % (D4, (9 + k) * 60, SI))[0]['n']
    if int(n) != 1: bad.append((hh, n, [x[:60] for x in res]))
    refused += sum(1 for x in res if not x.startswith('BOOKED'))
ok('8a 2 tien trinh song song, 2 khach KHAC so, CUNG tho SISI + CUNG gio x10 vong -> moi gio dung 1 hen, khach kia bi tu choi', not bad and refused == 10, (bad, refused))
D5 = (_dt.date.today() + _dt.timedelta(days=5)).isoformat(); bad = []
for k in range(5):
    sm = (10 + 2 * k) * 60; hh = '%02d:00' % (10 + 2 * k)
    for st_ in (TA, HA): sh('php', '-r', "require '%s/inc/core.php'; settings(); q(\"INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES ('%s', %d, 60, %d, '%d', 'BLK', '+15555550199', 'booked', 'admin', 'appt', 0, datetime('now'))\");" % (A, D5, sm, st_, GM))
    sa, sb = 'v3:Q%da' % k, 'v3:Q%db' % k; call(sa, '+155555501%02d' % (70 + k)); call(sb, '+155555501%02d' % (80 + k)); res = [None, None]; ev = threading.Event()
    def g9(i, sid, nm): ev.wait(); res[i] = tool(sid, 'book', name=nm, date=D5, time=hh, persons=[{'name': nm, 'service_ids': [GM], 'tech_id': 0}])
    th = [threading.Thread(target=g9, args=(0, sa, 'Ya%d' % k)), threading.Thread(target=g9, args=(1, sb, 'Yb%d' % k))]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
    n = sql("SELECT COUNT(*) AS n FROM appointments WHERE appt_date = '%s' AND start_min = %d AND phone <> '+15555550199' AND status = 'booked'" % (D5, sm))[0]['n']
    if int(n) != 1: bad.append((hh, n, [x[:60] for x in res]))
ok('8b Any tech, chi con 1 tho trong, 2 khach song song x5 vong -> dung 1 hen moi gio', not bad, bad)
say('PASS %d/%d' % (sum(R), len(R)))
