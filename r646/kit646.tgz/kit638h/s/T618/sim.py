# LAMWEB test 612 – Telnyx (test) next to SignalWire: fake Telnyx requests (TeXML form posts, AI webhooks JSON) + fake Telnyx API. Test numbers 555-01xx only.
import subprocess, json, os, sys, time, urllib.request, urllib.parse, shutil, atexit, re, datetime as _dt
A = sys.argv[1]; D = '/tmp/claude-0/T612'; T5 = '/tmp/claude-0/T586'; PORT = 19877; DB = D + '/db.sqlite'
R = []; out = open('/tmp/claude-0/T618/test-618-sim.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:600]))
import glob
[os.remove(x) for x in glob.glob(D + '/calls/txg-*.json')]
os.makedirs(D + '/calls', exist_ok=True); open(D + '/fake_tx.log', 'w').close()
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SHARED_DIR': T5 + '/shared', 'NF_CALLS_DIR': D + '/calls', 'NF_TX_BASE': 'http://127.0.0.1:19872/v2',
       'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SW_BASE': 'http://127.0.0.1:19870'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(T5 + '/shared/call-ai.json', 'w'))
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']
H = D + '/h612.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/calls-tx.php'; tx_table(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'tok') echo tx_token();
if ($a === 'cfg') echo json_encode(tx_cfg());
if ($a === 'save') { try { echo json_encode(tx_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
if ($a === 'setup') { require_once '%s/inc/calls-agent.php'; require_once '%s/inc/calls-ivr.php'; echo json_encode(tx_setup($argv[2] ?? '')); }
if ($a === 'kp') { $k = sodium_crypto_sign_keypair(); echo json_encode(['pub' => base64_encode(sodium_crypto_sign_publickey($k)), 'sec' => base64_encode(sodium_crypto_sign_secretkey($k))]); }
if ($a === 'sign') { echo base64_encode(sodium_crypto_sign_detached($argv[3] . '|' . file_get_contents($argv[4]), base64_decode($argv[2]))); }
if ($a === 'swtool') { require '%s/call_tx.php.lib'; }
if ($a === 'mk') { [$_, $_, $ph, $name, $date, $start, $staff] = $argv; upsert_customer($ph, $name);
  q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt','',?)", [$date, (int)$start, 45, (int)$staff, '%d', $name, $ph, now_str()]); echo (int)db()->lastInsertId(); }
""" % (A, A, A, A, A, A, S['Pedicure']))
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
ALLDAY = json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)})
h('set', json.dumps({'hours': ALLDAY, 'call_owner': '5155550177', 'call_fwd': '+15155550176', 'salon_name': 'AMERICAN NAILS AND SPA', 'call_on': '1'}))
TOK = h('tok')
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.2)
fk = subprocess.Popen(['python3', T5 + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
ft = subprocess.Popen(['python3', D + '/fake_tx.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
atexit.register(lambda: (sv.terminate(), fk.terminate(), ft.terminate())); time.sleep(0.8)
B = 'http://127.0.0.1:%d/call_tx.php' % PORT
SIGN = None
def req(a, body, form=False, tok=None, extra='', hdr=None, sign=True):
    raw = urllib.parse.urlencode(body).encode() if form else json.dumps(body).encode()
    hd = {'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json', **(hdr or {})}
    if SIGN and sign and 'telnyx-signature-ed25519' not in hd:
        ts = str(int(time.time())); open(D + '/.b', 'wb').write(raw); hd['telnyx-timestamp'] = ts; hd['telnyx-signature-ed25519'] = h('sign', SIGN, ts, D + '/.b')
    u = B + '?a=' + a + '&t=' + (TOK if tok is None else tok) + extra
    try: r = urllib.request.urlopen(urllib.request.Request(u, data=raw, headers=hd), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, ''
def row(cid): x = sql("SELECT * FROM calls WHERE call_sid = '%s'" % cid); return x[0] if x else {}
_t = _dt.date.today(); TOM = (_t + _dt.timedelta(days=1)).isoformat()
say('== LAMWEB test 2.99.612 – LENH 612 Telnyx (test) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake Telnyx (docs shapes: TeXML form posts, assistant webhooks JSON, REST /v2) · nothing real called')
# 0 settings
r = h('save', json.dumps({'key': 'KEY0123456789abcdefTEST_tx_key_99', 'number': '(515) 513-6667', 'on': True}))
ok('0 Settings: key saved encrypted, shown only "…y_99" (never the key)', r.get('keySet') and r.get('keyTail') == 'y_99' and 'KEY0123' not in json.dumps(r) and 'KEY0123' not in json.dumps(sql("SELECT v FROM settings WHERE k = 'tx_key'")), r)
r = h('save', json.dumps({'pub': 'not-a-key'})); ok('0 a wrong Public Key → a clear error', 'Public Key' in r.get('err', ''), r)
r = h('save', json.dumps({'number': '123'})); ok('0 a wrong number → error', 'digits' in r.get('err', ''), r)
# 1 setup against the fake Telnyx API
st = h('setup'); ok('1 "Set up automatically" (TELNYX-API-612 order): key checked (GET /phone_numbers?filter[phone_number]=15155136667, no +) · outbound voice profile (none → created) · TeXML Application · number put on it · AI assistant – each step OK', isinstance(st, list) and [x['t'] for x in st] == ['API key', 'Outbound voice profile', 'TeXML Application', 'Number +15155136667', 'AI assistant'] and all(x['ok'] for x in st), st)
ab = json.load(open(D + '/last-_v__ai_assistants.json'))
ins = ab.get('instructions', '')
ok('1 assistant: the SAME prompt as SignalWire (cl_agent_prompt) with the facts as {{now}} {{days}} {{menu}} {{techs}} {{caller_name}} {{upcoming}}; no "ALREADY played" line; greeting "Thank you for calling American Nails And Spa. Sorry we missed you – how can I help?"',
   all(v in ins for v in ['{{now}}', '{{days}}', '{{menu}}', '{{techs}}', '{{caller_name}}', '{{upcoming}}', 'Never say a price', 'find_appointments']) and 'ALREADY' not in ins and ab.get('greeting') == 'Thank you for calling American Nails And Spa. Sorry we missed you – how can I help?', (ins[:300], ab.get('greeting')))
tl = ab.get('tools', []); wh = [t['webhook']['name'] for t in tl if t['type'] == 'webhook']
ok('1 (616) tools: 10 webhook (cl_agent_ai + transfer_owner cua minh) + hangup, khong transfer Telnyx', wh == ['find_appointments', 'check_times', 'book', 'cancel', 'move', 'add_person', 'change_services', 'late', 'add_note', 'transfer_owner'] and not any(t['type'] == 'transfer' for t in tl), wh)
w0 = [t for t in tl if t['type'] == 'webhook' and t['webhook']['name'] == 'book'][0]['webhook']
ok('1 tool URL = call_tx.php?a=tool&t=<secret>&fn=book, POST, body = the same JSON schema, preset_query_params {"ccid": "{{call_control_id}}"} (the AI cannot change it), timeout 8 s', w0['url'].endswith('a=tool&t=' + TOK + '&fn=book') and w0['method'] == 'POST' and 'persons' in w0['body_parameters']['properties'] and w0.get('preset_query_params') == {'ccid': '{{call_control_id}}'} and [t for t in tl if t['type'] == 'webhook'][0]['timeout_ms'] == 8000, w0)
ok('1 assistant settings (CHAT F/G): model zai-org/GLM-5.3-Flash · voice = Maeve from GET /v2/text-to-speech/voices (no voice set; kept in tx_voice) · STT deepgram/flux en + keyterms (services, techs) · 300 s · idle 30 s · krisp · its own recording ON (2.99.646 anh Logan 05/11: the AI part is recorded as proof) · data_retention on · barge-in (not the greeting) · vars webhook a=vars 4000 ms + defaults "(no data)"',
   ab.get('model') == 'zai-org/GLM-5.3-Flash' and ab['voice_settings']['voice'] == 'Telnyx.Ultra.02a924f6-1111-2222-3333-444455556666' and ab['transcription']['model'] == 'deepgram/flux' and 'pedicure' in ab['transcription']['settings']['keyterm'] and 'tammy' in ab['transcription']['settings']['keyterm']
   and ab['telephony_settings'] == {'time_limit_secs': 300, 'noise_suppression': 'krisp', 'user_idle_timeout_secs': 30, 'recording_settings': {'enabled': True, 'channels': 'dual', 'format': 'mp3'}} and ab['privacy_settings'] == {'data_retention': True}
   and ab['interruption_settings'] == {'enable': True, 'disable_greeting_interruption': True} and ab.get('dynamic_variables_webhook_url', '').endswith('a=vars&t=' + TOK) and ab.get('dynamic_variables_webhook_timeout_ms') == 4000 and ab['dynamic_variables']['days'] == '(no data)', {k: ab.get(k) for k in ['model', 'voice_settings', 'transcription', 'telephony_settings', 'privacy_settings']})
ap = json.load(open(D + '/last-_v__texml_applications.json'))
ok('1 TeXML Application: Voice URL = call_tx.php?a=in&t=<secret> POST + outbound_voice_profile_id (the Dial to the iPhone is an outbound call)', ap.get('voice_url', '').endswith('/call_tx.php?a=in&t=' + TOK) and ap.get('voice_method') == 'post' and ap.get('outbound') == {'outbound_voice_profile_id': 'OVP-1'}, ap)
fl = open(D + '/fake_tx.log').read(); ok('1 the number got the application (PATCH /phone_numbers/PN-1 connection_id APP-1)', 'PATCH /v2/phone_numbers/PN-1 {"connection_id": "APP-1"}' in fl, fl[-400:])
st = h('setup', 'ai'); ok('1 "Update AI" → POST /ai/assistants/assistant-test-1 (update, not a new one)', len(st) == 1 and st[0]['ok'] and 'updated assistant-test-1' in st[0]['msg'], st)
ok('1 (2.99.613) the voice picked once is kept (setting tx_voice), not asked again', 'GET /v2/text-to-speech/voices' in open(D + '/fake_tx.log').read() and open(D + '/fake_tx.log').read().count('GET /v2/text-to-speech/voices') == 1, open(D + '/fake_tx.log').read().count('GET /v2/text-to-speech/voices'))
# 2 security
c, _ = req('in', {'CallSid': 'v3:X', 'From': '+15555550101'}, form=True, tok='wrong'); ok('2 a wrong secret → 403', c == 403, c)
kp = h('kp'); h('save', json.dumps({'pub': kp['pub']})); SIGN = kp['sec']
c, _ = req('status', {'CallSid': 'v3:S'}, form=True); ok('2 Public Key pasted: a correctly signed request (Ed25519 over "timestamp|body") → 200', c == 200, c)
c, _ = req('status', {'CallSid': 'v3:S'}, form=True, hdr={'telnyx-timestamp': str(int(time.time())), 'telnyx-signature-ed25519': 'A' * 88}); ok('2 a wrong signature → 403', c == 403, c)
ts = str(int(time.time()) - 400); open(D + '/.b', 'wb').write(b'CallSid=v3%3AS'); sg = h('sign', SIGN, ts, D + '/.b')
c, _ = req('status', {'CallSid': 'v3:S'}, form=True, hdr={'telnyx-timestamp': ts, 'telnyx-signature-ed25519': sg}); ok('2 a signature older than 5 minutes → 403', c == 403, c)
c, _ = req('status', {'CallSid': 'v3:S', 'ConnectionId': 'APP-1'}, form=True, sign=False); ok('2 no signature header (Telnyx may not sign the TeXML fetch): the secret + ConnectionId = our app → allowed (logged)', c == 200, c)
c, _ = req('status', {'CallSid': 'v3:S', 'ConnectionId': 'OTHER'}, form=True, sign=False); ok('2 no signature + another ConnectionId → 403', c == 403, c)
h('set', json.dumps({'tx_sig_strict': '1'})); c, _ = req('status', {'CallSid': 'v3:S'}, form=True, sign=False); h('set', json.dumps({'tx_sig_strict': '0'})); ok('2 tx_sig_strict = 1: no signature → 403', c == 403, c)
ok('2 the Public Key is kept encrypted too', 'Public' not in json.dumps(sql("SELECT v FROM settings WHERE k = 'tx_pub'")) and kp['pub'] not in json.dumps(sql("SELECT v FROM settings WHERE k = 'tx_pub'")), '')
# ===== LENH-618 BO SUNG: AI CALL SIMULATOR (LAMWEB) =====
# Calls the REAL endpoints of call_tx.php (no function mocked) with Telnyx-shaped payloads (TeXML form posts + AI webhook JSON), signed with a TEST
# Ed25519 key, one Call ID per call, a multi-turn conversation = the chain of tool calls a real model makes, the transcript served by the fake Telnyx API.
# Every check reads the DB (appointments / calls / customers / autosend / push_log) itself - never the app's "OK".
import threading, glob, hashlib, statistics, resource
RES = []   # (no, title, verdict, layer, evidence)
def V(no, title, verdict, layer, ev=''):
    mk_ = {'PASS': '✓', 'FAIL': '✗'}.get(verdict, '•'); RES.append((no, title, verdict, layer, str(ev)[:300]))
    say('%s %s [%s] %s%s%s' % (mk_, no, layer, verdict + ' · ' if mk_ == '•' else '', title, ('   → ' + str(ev)[:260]) if verdict != 'PASS' else ''))
    if verdict in ('PASS', 'FAIL'): R.append(verdict == 'PASS')
def xs(s): return urllib.parse.quote(s, safe='')
os.makedirs(D + '/conv', exist_ok=True)
def conv(sid, turns):  # the transcript Telnyx keeps for this call (user / assistant turns, 4 s apart)
    k = hashlib.sha1(sid.encode()).hexdigest()[:16]; t0 = time.time() - 10 * len(turns)
    json.dump([{'role': r, 'text': t, 'sent_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(t0 + 4 * i))} for i, (r, t) in enumerate(turns)], open(D + '/conv/' + k + '.json', 'w'))
def start(sid, frm, ring='no-answer'):
    c1, x1 = req('in', {'CallSid': sid, 'From': frm, 'To': '+15155136667', 'AccountSid': 'ACC1', 'ConnectionId': 'APP-1'}, form=True)
    c2, x2 = req('after', {'CallSid': sid, 'DialCallStatus': ring, 'AccountSid': 'ACC1'}, form=True, extra='&sid=' + xs(sid)); return x1, x2
def tvars(sid, frm):
    c, x = req('vars', {'data': {'event_type': 'assistant.initialization', 'payload': {'call_control_id': sid, 'telnyx_end_user_target': frm, 'telnyx_agent_target': '+15155136667'}}})
    try: return json.loads(x).get('dynamic_variables', {})
    except Exception: return {}
def tool(sid, fn, **a):
    c, x = req('tool', a, extra='&fn=' + fn + '&ccid=' + xs(sid))
    try: return json.loads(x).get('result', '')
    except Exception: return 'HTTP %s %s' % (c, x[:80])
def end(sid, reason='hangup'): return req('aiend', {'CallSid': sid, 'Reason': reason}, form=True, extra='&sid=' + xs(sid))[1]
def appts(ph, st='booked'): return sql("SELECT id, appt_date, start_min, duration, staff_id, service_ids, customer_name, status, source, group_id FROM appointments WHERE phone = '%s' AND status = '%s' ORDER BY id" % (ph, st))
def crow(sid): return row(sid)
def outbox(ph): return sql("SELECT kind, body FROM autosend WHERE phone = '%s' ORDER BY id" % ph) if sql("SELECT name FROM sqlite_master WHERE name='autosend'") else []
open(D + '/set618.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'call_tb_on' => '1', 'tx_on' => '1'] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set618.php')
open(D + '/tick618.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner']; cl_tick(); echo 'ticked';" % (A, A, A, A))
def tick(): return sh('php', D + '/tick618.php')
h('set', json.dumps({'call_owner': '5155550177', 'call_fwd': '+15155550176'})); h('setup', 'ai')
TA, HA, SI = seed['T']['TAMMY'], seed['T']['HANA'], seed['T']['SISI']; GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
DAY = lambda n: (_dt.date.today() + _dt.timedelta(days=n)).isoformat()
say('== LENH-618 AI CALL SIMULATOR – 20 tinh huong (INTEGRATION = endpoint call_tx.php that + fake Telnyx; khong goi / SMS that) ' + time.strftime('%H:%M %Z'))
P = lambda n: '+1515555%04d' % n   # (515) 555-01xx / 02xx test numbers
# 1 new customer
s, ph = 'v3:S01', P(201); x1, x2 = start(s, ph); v = tvars(s, ph)
r1 = tool(s, 'find_appointments'); r2 = tool(s, 'check_times', date=DAY(2), time='10:00', persons=[{'name': 'Nora', 'service_ids': [PD], 'tech_id': 0}])
r3 = tool(s, 'book', name='Nora Test', date=DAY(2), time='10:00', persons=[{'name': 'Nora Test', 'service_ids': [PD], 'tech_id': 0}])
conv(s, [('assistant', 'Thank you for calling. How can I help?'), ('user', 'I want a pedicure the day after tomorrow at 10'), ('assistant', "You're all set!")]); end(s); time.sleep(0.3)
a = appts(ph); cu = sql("SELECT name FROM customers WHERE phone = '%s'" % ph); cr = crow(s)
V('01', 'Khach moi dat lich', 'PASS' if v.get('caller_name') == 'none' and r3.startswith('BOOKED') and len(a) == 1 and a[0]['start_min'] == 600 and a[0]['source'] == 'call' and str(PD) == a[0]['service_ids'] and cu and cr.get('status') == 'booked' and int(cr.get('appt_id') or 0) == a[0]['id'] else 'FAIL', 'INTEGRATION', (v.get('caller_name'), r3[:60], a, cu, cr.get('status')))
# 2 returning customer
s = 'v3:S02'; start(s, ph); v = tvars(s, ph); up = v.get('upcoming', '')
r = tool(s, 'book', name='Nora Test', date=DAY(9), time='11:00', persons=[{'name': 'Nora Test', 'service_ids': [GM], 'tech_id': 0}]); a = appts(ph)
V('02', 'Khach cu goi dat lai', 'PASS' if 'NORA' in v.get('caller_name', '').upper() and up and r.startswith('BOOKED') and len(a) == 2 else 'FAIL', 'INTEGRATION', (v.get('caller_name'), up[:60], r[:60], len(a)))
# 3 specific tech  # 4 any tech
s, ph = 'v3:S03', P(203); start(s, ph); r = tool(s, 'book', name='Tia', date=DAY(2), time='13:00', persons=[{'name': 'Tia', 'service_ids': [GM], 'tech_id': HA}]); a = appts(ph)
V('03', 'Khach chon tho cu the', 'PASS' if r.startswith('BOOKED') and len(a) == 1 and a[0]['staff_id'] == HA else 'FAIL', 'INTEGRATION', (r[:60], a))
s, ph = 'v3:S04', P(204); start(s, ph); r = tool(s, 'book', name='Uma', date=DAY(2), time='13:00', persons=[{'name': 'Uma', 'service_ids': [GM], 'tech_id': 0}]); a = appts(ph)
V('04', 'Khach chon Any Tech', 'PASS' if r.startswith('BOOKED') and len(a) == 1 and a[0]['staff_id'] in (0, TA, SI) else 'FAIL', 'INTEGRATION', (r[:60], a))
# 5 several services
s, ph = 'v3:S05', P(205); start(s, ph); r = tool(s, 'book', name='Vy', date=DAY(3), time='10:00', persons=[{'name': 'Vy', 'service_ids': [PD, GM], 'tech_id': 0}]); a = appts(ph)
V('05', 'Nhieu dich vu (Pedicure + Gel Manicure)', 'PASS' if r.startswith('BOOKED') and len(a) == 1 and set(a[0]['service_ids'].split(',')) == {str(PD), str(GM)} and int(a[0]['duration']) >= 75 else 'FAIL', 'INTEGRATION', (r[:60], a))
# 6 several people
s, ph = 'v3:S06', P(206); start(s, ph); r = tool(s, 'book', name='Wen', date=DAY(3), time='14:00', persons=[{'name': 'Wen', 'service_ids': [PD], 'tech_id': 0}, {'name': 'Xia', 'service_ids': [GM], 'tech_id': 0}]); a = appts(ph)
V('06', 'Dat cho 2 nguoi', 'PASS' if r.startswith('BOOKED') and len(a) == 2 and len({x['group_id'] for x in a}) == 1 and a[0]['group_id'] else 'FAIL', 'INTEGRATION', (r[:60], a))
# 7 price / duration
v = tvars('v3:S06', ph); pr = tx_prompt = open(D + '/last-_v__ai_assistants_assistant_test__.json').read() if os.path.exists(D + '/last-_v__ai_assistants_assistant_test__.json') else ''
mn = v.get('menu', ''); hasdur = bool(re.search(r'\d+\s*min', mn)); hasprice = '$' in mn or bool(re.search(r'\b(35|40|50)\b', mn))
V('07', 'Hoi gia + thoi luong', 'PASS' if hasdur else 'FAIL', 'MOCK', 'menu: %s · co gia trong menu AI: %s' % (mn[:120], hasprice))
if not hasprice: V('07b', 'Hoi GIA: AI khong co gia -> theo thiet ke chuyen chu / goi lai', 'BY DESIGN', 'MOCK', 'menu khong co gia')
# 8 opening hours
dy = v.get('days', ''); V('08', 'Hoi gio mo cua (AI co lich mo cua 7 ngay)', 'PASS' if dy.count('\n') >= 5 and re.search(r'\d', dy) else 'FAIL', 'MOCK', dy[:160])
# 9 change mind mid-call
s, ph = 'v3:S09', P(209); start(s, ph); tool(s, 'check_times', date=DAY(4), time='10:00', persons=[{'name': 'Yen', 'service_ids': [PD], 'tech_id': 0}])
r = tool(s, 'book', name='Yen', date=DAY(4), time='15:00', persons=[{'name': 'Yen', 'service_ids': [PD], 'tech_id': 0}]); a = appts(ph)
V('09', 'Doi gio giua chung (hoi 10:00 -> dat 15:00)', 'PASS' if len(a) == 1 and a[0]['start_min'] == 900 else 'FAIL', 'INTEGRATION', (r[:60], a))
# 10 cancel / move an existing appointment
s = 'v3:S10'; start(s, ph); f = tool(s, 'find_appointments'); aid = a[0]['id']
rm = tool(s, 'move', appt_id=aid, said_date=DAY(4), said_time='15:00', date=DAY(5), time='16:00'); am = appts(ph)
s = 'v3:S10b'; start(s, ph); tool(s, 'find_appointments'); rc = tool(s, 'cancel', appt_id=am[0]['id'] if am else aid, said_date=DAY(5), said_time='16:00'); ac = appts(ph); cx = appts(ph, 'cancelled')
V('10', 'Doi lich roi huy lich da co', 'PASS' if rm.startswith('MOVED') and am and am[0]['start_min'] == 960 and am[0]['appt_date'] == DAY(5) and rc.startswith('CANCELLED') and not ac and cx else 'FAIL', 'INTEGRATION', (rm[:60], am, rc[:60], ac))
# 11 English / 12 Vietnamese
asb = json.load(open(sorted(glob.glob(D + '/last-_v__ai_assistants*.json'), key=os.path.getmtime)[-1]))
lang = json.dumps(asb.get('transcription', {})); V('11', 'Khach noi tieng Anh (STT deepgram en, prompt EN)', 'PASS' if '"en' in lang or 'en' in lang else 'FAIL', 'MOCK', lang[:120])
V('12', 'Khach noi tieng Viet', 'NOT IMPLEMENTED', 'MOCK', 'anh Logan chon AI CHI tieng Anh (CHAT 22:22); STT = en')
# 13 unclear / missing info -> no booking
s, ph = 'v3:S13', P(213); start(s, ph); r1 = tool(s, 'book', name='Zoe', date=DAY(4), time='11:00', persons=[{'name': 'Zoe', 'service_ids': [], 'tech_id': 0}])
r2 = tool(s, 'book', name='', date=DAY(4), time='11:00', persons=[{'name': '', 'service_ids': [PD], 'tech_id': 0}]); r3 = tool(s, 'book', name='Zoe', date='', time='', persons=[{'name': 'Zoe', 'service_ids': [PD], 'tech_id': 0}])
n13 = len(appts(ph)); r4 = tool(s, 'book', name='Zoe', date=DAY(4), time='11:00', persons=[{'name': 'Zoe', 'service_ids': [PD], 'tech_id': 0}])
V('13', 'Noi khong ro / thieu thong tin -> KHONG dat; noi ro -> dat', 'PASS' if n13 == 0 and all(x.startswith('NOT_BOOKED') for x in (r1, r2, r3)) and r4.startswith('BOOKED') and len(appts(ph)) == 1 else 'FAIL', 'INTEGRATION', (r1[:50], r2[:50], r3[:50], n13, r4[:40]))
# 14 silent caller
s, ph = 'v3:S14', P(214); start(s, ph); conv(s, [('assistant', 'Thank you for calling. How can I help?')]); end(s); time.sleep(0.3); tick(); cr = crow(s)
V('14', 'Khach khong noi gi -> missed + 1 tin missed call (outbox)', 'PASS' if cr.get('status') == 'missed' and len([o for o in outbox(ph) if o['kind'] == 'missed']) == 1 else 'FAIL', 'INTEGRATION', (cr.get('status'), cr.get('tb_state'), outbox(ph)))
# 15 asks for a person
s, ph = 'v3:S15', P(215); start(s, ph); n0 = open(D + '/fake_tx.log').read().count('Calls/' + xs(s)); r = tool(s, 'transfer_owner', reason='question'); n1 = open(D + '/fake_tx.log').read().count('Calls/' + xs(s))
c, xe = req('xfer', {'CallSid': s, 'DialCallStatus': 'no-answer'}, form=True, extra='&sid=' + xs(s)); cr = crow(s)
V('15', 'Xin gap nhan vien -> chuyen chu (khac iPhone); chu khong bat -> callback', 'PASS' if r.startswith('CONNECTING') and n1 == n0 + 1 and 'call you back' in xe and cr.get('status') == 'callback' else 'FAIL', 'INTEGRATION', (r[:50], n1 - n0, xe[-90:], cr.get('status')))
h('set', json.dumps({'call_owner': '+15155550176'})); s, ph = 'v3:S15c', P(218); start(s, ph); n0 = open(D + '/fake_tx.log').read().count('Calls/' + xs(s)); r = tool(s, 'transfer_owner'); n1 = open(D + '/fake_tx.log').read().count('Calls/' + xs(s)); cr = crow(s); h('set', json.dumps({'call_owner': '5155550177'}))
V('15c', '"Owner phone" = chinh iPhone vua do chuong -> KHONG chuyen ve iPhone; AI hen goi lai (callback)', 'PASS' if r.startswith('NO_ONE') and n1 == n0 and cr.get('status') == 'callback' else 'FAIL', 'INTEGRATION', (r[:50], n1 - n0, cr.get('status')))
s, ph = 'v3:S14b', P(219); req('in', {'CallSid': s, 'From': ph, 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True); req('status', {'CallSid': s, 'CallStatus': 'completed'}, form=True); tick(); cr = crow(s)
V('14b', 'Khach cup khi iPhone dang do chuong (chua toi AI) -> missed + 1 tin missed call', 'PASS' if cr.get('status') == 'missed' and len([o for o in outbox(ph) if o['kind'] == 'missed']) == 1 else 'FAIL', 'INTEGRATION', (cr.get('status'), cr.get('tb_state'), outbox(ph)))
V('15b', 'Chuyen may that (do chuong so chu, giong noi)', 'BLOCKED', 'REAL CALL', 'can cuoc goi that (anh Logan goi tay, CHAT xem log xfer)')
# 16 after hours
CLOSED = json.dumps({str(w): {'open': '09:00', 'close': '09:01'} for w in range(7)}); h('set', json.dumps({'hours': CLOSED}))
s, ph = 'v3:S16', P(216); x1, x2 = start(s, ph); r = tool(s, 'book', name='Ada', date=DAY(2), time='15:00', persons=[{'name': 'Ada', 'service_ids': [PD], 'tech_id': 0}])
h('set', json.dumps({'hours': json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)})}))
V('16', 'Goi ngoai gio: AI KHONG dat ngoai gio', 'PASS' if not appts(ph) and not r.startswith('BOOKED') else 'FAIL', 'INTEGRATION', r[:80])
V('16b', 'Goi ngoai gio: van do chuong iPhone truoc (anh Logan: "always ring the iPhone first", calls.php:203 CHAT 01/11)', 'BY DESIGN' if '<Dial' in x1 else 'PASS', 'INTEGRATION', 'Telnyx + SignalWire deu do iPhone truoc' if '<Dial' in x1 else '')
# 17 hangs up mid-call
s, ph = 'v3:S17', P(217); start(s, ph); tool(s, 'check_times', date=DAY(2), time='16:00', persons=[{'name': 'Bea', 'service_ids': [PD], 'tech_id': 0}])
conv(s, [('assistant', 'How can I help?'), ('user', 'pedicure Thursday at 4'), ('assistant', 'That time is open. What name?')]); end(s, 'hangup'); time.sleep(0.3); cr = crow(s)
pu = sql("SELECT title FROM push_log WHERE body LIKE '%%%s%%' OR body LIKE '%%%s%%'" % (ph[-4:], '555-0217')) if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []
V('17', 'Cup giua chung -> khong dat; cuoc "Needs review" + push cho chu', 'PASS' if not appts(ph) and cr.get('status') == 'review' and 'pedicure' in (cr.get('text_c') or '') else 'FAIL', 'INTEGRATION', (cr.get('status'), (cr.get('text_c') or '')[:40], pu[:2]))
# 18 two callers, same tech, same time
bad = 0
for k in range(5):
    sa, sb, pa, pb = 'v3:S18a%d' % k, 'v3:S18b%d' % k, P(230 + k), P(240 + k); start(sa, pa); start(sb, pb); ev = threading.Event(); o18 = [None, None]
    def g(i, s_, nm): ev.wait(); o18[i] = tool(s_, 'book', name=nm, date=DAY(6), time='%02d:00' % (9 + k), persons=[{'name': nm, 'service_ids': [GM], 'tech_id': SI}])
    th = [threading.Thread(target=g, args=(0, sa, 'Ca%d' % k)), threading.Thread(target=g, args=(1, sb, 'Cb%d' % k))]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
    n = sql("SELECT COUNT(*) AS n FROM appointments WHERE appt_date = '%s' AND start_min = %d AND staff_id = %d AND status = 'booked'" % (DAY(6), (9 + k) * 60, SI))[0]['n']
    bad += int(n) != 1
V('18', '2 khach cung tho cung gio cung luc (5 vong) -> 1 hen / gio', 'PASS' if bad == 0 else 'FAIL', 'INTEGRATION', 'vong sai: %d' % bad)
# 20 multi-salon (2 salons on the test machine)
B2 = A.rstrip('/') + '-salonB'; shutil.rmtree(B2, ignore_errors=True); shutil.copytree(A, B2, symlinks=True); DBB = D + '/dbB.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DBB); PB = PORT + 40
seedB = json.loads(sh('php', T5 + '/seed.php', B2, DBB, str(PB)).stdout)
HB = D + '/hB.php'; open(HB, 'w').write(open(H).read().replace(A + '/', B2 + '/'))
def hb(*a):
    r_ = sh('php', HB, *[str(x) for x in a])
    try: return json.loads(r_.stdout)
    except Exception: return r_.stdout
hb('set', json.dumps({'hours': json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)}), 'call_owner': '5155550188', 'call_fwd': '+15155550186', 'salon_name': 'SALON B TEST', 'call_on': '1', 'tx_on': '1'}))
hb('save', json.dumps({'key': 'KEY0123456789abcdefTEST_tx_key_99', 'number': '(515) 555-0190', 'on': True})); TOKB = hb('tok')
svB = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PB, '-t', B2, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '2'}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); atexit.register(svB.terminate); time.sleep(1.0)
def reqB(a, body, tok, extra='', form=False):
    raw = urllib.parse.urlencode(body).encode() if form else json.dumps(body).encode()
    try: r_ = urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/call_tx.php?a=%s&t=%s%s' % (PB, a, tok, extra), data=raw, headers={'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json'}), timeout=30); return r_.status, r_.read().decode()
    except urllib.error.HTTPError as e: return e.code, ''
cA, _ = reqB('in', {'CallSid': 'v3:B1', 'From': P(201), 'To': '+15155550190'}, TOK, form=True)
cB, xB = reqB('in', {'CallSid': 'v3:B1', 'From': P(201), 'To': '+15155550190'}, TOKB, form=True); reqB('after', {'CallSid': 'v3:B1', 'DialCallStatus': 'no-answer'}, TOKB, '&sid=' + xs('v3:B1'), form=True)
_, fB = reqB('tool', {}, TOKB, '&fn=find_appointments&ccid=' + xs('v3:B1')); fB = json.loads(fB or '{}').get('result', '')
_, bB = reqB('tool', {'name': 'Nora B', 'date': DAY(2), 'time': '10:00', 'persons': [{'name': 'Nora B', 'service_ids': [seedB['S']['Pedicure']], 'tech_id': 0}]}, TOKB, '&fn=book&ccid=' + xs('v3:B1')); bB = json.loads(bB or '{}').get('result', '')
inA = sql("SELECT COUNT(*) AS n FROM appointments WHERE customer_name LIKE 'NORA B%'")[0]['n']; inB = json.loads(sh('php', T5 + '/db.php', DBB, "SELECT COUNT(*) AS n FROM appointments WHERE phone = '%s' AND status = 'booked'" % P(201)).stdout or '[{"n":-1}]')[0]['n']
V('20', '2 salon: token tiem A vao tiem B -> 403; khach co 2 hen o A goi B -> B khong thay hen A; dat o B chi nam o DB B', 'PASS' if cA == 403 and cB == 200 and 'NORA' not in fB.upper() and bB.startswith('BOOKED') and int(inA) == 0 and int(inB) == 1 else 'FAIL', 'INTEGRATION', (cA, cB, fB[:70], bB[:40], inA, inB))
V('20b', 'Nhieu salon tren Telnyx that', 'BLOCKED', 'REAL CALL', 'hien chi AN dung Telnyx (1 so 513-6667)')

# ----- GIAI DOAN 4: bao mat / du lieu -----
say('== BAO MAT / DU LIEU')
c, _ = req('in', {'CallSid': 'v3:Z1', 'From': P(250), 'To': '+15155136667'}, form=True, tok='')
V('S1', 'Khong co secret (t) -> 403', 'PASS' if c == 403 else 'FAIL', 'INTEGRATION', c)
c, _ = req('status', {'CallSid': 'v3:Z2'}, form=True, hdr={'telnyx-timestamp': str(int(time.time())), 'telnyx-signature-ed25519': 'A' * 88})
V('S2', 'Chu ky Ed25519 sai -> 403', 'PASS' if c == 403 else 'FAIL', 'INTEGRATION', c)
raw = json.dumps({'name': 'Evil', 'date': DAY(2), 'time': '10:00', 'persons': []}).encode(); ts = str(int(time.time()) - 400); open(D + '/.bz', 'wb').write(raw); sg = h('sign', SIGN, ts, D + '/.bz')
c, _ = req('tool', json.loads(raw), extra='&fn=book&ccid=v3%3AS01', hdr={'telnyx-timestamp': ts, 'telnyx-signature-ed25519': sg})
V('S3', 'Replay: chu ky dung nhung cu > 5 phut -> 403', 'PASS' if c == 403 else 'FAIL', 'INTEGRATION', c)
c, _ = req('tool', {'name': 'X'}, extra='&fn=find_appointments&ccid=v3%3AS01', sign=False)
V('S4', 'Tool (JSON) KHONG chu ky khi da co Public Key -> ?', 'PASS' if c == 403 else 'FAIL', 'INTEGRATION', 'http %s (chi can secret t; tx_sig_strict=0 cho phep request khong ky - de TeXML cua Telnyx khong ky)' % c)
s, ph = 'v3:Z5', P(255); start(s, ph); start(s, ph)
V('S5', 'Webhook ?a=in gui lai (cung CallSid) -> 1 dong calls', 'PASS' if sql("SELECT COUNT(*) AS n FROM calls WHERE call_sid = '%s'" % s)[0]['n'] == 1 else 'FAIL', 'INTEGRATION', sql("SELECT COUNT(*) AS n FROM calls WHERE call_sid = '%s'" % s))
bk = dict(name='Gus', date=DAY(7), time='10:00', persons=[{'name': 'Gus', 'service_ids': [PD], 'tech_id': 0}], new_ok=True)
r1 = tool(s, 'book', **bk); r2 = tool(s, 'book', **bk)
V('S6', 'Tool book gui lai 2 lan (retry / duplicate, ca new_ok) -> 1 hen', 'PASS' if len(appts(ph)) == 1 else 'FAIL', 'INTEGRATION', (len(appts(ph)), r2[:50]))
s2, ph2 = 'v3:Z7', P(257); start(s2, ph2); f = tool(s2, 'find_appointments'); r = tool(s2, 'cancel', appt_id=appts(ph)[0]['id'], said_date=DAY(7), said_time='10:00')
V('S7', 'Huy hen cua SO KHAC (appt_id cua nguoi khac) -> khong huy', 'PASS' if len(appts(ph)) == 1 and not r.startswith('CANCELLED') else 'FAIL', 'INTEGRATION', r[:80])
f2 = tool(s2, 'find_appointments', phone=ph, caller_number=ph); r = tool(s2, 'cancel', appt_id=appts(ph)[0]['id'], said_date=DAY(7), said_time='10:00', phone=ph, caller_number=ph)
V('S7b', 'AI dua SO NAN NHAN trong body (find / cancel) -> khong thay, khong huy hen nguoi khac', 'PASS' if len(appts(ph)) == 1 and 'GUS' not in f2.upper() and not r.startswith('CANCELLED') else 'FAIL', 'INTEGRATION', (f2[:60], r[:60]))
r = tool(s2, 'book', name='Hal', date=DAY(7), time='11:00', persons=[{'name': 'Hal', 'service_ids': [PD], 'tech_id': 0}], phone='+15155550299', caller_number='+15155550299')
V('S8', 'AI dua so dien thoai khac trong body -> bo qua, dung so goi den', 'PASS' if not appts('+15155550299') and len(appts(ph2)) == 1 else 'FAIL', 'INTEGRATION', (r[:50], len(appts(ph2))))
c, x = req('in', {'CallSid': 'v3:Z9', 'From': P(259), 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True)
V('S9', 'Thong bao ghi am: "This call may be recorded." TRUOC khi do chuong / AI', 'PASS' if x.find('This call may be recorded') != -1 and x.find('This call may be recorded') < max(x.find('<Dial'), 0) + 10 ** 6 and x.find('may be recorded') < x.find('<Dial') else 'FAIL', 'INTEGRATION', x[:120])
V('S9b', 'Chinh sach dong y ghi am (luat bang)', 'BLOCKED', 'MOCK', 'can anh Logan / luat su xac nhan (Iowa: 1 ben dong y; khach goi tu bang 2 ben -> thong bao chung)')
logs = open(D + '/php.log').read(); nums = set(re.findall(r'\+?1?515555\d{4}', logs)); names = [n for n in ('Nora', 'NORA', 'Tia', 'Uma', 'Wen', 'Xia', 'Yen', 'Zoe', 'Gus', 'GUS', 'Hal', 'Bea') if re.search(r'\b' + n + r'\b', logs)]
V('S10', 'Log khong chua so dien thoai / TEN khach (tx_log)', 'PASS' if not nums and not names else 'FAIL', 'INTEGRATION', '%d so, ten: %s · vd %s' % (len(nums), names[:5], sorted(nums)[:3]))
V('S11', 'Key / Public Key / secret khong vao log', 'PASS' if 'KEY0123' not in logs and TOK not in logs else 'FAIL', 'INTEGRATION', '')
# ----- 19 + GIAI DOAN 5: nhieu cuoc dong thoi / tai -----
say('== TAI: 1 / 5 / 10 / 25 / 50 / 100 cuoc dong thoi (may test, PHP built-in 8 tien trinh + SQLite – live = php-fpm + MySQL)')
PL = PORT + 41; svL = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PL, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '8'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpL.log', 'w')); atexit.register(svL.terminate); time.sleep(1.2)
BL = 'http://127.0.0.1:%d/call_tx.php' % PL
import base64
def reqL(a, body, form=False, extra=''):
    raw = urllib.parse.urlencode(body).encode() if form else json.dumps(body).encode(); hd = {'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json'}
    ts = str(int(time.time())); bf = D + '/.bl-' + str(threading.get_ident()); open(bf, 'wb').write(raw); hd['telnyx-timestamp'] = ts; hd['telnyx-signature-ed25519'] = sigL(ts, raw)
    t0 = time.time()
    try: r_ = urllib.request.urlopen(urllib.request.Request(BL + '?a=' + a + '&t=' + TOK + extra, data=raw, headers=hd), timeout=30); return r_.status, r_.read().decode(), time.time() - t0
    except urllib.error.HTTPError as e: return e.code, '', time.time() - t0
    except Exception as e: return 0, str(e), time.time() - t0
import base64
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    _sk = Ed25519PrivateKey.from_private_bytes(base64.b64decode(SIGN)[:32])
    def sigL(ts, raw): return base64.b64encode(_sk.sign(ts.encode() + b'|' + raw)).decode()
except Exception:   # a server without python3-cryptography: sign with PHP sodium (slower, same signature)
    def sigL(ts, raw):
        bf = D + '/.bs-' + str(threading.get_ident()); open(bf, 'wb').write(raw); return h('sign', SIGN, ts, bf)
LOAD = []
NI = {1: 1, 5: 2, 10: 3, 25: 4, 50: 5, 100: 6}
slot = [0]
def one(i, n, lat, errs):
    sid = 'v3:L%d-%d' % (n, i); frm = '+1515%03d%04d' % (600 + NI[n], i)
    k = slot[0] + i; day = DAY(10 + k // 12); tm = '%02d:00' % (9 + k % 12)
    try:
        c1, x1, t1 = reqL('in', {'CallSid': sid, 'From': frm, 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True)
        c2, x2, t2 = reqL('after', {'CallSid': sid, 'DialCallStatus': 'no-answer'}, form=True, extra='&sid=' + xs(sid))
        c3, x3, t3 = reqL('tool', {'date': day, 'time': tm, 'persons': [{'name': 'L%d' % i, 'service_ids': [GM], 'tech_id': 0}]}, extra='&fn=check_times&ccid=' + xs(sid))
        c4, x4, t4 = reqL('tool', {'name': 'Load %d' % i, 'date': day, 'time': tm, 'persons': [{'name': 'Load %d' % i, 'service_ids': [GM], 'tech_id': 0}]}, extra='&fn=book&ccid=' + xs(sid))
        c5, x5, t5 = reqL('aiend', {'CallSid': sid, 'Reason': 'hangup'}, form=True, extra='&sid=' + xs(sid))
        lat.extend([('in', t1), ('after', t2), ('tool', t3), ('tool', t4), ('aiend', t5)])
        ok_ = all(c == 200 for c in (c1, c2, c3, c4, c5)) and 'BOOKED' in x4
        if not ok_: errs.append((i, c1, c2, c3, c4, c5, x4[:60]))
    except Exception as e: errs.append((i, str(e)[:80]))
def cpu():
    t = 0.0
    for p_ in glob.glob('/proc/[0-9]*/stat'):
        try:
            f_ = open(p_).read().split()
            if 'php' in f_[1]: t += (int(f_[13]) + int(f_[14])) / os.sysconf('SC_CLK_TCK')
        except Exception: pass
    return t
def rss():
    m = 0
    for p_ in glob.glob('/proc/[0-9]*/status'):
        try:
            s_ = open(p_).read()
            if 'Name:\tphp' in s_: m += int(re.search(r'VmRSS:\s+(\d+)', s_).group(1))
        except Exception: pass
    return m // 1024
for n in (1, 5, 10, 25, 50, 100):
    lat, errs = [], []; c0 = cpu(); t0 = time.time(); peak = [0]; stop = [False]
    def mon():
        while not stop[0]: peak[0] = max(peak[0], rss()); time.sleep(0.2)
    mt = threading.Thread(target=mon); mt.start()
    th = [threading.Thread(target=one, args=(i, n, lat, errs)) for i in range(n)]; [t.start() for t in th]; [t.join() for t in th]
    stop[0] = True; mt.join(); wall = time.time() - t0; c1_ = cpu()
    q = sql("SELECT COUNT(*) AS n, COUNT(DISTINCT appt_date || '-' || start_min || '-' || phone) AS d FROM appointments WHERE customer_name LIKE 'LOAD %%' AND status = 'booked' AND phone LIKE '+1515556%03d%%'" % (n,)) if False else None
    mine = sql("SELECT appt_date, start_min, phone FROM appointments WHERE phone LIKE '+1515%03d%%' AND status = 'booked'" % (600 + NI[n]))
    dup = len(mine) - len({(r_['appt_date'], r_['start_min'], r_['phone']) for r_ in mine})
    tl = sorted(t for k_, t in lat if k_ == 'tool'); p50 = statistics.median(tl) if tl else 0; p95 = tl[int(len(tl) * 0.95) - 1] if tl else 0
    slow = sum(1 for t in tl if t > 8)
    LOAD.append((n, len(mine), n - len(errs), dup, round(p50, 2), round(p95, 2), max(tl) if tl else 0, slow, round(wall, 1), round(c1_ - c0, 1), peak[0], errs[:2]))
    say('  %3d cuoc: xong %3d/%d · hen dat %3d · trung %d · tool p50 %.2fs p95 %.2fs max %.2fs · >8 s (Telnyx timeout) %d · %.1fs · CPU php %.1fs · RAM php max %d MB%s' % (n, n - len(errs), n, len(mine), dup, p50, p95, max(tl) if tl else 0, slow, wall, c1_ - c0, peak[0], ('  loi: ' + str(errs[:2])) if errs else ''))
    slot[0] += n
dbl = open(D + '/phpL.log').read().count('database is locked')
okL = all(x[2] == x[0] and x[1] == x[0] and x[3] == 0 for x in LOAD)
V('19', 'Nhieu cuoc dong thoi cung 1 salon (1..100): moi cuoc dat dung 1 hen, khong trung', 'PASS' if okL else 'FAIL', 'INTEGRATION', LOAD[-1][:9])
V('L1', 'Tai 100 cuoc: tool p95 < 8 s (timeout tool Telnyx)', 'PASS' if LOAD[-1][5] < 8 and LOAD[-1][7] == 0 else 'FAIL', 'INTEGRATION', 'p95 %.2fs, >8s: %d, SQLite locked: %d' % (LOAD[-1][5], LOAD[-1][7], dbl))
V('L2', 'Tai that (php-fpm + MySQL + Telnyx that, cuoc that)', 'BLOCKED', 'REAL CALL', 'may test chi do code + DB SQLite; khong do duoc STT / TTS / mang Telnyx')

say('PASS %d/%d' % (sum(R), len(R)))
