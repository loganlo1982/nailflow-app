# LAMWEB test 638h (Dejavoo answers 03/11) - PaymentType UserChoice; Status busy while the sale is open; unsure re-checked (never a 2nd sale); partial apart; void out of batch -> Return; no lower price on a P5 receipt.
# (from 638d) - Void / Refund of a receipt paid on the P5: the P5 gives the money back by itself (Void same batch, Return after the batch closed /
#   for a part); the P5 says no -> the receipt is NOT changed; a normal card receipt still needs "Done on DPS".
# Fake SPIn Proxy (fakespin.py) + a local copy with its own SQLite (T586 seed: Pedicure $35, Gel Manicure $40, Full Set $50). Nothing real.
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T638'; T5 = '/tmp/claude-0/T586'; SH = int(os.environ.get('NF_PORT_SHIFT', 0)); PORT = 19914 + SH; FP = 19915 + SH
R = []; out = open(D + '/test-638h.txt', 'w'); ENV = {**os.environ, 'TZ': 'America/Chicago'}
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
A = D + '/apph'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True); DB = D + '/dbh.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; TT = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA = TT['TAMMY']
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d','dv_base'=>'http://127.0.0.1:%d','dv_slack'=>2,'dv_wait'=>2);\n" % (DB, PORT, FP))
def php(code):
    r = sh('php', '-d', 'error_log=' + D + '/phph-err.log', '-r', 'require "%s/inc/core.php"; settings(); %s' % (A, code)); return (r.stdout + r.stderr).strip()
PW = 'adm638-' + os.urandom(3).hex(); php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % PW)
LOG = D + '/req-h.log'; open(LOG, 'w').close()
fk = subprocess.Popen(['python3', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fakespin.py'), str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phph.log', 'w'))
atexit.register(lambda: (sv.terminate(), fk.terminate())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
NUM = [0]
def appt(sid=None):
    NUM[0] += 1; ph = '+155555501%02d' % (40 + NUM[0])
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'P5 TEST %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tk%d')" % (time.strftime('%Y-%m-%d'), 600 + NUM[0] * 5, TA, sid or PD, NUM[0], ph, NUM[0]))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def co(aid, pays, sid=None, price=35):
    return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid or PD, 'price': price, 'staff': TA}], 'pays': pays})
def sales(): return [json.loads(l) for l in open(LOG) if '/v2/Payment/Sale' in l]
def pend(): return json.loads(php('echo setting("dv_pend");') or '{}')
def calls(p): return [json.loads(l) for l in open(LOG) if p in l]
def rcpt(rid): x = sql("SELECT status, pays, void_reason FROM receipts WHERE id = %d" % rid); return x[0] if x else {}
def paid(price=35, amt=None, sid=None):
    a = appt(sid); c, v = api('dv_charge', {'ids': [a], 'amt': amt or price}); c2, r = co(a, [{'m': 'Card', 'amt': amt or price, 'dv_ref': v.get('ref', '')}], sid=sid, price=price)
    return int(((r or {}).get('receipt') or {}).get('id', 0)), v.get('ref', '')
def money(rid, amt, how='Cash', reason='wrong price'): return api('receipt_money', {'id': rid, 'lines': [{'staff': TA, 'amt': amt}], 'how': how, 'reason': reason})
try:
    say('== LAMWEB test 638h - Dejavoo answers (fake proxy) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
    php('require_once "%s/inc/dejavoo.php"; dv_set_creds("220926423654", "REG01", "AK12345678"); set_setting("dv_on", "1");' % A)
    rid1, ref1 = paid(price=35)
    s1 = [x for x in sales() if x['body'].get('ReferenceId') == ref1]
    ok('1 Sale sends PaymentType "UserChoice" (Dejavoo q7: Card is not used in the US) and is approved', rid1 and s1 and s1[-1]['body'].get('PaymentType') == 'UserChoice', (rid1, s1[-1]['body'] if s1 else None))
    c, r = api('receipt_void', {'id': rid1, 'reason': 'void 638h', 'dps_done': False}); vv = calls('/v2/Payment/Void')
    ok('2 Void sends the SAME PaymentType as the sale (q6) and is approved', c == 200 and vv and vv[-1]['body'].get('PaymentType') == 'UserChoice' and pend()[ref1]['st'] == 'voided', (c, str(r)[:200]))
    st = json.loads(php('require_once "%s/inc/dejavoo.php"; echo json_encode(dv_status("%s"));' % (A, ref1)) or '{}')
    ok('3 Status with the same PaymentType finds the sale (approved)', st.get('status') == 'approved', st)
    # q6: the sale still open on the P5 -> Status = busy; a 2nd tap must ask the P5 first, never a 2nd sale
    a9 = appt(); n0 = len(sales()); t0 = time.time(); c, v = api('dv_charge', {'ids': [a9], 'amt': 35.09})
    p9 = [k for k, x in pend().items() if x.get('key') == 'T%d' % a9]
    ok('4 sale still open on the P5 (the app stopped waiting, Status = busy): NOT paid, says "still busy" (not a failure)', c == 409 and 'still busy' in (v.get('error') or '') and p9 and pend()[p9[0]]['st'] == 'unsure', (c, v, p9 and pend()[p9[0]]))
    time.sleep(max(0, 9 - (time.time() - t0)))
    c, v2 = api('dv_charge', {'ids': [a9], 'amt': 35.09}); n1 = len(sales())
    ok('5 tap Pay again after the P5 finished: the SAME payment comes back (asked by Status) - only ONE sale sent to the P5', c == 200 and v2.get('ref') == p9[0] and n1 - n0 == 1, (c, v2, n1 - n0))
    c, r = co(a9, [{'m': 'Card', 'amt': 35.09, 'dv_ref': v2.get('ref', '')}], price=35.09); ok('5 ... and its receipt', c == 200 and r.get('receipt'), (c, str(r)[:150]))
    a6 = appt(); c, v = api('dv_charge', {'ids': [a6], 'amt': 35.06}); p6 = [x for k, x in pend().items() if x.get('key') == 'T%d' % a6]
    ok('6 partial approval (0001): kept apart as "partial" (never re-checked as paid), the desk is told to cancel it on the P5', c == 402 and p6 and p6[0]['st'] == 'partial' and 'PART' in (v.get('error') or ''), (c, v, p6))
    # q10: Void of a sale no longer in the open batch -> Not found -> Return (the customer taps the card)
    rid3, ref3 = paid(price=50, sid=S['Full Set']); php('require_once "%s/inc/dejavoo.php"; dv_settle(dv_new_ref(), 30);' % A); n2 = len(calls('/v2/Payment/Return'))
    c, r = api('receipt_void', {'id': rid3, 'reason': 'after settle', 'dps_done': False}); rr = calls('/v2/Payment/Return'); vv = calls('/v2/Payment/Void')
    ok('7 Void after the batch closed: the P5 says "Not found" (q10) -> Return $50 with UserChoice -> receipt void, payment "returned"', c == 200 and len(rr) == n2 + 1 and rr[-1]['body']['Amount'] == 50 and rr[-1]['body']['PaymentType'] == 'UserChoice' and rcpt(rid3).get('status') == 'void' and pend()[ref3]['st'] == 'returned', (c, str(r)[:200]))
    # e: "Fix service prices" lower on a P5 receipt -> refused (it never reached the P5); a normal card receipt still can
    rid5, ref5 = paid(price=35); nb = (len(calls('/v2/Payment/Return')), len(calls('/v2/Payment/Void'))); before = sql("SELECT total, refund FROM receipts WHERE id = %d" % rid5)[0]
    c, r = money(rid5, 30, how='Card'); after = sql("SELECT total, refund FROM receipts WHERE id = %d" % rid5)[0]
    ok('8 Fix service prices LOWER on a P5 receipt: refused (use Refund), receipt unchanged, nothing sent to the P5', c == 409 and 'Refund' in (r.get('error') or '') and before == after and nb == (len(calls('/v2/Payment/Return')), len(calls('/v2/Payment/Void'))), (c, r, before, after))
    a0 = appt(); c, r = co(a0, [{'m': 'Card', 'amt': 35, 'last4': '1111'}]); r0 = int(r['receipt']['id'])
    c, r = money(r0, 30, how='Card'); ok('9 a NORMAL card receipt (not P5): lowering still works as before (639a)', c == 200, (c, r))
    c, r = money(rid5, 40, how='Cash'); ok('10 RAISING the price on a P5 receipt (collected more in cash) still works', c == 200, (c, r))
    err = open(D + '/phph.log').read() + (open(D + '/phph-err.log').read() if os.path.exists(D + '/phph-err.log') else '')
    ok('11 no PHP Warning / Fatal', not any(x in err for x in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in err.splitlines() if 'PHP' in l][:3])
finally:
    sv.terminate(); fk.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
