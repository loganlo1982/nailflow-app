# LAMWEB test 638a - Dejavoo P5 SPIn Cloud: the calls (inc/dejavoo.php) against a FAKE SPIn Proxy (fakespin.py) - nothing real.
# Never "paid" without an approval; a lost / late answer is checked by Status with the SAME ReferenceId (never a 2nd charge); the codes never in a log.
import subprocess, json, os, sys, time, shutil, re
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T638'; PORT = 19899 + int(os.environ.get('NF_PORT_SHIFT', 0)); R = []; out = open(D + '/test-638a.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:300]))
ENV = {**os.environ, 'TZ': 'America/Chicago'}
APP = D + '/app'; shutil.rmtree(APP, ignore_errors=True); shutil.copytree(A0, APP, symlinks=True); db = D + '/db.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', db)
open(APP + '/inc/config.php', 'w').write("<?php\nreturn ['driver' => 'sqlite', 'sqlite_path' => '%s', 'site_url' => 'http://127.0.0.1:1', 'dv_base' => 'http://127.0.0.1:%d', 'dv_slack' => 2];\n" % (db, PORT))
LOG = D + '/req.log'; open(LOG, 'w').close()
srv = subprocess.Popen(['python3', D + '/fakespin.py', str(PORT), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(0.8)
def php(code):
    r = subprocess.run(['php', '-d', 'error_log=' + D + '/php-err.log', '-r', 'require "%s/inc/core.php"; settings(); if (is_file("%s/inc/dejavoo.php")) require_once "%s/inc/dejavoo.php"; %s' % (APP, APP, APP, code)], capture_output=True, text=True, env=ENV)
    return (r.stdout + r.stderr).strip()
def pj(code):
    x = php('echo json_encode(' + code + ');')
    try: return json.loads(x)
    except Exception: return {'_raw': x[:300]}
def reqs(): return [json.loads(l) for l in open(LOG) if l.strip()]
try:
    say('== LAMWEB test 638a - Dejavoo P5 SPIn (fake proxy) ' + time.strftime('%Y-%m-%d %H:%M %Z'))
    x = pj('["on" => dv_on(), "ready" => dv_ready(), "env" => dv_env(), "base" => DV_URL]')
    ok('1 OFF by default (dv_on 0), not set up, sandbox (uat) unless dv_env = live; sandbox URL https://test.spinpos.net', x.get('on') is False and x.get('ready') is False and x.get('env') == 'uat' and (x.get('base') or {}).get('uat') == 'https://test.spinpos.net', x)
    x = pj('dv_sale(10, 0, dv_new_ref())'); ok('1 not set up: a sale sends NOTHING, says not set up, never paid', x.get('status') == 'auth' and x.get('paid') is False and reqs() == [], (x, reqs()[:1]))
    x = pj('dv_set_creds("220926423654", "REG01", "AK12345678")')
    ok('2 codes saved: TPN shown, Register ID / Auth Key only "…" + last 4', x.get('tpn') == '220926423654' and x.get('reg') == '…EG01' and x.get('auth') == '…5678', x)
    raw = php('echo setting("dv_reg"), "|", setting("dv_auth");'); ok('2 Register ID / Auth Key stored ENCRYPTED (not readable in the database)', 'REG01' not in raw and 'AK12345678' not in raw and raw.count('|') == 1 and len(raw) > 20, raw[:60])
    x = php('try { dv_set_creds("", "", "short"); echo "saved"; } catch (InvalidArgumentException $e) { echo $e->getMessage(); }'); ok('2 a wrong Auth Key (not 10 characters) is refused, the saved one kept', 'exactly 10' in x and pj('dv_shown()').get('auth') == '…5678' and pj('dv_shown()').get('tpn') == '220926423654', x)
    x = pj('dv_terminal_status()'); q = reqs()[-1]
    ok('3 Terminal Connection Status: GET /v2/Common/TerminalStatus?request.tpn&request.authkey -> Online', x.get('online') is True and q['path'] == '/v2/Common/TerminalStatus' and q['query'].get('request.tpn') == '220926423654', (x, q.get('path')))
    ref = php('echo dv_new_ref();'); ok('4 ReferenceId: alphanumeric, 1-50, a new one each time', re.fullmatch(r'[A-Z0-9]{1,50}', ref) is not None and ref != php('echo dv_new_ref();'), ref)
    x = pj('dv_sale(25, 2.5, "%s", "R123")' % ref); q = reqs()[-1]; b = q.get('body', {})
    ok('4 sale $25 + $2.50 tip: approved -> paid, Last4 4242, Visa, AuthCode, PNReferenceId', x.get('paid') is True and x.get('status') == 'approved' and x.get('last4') == '4242' and x.get('card') == 'Visa' and x.get('auth_code') and x.get('pnref') and x.get('total') == 27.5, x)
    ok('4 what was sent: POST /v2/Payment/Sale, Amount 25, TipAmount 2.5, PaymentType UserChoice (638h: Dejavoo - Card is not used in the US), ReferenceId, InvoiceNumber, Tpn, Authkey, SPInProxyTimeout 120',
       q['path'] == '/v2/Payment/Sale' and b.get('Amount') == 25 and b.get('TipAmount') == 2.5 and b.get('PaymentType') == 'UserChoice' and b.get('ReferenceId') == ref and b.get('InvoiceNumber') == 'R123' and b.get('Tpn') == '220926423654' and b.get('Authkey') == 'AK12345678' and b.get('SPInProxyTimeout') == 120, b)
    n0 = len(reqs()); x = pj('dv_sale(25, 2.5, "%s")' % ref); sales = [r for r in reqs()[n0:] if r['path'] == '/v2/Payment/Sale']
    ok('4 the SAME ReferenceId again (double tap): the P5 says duplicate -> Status -> the first payment (paid once, nothing charged twice)', x.get('paid') is True and x.get('checked') is True and len(sales) == 1 and x.get('ref') == ref, (x.get('status'), x.get('code'), len(sales)))
    for amt, nm, st in [(10.01, 'declined', 'declined'), (10.02, 'cancelled on the P5', 'cancelled')]:
        x = pj('dv_sale(%s, 0, dv_new_ref())' % amt); ok('5 %s -> not paid, may try again, says why' % nm, x.get('paid') is False and x.get('retry_ok') is True and x.get('status') == st and x.get('msg'), x)
    t0 = time.time(); x = pj('dv_sale(10.03, 0, dv_new_ref(), "", 1)'); dt = time.time() - t0
    ok('6 charged but the answer came too late: Status (same ReferenceId) finds it -> paid, NOT asked to charge again', x.get('paid') is True and x.get('checked') is True and x.get('retry_ok') is False and dt < 15, (x.get('status'), x.get('paid'), round(dt, 1)))
    x = pj('dv_sale(10.04, 0, dv_new_ref(), "", 5)'); ok('6 charged, then the connection dropped: Status -> paid', x.get('paid') is True and x.get('checked') is True, (x.get('status'), x.get('paid')))
    x = pj('dv_sale(10.05, 0, dv_new_ref(), "", 1)'); ok('6 never charged and no answer: Status says not found -> not paid, safe to try again', x.get('paid') is False and x.get('retry_ok') is True and x.get('checked') is True, x)
    x = pj('dv_sale(10.06, 0, dv_new_ref())'); ok('7 partial approval (0001): NOT paid, NOT safe to charge again (void it on the P5)', x.get('paid') is False and x.get('retry_ok') is False and x.get('unsure') is True, x)
    x = pj('dv_sale(10.07, 0, dv_new_ref())'); ok('7 terminal in use (2008) and Status still busy: not paid, not safe to retry (look at the P5)', x.get('paid') is False and x.get('retry_ok') is False and x.get('unsure') is True, x)
    x = pj('dv_sale(10.08, 0, dv_new_ref())'); ok('7 terminal in use with a PREVIOUS request (2008), this one never started (Status: not found): not paid, safe to retry', x.get('paid') is False and x.get('retry_ok') is True and x.get('checked') is True, x)
    x = pj('dv_tip_adjust(25, 5, "%s")' % ref); q = reqs()[-1]['body']
    ok('8 tip adjust: TipAdjust Amount 25, TipAmount 5, TipIndicator Replace, same ReferenceId -> ok', x.get('ok') is True and q.get('TipIndicator') == 'Replace' and q.get('TipAmount') == 5 and q.get('ReferenceId') == ref, (x.get('status'), q))
    r2 = php('echo dv_new_ref();'); pj('dv_sale(40, 0, "%s")' % r2); x = pj('dv_void(40, "%s")' % r2); q = reqs()[-1]
    ok('8 void today (before settle): POST /v2/Payment/Void with the ORIGINAL ReferenceId + amount -> ok, Voided', x.get('ok') is True and x.get('voided') is True and q['path'] == '/v2/Payment/Void' and q['body'].get('ReferenceId') == r2, x)
    x = pj('dv_void(1, "NOPE123")'); ok('8 void of a payment the P5 does not have -> not ok (nothing changes)', x.get('ok') is False and x.get('status') == 'not_found', x)
    x = pj('dv_settle(dv_new_ref(), 30)'); t = (x.get('totals') or [{}])[0]
    ok('9 settle: ok + the P5 totals per batch (count, sale, return, total)', x.get('ok') is True and t.get('count', 0) >= 1 and t.get('sale', 0) >= 30 and 'total' in t and t.get('batch') == '1', x.get('totals'))
    x = pj('dv_void(25, "%s")' % ref); ok('9 void AFTER settle -> not ok (use Return)', x.get('ok') is False, x)
    x = pj('dv_return(25, dv_new_ref())'); q = reqs()[-1]; ok('9 return (money back, new ReferenceId): POST /v2/Payment/Return -> paid back', x.get('paid') is True and q['path'] == '/v2/Payment/Return' and q['body'].get('ReferenceId') != ref, x)
    x = pj('dv_abort("%s")' % ref); ok('10 abort: POST /v2/Payment/AbortTransaction -> ok', x.get('ok') is True and reqs()[-1]['path'] == '/v2/Payment/AbortTransaction', x)
    php('dv_set_creds("", "", "BADKEY0000");'); x = pj('dv_sale(10, 0, dv_new_ref())'); y = pj('dv_terminal_status()')
    ok('11 wrong Auth Key: not paid, "auth" (no Status loop), terminal Offline', x.get('paid') is False and x.get('status') == 'auth' and y.get('online') is False, (x, y))
    lg = php('echo setting("dv_log");'); aud = php('echo json_encode(q("SELECT * FROM audit_log")->fetchAll());'); err = open(D + '/php-err.log').read() if os.path.exists(D + '/php-err.log') else ''
    ok('12 Dejavoo journal kept (ref, amounts, result, Last4, card, AuthCode, PNReferenceId)', '"op":"sale"' in lg and '4242' in lg and ref in lg and '"pnref"' in lg, lg[:200])
    ok('12 the codes / card number NEVER in the journal, the audit or the PHP log', not any(s in t for s in ['AK12345678', 'BADKEY0000', 'REG01', '411111', '4111'] for t in [lg, aud, err]), '')
finally:
    srv.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
