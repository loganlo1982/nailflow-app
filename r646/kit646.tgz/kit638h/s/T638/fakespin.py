# LAMWEB 638a: FAKE Dejavoo SPIn Proxy (REST v2) for the kit – nothing real. Behaviour picked by the cents of Amount:
#   .01 declined 1015 · .02 cancelled 1012 · .03 charged but the answer comes too late · .04 charged, connection dropped · .05 never charged, too late
#   .06 partial approval 0001 · .07 taken by the P5 but answered 2008 (Status too: unsure) · .08 terminal in use 2008, never started · else approved. Same ReferenceId twice in a batch -> 1011. Wrong Authkey -> 2002.
#   .09 (638h) the sale stays open on the P5 longer than the app waits; Status meanwhile = 2008 busy; then approved. PaymentType must be a US one (UserChoice ...), same on Status / Void / Tip.
# Every request body is written to <dir>/req.log (the test checks what was sent).
import json, sys, time, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
PORT = int(sys.argv[1]); LOG = sys.argv[2]; AUTH = 'AK12345678'; TPN = '220926423654'
TX = {}; BATCH = {'n': 1}; LOCK = threading.Lock(); OPEN = set()  # 638h: a sale still waiting on the P5 (Status of it = 2008 busy, Dejavoo q6)
VALID_PT = {'Credit', 'Debit', 'EBT_Food', 'EBT_Cash', 'Gift', 'UserChoice'} | ({'Card'} if __import__('os').environ.get('FAKE_ALLOW_CARD') else set())  # only to show what the OLD code does  # 638h: 'Card' is refused like the real US P5 (Dejavoo q7)
def gr(rc, sc, msg='', delay=None): return {'GeneralResponse': {'HostResponseCode': '', 'HostResponseMessage': '', 'ResultCode': rc, 'StatusCode': sc, 'Message': msg, 'DetailedMessage': '', 'DelayBeforeNextRequest': delay}}
def full(t, typ):
    o = gr('0', '0000', 'Approved')
    o.update({'PaymentType': 'Credit', 'TransactionType': typ, 'Amounts': {'TotalAmount': round(t['amount'] + t['tip'], 2), 'Amount': t['amount'], 'TipAmount': t['tip'], 'FeeAmount': 0, 'TaxAmount': 0},
              'AuthCode': 'A' + t['ref'][-5:], 'ReferenceId': t['ref'], 'InvoiceNumber': t.get('inv', ''), 'SerialNumber': 'P5SN01', 'BatchNumber': str(BATCH['n']), 'TransactionNumber': str(t['no']),
              'Voided': t.get('voided', False), 'RRN': 'R' + t['ref'][-8:], 'PNReferenceId': 'PN' + t['ref'][-8:], 'CardData': {'CardType': 'Credit', 'EntryType': 'Contactless', 'Last4': '4242', 'First4': '4111', 'BIN': '411111', 'ExpirationDate': '', 'Name': '', 'CardBrand': 'Visa'}})
    return o
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def out(self, code, o):
        b = json.dumps(o).encode(); self.send_response(code); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        with open(LOG, 'a') as f: f.write(json.dumps({'path': u.path, 'query': {k: v[0] for k, v in q.items()}}) + '\n')
        if u.path != '/v2/Common/TerminalStatus': return self.out(404, {})
        ok = q.get('request.authkey', [''])[0] == AUTH and q.get('request.tpn', [''])[0] == TPN
        self.out(200, {'TerminalStatus': 'Online' if ok else 'Offline', 'Tpn': TPN if ok else '', 'ErrorDescription': '' if ok else 'Active AuthKey not found'})
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0); j = json.loads(self.rfile.read(n) or b'{}'); p = urlparse(self.path).path
        with open(LOG, 'a') as f: f.write(json.dumps({'path': p, 'body': j}) + '\n')
        if j.get('Authkey') != AUTH: return self.out(400, gr('2', '2002', 'Active AuthKey not found'))
        ref = str(j.get('ReferenceId', '')); amt = round(float(j.get('Amount') or 0), 2); cents = int(round(amt * 100)) % 100; wait = int(j.get('SPInProxyTimeout') or 120)
        if p in ('/v2/Payment/Sale', '/v2/Payment/Return'):
            if j.get('PaymentType') not in VALID_PT: return self.out(400, gr('1', '1014', 'Invalid Payment Type'))
            with LOCK:
                if ref in TX and TX[ref]['batch'] == BATCH['n']: return self.out(400, gr('1', '1011', 'Duplicate Reference ID'))
            if cents == 1: return self.out(400, gr('1', '1015', 'Declined'))
            if cents == 2: return self.out(400, gr('1', '1012', 'Cancelled'))
            if cents == 8: return self.out(400, gr('2', '2008', 'Terminal in use', 30))
            t = {'ref': ref, 'amount': amt, 'tip': round(float(j.get('TipAmount') or 0), 2), 'batch': BATCH['n'], 'no': len(TX) + 1, 'type': 'Sale' if p.endswith('Sale') else 'Return', 'inv': j.get('InvoiceNumber', ''), 'pt': j.get('PaymentType')}
            if cents == 9:  # 638h: the customer is still at the P5 - the answer comes after the app gave up; Status meanwhile = busy
                OPEN.add(ref); time.sleep(wait + 6)
                with LOCK: TX[ref] = t
                OPEN.discard(ref); return self.out(200, full(t, t['type']))
            if cents == 5: time.sleep(wait + 3); return self.out(400, gr('2', '2007', 'The operation has timed out'))
            with LOCK: TX[ref] = t
            if cents == 3: time.sleep(wait + 3); return self.out(200, full(t, t['type']))
            if cents == 4: self.connection.close(); return
            if cents == 7: return self.out(400, gr('2', '2008', 'Terminal in use', 30))
            if cents == 6: o = full(t, t['type']); o['GeneralResponse']['StatusCode'] = '0001'; o['GeneralResponse']['Message'] = 'Partial Approval'; o['Amounts']['Amount'] = round(amt / 2, 2); return self.out(200, o)
            return self.out(200, full(t, t['type']))
        if ref in OPEN and p != '/v2/Payment/AbortTransaction': return self.out(400, gr('2', '2008', 'Terminal in use', 30))
        t = TX.get(ref)
        if t and p in ('/v2/Payment/Status', '/v2/Payment/Void', '/v2/Payment/TipAdjust') and j.get('PaymentType') != t.get('pt'): return self.out(400, gr('1', '1001', 'Not Found'))  # 638h q6: same PaymentType as the sale
        if p == '/v2/Payment/Status':
            if t and int(round(t['amount'] * 100)) % 100 == 7: return self.out(400, gr('2', '2008', 'Terminal in use', 30))
            return self.out(200, full(t, t['type'])) if t else self.out(400, gr('1', '1001', 'Not Found'))
        if p == '/v2/Payment/Void':
            if not t: return self.out(400, gr('1', '1001', 'Not Found'))
            if t['batch'] != BATCH['n']: return self.out(400, gr('1', '1001', 'Not Found'))  # 638h q10: a sale no longer in the open batch -> Not found
            t['voided'] = True; return self.out(200, full(t, 'Void'))
        if p == '/v2/Payment/TipAdjust':
            if not t: return self.out(400, gr('1', '1001', 'Not Found'))
            t['tip'] = round(float(j.get('TipAmount') or 0), 2); return self.out(200, full(t, 'TipAdjust'))
        if p == '/v2/Report/Daily':
            with LOCK:
                rows = [{'Number': x['no'], 'ReferenceId': x['ref'], 'CardType': 'Visa', 'TransactionType': ('Void' if x.get('voided') else x['type']), 'Last4': '4242', 'Amount': round(x['amount'] + x['tip'], 2)} for x in TX.values() if x['batch'] == BATCH['n']]
                o = gr('0', '0000', 'Approved'); o['DailyDetails'] = [{'MerchantNumber': 1, 'Application': 'Credit', 'TotalAmount': None, 'TransactionsDailyReports': rows}]
            return self.out(200, o)
        if p == '/v2/Payment/AbortTransaction': return self.out(200, gr('0', '0000', 'Aborted'))
        if p == '/v2/Payment/Settle':
            with LOCK:
                cur = [x for x in TX.values() if x['batch'] == BATCH['n'] and not x.get('voided')]
                sale = round(sum(x['amount'] + x['tip'] for x in cur if x['type'] == 'Sale'), 2); ret = round(sum(x['amount'] for x in cur if x['type'] == 'Return'), 2)
                o = gr('0', '0000', 'Approved'); o['SettleDetails'] = [{'MerchantNumber': 1, 'MerchantName': 'TEST', 'Application': 'Credit', 'DetailedMessage': '', 'BatchNumber': str(BATCH['n']), 'HostStatus': 'OK',
                    'TransactionsReports': {'TransactionsCount': len(cur), 'SaleAmount': sale, 'ReturnAmount': ret, 'VoidAmount': 0, 'AuthAmount': 0, 'TicketAmount': 0, 'ReversalAmount': 0, 'CashAdvanceAmount': 0, 'TotalAmount': round(sale - ret, 2)}, 'Receipt': ''}]
                BATCH['n'] += 1
            return self.out(200, o)
        self.out(404, gr('2', '2006', 'Not pars request'))
ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
