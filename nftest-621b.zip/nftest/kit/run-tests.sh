#!/bin/bash
# LAMWEB 618 - one command for ALL the tests on a local copy (nothing real: fake Telnyx / SignalWire / STT / AI, texts to a table, SQLite of its own).
#   ./run-tests.sh <app folder>            all suites
#   ./run-tests.sh <app folder> telnyx sw  some suites (names below)
# Each suite gets its OWN fresh copy of the app (the app folder itself is never changed). Results: run/logs/<suite>.txt + run/SUMMARY.txt
# A FAIL line that is in baseline/<suite>.txt is an OLD known one (it fails on LIVE 2.99.613 too, written down there with the reason);
# any other FAIL = NEW -> exit code 1 (the package is not sent).
set -u
K=$(cd "$(dirname "$0")" && pwd); [ $# -ge 1 ] || { echo "usage: $0 <app folder> [suite...]"; exit 2; }
APP=$(cd "$1" && pwd) || exit 2; shift
ALL="aicall telnyx telnyx615 review622 mod619 pay619 book610 sw605b sw602b sw590 sw624 book611a book620 turn609"; SU=${*:-$ALL}
R=$K/run; rm -rf "$R"; mkdir -p "$R/logs"; cp -a "$K/s/." "$R/"
grep -rl --include='*.py' --include='*.js' --include='*.php' '/tmp/claude-0' "$R" | xargs sed -i "s#/tmp/claude-0#$R#g"
export TZ=America/Chicago
export PHP_INI_SCAN_DIR="${PHP_INI_SCAN_DIR:-}:$K/phpini"   # (621-B) the kit's own PHP settings on top of the server's (errors -> stderr, exec on) – see phpini/zz-nftest.ini
# (621 A3) DONG HO GIA: moi test thay CUNG 1 gio co dinh (mac dinh Thu Tu 2026-11-04 10:00 CST, doi bang NF_TEST_NOW="YYYY-MM-DD HH:MM"), khong phu thuoc gio may
CK="$K/clock/nfclock.so"; [ -f "$CK" ] || gcc -shared -fPIC -O2 -o "$CK" "$K/clock/nfclock.c" -ldl 2>/dev/null
if [ -f "$CK" ]; then export NF_FAKE_T0=$(date +%s) NF_FAKE_NOW=$(date -d "${NF_TEST_NOW:-2026-11-04 10:00}" +%s) LD_PRELOAD="$CK"; CLK="gio gia ${NF_TEST_NOW:-2026-11-04 10:00}"; else CLK="!! KHONG co gcc: dung GIO MAY (vai test phu thuoc ngay)"; fi
mk() { local d="$R/app-$1"; rm -rf "$d"; cp -a "$APP" "$d"; sed -i "s#'/usr/bin/mpg123'#'$R/T616/mpg123'#g" "$d/inc/calls-tx.php" 2>/dev/null; echo "$d"; }
run() { local n=$1; shift; local t0=$(date +%s); timeout 300 "$@" > "$R/logs/$n.txt" 2>&1; local rc=$?; local dt=$(( $(date +%s) - t0 ))
  local pass=$(grep -c '^✓' "$R/logs/$n.txt"); local fail=$(grep -c '^✗' "$R/logs/$n.txt"); local new=0
  if [ -f "$K/baseline/$n.txt" ]; then new=$(grep '^✗' "$R/logs/$n.txt" | cut -c1-80 | grep -vxF -f <(cut -c1-80 "$K/baseline/$n.txt") | wc -l); else new=$fail; fi
  [ $((pass + fail)) -eq 0 ] && new=1
  printf '%-10s PASS %3d  FAIL %3d  (FAIL MOI %d)  %3ds%s\n' "$n" "$pass" "$fail" "$new" "$dt" "$([ $rc -ne 0 ] && echo "  rc=$rc")" | tee -a "$R/SUMMARY.txt"
  [ "$new" -eq 0 ] || grep '^✗' "$R/logs/$n.txt" | cut -c1-80 | grep -vxF -f <(cut -c1-80 "$K/baseline/$n.txt" 2>/dev/null || true) | sed 's/^/      MOI: /' | tee -a "$R/SUMMARY.txt"
  TOTNEW=$((TOTNEW + new)); TOTP=$((TOTP + pass)); TOTF=$((TOTF + fail)); }
TOTNEW=0; TOTP=0; TOTF=0
echo "== run-tests $(LD_PRELOAD= date '+%Y-%m-%d %H:%M %Z') · $CLK · app: $APP · version: $(grep -o "APP_VERSION', '[^']*" "$APP/inc/core.php" 2>/dev/null | cut -d"'" -f3)" | tee "$R/SUMMARY.txt"
echo "   sha calls-tx $(sha256sum "$APP/inc/calls-tx.php" | cut -c1-8) · calls-job $(sha256sum "$APP/inc/calls-job.php" | cut -c1-8) · calls-agent $(sha256sum "$APP/inc/calls-agent.php" | cut -c1-8) · call_tx $(sha256sum "$APP/call_tx.php" | cut -c1-8)" | tee -a "$R/SUMMARY.txt"
echo "   moi truong: $(php -r 'echo "PHP ", PHP_VERSION, " · SQLite ", (new PDO("sqlite::memory:"))->query("select sqlite_version()")->fetchColumn(), " · display_errors=", ini_get("display_errors"), " · error_log=", ini_get("error_log") === "" ? "(stderr)" : ini_get("error_log"), " · exec ", function_exists("exec") ? "co" : "TAT";' 2>&1 | head -c 300) · ffmpeg $(command -v ffmpeg >/dev/null && echo co || echo KHONG) · mpg123 $(ls /usr/bin/mpg123 /bin/mpg123 2>/dev/null | head -1 || true) · node $(command -v node >/dev/null && echo co || echo KHONG)" | tee -a "$R/SUMMARY.txt"
for b in aicall; do [ -s "$K/baseline/$b.txt" ] || echo "!! THIEU baseline/$b.txt (S4 se bi tinh la loi MOI) – chep lai thu muc baseline/ cua kit" | tee -a "$R/SUMMARY.txt"; done
for s in $SU; do case $s in
  aicall)    a=$(mk $s); cd "$R/T612" && rm -rf calls/txg-* conv "$a-salonB"; run aicall python3 "$R/T618/sim.py" "$a"; cd "$K" ;;
  telnyx)    a=$(mk $s); cd "$R/T612" && rm -f calls/txg-* calls/txh-* calls/.tx-clean; run telnyx python3 "$R/T616/t616full.py" "$a"; cd "$K" ;;
  telnyx615) a=$(mk $s); rm -f "$R"/T612/calls/txg-*; run telnyx615 python3 "$R/T615/t616.py" "$a" ;;
  review622) a=$(mk $s); run review622 python3 "$R/T622/t622.py" "$a" ;;
  book610)   a=$(mk $s); cd "$R/T610" && NF_FAKE_NOW=$(date -d '2026-11-01 10:00' +%s) APP="$a" run book610 python3 "$R/T610/a610.py"; cd "$K" ;; # gio gia = 01/11 10:00 (ngay doi gio) cho muc 10 DST
  mod619)    a=$(mk $s); run mod619 python3 "$R/T619/t619m.py" "$a" ;;
  pay619)    a=$(mk $s); run pay619 python3 "$R/T619P/t619p.py" "$a" ;;
  sw624)     a=$(mk $s); run sw624 python3 "$R/T624/t624.py" "$a" ;;
  sw605)     a=$(mk $s); run sw605 python3 "$R/T605/t605.py" "$a" ;;
  sw605b)    a=$(mk $s); run sw605b python3 "$R/T605B/t605b.py" "$a" ;;
  sw602b)    a=$(mk $s); run sw602b python3 "$R/T586/t602b.py" "$a" ;;
  sw590)     a=$(mk $s); run sw590 python3 "$R/T586/t590.py" "$a" ;;
  book611a)  a=$(mk $s); b=$(mk $s-base); run book611a node "$R/T611A/t611a.js" "$a" "$b" 19960 "$R/out611a" ;;
  book620)   a=$(mk $s); b=$(mk $s-base); cp "$K/s/T620/base-book-2.js" "$b/assets/book-2.js" 2>/dev/null; cp "$K/s/T620/base-book-2.css" "$b/assets/book-2.css" 2>/dev/null; run book620 node "$R/T620/t620.js" "$a" "$b" 19970 "$R/out620" ;;
  turn609)   a=$(mk $s); run turn609 node "$R/T609/ui609.js" "$a" ;;
  *) echo "unknown suite $s (known: $ALL)" ;;
esac; done
echo "== TONG: PASS $TOTP · FAIL $TOTF · FAIL MOI $TOTNEW  -> $([ $TOTNEW -eq 0 ] && echo 'OK (chi con FAIL cu da biet)' || echo 'CO FAIL MOI - KHONG GUI GOI')" | tee -a "$R/SUMMARY.txt"
[ $TOTNEW -eq 0 ]
