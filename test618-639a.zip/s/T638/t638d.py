# LAMWEB test 638d - Void / Refund of a receipt paid on the P5: the P5 gives the money back by itself (Void same batch, Return after the batch closed /
#   for a part); the P5 says no -> the receipt is NOT changed; a normal card receipt still needs "Done on DPS".
# Fake SPIn Proxy (fakespin.py) + a local copy with its own SQLite (T586 seed: Pedicure $35, Gel Manicure $40, Full Set $50). Nothing real.
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T638'; T5 = '/tmp/claude-0/T586'; SH = int(os.environ.get('NF_PORT_SHIFT', 0)); PORT = 19904 + SH; FP = 19905 + SH
R = []; out = open(D + '/test-638d.txt', 'w'); ENV = {**os.environ, 'TZ': 'America/Chicago'}
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
A = D + '/appd'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True); DB = D + '/dbd.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; TT = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA = TT['TAMMY']
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d','dv_base'=>'http://127.0.0.1:%d','dv_slack'=>2,'dv_wait'=>2);\n" % (DB, PORT, FP))
def php(code):
    r = sh('php', '-d', 'error_log=' + D + '/phpd-err.log', '-r', 'require "%s/inc/core.php"; settings(); %s' % (A, code)); return (r.stdout + r.stderr).strip()
PW = 'adm638-' + os.urandom(3).hex(); php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % PW)
LOG = D + '/req-d.log'; open(LOG, 'w').close()
fk = subprocess.Popen(['python3', D + '/fakespin.py', str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpd.log', 'w'))
atexit.register(lambda: (sv.terminate(), fk.terminate())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
NUM = [0]
def appt(sid=None):
    NUM[0] += 1; ph = '+155555501%02d' % (40 + NUM[0])
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'P5 TEST %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tk%d')" % (time.strftime('%Y-%m-%d'), 600 + NUM[0] * 5, TA, sid or PD, NUM[0], ph, NUM[0]))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def co(aid, pays, sid=None, price=35):
    return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid or PD, 'price': price, 'staff': TA}], 'pays': pays})
def sales(): return [json.loads(l) for l in open(LOG) if '/v2/Payment/Sale' in l]
def pend(): return json.loads(php('echo setting("dv_pend");') or '{}')
def calls(p): return [json.loads(l) for l in open(LOG) if p in l]
def rcpt(rid): x = sql("SELECT status, pays, void_reason FROM receipts WHERE id = %d" % rid); return x[0] if x else {}
def paid(price=35, amt=None, sid=None):
    a = appt(sid); c, v = api('dv_charge', {'ids': [a], 'amt': amt or price}); c2, r = co(a, [{'m': 'Card', 'amt': amt or price, 'dv_ref': v.get('ref', '')}], sid=sid, price=price)
    return int(((r or {}).get('receipt') or {}).get('id', 0)), v.get('ref', '')
try:
    say('== LAMWEB test 638d - void / refund on the P5 (fake proxy) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
    php('require_once "%s/inc/dejavoo.php"; dv_set_creds("220926423654", "REG01", "AK12345678"); set_setting("dv_on", "1");' % A)
    a0 = appt(); c, r = co(a0, [{'m': 'Card', 'amt': 35, 'last4': '1111'}]); r0 = int(r['receipt']['id'])
    c, r = api('receipt_void', {'id': r0, 'reason': 'test dps', 'dps_done': False}); ok('1 a NORMAL card receipt (not P5): Void still needs "Done on DPS" (unchanged)', c == 400 and 'DPS' in r.get('error', ''), (c, r))
    rid, ref = paid(); n0 = len(calls('/v2/Payment/Void'))
    c, r = api('receipt_void', {'id': rid, 'reason': 'test p5 void', 'dps_done': False}); vv = calls('/v2/Payment/Void')
    ok('2 P5 receipt Void: no tick needed – the P5 Void with its ReferenceId + amount -> receipt VOID, reason "back on the P5"', c == 200 and len(vv) == n0 + 1 and vv[-1]['body']['ReferenceId'] == ref and vv[-1]['body']['Amount'] == 35 and rcpt(rid).get('status') == 'void' and 'P5' in rcpt(rid).get('void_reason', ''), (c, r, rcpt(rid)))
    ok('2 the P5 payment is marked voided', pend()[ref]['st'] == 'voided', pend().get(ref))
    rid2, ref2 = paid(price=40, sid=GM); n1 = len(calls('/v2/Payment/Return'))
    c, r = api('receipt_refund', {'id': rid2, 'amount': 10, 'how': 'Card', 'dps_done': False, 'reason': 'part back'}); rr = calls('/v2/Payment/Return')
    ok('3 refund $10 of a $40 P5 receipt: P5 Return $10 (new ReferenceId) -> refund saved', c == 200 and len(rr) == n1 + 1 and rr[-1]['body']['Amount'] == 10 and rr[-1]['body']['ReferenceId'] != ref2, (c, str(r)[:200]))
    c, r = api('receipt_refund', {'id': rid2, 'amount': 10.01, 'how': 'Card', 'dps_done': False, 'reason': 'declined back'}); st = sql("SELECT refunds FROM receipts WHERE id = %d" % rid2)
    ok('4 the P5 declines the Return -> 402, the refund NOT saved', c == 402 and 'NOT changed' in r.get('error', ''), (c, r))
    rid3, ref3 = paid(price=50, sid=S['Full Set']); php('require_once "%s/inc/dejavoo.php"; dv_settle(dv_new_ref(), 30);' % A); n2 = len(calls('/v2/Payment/Return'))
    c, r = api('receipt_void', {'id': rid3, 'reason': 'after settle', 'dps_done': False}); rr = calls('/v2/Payment/Return')
    ok('5 Void AFTER the batch closed: P5 Void says no -> Return $50 (customer taps) -> receipt VOID, payment "returned"', c == 200 and len(rr) == n2 + 1 and rr[-1]['body']['Amount'] == 50 and rcpt(rid3).get('status') == 'void' and pend()[ref3]['st'] == 'returned', (c, str(r)[:200], pend().get(ref3)))
    rid4, ref4 = paid(price=35); c, r = api('receipt_refund', {'id': rid4, 'amount': 35, 'how': 'Card', 'dps_done': False, 'reason': 'all back'}); vv = calls('/v2/Payment/Void')
    ok('6 refund ALL of a P5 receipt in the same batch: P5 Void (no card needed)', c == 200 and vv[-1]['body']['ReferenceId'] == ref4 and pend()[ref4]['st'] == 'voided', (c, str(r)[:200]))
    rid7, ref7 = paid(price=35); c, r = api('receipt_tips_edit', {'id': rid7, 'tips': [{'staff': TA, 'amt': 5}], 'tip_total': 5, 'cash_tips': [], 'cash_tip_total': 0})
    ok('6b a P5 receipt: its CARD tip cannot be changed after (the P5 would not match) – says use a cash tip / void', c == 400 and 'P5' in r.get('error', ''), (c, r))
    c, r = api('receipt_tips_edit', {'id': rid7, 'tips': [], 'tip_total': 0, 'cash_tips': [{'staff': TA, 'amt': 5}], 'cash_tip_total': 5}); ok('6b ... a cash tip on it is fine', c == 200, (c, r))
    a8 = appt(); c, v8 = api('dv_charge', {'ids': [a8], 'amt': 35}); c, r8 = co(a8, [{'m': 'Card', 'amt': 35, 'dv_ref': v8.get('ref', '')}, {'m': 'Cash', 'amt': 20}], price=55); rid8 = int(((r8 or {}).get('receipt') or {}).get('id', 0))
    n8 = len(calls('/v2/Payment/Return')); c, r = api('receipt_refund', {'id': rid8, 'amount': 50, 'how': 'Card', 'dps_done': False, 'reason': 'more than P5'})
    ok('6c (638d2) $35 on the P5 + $20 cash: a $50 CARD refund -> refused (at most $35 on the card), the P5 NOT asked', rid8 and c == 400 and '35' in r.get('error', '') and len(calls('/v2/Payment/Return')) == n8, (rid8, c, r))
    rid6, ref6 = paid(price=35); php('set_setting("dv_auth", "");')
    c, r = api('receipt_void', {'id': rid6, 'reason': 'p5 gone', 'dps_done': True}); ok('7 P5 not set up any more: a P5 receipt is NOT voided (says why), nothing changed', c == 409 and rcpt(rid6).get('status') == 'paid', (c, r))
    js = open(A + '/assets/admin/checkout-receipt.js', encoding='utf-8').read()
    ok('8 screen: a P5 receipt shows "goes back on the P5 by itself" (no tick), the others the DPS tick as before; void / refund wait for the P5', 'const isP5 =' in js and 'Done on DPS' in js and "isP5 /* (2.99.638d)" in js and "isP5 && how === 'Card'" in js, '')
    r = subprocess.run(['node', '--check', A + '/assets/admin/checkout-receipt.js'], capture_output=True, text=True); ok('8 checkout-receipt.js: no syntax error', r.returncode == 0, r.stderr[:200])
    allaud = php('echo json_encode(q("SELECT * FROM audit_log")->fetchAll());'); ok('9 audit: P5 void / return rows, never the codes', 'P5 void' in allaud and 'P5 return' in allaud and 'AK12345678' not in allaud, '')
    err = open(D + '/phpd.log').read() + (open(D + '/phpd-err.log').read() if os.path.exists(D + '/phpd-err.log') else '')
    ok('10 no PHP Warning / Fatal', not any(x in err for x in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in err.splitlines() if 'PHP' in l][:3])
finally:
    sv.terminate(); fk.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
