# LAMWEB test 638e - Close day -> "Check the P5": the P5's open batch payment by payment vs the app's P5 payments; differences in plain words (reads only).
# Fake SPIn Proxy (fakespin.py) + a local copy with its own SQLite (T586 seed: Pedicure $35, Gel Manicure $40, Full Set $50). Nothing real.
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T638'; T5 = '/tmp/claude-0/T586'; SH = int(os.environ.get('NF_PORT_SHIFT', 0)); PORT = 19906 + SH; FP = 19907 + SH
R = []; out = open(D + '/test-638e.txt', 'w'); ENV = {**os.environ, 'TZ': 'America/Chicago'}
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
A = D + '/appe'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True); DB = D + '/dbe.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; TT = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA = TT['TAMMY']
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d','dv_base'=>'http://127.0.0.1:%d','dv_slack'=>2,'dv_wait'=>2);\n" % (DB, PORT, FP))
def php(code):
    r = sh('php', '-d', 'error_log=' + D + '/phpe-err.log', '-r', 'require "%s/inc/core.php"; settings(); %s' % (A, code)); return (r.stdout + r.stderr).strip()
PW = 'adm638-' + os.urandom(3).hex(); php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % PW)
LOG = D + '/req-e.log'; open(LOG, 'w').close()
fk = subprocess.Popen(['python3', D + '/fakespin.py', str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpe.log', 'w'))
atexit.register(lambda: (sv.terminate(), fk.terminate())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
NUM = [0]
def appt(sid=None):
    NUM[0] += 1; ph = '+155555501%02d' % (40 + NUM[0])
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'P5 TEST %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tk%d')" % (time.strftime('%Y-%m-%d'), 600 + NUM[0] * 5, TA, sid or PD, NUM[0], ph, NUM[0]))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def co(aid, pays, sid=None, price=35):
    return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid or PD, 'price': price, 'staff': TA}], 'pays': pays})
def sales(): return [json.loads(l) for l in open(LOG) if '/v2/Payment/Sale' in l]
def pend(): return json.loads(php('echo setting("dv_pend");') or '{}')
def paid(price=35, sid=None):
    a = appt(sid); c, v = api('dv_charge', {'ids': [a], 'amt': price}); c2, r = co(a, [{'m': 'Card', 'amt': price, 'dv_ref': v.get('ref', '')}], sid=sid, price=price); return v.get('ref', '')
def day(): c, x = api('dv_day'); return c, x
def whats(x): return sorted(i['what'] for i in x.get('issues', []))
def setp(ref, **kw): php('require_once "%s/inc/dejavoo-pay.php"; dv_pend_put(%s, %s);' % (A, json.dumps(ref), 'json_decode(%s, true)' % json.dumps(json.dumps(kw))))
try:
    say('== LAMWEB test 638e - close day P5 check (fake proxy) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
    TD = time.strftime('%Y-%m-%d'); c, d = api('close_day', None, '&day=' + TD); ok('1 P5 OFF: Close day says dvOn false (no P5 box), the rest as before', c == 200 and d.get('dvOn') is False and 'techs' in d, (c, str(d)[:120]))
    c, x = day(); ok('1 OFF: dv_day says off, asks nothing', c == 200 and x.get('ok') is False and not [l for l in open(LOG) if 'Report/Daily' in l], (c, x))
    php('require_once "%s/inc/dejavoo.php"; dv_set_creds("220926423654", "REG01", "AK12345678"); set_setting("dv_on", "1");' % A)
    c, d = api('close_day', None, '&day=' + TD); ok('2 ON: Close day says dvOn true', d.get('dvOn') is True, str(d)[:100])
    r1 = paid(35); r2 = paid(40, GM); c, x = day()
    ok('2 two receipts paid on the P5: the P5 batch $75 = the app, no difference', c == 200 and x.get('ok') is True and (x.get('p5') or {}).get('total') == 75 and x.get('issues') == [], (c, x))
    ok('2 reads only: POST /v2/Report/Daily, nothing charged / settled', [l for l in open(LOG) if 'Report/Daily' in l] and not [l for l in open(LOG) if 'Payment/Settle' in l], '')
    a3 = appt(); c, v3 = api('dv_charge', {'ids': [a3], 'amt': 50}); c, x = day()
    ok('3 approved on the P5, no receipt yet -> "not on a receipt yet"', whats(x) == ['waiting'] and any(str(50) in i['say'] for i in x['issues']), x.get('issues'))
    setp(v3['ref'], st='failed'); c, x = day(); ok('4 the P5 TOOK the money but NailFlow has it as failed -> "The P5 TOOK ... no receipt"', whats(x) == ['charged_no_receipt'] and 'TOOK' in x['issues'][0]['say'], x.get('issues'))
    setp(v3['ref'], st='void'); php('require_once "%s/inc/dejavoo.php"; dv_sale(12, 0, "MANUAL001");' % A); c, x = day()
    ok('5 a sale typed on the P5 by hand (not from NailFlow) + one cancelled in NailFlow but still a sale on the P5 -> both listed', whats(x) == ['p5_only', 'void_missing'], x.get('issues'))
    setp(r1, amt=36); c, x = day(); ok('6 the receipt amount differs from the P5 -> "amount"', 'amount' in whats(x), x.get('issues'))
    setp(r1, amt=35); php('require_once "%s/inc/dejavoo.php"; dv_settle(dv_new_ref(), 30);' % A); c, x = day()
    ok('7 after the P5 batch closed: today\'s P5 receipts not in the (new, empty) batch -> listed "already settled?"', whats(x).count('app_only') == 2 and (x.get('p5') or {}).get('total') == 0, x.get('issues'))
    php('set_setting("dv_auth", "");'); c, x = day(); ok('8 P5 not set up / not answering: "not checked" with the reason (Close day still works)', c == 200 and x.get('ok') is False and x.get('msg'), (c, x))
    js = open(A + '/assets/admin/giftcards.js', encoding='utf-8').read()
    ok('9 screen: Close day shows the P5 box only when dvOn; it asks dv_day and lists the differences', 'async function dvDayFill(el)' in js and "d.dvOn && form ?" in js and "dvDayFill($('#cdP5', sh))" in js, '')
    r = subprocess.run(['node', '--check', A + '/assets/admin/giftcards.js'], capture_output=True, text=True); ok('9 giftcards.js: no syntax error', r.returncode == 0, r.stderr[:200])
    err = open(D + '/phpe.log').read() + (open(D + '/phpe-err.log').read() if os.path.exists(D + '/phpe-err.log') else '')
    ok('10 no PHP Warning / Fatal', not any(x in err for x in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in err.splitlines() if 'PHP' in l][:3])
finally:
    sv.terminate(); fk.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
