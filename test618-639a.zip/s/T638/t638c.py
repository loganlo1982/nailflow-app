# LAMWEB test 638c - Checkout -> Card -> "Card on the P5": the P5 first, the receipt after; one P5 payment per ticket (never twice); off = as before.
# Fake SPIn Proxy (fakespin.py) + a local copy with its own SQLite (T586 seed: Pedicure $35, Gel Manicure $40, Full Set $50). Nothing real.
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T638'; T5 = '/tmp/claude-0/T586'; SH = int(os.environ.get('NF_PORT_SHIFT', 0)); PORT = 19902 + SH; FP = 19903 + SH
R = []; out = open(D + '/test-638c.txt', 'w'); ENV = {**os.environ, 'TZ': 'America/Chicago'}
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
A = D + '/appc'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True); DB = D + '/dbc.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; TT = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA = TT['TAMMY']
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d','dv_base'=>'http://127.0.0.1:%d','dv_slack'=>2,'dv_wait'=>2);\n" % (DB, PORT, FP))
def php(code):
    r = sh('php', '-d', 'error_log=' + D + '/phpc-err.log', '-r', 'require "%s/inc/core.php"; settings(); %s' % (A, code)); return (r.stdout + r.stderr).strip()
PW = 'adm638-' + os.urandom(3).hex(); php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % PW)
LOG = D + '/req-c.log'; open(LOG, 'w').close()
fk = subprocess.Popen(['python3', D + '/fakespin.py', str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpc.log', 'w'))
atexit.register(lambda: (sv.terminate(), fk.terminate())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
NUM = [0]
def appt(sid=None):
    NUM[0] += 1; ph = '+155555501%02d' % (40 + NUM[0])
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'P5 TEST %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tk%d')" % (time.strftime('%Y-%m-%d'), 600 + NUM[0] * 5, TA, sid or PD, NUM[0], ph, NUM[0]))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def co(aid, pays, sid=None, price=35):
    return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid or PD, 'price': price, 'staff': TA}], 'pays': pays})
def sales(): return [json.loads(l) for l in open(LOG) if '/v2/Payment/Sale' in l]
def pend(): return json.loads(php('echo setting("dv_pend");') or '{}')
try:
    say('== LAMWEB test 638c - Checkout card on the P5 (fake proxy) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
    a1 = appt(); c, t = api('ticket', None, '&id=%d' % a1)
    ok('1 P5 OFF (default): the ticket says dvOn false', c == 200 and t.get('dvOn') is False, (c, str(t)[:150]))
    c, r = co(a1, [{'m': 'Card', 'amt': 35, 'last4': '1111'}]); ok('1 OFF: Card checkout exactly as before (receipt, last 4 typed), nothing sent to a P5', c == 200 and r.get('receipt') and not sales(), (c, str(r)[:200]))
    c, r = api('dv_charge', {'ids': [appt()], 'amt': 35}); ok('1 OFF: dv_charge refused ("off")', c == 400 and 'off' in r.get('error', ''), (c, r))
    php('require_once "%s/inc/dejavoo.php"; dv_set_creds("220926423654", "REG01", "AK12345678"); set_setting("dv_on", "1");' % A)
    a2 = appt(); c, t = api('ticket', None, '&id=%d' % a2); ok('2 P5 ON: the ticket says dvOn true (the "Card on the P5" box shows)', t.get('dvOn') is True, str(t)[:100])
    c, v = api('dv_charge', {'ids': [a2], 'amt': 35}); n1 = len(sales())
    ok('3 Pay: the P5 approves $35 -> ref + Last4 4242 + Visa + AuthCode', c == 200 and v.get('ref') and v.get('last4') == '4242' and v.get('card') == 'Visa' and v.get('auth_code'), (c, v))
    c2, v2 = api('dv_charge', {'ids': [a2], 'amt': 35}); ok('4 Pay tapped again (same ticket, same amount): the SAME payment back, the P5 not asked again', c2 == 200 and v2.get('ref') == v.get('ref') and v2.get('again') is True and len(sales()) == n1, (c2, v2, len(sales()), n1))
    c, r = co(a2, [{'m': 'Card', 'amt': 36, 'dv_ref': v['ref']}], price=36); ok('5 the receipt with a DIFFERENT card amount than the P5 took -> refused, no receipt, the payment still waits', c == 409 and pend()[v['ref']]['st'] == 'paid', (c, r))
    c, r = co(a2, [{'m': 'Card', 'amt': 35, 'dv_ref': v['ref']}]); rc = (r or {}).get('receipt') or {}
    rows = sql("SELECT pays FROM receipts ORDER BY id DESC LIMIT 1"); pz = json.loads(rows[0]['pays']) if rows else []
    ok('6 receipt saved: Card $35 ··4242 with the P5 details (ref, auth, pnref, card) – no "Done on DPS" needed', c == 200 and pz and pz[0].get('last4') == '4242' and pz[0].get('dv', {}).get('ref') == v['ref'] and pz[0]['dv'].get('auth') and pz[0]['dv'].get('pnref') and pz[0]['dv'].get('amt') == 35, (c, str(r)[:200], pz))
    ok('6 the P5 payment is now "used" (on that receipt)', pend()[v['ref']]['st'] == 'used', pend().get(v['ref']))
    a3 = appt(); c, r = co(a3, [{'m': 'Card', 'amt': 35, 'dv_ref': v['ref']}]); ok('7 the same P5 payment on ANOTHER ticket -> refused (used / other ticket)', c == 409 and not r.get('receipt'), (c, r))
    c, r = api('dv_charge', {'ids': [a3], 'amt': 35.01}); ok('8 card declined on the P5 -> no payment, clear reason (402), nothing to use', c == 402 and 'declined' in r.get('error', '').lower(), (c, r))
    c, r = api('dv_charge', {'ids': [a3], 'amt': 35.02}); ok('8 cancelled on the P5 -> no payment, says so', c == 402 and 'cancel' in r.get('error', '').lower(), (c, r))
    c, v3 = api('dv_charge', {'ids': [a3], 'amt': 35}); c4, r4 = api('dv_charge', {'ids': [a3], 'amt': 40})
    ok('9 ticket changed after the P5 took $35 (now $40): refused, says the P5 already took $35 (dvPaid) – never a 2nd charge', c == 200 and c4 == 409 and 'already took' in r4.get('error', '') and (r4.get('dvPaid') or {}).get('ref') == v3.get('ref'), (c4, r4))
    c, w = api('dv_waiting'); ok('9 the desk can see it: approved on the P5, not on a receipt yet', any(x.get('ref') == v3.get('ref') for x in w.get('waiting', [])), w)
    c, r = api('dv_cancel', {'ref': v3['ref']}); vd = [json.loads(l) for l in open(LOG) if '/v2/Payment/Void' in l]
    ok('9 "Cancel on the P5": Void with its ReferenceId -> ok, the payment is void', c == 200 and pend()[v3['ref']]['st'] == 'void' and vd and vd[-1]['body']['ReferenceId'] == v3['ref'], (c, r))
    c, v4 = api('dv_charge', {'ids': [a3], 'amt': 40}); c, r = co(a3, [{'m': 'Card', 'amt': 40, 'dv_ref': v4.get('ref', '')}], price=40)
    ok('9 then $40 on the P5 -> receipt $40', c == 200 and r.get('receipt'), (c, str(r)[:150]))
    a5 = appt(); c, v5 = api('dv_charge', {'ids': [a5], 'amt': 50.03})
    ok('10 the P5 answer came too late (charged): Status finds it -> paid (not "declined", not charged again)', c == 200 and v5.get('ref') and len([s for s in sales() if s['body']['ReferenceId'] == v5.get('ref')]) == 1, (c, v5))
    c, r = co(a5, [{'m': 'Card', 'amt': 50.03, 'dv_ref': v5['ref']}], sid=S['Full Set'], price=50.03); ok('10 ... and its receipt', c == 200 and r.get('receipt'), (c, str(r)[:150]))
    c, r = api('dv_cancel', {'ref': v['ref']}); ok('11 a payment already on a receipt cannot be cancelled here (refund = 638d)', c == 404, (c, r))
    aud = php('echo json_encode(q("SELECT kind, target, after_v FROM audit_log WHERE kind = \'dejavoo\'")->fetchAll());'); allaud = php('echo json_encode(q("SELECT * FROM audit_log")->fetchAll());')
    ok('12 audit: each P5 approval + the void, with ref / ··4242 / auth – never the Auth Key / Register ID', aud.count('approved') >= 3 and 'void' in aud and 'AK12345678' not in allaud and 'REG01' not in allaud, aud[:300])
    php('set_setting("dv_on", "0");'); a6 = appt(); c, r = api('dv_charge', {'ids': [a6], 'amt': 35}); c2, t = api('ticket', None, '&id=%d' % a6)
    ok('13 turned OFF again: no P5, the ticket box gone, Card as before', c == 400 and t.get('dvOn') is False, (c, r))
    js = open(A + '/assets/admin/checkout-2d.js', encoding='utf-8').read(); jb = open(A + '/assets/admin/checkout-2b.js', encoding='utf-8').read()
    ok('14 screen: the box only when the ticket says dvOn; Pay sends the card part to the P5 first, then checkout2 with dv_ref', "function dvBox()" in js and "if (!window.DV_ON) return ''" in js and "dvP.dv_ref = v.ref" in js and jb.count('dvBox()') == 2, '')
    r = subprocess.run(['node', '--check', A + '/assets/admin/checkout-2d.js'], capture_output=True, text=True); r2 = subprocess.run(['node', '--check', A + '/assets/admin/checkout-2b.js'], capture_output=True, text=True)
    ok('14 checkout-2b.js / checkout-2d.js: no syntax error', r.returncode == 0 and r2.returncode == 0, (r.stderr + r2.stderr)[:200])
    err = open(D + '/phpc.log').read() + (open(D + '/phpc-err.log').read() if os.path.exists(D + '/phpc-err.log') else '')
    ok('15 no PHP Warning / Fatal', not any(x in err for x in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in err.splitlines() if 'PHP' in l][:3])
finally:
    sv.terminate(); fk.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
