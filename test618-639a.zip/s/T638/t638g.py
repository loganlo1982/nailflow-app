# LAMWEB test 638g - Tap to Pay on iPhone (server side): the app sends the Dejavoo answer (Spin_Response, like the docs' Sample Responses) -> a payment of the
#   ticket -> the receipt like 638c; the same RefId never twice; not approved = nothing; its void / refund never go to the P5.
# Fake SPIn Proxy (fakespin.py) + a local copy with its own SQLite (T586 seed: Pedicure $35, Gel Manicure $40, Full Set $50). Nothing real.
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T638'; T5 = '/tmp/claude-0/T586'; SH = int(os.environ.get('NF_PORT_SHIFT', 0)); PORT = 19908 + SH; FP = 19909 + SH
R = []; out = open(D + '/test-638g.txt', 'w'); ENV = {**os.environ, 'TZ': 'America/Chicago'}
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
A = D + '/appg'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True); DB = D + '/dbg.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; TT = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA = TT['TAMMY']
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d','dv_base'=>'http://127.0.0.1:%d','dv_slack'=>2,'dv_wait'=>2);\n" % (DB, PORT, FP))
def php(code):
    r = sh('php', '-d', 'error_log=' + D + '/phpg-err.log', '-r', 'require "%s/inc/core.php"; settings(); %s' % (A, code)); return (r.stdout + r.stderr).strip()
PW = 'adm638-' + os.urandom(3).hex(); php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % PW)
LOG = D + '/req-g.log'; open(LOG, 'w').close()
fk = subprocess.Popen(['python3', D + '/fakespin.py', str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpg.log', 'w'))
atexit.register(lambda: (sv.terminate(), fk.terminate())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
NUM = [0]
def appt(sid=None):
    NUM[0] += 1; ph = '+155555501%02d' % (40 + NUM[0])
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'P5 TEST %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tk%d')" % (time.strftime('%Y-%m-%d'), 600 + NUM[0] * 5, TA, sid or PD, NUM[0], ph, NUM[0]))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def co(aid, pays, sid=None, price=35):
    return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid or PD, 'price': price, 'staff': TA}], 'pays': pays})
def sales(): return [json.loads(l) for l in open(LOG) if '/v2/Payment/Sale' in l]
def pend(): return json.loads(php('echo setting("dv_pend");') or '{}')
def spin(ref, total='35.00', rc='0', msg='Approved', l4='1881'):
    return {'Spin_Response': {'RefId': ref, 'AuthCode': 'TT' + ref[-4:], 'PNRef': 'PN' + ref[-6:], 'RRN': 'R' + ref[-6:], 'ResultCode': rc, 'RespCode': '00' if rc == '0' else '05', 'Message': msg,
        'PaymentType': 'Credit', 'CardType': 'VISA', 'AcntFirst4': '4111', 'AcntLast4': l4, 'EntryType': 'Tap On Phone', 'Amount': total, 'Tip': '0.00', 'TotalAmt': total, 'BatchNum': '12', 'TransNum': '7', 'DateTime': '20261103123456'}}
def calls(p): return [json.loads(l) for l in open(LOG) if p in l]
try:
    say('== LAMWEB test 638g - Tap to Pay result (server) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
    a1 = appt(); c, r = api('ttp_result', {'ids': [a1], 'amt': 35, 'spin': spin('202611030001')}); ok('1 OFF (dv_on 0): refused, nothing kept', c == 400 and not pend(), (c, r))
    php('require_once "%s/inc/dejavoo.php"; dv_set_creds("220926423654", "REG01", "AK12345678"); set_setting("dv_on", "1");' % A)
    c, v = api('ttp_result', {'ids': [a1], 'amt': 35, 'spin': spin('202611030001')})
    ok('2 approved Tap to Pay answer -> a payment of this ticket (ref TTP…, ··1881, VISA, AuthCode)', c == 200 and v.get('ref') == 'TTP202611030001' and v.get('last4') == '1881' and v.get('auth_code') == 'TT0001', (c, v))
    c2, v2 = api('ttp_result', {'ids': [a1], 'amt': 35, 'spin': spin('202611030001')}); ok('3 the same answer sent again (app retry) -> the SAME payment, not a 2nd one', c2 == 200 and v2.get('again') is True and len([k for k in pend() if k.startswith('TTP')]) == 1, (c2, v2))
    c, r = co(a1, [{'m': 'Card', 'amt': 35, 'dv_ref': v['ref']}]); rows = sql("SELECT id, pays FROM receipts ORDER BY id DESC LIMIT 1"); pz = json.loads(rows[0]['pays']) if rows else []
    ok('4 Checkout with it -> receipt Card $35 ··1881 with ref / auth / pnref (used once)', c == 200 and pz and pz[0]['dv']['ref'] == 'TTP202611030001' and pz[0]['last4'] == '1881' and pend()['TTP202611030001']['st'] == 'used', (c, pz))
    rid = int(rows[0]['id']); a2 = appt(); c, r = api('ttp_result', {'ids': [a2], 'amt': 35, 'spin': spin('202611030001')}); ok('5 the same RefId for ANOTHER ticket -> refused', c == 409, (c, r))
    c, r = api('ttp_result', {'ids': [a2], 'amt': 35, 'spin': spin('202611030002', rc='1', msg='Declined')}); ok('6 not approved (ResultCode 1) -> 402, nothing kept', c == 402 and 'TTP202611030002' not in pend(), (c, r))
    c, r = api('ttp_result', {'ids': [a2], 'amt': 35, 'spin': {'Spin_Response': {'ResultCode': '0'}}}); ok('6 no RefId -> refused', c == 400, (c, r))
    c, r = api('ttp_result', {'ids': [a2], 'amt': 35, 'spin': spin('202611030003', total='40.00')}); ok('7 the iPhone took $40, the ticket $35 -> 409 (kept to check, never "paid" for $35)', c == 409 and (r.get('dvPaid') or {}).get('amt') == 40, (c, r))
    c, r = api('dv_cancel', {'ref': 'TTP202611030003'}); ok('8 "Cancel on the P5" of a Tap to Pay payment -> refused: refund it on the iPhone', c == 409 and 'iPhone' in r.get('error', '') and not calls('/v2/Payment/Void'), (c, r))
    c, r = api('receipt_void', {'id': rid, 'reason': 'ttp void test', 'dps_done': False}); ok('9 void of a Tap to Pay receipt: NOT sent to the P5; needs the tick like a normal card (refund on the iPhone)', c == 400 and not calls('/v2/Payment/Void'), (c, r))
    c, r = api('receipt_void', {'id': rid, 'reason': 'ttp void test', 'dps_done': True}); ok('9 ... ticked -> voided, still nothing on the P5', c == 200 and not calls('/v2/Payment/Void') and not calls('/v2/Payment/Return'), (c, str(r)[:150]))
    c, x = api('dv_day'); ok('10 Close day P5 check: Tap to Pay payments are not counted as missing on the P5', c == 200 and not [i for i in x.get('issues', []) if i.get('ref', '').startswith('TTP') and i['what'] == 'app_only'], x)
    ok('11 nothing was ever sent to the P5 for Tap to Pay (no Sale)', not calls('/v2/Payment/Sale'), '')
    err = open(D + '/phpg.log').read() + (open(D + '/phpg-err.log').read() if os.path.exists(D + '/phpg-err.log') else '')
    ok('12 no PHP Warning / Fatal', not any(x in err for x in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in err.splitlines() if 'PHP' in l][:3])
finally:
    sv.terminate(); fk.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
