# LAMWEB test 638b - Settings -> Payments -> "Dejavoo P5 (NailFlow)": the codes box + "Check the connection". Only NailFlow (American Nails' owner /
# a support session); the owner of another salon is refused on the SERVER. The codes never come back, never in the audit. Fake SPIn Proxy only.
import sys, json, os, time, subprocess; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'T637')); from nfenv import Env
FP = 19900 + int(os.environ.get('NF_PORT_SHIFT', 0)); D = '/tmp/claude-0/T638'
T = Env(sys.argv[1], D, 19901, out='test-638b.txt', cfgx=", 'dv_base'=>'http://127.0.0.1:%d', 'dv_slack'=>2" % FP); T.start()
LOG = D + '/req-b.log'; open(LOG, 'w').close(); fk = subprocess.Popen(['python3', D + '/fakespin.py', str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(0.8)
try:
    T.say('== LAMWEB test 638b - Dejavoo P5 box (NailFlow only)')
    ck, cs = T.login('s001', '0')
    c, b = T.req('s001', 'dv_info', None, ck, cs); j = json.loads(b) if c == 200 else {}
    T.ok('1 American Nails owner (NailFlow): the box data – off, sandbox, not set up', c == 200 and j.get('dv', {}).get('on') is False and j['dv'].get('env') == 'uat' and j['dv'].get('ready') is False, (c, b[:200]))
    c, b = T.req('s001', 'dv_save', {'on': True}, ck, cs); T.ok('1 "Card on the P5" cannot be turned on before the codes are there', c == 400 and T.php('s001', 'echo setting("dv_on");') in ('', '0'), (c, b[:120]))
    c, b = T.req('s001', 'dv_save', {'tpn': '220926423654', 'reg': 'REG01', 'auth': 'AK12345678', 'on': True}, ck, cs); j = json.loads(b) if c == 200 else {}
    T.ok('2 codes saved: the answer shows only TPN + "…" last 4 (never the codes)', c == 200 and j['dv'].get('auth') == '…5678' and j['dv'].get('reg') == '…EG01' and 'AK12345678' not in b and 'REG01' not in b and j['dv'].get('on') is True, (c, b[:200]))
    raw = T.php('s001', 'echo setting("dv_auth"), "|", setting("dv_reg");'); aud = T.php('s001', 'echo json_encode(q("SELECT * FROM audit_log")->fetchAll());')
    T.ok('2 kept encrypted; the audit says what changed (TPN, Register ID, Auth Key, on) but never the codes', 'AK12345678' not in raw and 'REG01' not in raw and 'Dejavoo P5' in aud and 'Auth Key' in aud and 'AK12345678' not in aud and 'REG01' not in aud, aud[-300:])
    c, b = T.req('s001', 'dv_save', {'tpn': '', 'reg': '', 'auth': ''}, ck, cs); T.ok('2 Save with the code boxes empty = keep the codes', c == 200 and json.loads(b)['dv'].get('auth') == '…5678', (c, b[:150]))
    c, b = T.req('s001', 'dv_save', {'auth': 'short'}, ck, cs); T.ok('2 a wrong Auth Key -> refused with the reason, the saved one kept', c == 400 and '10' in b and T.php('s001', 'require_once getenv("NFR") . "/inc/dejavoo.php"; echo dv_shown()["auth"];') == '…5678', (c, b[:150]))
    c, b = T.req('s001', 'dv_check', {}, ck, cs); j = json.loads(b) if c == 200 else {}
    T.ok('3 "Check the connection" -> Terminal Status Online (nothing charged)', c == 200 and j.get('online') is True and not [l for l in open(LOG) if 'Payment/Sale' in l], (c, b[:200]))
    S = 's005'; ck5, cs5 = T.login(S)
    for a, body in [('dv_info', None), ('dv_save', {'tpn': '220926423654', 'auth': 'AK12345678'}), ('dv_check', {})]:
        c, b = T.req(S, a, body, ck5, cs5); T.ok('4 another salon\'s owner: %s -> 403 "NailFlow"' % a, c == 403 and 'NailFlow' in b, (c, b[:120]))
    T.ok('4 nothing saved there', T.php(S, 'echo setting("dv_tpn"), setting("dv_auth");') == '', '')
    x = T.php(S, 'require_once getenv("NFR") . "/inc/support.php"; echo json_encode([in_array("dv_save", NF_ONLY_ACTS, true), in_array("dv_check", NF_ONLY_ACTS, true), in_array("dv_info", NF_ONLY_ACTS, true)]);')
    T.ok('4 the 3 actions are in the NailFlow-only list (a support session still may – nf_only() is false for it)', x == '[true,true,true]', x)
    rd = lambda f: open(T.REL + '/' + f, encoding='utf-8').read() if os.path.exists(T.REL + '/' + f) else ''
    T.ok('5 Settings: dejavoo-hq.js loads with Settings, shown only to NailFlow (!S.nfOnly || S.support), never to a manager', "'dejavoo-hq'" in rd('assets/admin-core.js') and '!IS_MGR && (!S.nfOnly || !!S.support)' in rd('assets/admin/dejavoo-hq.js'), '')
    T.ok('5 the box never shows the codes (password boxes, empty, placeholder …abcd)', 'type="password" autocomplete="new-password" value=""' in rd('assets/admin/dejavoo-hq.js'), '')
    r = subprocess.run(['node', '--check', T.REL + '/assets/admin/dejavoo-hq.js'], capture_output=True, text=True); T.ok('5 dejavoo-hq.js: no syntax error', r.returncode == 0, r.stderr[:200])
    # (638c) item 6 'Checkout unchanged by this package' was a 638b-only scope check: 638c changes Checkout on purpose. Its real rule – P5 OFF = Checkout as before – is t638c items 1 + 13.
finally:
    fk.terminate(); T.end()
