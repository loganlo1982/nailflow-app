# LAMWEB test 638d - Void / Refund of a receipt paid on the P5: the P5 gives the money back by itself (Void same batch, Return after the batch closed /
#   for a part); the P5 says no -> the receipt is NOT changed; a normal card receipt still needs "Done on DPS".
# Fake SPIn Proxy (fakespin.py) + a local copy with its own SQLite (T586 seed: Pedicure $35, Gel Manicure $40, Full Set $50). Nothing real.
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T638X'; T5 = '/tmp/claude-0/T586'; SH = int(os.environ.get('NF_PORT_SHIFT', 0)); PORT = 19904 + SH; FP = 19905 + SH
R = []; out = open(D + '/qa-638x.txt', 'w'); ENV = {**os.environ, 'TZ': 'America/Chicago'}
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
A = D + '/appd'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True); DB = D + '/dbd.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; TT = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA = TT['TAMMY']
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d','dv_base'=>'http://127.0.0.1:%d','dv_slack'=>2,'dv_wait'=>2);\n" % (DB, PORT, FP))
def php(code):
    r = sh('php', '-d', 'error_log=' + D + '/phpd-err.log', '-r', 'require "%s/inc/core.php"; settings(); %s' % (A, code)); return (r.stdout + r.stderr).strip()
PW = 'adm638-' + os.urandom(3).hex(); php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % PW)
LOG = D + '/req-d.log'; open(LOG, 'w').close()
fk = subprocess.Popen(['python3', D + '/fakespin.py', str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpd.log', 'w'))
atexit.register(lambda: (sv.terminate(), fk.terminate())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
NUM = [0]
def appt(sid=None):
    NUM[0] += 1; ph = '+155555501%02d' % (40 + NUM[0])
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'P5 TEST %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tk%d')" % (time.strftime('%Y-%m-%d'), 600 + NUM[0] * 5, TA, sid or PD, NUM[0], ph, NUM[0]))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def co(aid, pays, sid=None, price=35):
    return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid or PD, 'price': price, 'staff': TA}], 'pays': pays})
def sales(): return [json.loads(l) for l in open(LOG) if '/v2/Payment/Sale' in l]
def pend(): return json.loads(php('echo setting("dv_pend");') or '{}')
def calls(p): return [json.loads(l) for l in open(LOG) if p in l]
def rcpt(rid): x = sql("SELECT status, pays, void_reason FROM receipts WHERE id = %d" % rid); return x[0] if x else {}
def paid(price=35, amt=None, sid=None):
    a = appt(sid); c, v = api('dv_charge', {'ids': [a], 'amt': amt or price}); c2, r = co(a, [{'m': 'Card', 'amt': amt or price, 'dv_ref': v.get('ref', '')}], sid=sid, price=price)
    return int(((r or {}).get('receipt') or {}).get('id', 0)), v.get('ref', '')
try:
    say('== CHAT QA-0028 repro: P5 money moves BEFORE the receipt checks ' + time.strftime('%H:%M'))
    php('require_once "%s/inc/dejavoo.php"; dv_set_creds("220926423654", "REG01", "AK12345678"); set_setting("dv_on", "1");' % A)
    # A: refund more than the receipt
    rid, ref = paid(); n = len(calls('/v2/Payment/Return'))
    c, r = api('receipt_refund', {'id': rid, 'amount': 50, 'how': 'Card', 'dps_done': False, 'reason': 'too much'}); rr = calls('/v2/Payment/Return')
    ok('A refund $50 on a $35 P5 receipt -> refused AND the P5 is NOT asked', c >= 400 and len(rr) == n, (c, r.get('error'), 'P5 Return calls +%d' % (len(rr) - n), rr[-1]['body'].get('Amount') if len(rr) > n else ''))
    # B: full refund twice
    rid, ref = paid(); nv = len(calls('/v2/Payment/Void')); n = len(calls('/v2/Payment/Return'))
    c1, r1 = api('receipt_refund', {'id': rid, 'amount': 35, 'how': 'Card', 'dps_done': False, 'reason': 'all back'})
    c2, r2 = api('receipt_refund', {'id': rid, 'amount': 35, 'how': 'Card', 'dps_done': False, 'reason': 'tapped again'})
    moved = (len(calls('/v2/Payment/Void')) - nv) * 35 + sum(x['body']['Amount'] for x in calls('/v2/Payment/Return')[n:])
    ok('B full refund $35 then again -> 2nd refused, P5 gave back only $35', c1 == 200 and c2 >= 400 and abs(moved - 35) < 0.01, (c1, c2, r2.get('error'), 'P5 gave back $%.2f' % moved))
    # C: partial refund then void
    rid, ref = paid(price=40, sid=GM); nv = len(calls('/v2/Payment/Void')); n = len(calls('/v2/Payment/Return'))
    c1, r1 = api('receipt_refund', {'id': rid, 'amount': 10, 'how': 'Card', 'dps_done': False, 'reason': 'part'})
    c2, r2 = api('receipt_void', {'id': rid, 'reason': 'void after part', 'dps_done': False})
    moved = sum(x['body']['Amount'] for x in calls('/v2/Payment/Void')[nv:]) + sum(x['body']['Amount'] for x in calls('/v2/Payment/Return')[n:])
    ok('C refund $10 then Void -> Void refused, P5 gave back only $10', c1 == 200 and c2 >= 400 and abs(moved - 10) < 0.01, (c1, c2, r2.get('error'), 'P5 gave back $%.2f' % moved, rcpt(rid).get('status')))
finally:
    say('== %d/%d' % (sum(R), len(R)))
