# LAMWEB test 639b - QA-0011: a REFUND made while this week's payroll is CLOSED (closed early / force) lost the techs' part (no adjustment into next week).
#   Now: asked first (PAYROLL_CLOSED, like Void) -> the tech's part goes into next week's adjustments; an open week: as before.
# Fake SPIn Proxy (fakespin.py) + a local copy with its own SQLite (T586 seed: Pedicure $35, Gel Manicure $40, Full Set $50). Nothing real.
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T639'; T5 = '/tmp/claude-0/T586'; SH = int(os.environ.get('NF_PORT_SHIFT', 0)); PORT = 19912 + SH; FP = 19913 + SH
R = []; out = open(D + '/test-639b.txt', 'w'); ENV = {**os.environ, 'TZ': 'America/Chicago'}
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
A = D + '/appb'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True); DB = D + '/dbb.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; TT = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA = TT['TAMMY']
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d','dv_base'=>'http://127.0.0.1:%d','dv_slack'=>2,'dv_wait'=>2);\n" % (DB, PORT, FP))
def php(code):
    r = sh('php', '-d', 'error_log=' + D + '/phpb-err.log', '-r', 'require "%s/inc/core.php"; settings(); %s' % (A, code)); return (r.stdout + r.stderr).strip()
PW = 'adm638-' + os.urandom(3).hex(); php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % PW)
LOG = D + '/req-b.log'; open(LOG, 'w').close()
fk = subprocess.Popen(['python3', D + '/fakespin.py', str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpb.log', 'w'))
atexit.register(lambda: (sv.terminate(), fk.terminate())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
NUM = [0]
def appt(sid=None):
    NUM[0] += 1; ph = '+155555501%02d' % (40 + NUM[0])
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'P5 TEST %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tk%d')" % (time.strftime('%Y-%m-%d'), 600 + NUM[0] * 5, TA, sid or PD, NUM[0], ph, NUM[0]))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def co(aid, pays, sid=None, price=35):
    return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid or PD, 'price': price, 'staff': TA}], 'pays': pays})
def sales(): return [json.loads(l) for l in open(LOG) if '/v2/Payment/Sale' in l]
def pend(): return json.loads(php('echo setting("dv_pend");') or '{}')
HA = TT['HANA']
def rc(rid): x = sql("SELECT total, refund, status FROM receipts WHERE id = %d" % rid); return x[0] if x else {}
def adj(): return sql("SELECT staff_id, amount, reason, week_start FROM payroll_adj ORDER BY id")
def coh(aid, price): return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': S['Full Set'], 'price': price, 'staff': HA}], 'pays': [{'m': 'Cash', 'amt': price}]})
def mk(price):
    a = appt(S['Full Set']); sql("UPDATE appointments SET staff_id = %d WHERE id = %d" % (HA, a)); c, r = coh(a, price); return int(r['receipt']['id'])
try:
    say('== LAMWEB test 639b - QA-0011 (refund in a closed payroll week) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
    sql("UPDATE staff SET commission_pct = 55, pct_hist = '' WHERE id = %d" % HA)
    r0 = mk(100); c, r = api('receipt_refund', {'id': r0, 'amount': 10, 'how': 'Cash', 'reason': 'open week'})
    ok('1 week OPEN: a refund as before (no question, no adjustment)', c == 200 and not adj(), (c, r.get('error'), adj()))
    r1 = mk(100); r2 = mk(100); TD = time.strftime('%Y-%m-%d'); c, w = api('payroll_close', {'day': TD, 'force': True}); ok('setup: this week closed early (force)', c == 200, (c, str(w)[:150]))
    c, r = api('receipt_refund', {'id': r1, 'amount': 20, 'how': 'Cash', 'reason': 'closed week'}); x = rc(r1)
    ok('2 week CLOSED: the refund asks first (PAYROLL_CLOSED, like Void) – nothing saved yet', c == 409 and r.get('error') == 'PAYROLL_CLOSED' and float(x['refund']) == 0, (c, r.get('error'), x))
    c, r = api('receipt_refund', {'id': r1, 'amount': 20, 'how': 'Cash', 'reason': 'closed week', 'ok_closed': True}); a = adj()
    ok('3 confirmed: refund saved AND HANA -$11 (55% of $20) goes into NEXT week\'s adjustments', c == 200 and float(rc(r1)['refund']) == 20 and len(a) == 1 and int(a[0]['staff_id']) == HA and abs(float(a[0]['amount']) + 11) < 0.01 and a[0]['week_start'] > TD, (c, r.get('error'), a))
    ok('3 the answer lists it (carry) so the screen can say so', isinstance(r.get('carry'), list) and r['carry'] and abs(r['carry'][0]['amt'] + 11) < 0.01, r.get('carry'))
    c, r = api('receipt_money', {'id': r2, 'lines': [{'staff': HA, 'amt': 80}], 'how': 'Cash', 'reason': 'wrong price'}); a = adj()
    ok('4 "Fix service prices" lowering (= a refund) in the closed week: HANA -$11 into next week too', c == 200 and len(a) == 2 and abs(float(a[1]['amount']) + 11) < 0.01, (c, r.get('error'), a))
    js = open(A + '/assets/admin/checkout-receipt.js', encoding='utf-8').read()
    ok('5 screen: the refund asks "payroll closed" like Void (payClosedAsk) and sends ok_closed', 'ok_closed: okc' in js and js.count('PAYROLL_CLOSED') >= 3, js.count('PAYROLL_CLOSED'))
    r = subprocess.run(['node', '--check', A + '/assets/admin/checkout-receipt.js'], capture_output=True, text=True); ok('5 checkout-receipt.js: no syntax error', r.returncode == 0, r.stderr[:200])
    err = open(D + '/phpb.log').read() + (open(D + '/phpb-err.log').read() if os.path.exists(D + '/phpb-err.log') else '')
    ok('6 no PHP Warning / Fatal', not any(x in err for x in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in err.splitlines() if 'PHP' in l][:3])
finally:
    sv.terminate(); fk.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
