# LAMWEB test 639a - QA-0012: "Fix service prices" lowering the price TWICE refunded twice (the line price stays, only a refund is written).
#   A receipt that already has a refund: lowering is refused ("refund the difference instead"); the first lowering + everything else as before.
# Fake SPIn Proxy (fakespin.py) + a local copy with its own SQLite (T586 seed: Pedicure $35, Gel Manicure $40, Full Set $50). Nothing real.
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T639'; T5 = '/tmp/claude-0/T586'; SH = int(os.environ.get('NF_PORT_SHIFT', 0)); PORT = 19910 + SH; FP = 19911 + SH
R = []; out = open(D + '/test-639a.txt', 'w'); ENV = {**os.environ, 'TZ': 'America/Chicago'}
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
A = D + '/appa'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True); DB = D + '/dba.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; TT = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA = TT['TAMMY']
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d','dv_base'=>'http://127.0.0.1:%d','dv_slack'=>2,'dv_wait'=>2);\n" % (DB, PORT, FP))
def php(code):
    r = sh('php', '-d', 'error_log=' + D + '/phpa-err.log', '-r', 'require "%s/inc/core.php"; settings(); %s' % (A, code)); return (r.stdout + r.stderr).strip()
PW = 'adm638-' + os.urandom(3).hex(); php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % PW)
LOG = D + '/req-a.log'; open(LOG, 'w').close()
fk = subprocess.Popen(['python3', D + '/fakespin.py', str(FP), LOG], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpa.log', 'w'))
atexit.register(lambda: (sv.terminate(), fk.terminate())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
NUM = [0]
def appt(sid=None):
    NUM[0] += 1; ph = '+155555501%02d' % (40 + NUM[0])
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'P5 TEST %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tk%d')" % (time.strftime('%Y-%m-%d'), 600 + NUM[0] * 5, TA, sid or PD, NUM[0], ph, NUM[0]))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def co(aid, pays, sid=None, price=35):
    return api('checkout2', {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid or PD, 'price': price, 'staff': TA}], 'pays': pays})
def sales(): return [json.loads(l) for l in open(LOG) if '/v2/Payment/Sale' in l]
def pend(): return json.loads(php('echo setting("dv_pend");') or '{}')
def rc(rid): x = sql("SELECT total, refund, refunds, status FROM receipts WHERE id = %d" % rid); return x[0] if x else {}
def money(rid, amt, how='Cash', reason='wrong price'): return api('receipt_money', {'id': rid, 'lines': [{'staff': TA, 'amt': amt}], 'how': how, 'reason': reason})
try:
    say('== LAMWEB test 639a - QA-0012 (lower the price twice) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
    a = appt(S['Full Set']); c, r = co(a, [{'m': 'Cash', 'amt': 50}], sid=S['Full Set'], price=50); rid = int(r['receipt']['id'])
    c, r = money(rid, 40); x = rc(rid); ok('1 first lowering $50 -> $40: refund $10 (as before)', c == 200 and abs(float(x['refund']) - 10) < 0.001, (c, r.get('error'), x))
    c, r = money(rid, 40, reason='again by mistake'); x = rc(rid)
    ok('2 the SAME lowering again (the dialog still shows $50): refused – "refund the difference instead" – NO 2nd refund', c == 400 and 'refund' in r.get('error', '').lower() and abs(float(x['refund']) - 10) < 0.001, (c, r.get('error'), x))
    c, r = money(rid, 45, reason='lower again'); x = rc(rid); ok('2 any lowering on a receipt with a refund: refused, refund stays $10', c == 400 and abs(float(x['refund']) - 10) < 0.001, (c, r.get('error'), x))
    c, r = money(rid, 60, reason='raise'); ok('3 raising on a receipt with a refund: still refused (as before)', c == 400, (c, r.get('error')))
    c, r = api('receipt_refund', {'id': rid, 'amount': 5, 'how': 'Cash', 'reason': 'normal refund'}); x = rc(rid); ok('3 a normal Refund on it still works ($10 -> $15)', c == 200 and abs(float(x['refund']) - 15) < 0.001, (c, r.get('error'), x))
    a2 = appt(S['Full Set']); c, r = co(a2, [{'m': 'Cash', 'amt': 50}], sid=S['Full Set'], price=50); rid2 = int(r['receipt']['id'])
    c, r = money(rid2, 60, reason='raise first'); x = rc(rid2); ok('4 raising on a receipt WITHOUT a refund: works as before ($60)', c == 200 and abs(float(x['total']) - 60) < 0.001, (c, r.get('error'), x))
    err = open(D + '/phpa.log').read() + (open(D + '/phpa-err.log').read() if os.path.exists(D + '/phpa-err.log') else '')
    ok('5 no PHP Warning / Fatal', not any(x in err for x in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in err.splitlines() if 'PHP' in l][:3])
finally:
    sv.terminate(); fk.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
