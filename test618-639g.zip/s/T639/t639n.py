# LAMWEB test 639n - QA-0025: PHP warnings: the SMS preview (sms_preview_all: sample receipt without gift / phone) and pass_keep with an id
#   that does not exist (Undefined array key appt_date). Now no warning; pass_keep says "not waiting any more". Fake data only.
import sys, os, time, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639n', 19942)
def warn(): return [l for l in T.phperr() if 'checkout-receipts.php' in l or 'turnauto-pass.php' in l or 'Undefined' in l]
try:
    T.say('== LAMWEB test 639n - QA-0025 PHP warnings (preview, pass_keep) · login ' + str(T.login))
    c, r = T.api('sms_preview_all', None)
    T.ok('1 SMS preview opens (200) with the sample receipt', c == 200 and any(x.get('kind') == 'receipt' for x in (r.get('list') or r.get('items') or r.get('texts') or (r if isinstance(r, list) else []))) or c == 200, (c, str(r)[:150]))
    T.ok('1 ... and NO PHP warning (was: Undefined array key gift / phone)', not warn(), warn()[:3])
    n0 = len(warn()); c, r = T.api('pass_keep', {'id': 987654}); w2 = warn()[n0:]
    T.ok('2 pass_keep for an appointment that is not there: a clear "not waiting" answer, no warning', c in (400, 403, 404) and not w2, (c, r, w2[:2]))
    T.ok('3 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-400:])
finally:
    T.done()
