# LAMWEB test 639g - QA-0010: a GROUP whose people start at DIFFERENT times (the owner moved one): the customer's move checked everyone at the 1st
#   person's time but saved each at their own (+ the old gap) -> the later person was never checked (on top of that tech's next customer). Fake data only.
import sys, os, time, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639g', 19928)
D2 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 2 * 86400)); TA, HA, SI = T.T['TAMMY'], T.T['HANA'], T.T['SISI']; PD = T.S['Pedicure']
def add(name, start, staff, tok, grp='', ph='+15555550191'):
    T.sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', '%s', '%s', 'booked', 'online', 'appt', '%s', datetime('now'), '%s')" % (D2, start, staff, PD, name, ph, grp, tok))
    return T.sql("SELECT id FROM appointments WHERE token = '%s'" % tok)[0]['id']
def st(i): return T.sql("SELECT start_min FROM appointments WHERE id = %d" % i)[0]['start_min']
try:
    T.say('== LAMWEB test 639g - QA-0010 group with different start times · login ' + str(T.login))
    g1 = add('GROUP ONE', 600, TA, 'tkG1', 'grp639g'); g2 = add('GROUP TWO', 660, HA, 'tkG2', 'grp639g'); d = add('OTHER', 900, HA, 'tkD', ph='+15555550192')
    c, r = T.api('reschedule', {'t': 'tkG1', 'date': D2, 'start': 840})
    T.ok('1 group TAMMY 10:00 + HANA 11:00, HANA busy at 3:00 PM: moving the group to 2:00 PM (HANA -> 3:00 PM) is REFUSED', c == 409 and st(g1) == 600 and st(g2) == 660, (c, r, st(g1), st(g2)))
    c, r = T.api('reschedule', {'t': 'tkG1', 'date': D2, 'start': 720})
    T.ok('2 moving it to 12:00 (HANA 1:00 PM, free) works, the 1 h gap is kept', c == 200 and st(g1) == 720 and st(g2) == 780, (c, r, st(g1), st(g2)))
    s1 = add('SAME TIME A', 600, TA, 'tkS1', 'grp639s', '+15555550193'); s2 = add('SAME TIME B', 600, SI, 'tkS2', 'grp639s', '+15555550193')
    c, r = T.api('reschedule', {'t': 'tkS1', 'date': D2, 'start': 1080})
    T.ok('3 a normal group (same start) moves as before', c == 200 and st(s1) == 1080 and st(s2) == 1080, (c, r))
    T.ok('4 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-600:])
finally:
    T.done()
