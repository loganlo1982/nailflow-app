# LAMWEB test 639m - QA-0024: save_staff_one / the setup link's setup_staff_one with payMethod sent as an ARRAY -> HTTP 500 (half saved).
#   Now a payMethod that is not one of the pay methods = 'check' (as for any unknown value). Fake data only.
import sys, os, time, json, urllib.parse; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639m', 19940)
HA = T.T['HANA']
try:
    T.say('== LAMWEB test 639m - QA-0024 payMethod array · login ' + str(T.login))
    c, r = T.api('save_staff_one', {'id': HA, 'name': 'HANA', 'commission': 55, 'payMethod': ['check']})
    pm = T.sql("SELECT pay_method, commission_pct FROM staff WHERE id = %d" % HA)[0]
    T.ok('1 owner: payMethod as a list -> no 500, saved with "check"', c == 200 and pm['pay_method'] == 'check' and float(pm['commission_pct']) == 55, (c, r, pm))
    c, r = T.api('save_staff_one', {'id': HA, 'name': 'HANA', 'commission': 50, 'payMethod': 'cash'}); pm = T.sql("SELECT pay_method FROM staff WHERE id = %d" % HA)[0]
    T.ok('2 owner: a real pay method (cash) saves as before', c == 200 and pm['pay_method'] == 'cash', (c, r, pm))
    c, r = T.api('setup_new', {}); tok = urllib.parse.parse_qs(urllib.parse.urlparse(r.get('url', '')).query).get('t', [''])[0]
    c, r = T.api('setup_staff_one', {'t': tok, 'id': HA, 'name': 'HANA', 'commission': 45, 'payMethod': {'x': 1}}, cs='')
    T.ok('3 the setup link (no owner login): payMethod as an object -> no 500', c in (200, 400, 403) and c != 500, (c, r))
    T.ok('4 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-400:])
finally:
    T.done()
