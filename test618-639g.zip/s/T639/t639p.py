# LAMWEB test 639p - QA-0027 (owner sending data the screens never send): appt_rename name as a list -> "ARRAY"; a price "1e309" -> INF (the service
#   disappeared from the booking page + warnings); cust_not_dup any long pair; colors_import without rows -> warning. Fake data only.
import sys, os, time, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639p', 19946)
TD = time.strftime('%Y-%m-%d'); TA = T.T['TAMMY']; PD = T.S['Pedicure']
try:
    T.say('== LAMWEB test 639p - QA-0027 bad data from the owner · login ' + str(T.login))
    T.sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, created_at, token) VALUES ('%s', 600, 45, %d, '%d', 'RENAME ME', '+15555550221', 'booked', 'admin', 'appt', datetime('now'), 'tkp1')" % (TD, TA, PD))
    a = T.sql("SELECT id FROM appointments WHERE token = 'tkp1'")[0]['id']
    c, r = T.api('appt_rename', {'id': a, 'name': ['X']}); nm = T.sql("SELECT customer_name FROM appointments WHERE id = %d" % a)[0]['customer_name']
    T.ok('1 appt_rename with a list: refused, the name stays (was: "ARRAY")', c == 400 and nm == 'RENAME ME', (c, r, nm))
    svc = [{'id': s['id'], 'name': s['name'], 'duration': s['duration'], 'price': s['price']} for s in T.sql("SELECT id, name, duration, price FROM services WHERE active = 1 ORDER BY sort")]
    for s in svc:
        if s['id'] == PD: s['price'] = '1e309'
    c, r = T.api('save_services', {'services': svc}); p = T.sql("SELECT price FROM services WHERE id = %d" % PD)[0]['price']
    T.ok('2 a price "1e309": never INF (saved as $0, the service stays a normal one)', c == 200 and str(p) not in ('inf', 'INF', 'Infinity') and float(p) < 1e7, (c, p))
    for s in svc:
        if s['id'] == PD: s['price'] = 35
    c, r = T.api('save_services', {'services': svc}); p = T.sql("SELECT price FROM services WHERE id = %d" % PD)[0]['price']
    T.ok('3 a normal price ($35) saves as before', c == 200 and abs(float(p) - 35) < 0.001, (c, p))
    c, r = T.api('cust_not_dup', {'a': '1' * 5000, 'b': '2' * 5000}); v = T.php('echo strlen((string)setting("dup_ignore"));').splitlines()[-1]
    T.ok('4 cust_not_dup with very long values: kept short (each side at most 20)', c == 200 and int(v) < 200, (c, v))
    n0 = len(T.phperr()); c, r = T.api('colors_import', {}); w = T.phperr()[n0:]
    T.ok('5 colors_import without rows: no PHP warning', not [l for l in w if 'rows' in l], (c, w[:2]))
    T.ok('6 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-400:])
finally:
    T.done()
