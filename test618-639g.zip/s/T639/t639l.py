# LAMWEB test 639l - QA-0019: Quick checkout had its own tech-PIN counter (5 wrong -> 15 min, then again) with NO 24-hour lock -> ~480 guesses a
#   day at another tech's PIN. Now it uses the same tech PIN locks as /tech/ (15 min, 3 locks in 24 h -> 24 h) too. Fake data only.
import sys, os, time, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639l', 19938)
HA, SI = T.T['HANA'], T.T['SISI']
def pin(sid, p): return T.api('quick_co_pin', {'staff': sid, 'pin': p})
def later(sid): T.sql("DELETE FROM login_attempts WHERE ip IN ('QL:%d', 'QP:%d', 'PL:%d', 'P:%d')" % (sid, sid, sid, sid))  # 15 minutes went by (the 24 h counter stays)
try:
    T.say('== LAMWEB test 639l - QA-0019 quick checkout PIN 24 h lock · login ' + str(T.login))
    T.php('q("UPDATE staff SET pin_hash = ? WHERE id IN (%d, %d)", [password_hash("2468", PASSWORD_DEFAULT)]);' % (HA, SI))
    c, r = pin(HA, '2468'); T.ok('1 the right PIN works', c == 200 and r.get('ok'), (c, r))
    codes = []
    for rnd in range(3):
        for i in range(5): c, r = pin(HA, '1111'); codes.append(c)
        later(HA)
    c, r = pin(HA, '2468')
    T.ok('2 15 wrong PINs (3 rounds of 5, 15 min apart): even the RIGHT PIN is refused now - locked 24 h (was: back after 15 min)', c == 429, (c, r, codes[-3:]))
    T.php('set_setting("pinlock_%d", "3"); set_setting("pinlock_t_%d", (string)time());' % (SI, SI))
    c, r = pin(SI, '2468'); T.ok('3 a tech already locked 24 h on /tech/ cannot open Quick checkout either', c == 429, (c, r))
    T.php('q("DELETE FROM settings WHERE k LIKE \'pinlock%\'"); q("DELETE FROM login_attempts");')
    c, r = pin(SI, '1111'); c2, r2 = pin(SI, '2468'); T.ok('4 one wrong then the right PIN: works, counters cleared', c == 422 and c2 == 200, (c, c2))
    T.ok('5 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-400:])
finally:
    T.done()
