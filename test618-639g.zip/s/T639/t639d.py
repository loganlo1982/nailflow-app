# LAMWEB test 639d - QA-0009: the customer moves their own booking (text link, action reschedule): the free time was checked with the MENU minutes,
#   not the booking's own length (the owner made it longer) -> the longer booking was moved on top of the tech's next customer. Fake data only.
import sys, os, time, json, urllib.request; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639d', 19922)
D2 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 2 * 86400)); TA, HA = T.T['TAMMY'], T.T['HANA']; GM, PD = T.S['Gel Manicure'], T.S['Pedicure']
def add(name, start, dur, staff, sid, tok, grp=''):
    T.sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, %d, %d, '%d', '%s', '+15555550170', 'booked', 'online', 'appt', '%s', datetime('now'), '%s')" % (D2, start, dur, staff, sid, name, grp, tok))
    return T.sql("SELECT id FROM appointments WHERE token = '%s'" % tok)[0]['id']
def get(i): return T.sql("SELECT start_min, duration, staff_id, appt_date FROM appointments WHERE id = %d" % i)[0]
def slots(tok, sid, people):
    rq = urllib.request.Request(T.B + '/api.php?action=slots&date=%s&services=%d&people=%s&rs=%s' % (D2, sid, people, tok))
    return json.loads(urllib.request.urlopen(rq, timeout=30).read().decode()).get('slots', [])
try:
    T.say('== LAMWEB test 639d - QA-0009 reschedule keeps the booking length · login ' + str(T.login))
    A = add('LONG ONE', 600, 120, TA, GM, 'tkA639d'); B = add('NEXT ONE', 720, 45, TA, PD, 'tkB639d')
    c, r = T.api('reschedule', {'t': 'tkA639d', 'date': D2, 'start': 660})
    T.ok('1 Gel Manicure (menu 30 min) made 2 h by the owner, TAMMY busy at 12:00: moving it to 11:00 is REFUSED (11:00-13:00 would cover 12:00)', c == 409 and get(A)['start_min'] == 600, (c, r, get(A)))
    s = slots('tkA639d', GM, TA)
    T.ok('2 the customer page does not offer 11:00 (nor 10:45 .. 11:45) for that booking', not any(x in s for x in (645, 660, 675, 690, 705)), [x for x in s if 600 <= x <= 720])
    T.ok('3 ... but offers 1:00 PM (after NEXT ONE, 2 h free)', 780 in s, [x for x in s if 700 <= x <= 800])
    c, r = T.api('reschedule', {'t': 'tkA639d', 'date': D2, 'start': 780}); g = get(A)
    T.ok('4 moving it to 1:00 PM works and keeps the 2 h', c == 200 and g['start_min'] == 780 and g['duration'] == 120, (c, r, g))
    C = add('NORMAL', 900, 30, HA, GM, 'tkC639d'); c, r = T.api('reschedule', {'t': 'tkC639d', 'date': D2, 'start': 960}); g = get(C)
    T.ok('5 a normal booking (menu length) moves as before', c == 200 and g['start_min'] == 960 and g['duration'] == 30, (c, r, g))
    E2 = add('SHORT', 600, 15, HA, PD, 'tkE639d'); c, r = T.api('reschedule', {'t': 'tkE639d', 'date': D2, 'start': 1020}); g = get(E2)
    T.ok('6 a booking SHORTER than the menu: still checked with the menu (45 min) - never less than before', c == 200 and g['start_min'] == 1020, (c, r, g))
    T.ok('7 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-600:])
finally:
    T.done()
