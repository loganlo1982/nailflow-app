# LAMWEB test 639j - QA-0017: automatic promos could go out at night: promo hours took 00:00-23:59, and a promo handed to the Android at 7:59 PM
#   was kept 2 hours (a phone asleep until 9:45 PM still sent it). Now the hours stay inside 8:00 AM - 8:00 PM and a promo expires at the end of them.
import sys, os, time, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639j', 19934)
def P(code): r = T.php('require_once APP_ROOT . "/inc/autosend.php"; require_once APP_ROOT . "/inc/android.php"; ' + code); return r.splitlines()[-1] if r else ''
try:
    T.say('== LAMWEB test 639j - QA-0017 promo hours 8 AM - 8 PM · login ' + str(T.login))
    T.php('set_setting("as_promo_from", "00:00"); set_setting("as_promo_to", "23:59");')
    c = json.loads(P('echo json_encode(as_cfg());'))
    T.ok('1 hours saved before as 00:00 - 23:59: used as 8:00 AM - 8:00 PM', c['from'] == '08:00' and c['to'] == '20:00', (c['from'], c['to']))
    c1, r = T.api('autosend_save', {'from': '06:00', 'to': '19:00'}); c2, r2 = T.api('autosend_save', {'from': '09:00', 'to': '22:30'})
    T.ok('2 saving promo hours before 8 AM or after 8 PM is refused', c1 == 400 and c2 == 400, (c1, r, c2, r2))
    c3, r3 = T.api('autosend_save', {'from': '09:00', 'to': '19:30'}); c = json.loads(P('echo json_encode(as_cfg());'))
    T.ok('3 9:00 AM - 7:30 PM saves as before', c3 == 200 and c['from'] == '09:00' and c['to'] == '19:30', (c3, str(r3)[:150], c['from'], c['to']))
    ttl = int(P('echo ad_ttl(["kind" => "bday", "src" => "promo:x"]);')); end = time.mktime(time.strptime(time.strftime('%Y-%m-%d') + ' 19:30', '%Y-%m-%d %H:%M')); want = int(min(7200, max(60, end - time.time())))
    T.ok('4 a promo handed to the Android expires at the end of the promo hours (7:30 PM), never later', abs(ttl - want) <= 5, (ttl, want))
    ttl2 = int(P('echo ad_ttl(["kind" => "reminder", "src" => "x"]);'))
    T.ok('5 a reminder keeps its 2 hours as before', ttl2 == 7200, ttl2)
    T.ok('6 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-300:])
finally:
    T.done()
