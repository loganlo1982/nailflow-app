# LAMWEB test 639f - QA-0014: "2 in one" Confirm (2 bookings, same number, same day) -> the text that WENT had only the newest booking
#   (sms_out_final rebuilt the short text from ONE appointment); the 1st was "Skipped - replaced (2 in one)" -> never confirmed. Nothing is sent.
import sys, os, time, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639f', 19926)
D3 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 3 * 86400)); TA = T.T['TAMMY']
def add(name, start, tok):
    T.sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, created_at, token) VALUES ('%s', %d, 45, %d, '%d', '%s', '+15555550181', 'booked', 'online', 'appt', datetime('now'), '%s')" % (D3, start, TA, T.S['Pedicure'], name, tok))
    return T.sql("SELECT id FROM appointments WHERE token = '%s'" % tok)[0]['id']
def final(aid, body, style):
    import base64; b = base64.b64encode(body.encode()).decode()
    code = 'require_once APP_ROOT . "/inc/outbox.php"; require_once APP_ROOT . "/inc/sms-short.php"; set_setting("sms_style", "%s"); $b = base64_decode("%s"); q("INSERT INTO outbox (kind, ref, phone, name, body, appt_id, status, created_at) VALUES (\'confirm\', ?, \'+15555550181\', \'TWO\', ?, ?, \'auto\', ?)", ["t639f" . mt_rand(), $b, %d, now_str()]); $id = (int)db()->lastInsertId(); echo json_encode(sms_out_final(["body" => $b, "kind" => "confirm", "src" => "ob:" . $id, "phone" => "+15555550181", "name" => "TWO"]));' % (style, b, aid)
    r = T.php(code)
    try: return json.loads(r.splitlines()[-1])
    except Exception: return r
try:
    T.say('== LAMWEB test 639f - QA-0014 "2 in one" confirm keeps both bookings · login ' + str(T.login))
    a1 = add('TWO VISITS', 600, 'tk639f1'); a2 = add('TWO VISITS', 900, 'tk639f2')
    two = "Hi Two!\n\n📅 %s at 10:00 AM\n💅 Pedicure\n\n📅 %s at 3:00 PM\n💅 Pedicure\n\nReply C to confirm" % (D3, D3)
    r = final(a2, two, 'short')
    T.ok('1 short style: the "2 in one" text keeps BOTH times (10:00 AM and 3:00 PM)', isinstance(r, str) and '10:00 AM' in r and '3:00 PM' in r, r)
    r = final(a2, two, 'lines'); T.ok('2 lines style: both times too', isinstance(r, str) and '10:00 AM' in r and '3:00 PM' in r, r)
    one = "Hi Two!\n\n📅 %s at 3:00 PM\n💅 Pedicure\n\nReply C to confirm" % D3
    r = final(a2, one, 'short'); T.ok('3 ONE booking: the short text is built as before (it changes the body)', isinstance(r, str) and r != one and '3:00' in r, r)
    r = final(a2, two, 'full'); T.ok('4 full style: as it was (the body itself)', r == two, r)
    T.ok('5 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-600:])
finally:
    T.done()
