# LAMWEB test 639k - QA-0018: the GUEST owner (try-out login) got around its limits through the setup link (setup_new -> /setup/ link -> turn a
#   tech off / change commission without need_admin), and could change 2-step (totp_ask) / Face ID lock (app_lock_bio) and upload push files (pt_file).
import sys, os, time, json, urllib.request, http.cookiejar; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639k', 19936)
try:
    T.say('== LAMWEB test 639k - QA-0018 guest owner limits · login ' + str(T.login))
    GP = 'guest-' + os.urandom(3).hex()
    T.php('set_setting("guest_on", "1"); set_setting("guest_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("totp_ask", "90"); set_setting("app_lock_bio", "0");' % GP)
    G = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    c, r = T.api('login', {'password': GP}, op=G, cs=''); GC = r.get('csrf', '')
    T.ok('0 the guest owner logs in', c == 200 and GC, (c, r))
    c, r = T.api('setup_new', {}, op=G, cs=GC); T.ok('1 guest: make a setup link -> refused (was: a link that changes techs without the owner)', c == 403 and not r.get('url'), (c, r))
    c, r = T.api('setup_prev_clear', {'part': 'staff'}, op=G, cs=GC); T.ok('2 guest: setup_prev_clear -> refused', c == 403, (c, r))
    c, r = T.api('pt_file', {'which': 'android', 'text': '{}'}, op=G, cs=GC); T.ok('3 guest: upload a push file (pt_file) -> refused', c == 403, (c, r))
    c, r = T.api('save_settings', {'totp_ask': 'always', 'app_lock_bio': '1'}, op=G, cs=GC)
    v = T.php('echo setting("totp_ask") . "|" . setting("app_lock_bio");').splitlines()[-1]
    T.ok('4 guest: save_settings totp_ask / app_lock_bio -> not changed (2-step / Face ID stay the owner\'s)', v == '90|0', (c, str(r)[:150], v))
    c, r = T.api('setup_new', {}); T.ok('5 the OWNER still makes a setup link', c == 200 and r.get('url'), (c, str(r)[:150]))
    c, r = T.api('save_settings', {'totp_ask': 'always'}); v = T.php('echo setting("totp_ask");').splitlines()[-1]
    T.ok('6 the OWNER still changes totp_ask', c == 200 and v == 'always', (c, str(r)[:150], v))
    T.ok('7 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-400:])
finally:
    T.done()
