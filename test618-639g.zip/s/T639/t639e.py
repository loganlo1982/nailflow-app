# LAMWEB test 639e - QA-0015: the AI phone offered and BOOKED a service with no price yet (hidden online since 636): menu, guess "pedicure", book tool.
#   Now every AI phone service list leaves out the no-price services (the same svc_noprice_ids() as the booking page). Nothing is called / sent.
import sys, os, time, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639e', 19924)
LIB = "define('NF_API_LIB',1); require '%s/inc/core.php'; settings(); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s'.$f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; require_once '%s/inc/calls-ivr.php'; require_once '%s/inc/calls-agent.php'; require_once '%s/inc/replies.php'; " % ((T.A,) * 7)
def lib(code): r = T.sh('php', '-d', 'error_log=' + T.D + '/phpcli-639e.log', '-r', LIB + code); return (r.stdout + r.stderr).strip()
D3 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 3 * 86400))
try:
    T.say('== LAMWEB test 639e - QA-0015 AI phone and services with no price · login ' + str(T.login))
    T.sql("INSERT INTO services (name, duration, price, sort, active) VALUES ('Basic Pedicure', 30, 0, -1, 1)"); NP = T.sql("SELECT id FROM services WHERE name = 'Basic Pedicure'")[0]['id']
    T.php('$i = json_decode((string)setting("svc_info"), true) ?: []; $i["%d"] = ["np" => 1]; set_setting("svc_info", json_encode($i));' % NP)
    np = json.loads(T.php('require_once APP_ROOT . "/inc/svc-tpl.php"; echo json_encode(svc_noprice_ids());') or '[]')
    T.ok('0 setup: "Basic Pedicure" $0 is a no-price service (hidden on the booking page)', NP in np, np)
    menu = json.loads(lib("echo json_encode(cl_agent_data('+15555550177')['menu']);") or '[]')
    T.ok('1 the AI receptionist menu does NOT list the no-price service', menu and not any('Basic Pedicure' in m for m in menu), menu)
    T.ok('1 ... the priced services are still there', any('Pedicure (' in m and 'Basic' not in m for m in menu) and any('Gel Manicure' in m for m in menu), menu)
    g = lib("echo cl_guess_service('I want a pedicure please');")
    T.ok('2 "pedicure" -> the priced Pedicure (was: the cheapest = the $0 one)', g == str(T.S['Pedicure']), (g, T.S['Pedicure']))
    T.php('set_setting("call_on","1");')
    r = lib("echo json_encode(cl_agent_tool(['function'=>'book','argument'=>['parsed'=>[['date'=>'%s','time'=>'11:00','name'=>'NOPRICE TEST','persons'=>[['name'=>'NOPRICE TEST','service_ids'=>[%d],'tech_id'=>0]],'new_ok'=>true]]],'caller_id_num'=>'+15555550177','call_id'=>'np639e']));" % (D3, NP))
    n = T.sql("SELECT id, service_ids FROM appointments WHERE customer_name = 'NOPRICE TEST'")
    T.ok('3 the book tool with the no-price service: NOT booked (asks for a service)', not n and 'NOT_BOOKED' in r, (r[:300], n))
    r = lib("echo json_encode(cl_agent_tool(['function'=>'book','argument'=>['parsed'=>[['date'=>'%s','time'=>'13:00','name'=>'PRICED TEST','persons'=>[['name'=>'PRICED TEST','service_ids'=>[%d],'tech_id'=>0]],'new_ok'=>true]]],'caller_id_num'=>'+15555550178','call_id'=>'pr639e']));" % (D3, T.S['Pedicure']))
    n = T.sql("SELECT id FROM appointments WHERE customer_name = 'PRICED TEST'")
    T.ok('4 a priced service is booked by the AI as before', n and 'BOOKED' in r, r[:300])
    T.ok('5 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-600:])
finally:
    T.done()
