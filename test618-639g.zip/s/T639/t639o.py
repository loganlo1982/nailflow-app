# LAMWEB test 639o - QA-0026: anyone could fill the PHP log with "Array to string conversion" by sending x[]= in the query or a list where a
#   word is expected (book, slots, reschedule, answer, setup link, gift balance...). Now a list there is ignored (as if not sent): no warning, same answers.
import sys, os, time, json, urllib.request, urllib.error; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639o', 19944)
def raw(path, body=None):
    rq = urllib.request.Request(T.B + path, data=json.dumps(body).encode() if body is not None else None, headers={'Content-Type': 'application/json'})
    try: r = urllib.request.urlopen(rq, timeout=30); return r.status
    except urllib.error.HTTPError as e: return e.code
def arr(): return [l for l in T.phperr() if 'Array to string' in l or 'Illegal offset' in l or 'Fatal' in l]
try:
    T.say('== LAMWEB test 639o - QA-0026 lists where a word is expected · login ' + str(T.login))
    D2 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 2 * 86400)); PD = T.S['Pedicure']
    codes = {}
    codes['slots date[]'] = raw('/api.php?action=slots&date[]=x&services=%d&people=0' % PD)
    codes['slots tm[]'] = raw('/api.php?action=slots&date=%s&services=%d&people=0&tm[]=1&rs[]=2&svcs[]=3&design[]=1&plan[]=1' % (D2, PD))
    codes['info tm[]'] = raw('/api.php?action=info&tm[]=1')
    codes['book name[]'] = raw('/api.php?action=book', {'date': D2, 'start': 600, 'name': ['A'], 'phone': ['5555550111'], 'tm': ['x'], 'services': [PD], 'people': [0]})
    codes['reschedule t[]'] = raw('/api.php?action=reschedule', {'t': ['x'], 'date': [D2], 'start': 600})
    codes['answer t[]'] = raw('/api.php?action=answer', {'t': ['x'], 'a': 'yes'})
    codes['gift_balance code[]'] = raw('/api.php?action=gift_balance', {'code': ['1'], 'phone': ['2']})
    codes['action[]'] = raw('/api.php?action[]=book')
    w = arr()
    T.ok('1 lists sent where a word is expected: no "Array to string conversion" / 500 in the log', not w, (w[:3], codes))
    T.ok('2 no 500 at all', all(c != 500 for c in codes.values()), codes)
    c = raw('/api.php?action=slots&date=%s&services=%d&people=0' % (D2, PD)); T.ok('3 the normal booking page times still work (200)', c == 200, c)
    c, r = T.api('save_staff_one', {'id': T.T['HANA'], 'name': 'HANA', 'skills': [PD]}); T.ok('4 a real list (owner, skills) still works', c == 200, (c, r))
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-400:])
finally:
    T.done()
