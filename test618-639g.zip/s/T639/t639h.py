# LAMWEB test 639h - QA-0013: Void in a CLOSED payroll week of a tech who has LEFT (inactive): payroll_carry only went over the techs of
#   payroll_rows() -> the left tech's part was never taken back (no adjustment into next week). Fake data only.
import sys, os, time, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639h', 19930)
HA, TA = T.T['HANA'], T.T['TAMMY']; FS = T.S['Full Set']; TD = time.strftime('%Y-%m-%d'); N = [0]
def mk(staff, price):
    N[0] += 1; ph = '+155555502%02d' % N[0]
    T.sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', 'PAY %d', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), 'tkh%d')" % (TD, 600 + N[0] * 5, staff, FS, N[0], ph, N[0]))
    a = T.sql("SELECT id FROM appointments WHERE phone = '%s'" % ph)[0]['id']
    c, r = T.api('checkout2', {'ids': [a], 'lines': [{'appt': a, 'sid': FS, 'price': price, 'staff': staff}], 'pays': [{'m': 'Cash', 'amt': price}]}); return int(r['receipt']['id'])
def adj(sid): return T.sql("SELECT amount, week_start FROM payroll_adj WHERE staff_id = %d ORDER BY id" % sid)
try:
    T.say('== LAMWEB test 639h - QA-0013 void in a closed week, tech who left · login ' + str(T.login))
    T.sql("UPDATE staff SET commission_pct = 50, pct_hist = '' WHERE id IN (%d, %d)" % (HA, TA))
    rh = mk(HA, 100); rt = mk(TA, 100)
    c, w = T.api('payroll_close', {'day': TD, 'force': True}); T.ok('setup: this week closed (force), HANA $50 and TAMMY $50 in it', c == 200, (c, str(w)[:200]))
    T.sql("UPDATE staff SET active = 0 WHERE id = %d" % HA)
    c, r = T.api('receipt_void', {'id': rh, 'reason': 'void after close', 'dps_done': True, 'ok_closed': True}); a = adj(HA)
    T.ok('1 HANA left (inactive), her receipt voided in the closed week: -$50 goes into NEXT week for HANA (was: nothing)', c == 200 and len(a) == 1 and abs(float(a[0]['amount']) + 50) < 0.01 and a[0]['week_start'] > TD, (c, r.get('error'), a))
    c, r = T.api('receipt_void', {'id': rt, 'reason': 'void after close', 'dps_done': True, 'ok_closed': True}); a = adj(TA)
    T.ok('2 an ACTIVE tech (TAMMY): -$50 into next week as before', c == 200 and len(a) == 1 and abs(float(a[0]['amount']) + 50) < 0.01, (c, r.get('error'), a))
    T.ok('3 nothing twice: HANA still one adjustment', len(adj(HA)) == 1, adj(HA))
    T.ok('4 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-600:])
finally:
    T.done()
