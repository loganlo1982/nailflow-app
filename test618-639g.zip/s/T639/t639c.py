# LAMWEB test 639c - QA-0021: tapping "Check in »" / "Book »" TWICE in the walk-in / booking form (book-form.js #wSave) made 2 appointments.
#   Now: one save at a time (busy) + the 'once' key the server already knows (inc/api/appts.php) -> 1 appointment. Real browser (Playwright), fake data.
import sys, os, re; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
from playwright.sync_api import sync_playwright
T = Env(sys.argv[1], '639c', 19920)
def form(p, name, phone, walkin=True):
    p.evaluate("(()=>{try{if(!document.querySelector('#sheet').hidden)closeSheet();}catch(e){}})()"); p.wait_for_timeout(300)
    if walkin: p.evaluate("setTab('checkin')"); p.wait_for_timeout(1200); p.click('#walkin')
    else: p.evaluate("setTab('appts')"); p.wait_for_timeout(1200); p.evaluate("openBook()")
    p.wait_for_timeout(900); p.locator('#sheet button', has_text='1').first.click(); p.wait_for_timeout(600)
    p.locator('#sheet button.schip', has_text='Pedicure').first.click(); p.wait_for_timeout(400)
    no = p.locator('#sheet [data-addno]');
    if no.count(): no.first.click(); p.wait_for_timeout(300)
    for i in range(8):
        if p.locator('#wSave').count() and p.locator('#wSave').is_visible() and (not p.locator('#wName').count() or p.locator('#wName').input_value()):
            for sel, val in (('#wBm', '5'), ('#wBd', '12')):
                el = p.locator(sel)
                if el.count() and el.is_visible():
                    try: el.select_option(val)
                    except Exception: el.select_option(index=5)
            break
        if p.locator('#tpBg.on [data-tp="0"]').count(): p.locator('#tpBg.on [data-tp="0"]').first.click(); p.wait_for_timeout(500); continue
        for sel, val in (('#wPhone', phone), ('#wName', name)):
            el = p.locator(sel)
            if el.count() and el.is_visible() and not el.input_value(): el.fill(val); p.wait_for_timeout(200)
        for sel, val in (('#wBm', '5'), ('#wBd', '12')):
            el = p.locator(sel)
            if el.count() and el.is_visible():
                try: el.select_option(val)
                except Exception: el.select_option(index=5)
        nx = p.locator('#wNext')
        if nx.count() and nx.is_visible(): nx.click(); p.wait_for_timeout(800)
        else: p.wait_for_timeout(400)
    return p.locator('#wSave').count() > 0
def count(name): return len(T.sql("SELECT id FROM appointments WHERE customer_name = '%s' AND status <> 'cancelled'" % name))
try:
    T.say('== LAMWEB test 639c - QA-0021 double tap in the walk-in / booking form · login ' + str(T.login))
    errs = []
    with sync_playwright() as pw:
        br = pw.chromium.launch(); p = br.new_page(viewport={'width': 1024, 'height': 900}); p.on('pageerror', lambda e: errs.append(str(e)))
        p.goto(T.B + '/admin/'); p.wait_for_timeout(1200); p.fill('#loginPass', T.PW); p.keyboard.press('Enter'); p.wait_for_timeout(3000)
        for i in range(3):
            sk = p.get_by_text('Skip', exact=True)
            if sk.count(): sk.first.click(); p.wait_for_timeout(300)
        got = form(p, 'DOUBLETAP WALKIN', '5555550161')
        T.ok('0 the walk-in form reaches its last step (Check in »)', got, p.evaluate("document.querySelector('#sheet').innerText.slice(0,300)"))
        p.evaluate("(()=>{const b=document.querySelector('#wSave'); b.click(); b.click();})()"); p.wait_for_timeout(2500)
        n = count('DOUBLETAP WALKIN'); T.ok('1 walk-in: "Check in »" tapped TWICE -> ONE appointment (was 2)', n == 1, (n, p.evaluate("(document.querySelector('#sheet:not([hidden])')||{}).innerText||'closed'")[:400], T.sql("SELECT customer_name, phone FROM appointments ORDER BY id DESC LIMIT 3")))
        got = form(p, 'DOUBLETAP BOOK', '5555550162')
        if got:
            p.evaluate("(()=>{const b=document.querySelector('#wSave'); b.click(); b.click(); b.click();})()"); p.wait_for_timeout(2500)
        n = count('DOUBLETAP BOOK'); T.ok('2 tapped 3 times fast -> ONE appointment', got and n == 1, (got, n))
        got = form(p, 'ONE TAP', '5555550163')
        if got: p.click('#wSave'); p.wait_for_timeout(2500)
        T.ok('3 one normal tap still books (1 appointment, the form closes)', count('ONE TAP') == 1 and p.evaluate("document.querySelector('#sheet').hidden"), count('ONE TAP'))
        got = form(p, 'TWO VISITS', '5555550164')
        if got: p.click('#wSave'); p.wait_for_timeout(2000)
        got2 = form(p, 'TWO VISITS', '5555550164')
        if got2: p.click('#wSave'); p.wait_for_timeout(2000)
        T.ok('4 a NEW form for the same customer is a new booking (the once key is per form)', count('TWO VISITS') == 2, count('TWO VISITS'))
        br.close()
    T.ok('5 no JavaScript error', not errs, errs[:3]); T.ok('6 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-600:])
finally:
    T.done()
