# LAMWEB 639c+: one small test env for the QA packages (copy of the app + its own SQLite with the T586 seed + php -S + owner login). Nothing real.
#   from qaenv import Env;  T = Env(app_dir, tag, port)  -> T.api(action, body, get), T.sql(q), T.php(code), T.ok(name, cond, info), T.done()
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, http.cookiejar, atexit
T5 = '/tmp/claude-0/T586'
class Env:
    def __init__(self, a0, tag, port, cfgx=''):
        self.D = '/tmp/claude-0/T639Q'; os.makedirs(self.D, exist_ok=True); SH = int(os.environ.get('NF_PORT_SHIFT', 0)); self.PORT = port + SH
        self.R = []; self.out = open(self.D + '/test-%s.txt' % tag, 'w'); self.ENV = {**os.environ, 'TZ': 'America/Chicago'}; self.tag = tag
        self.A = self.D + '/app-' + tag; shutil.rmtree(self.A, ignore_errors=True); shutil.copytree(os.path.abspath(a0), self.A, symlinks=True)
        self.DB = self.D + '/db-%s.sqlite' % tag; shutil.copy('/tmp/claude-0/tdb/base.sqlite', self.DB)
        seed = json.loads(self.sh('php', T5 + '/seed.php', self.A, self.DB, str(self.PORT)).stdout); self.S = seed['S']; self.T = seed['T']
        open(self.A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d'%s);\n" % (self.DB, self.PORT, cfgx))
        self.PW = 'qa639-' + os.urandom(3).hex()
        self.php('set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on", "0"); set_setting("admin_fee_on", "0"); set_setting("tax_pct", "0");' % self.PW)
        self.errlog = self.D + '/php-%s.log' % tag
        open(self.D + '/phpcli-%s.log' % tag, 'w').close()
        self.sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % self.PORT, '-t', self.A, '/tmp/claude-0/router.php'], env={**self.ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(self.errlog, 'w'))
        atexit.register(self.sv.terminate); time.sleep(1.2)
        self.B = 'http://127.0.0.1:%d' % self.PORT; self.jar = http.cookiejar.CookieJar(); self.OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar)); self.CS = None
        c, r = self.api('login', {'password': self.PW}); self.CS = r.get('csrf'); self.login = c
    def sh(self, *a): return subprocess.run(a, capture_output=True, text=True, env=self.ENV)
    def sql(self, q): r = self.sh('php', T5 + '/db.php', self.DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
    def php(self, code):
        r = self.sh('php', '-d', 'error_log=' + self.D + '/phpcli-%s.log' % self.tag, '-r', 'require "%s/inc/core.php"; settings(); %s' % (self.A, code)); return (r.stdout + r.stderr).strip()
    def api(self, action, body=None, get='', op=None, cs=None):
        hd = {'Content-Type': 'application/json'}; c = cs if cs is not None else self.CS; hd.update({'X-CSRF': c} if c else {})
        rq = urllib.request.Request(self.B + '/api.php?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
        try: r = (op or self.OP).open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
        except urllib.error.HTTPError as e:
            try: return e.code, json.loads(e.read().decode() or '{}')
            except Exception: return e.code, {}
    def say(self, s): print(s, flush=True); self.out.write(s + '\n'); self.out.flush()
    def ok(self, n, c, i=''): self.R.append(bool(c)); self.say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
    def phperr(self):
        t = open(self.errlog).read() + (open(self.D + '/phpcli-%s.log' % self.tag).read() if os.path.exists(self.D + '/phpcli-%s.log' % self.tag) else '')
        return [l for l in t.splitlines() if any(x in l for x in ['PHP Warning', 'PHP Fatal', 'Uncaught', 'PHP Deprecated', 'PHP Notice'])]
    def done(self):
        self.sv.terminate(); self.say('PASS %d/%d' % (sum(self.R), len(self.R))); sys.exit(0 if self.R and all(self.R) else 1)
