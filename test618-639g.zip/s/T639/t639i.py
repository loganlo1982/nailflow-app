# LAMWEB test 639i - QA-0016: the AI phone's "1 of the group cancelled" text (ref cxlpart:) was ALWAYS dropped ("Still booked that day":
#   out_validate / as_stale), and the short style rebuilt it as a plain Cancelled. Now it stays and goes as written. Nothing is sent.
import sys, os, time, json, base64; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from qaenv import Env
T = Env(sys.argv[1], '639i', 19932)
D3 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 3 * 86400)); TA, HA = T.T['TAMMY'], T.T['HANA']; PD = T.S['Pedicure']
def add(name, staff, status, tok):
    T.sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', 600, 45, %d, '%d', '%s', '+15555550211', '%s', 'call', 'appt', 'grp639i', datetime('now'), '%s')" % (D3, staff, PD, name, status, tok))
    return T.sql("SELECT id FROM appointments WHERE token = '%s'" % tok)[0]['id']
BODY = "Hi Mai!\n\nCANCELLED: Lan\nStill booked: 1 person (Mai)\n\nQuestions? Call us"
def row(aid, ref):
    b = base64.b64encode(BODY.encode()).decode()
    return int(T.php('require_once APP_ROOT . "/inc/outbox.php"; q("INSERT INTO outbox (kind, ref, phone, name, body, appt_id, status, created_at) VALUES (\'cancel\', ?, \'+15555550211\', \'MAI\', ?, ?, \'pending\', ?)", ["%s", base64_decode("%s"), %d, now_str()]); echo db()->lastInsertId();' % (ref, b, aid)).splitlines()[-1])
try:
    T.say('== LAMWEB test 639i - QA-0016 part-cancel text of a group · login ' + str(T.login))
    keep = add('MAI', TA, 'booked', 'tki1'); gone = add('LAN', HA, 'cancelled', 'tki2')
    o1 = row(gone, 'cxlpart:%d' % gone)
    T.php('require_once APP_ROOT . "/inc/outbox.php"; if (!function_exists("out_validate")) require_once APP_ROOT . "/inc/outbox-2.php"; out_validate();')
    x = T.sql("SELECT status, info, body FROM outbox WHERE id = %d" % o1)[0]
    T.ok('1 out_validate: the part-cancel text STAYS in To send (was: skipped "Still booked that day")', x['status'] == 'pending', x)
    T.ok('1 ... with its own words (who is cancelled + who is still booked), not rebuilt as a plain Cancelled', 'Still booked: 1 person' in (x['body'] or ''), x['body'])
    st = T.php('require_once APP_ROOT . "/inc/outbox.php"; require_once APP_ROOT . "/inc/autosend.php"; echo json_encode(as_stale(["src" => "ob:%d", "kind" => "cancel"]));' % o1).splitlines()[-1]
    T.ok('2 Auto send (as_stale): not stale (was "still booked that day")', json.loads(st) == '', st)
    b = base64.b64encode(BODY.encode()).decode()
    f = T.php('require_once APP_ROOT . "/inc/outbox.php"; require_once APP_ROOT . "/inc/sms-short.php"; set_setting("sms_style", "short"); echo json_encode(sms_out_final(["body" => base64_decode("%s"), "kind" => "cancel", "src" => "ob:%d", "phone" => "+15555550211", "name" => "MAI"]));' % (b, o1)).splitlines()[-1]
    T.ok('3 short style: the part-cancel text goes with its own words (both names)', 'Lan' in json.loads(f) and 'Mai' in json.loads(f), f)
    o2 = row(gone, 'cxl:%d' % gone)
    T.php('require_once APP_ROOT . "/inc/outbox.php"; if (!function_exists("out_validate")) require_once APP_ROOT . "/inc/outbox-2.php"; out_validate();')
    x = T.sql("SELECT status, info FROM outbox WHERE id = %d" % o2)[0]
    T.ok('4 a NORMAL Cancelled while the customer is still booked that day: skipped as before', x['status'] == 'skipped', x)
    T.ok('5 no PHP Warning / Fatal', not T.phperr(), T.phperr()[:3])
except Exception as e:
    import traceback; T.ok('test ran to the end', False, traceback.format_exc()[-600:])
finally:
    T.done()
