#!/bin/bash
# LAMWEB 618 - one command for ALL the tests on a local copy (nothing real: fake Telnyx / SignalWire / STT / AI, texts to a table, SQLite of its own).
#   ./run-tests.sh <app folder>            all suites
#   ./run-tests.sh <app folder> telnyx sw  some suites (names below)
# Each suite gets its OWN fresh copy of the app (the app folder itself is never changed). Results: run/logs/<suite>.txt + run/SUMMARY.txt
# A FAIL line that is in baseline/<suite>.txt is an OLD known one (it fails on LIVE 2.99.613 too, written down there with the reason);
# any other FAIL = NEW -> exit code 1 (the package is not sent).
set -u
K=$(cd "$(dirname "$0")" && pwd); [ $# -ge 1 ] || { echo "usage: $0 <app folder> [suite...]"; exit 2; }
APP=$(cd "$1" && pwd) || exit 2; shift
ALL="aicall telnyx telnyx615 review622 mod619 pay619 money626 money627 calls629 mani631 setup632 cross635 qa635b setup636 hide636 sec637a sec637b sec637c sec637d sec637e dv638a dv638b dv638c dv638d dv638e dv638g dv638h qa638x qa639a qa639b qa639c qa639d qa639e qa639f qa639g qa639h qa639i qa639j qa639k qa639l install633 book610 sw605b sw602b sw590 sw624 book611a book620 turn609"; SU=${*:-$ALL}
R=$K/run; rm -rf "$R"; mkdir -p "$R/logs"; cp -a "$K/s/." "$R/"
grep -rl --include='*.py' --include='*.js' --include='*.php' '/tmp/claude-0' "$R" | xargs sed -i "s#/tmp/claude-0#$R#g"
export TZ=America/Chicago
[ -n "${NF_NO_PHPINI:-}" ] || export PHP_INI_SCAN_DIR="${PHP_INI_SCAN_DIR:-}:$K/phpini"   # (621-B) the kit's own PHP settings on top of the server's (errors -> stderr, exec on) – see phpini/zz-nftest.ini
# (621 A3) DONG HO GIA: moi test thay CUNG 1 gio co dinh (mac dinh Thu Tu 2026-11-04 10:00 CST, doi bang NF_TEST_NOW="YYYY-MM-DD HH:MM"), khong phu thuoc gio may
CK="$K/clock/nfclock.so"; [ -f "$CK" ] || gcc -shared -fPIC -O2 -o "$CK" "$K/clock/nfclock.c" -ldl 2>/dev/null
if [ -f "$CK" ]; then export NF_FAKE_T0=$(date +%s) NF_FAKE_NOW=$(date -d "${NF_TEST_NOW:-2026-11-04 10:00}" +%s) LD_PRELOAD="$CK"; CLK="gio gia ${NF_TEST_NOW:-2026-11-04 10:00}"; else CLK="!! KHONG co gcc: dung GIO MAY (vai test phu thuoc ngay)"; fi
mk() { local d="$R/app-$1"; rm -rf "$d"; cp -a "$APP" "$d"; sed -i "s#'/usr/bin/mpg123'#'$R/T616/mpg123'#g" "$d/inc/calls-tx.php" 2>/dev/null; echo "$d"; }
# (635 C-a) a known FAIL = the same TEST NAME (the text before "   →"); the details after the arrow differ per machine (server vs LAMWEB) and are not compared
nfname() { sed -E 's/ +→ .*$//' | cut -c1-200; }
run() { local n=$1; shift; local t0=$(date +%s); timeout 300 "$@" > "$R/logs/$n.txt" 2>&1; local rc=$?; local dt=$(( $(date +%s) - t0 ))
  local pass=$(grep -c '^✓' "$R/logs/$n.txt"); local fail=$(grep -c '^✗' "$R/logs/$n.txt"); local new=0
  if [ -f "$K/baseline/$n.txt" ]; then new=$(grep '^✗' "$R/logs/$n.txt" | nfname | grep -vxF -f <(nfname < "$K/baseline/$n.txt") | wc -l); else new=$fail; fi
  [ $((pass + fail)) -eq 0 ] && new=1
  printf '%-10s PASS %3d  FAIL %3d  (FAIL MOI %d)  %3ds%s\n' "$n" "$pass" "$fail" "$new" "$dt" "$([ $rc -ne 0 ] && echo "  rc=$rc")" | tee -a "$R/SUMMARY.txt"
  [ "$new" -eq 0 ] || grep '^✗' "$R/logs/$n.txt" | nfname | grep -vxF -f <(nfname < "$K/baseline/$n.txt" 2>/dev/null || true) | sed 's/^/      MOI: /' | tee -a "$R/SUMMARY.txt"
  TOTNEW=$((TOTNEW + new)); TOTP=$((TOTP + pass)); TOTF=$((TOTF + fail)); killkit; }
# (621-D) the kit's own processes (php -S + its workers, fake servers) are found by their path under $R/ and stopped: at the start (left from an
# earlier run), after EVERY suite (the next one uses the same ports) and on exit / Ctrl-C / timeout (trap). Only processes of this kit – nothing else.
killkit() { local sig p   # only: php|python3|node <kit script> …  or  php -S … -t <kit app>
  for sig in TERM KILL; do
    for p in $(ps -eo pid=,args= | awk -v k="$R/" '$2 ~ /(^|\/)(php[0-9.]*|python3?[0-9.]*|node)$/ && (index($3, k) == 1 || index($0, " -t " k)) {print $1}'); do [ "$p" != "$$" ] && kill -$sig "$p" 2>/dev/null; done
    sleep 0.5; done; }
portsfree() { python3 -c '
import socket, sys
busy = []
for p in range(19860, 20000):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try: s.bind(("127.0.0.1", p))
    except OSError: busy.append(p)
    finally: s.close()
print(" ".join(map(str, busy)))'; }
trap 'killkit' EXIT; trap 'killkit; exit 130' INT TERM
killkit; BUSY=$(portsfree)
if [ -n "$BUSY" ]; then echo "!! CONG DANG BAN (khong phai cua kit): $BUSY – dung lai, KHONG chay test (ket qua se sai). Xem: ss -ltnp | grep -E '$(echo $BUSY | tr ' ' '|')'" | tee -a "$R/SUMMARY.txt"; exit 3; fi
TOTNEW=0; TOTP=0; TOTF=0
echo "== run-tests $(LD_PRELOAD= date '+%Y-%m-%d %H:%M %Z') · $CLK · app: $APP · version: $(grep -o "APP_VERSION', '[^']*" "$APP/inc/core.php" 2>/dev/null | cut -d"'" -f3)" | tee "$R/SUMMARY.txt"
echo "   sha calls-tx $(sha256sum "$APP/inc/calls-tx.php" | cut -c1-8) · calls-job $(sha256sum "$APP/inc/calls-job.php" | cut -c1-8) · calls-agent $(sha256sum "$APP/inc/calls-agent.php" | cut -c1-8) · call_tx $(sha256sum "$APP/call_tx.php" | cut -c1-8)" | tee -a "$R/SUMMARY.txt"
echo "   moi truong: $(php -r 'echo "PHP ", PHP_VERSION, " · SQLite ", (new PDO("sqlite::memory:"))->query("select sqlite_version()")->fetchColumn(), " · display_errors=", ini_get("display_errors"), " · error_log=", ini_get("error_log") === "" ? "(stderr)" : ini_get("error_log"), " · exec ", function_exists("exec") ? "co" : "TAT";' 2>&1 | head -c 300) · ffmpeg $(command -v ffmpeg >/dev/null && echo co || echo KHONG) · mpg123 $(ls /usr/bin/mpg123 /bin/mpg123 2>/dev/null | head -1 || true) · node $(command -v node >/dev/null && echo co || echo KHONG)" | tee -a "$R/SUMMARY.txt"
for b in aicall; do [ -s "$K/baseline/$b.txt" ] || echo "!! THIEU baseline/$b.txt (S4 se bi tinh la loi MOI) – chep lai thu muc baseline/ cua kit" | tee -a "$R/SUMMARY.txt"; done
for s in $SU; do case $s in
  aicall)    a=$(mk $s); cd "$R/T612" && rm -rf calls/txg-* conv "$a-salonB"; run aicall python3 "$R/T618/sim.py" "$a"; cd "$K" ;;
  telnyx)    a=$(mk $s); cd "$R/T612" && rm -f calls/txg-* calls/txh-* calls/.tx-clean; run telnyx python3 "$R/T616/t616full.py" "$a"; cd "$K" ;;
  telnyx615) a=$(mk $s); rm -f "$R"/T612/calls/txg-*; run telnyx615 python3 "$R/T615/t616.py" "$a" ;;
  review622) a=$(mk $s); run review622 python3 "$R/T622/t622.py" "$a" ;;
  mani631)   a=$(mk $s); cd "$R/T631" && run mani631 python3 "$R/T631/t631.py" "$a"; cd "$K" ;;
  setup632)  a=$(mk $s); cd "$R/T632" && run setup632 python3 "$R/T632/t632.py" "$a"; cd "$K" ;;
  install633) a=$(mk $s); cd "$R/T633" && run install633 python3 "$R/T633/t633.py" "$a"; cd "$K" ;;
  cross635)  a=$(mk $s); cd "$R/T635" && run cross635 python3 "$R/T635/t635.py" "$a"; cd "$K" ;;
  setup636)  a=$(mk $s); cd "$R/T636" && run setup636 python3 "$R/T636/t636.py" "$a"; cd "$K" ;;
  hide636)   a=$(mk $s); cd "$R/T636H" && run hide636 python3 "$R/T636H/t636h.py" "$a"; cd "$K" ;;
  sec637a)   a=$(mk $s); cd "$R/T637" && run sec637a python3 "$R/T637/t637a.py" "$a"; cd "$K" ;;
  sec637b)   a=$(mk $s); cd "$R/T637" && run sec637b python3 "$R/T637/t637b.py" "$a"; cd "$K" ;;
  sec637c)   a=$(mk $s); cd "$R/T637" && run sec637c python3 "$R/T637/t637c.py" "$a"; cd "$K" ;;
  sec637d)   a=$(mk $s); cd "$R/T637" && run sec637d python3 "$R/T637/t637d.py" "$a"; cd "$K" ;;
  sec637e)   a=$(mk $s); cd "$R/T637" && run sec637e python3 "$R/T637/t637e.py" "$a"; cd "$K" ;;
  dv638a)    a=$(mk $s); cd "$R/T638" && run dv638a python3 "$R/T638/t638a.py" "$a"; cd "$K" ;;
  dv638b)    a=$(mk $s); cd "$R/T638" && run dv638b python3 "$R/T638/t638b.py" "$a"; cd "$K" ;;
  dv638c)    a=$(mk $s); cd "$R/T638" && run dv638c python3 "$R/T638/t638c.py" "$a"; cd "$K" ;;
  dv638d)    a=$(mk $s); cd "$R/T638" && run dv638d python3 "$R/T638/t638d.py" "$a"; cd "$K" ;;
  dv638e)    a=$(mk $s); cd "$R/T638" && run dv638e python3 "$R/T638/t638e.py" "$a"; cd "$K" ;;
  dv638g)    a=$(mk $s); cd "$R/T638" && run dv638g python3 "$R/T638/t638g.py" "$a"; cd "$K" ;;
  dv638h)    a=$(mk $s); cd "$R/T638" && run dv638h python3 "$R/T638/t638h.py" "$a"; cd "$K" ;;
  qa638x)    a=$(mk $s); cd "$R/T638X" && run qa638x python3 "$R/T638X/qa638x.py" "$a"; cd "$K" ;;
  qa639a)    a=$(mk $s); cd "$R/T639" && run qa639a python3 "$R/T639/t639a.py" "$a"; cd "$K" ;;
  qa639b)    a=$(mk $s); cd "$R/T639" && run qa639b python3 "$R/T639/t639b.py" "$a"; cd "$K" ;;
  qa639c)     a=$(mk $s); cd "$R/T639" && run qa639c python3 "$R/T639/t639c.py" "$a"; cd "$K" ;;
  qa639d)     a=$(mk $s); cd "$R/T639" && run qa639d python3 "$R/T639/t639d.py" "$a"; cd "$K" ;;
  qa639e)     a=$(mk $s); cd "$R/T639" && run qa639e python3 "$R/T639/t639e.py" "$a"; cd "$K" ;;
  qa639f)     a=$(mk $s); cd "$R/T639" && run qa639f python3 "$R/T639/t639f.py" "$a"; cd "$K" ;;
  qa639g)     a=$(mk $s); cd "$R/T639" && run qa639g python3 "$R/T639/t639g.py" "$a"; cd "$K" ;;
  qa639h)     a=$(mk $s); cd "$R/T639" && run qa639h python3 "$R/T639/t639h.py" "$a"; cd "$K" ;;
  qa639i)     a=$(mk $s); cd "$R/T639" && run qa639i python3 "$R/T639/t639i.py" "$a"; cd "$K" ;;
  qa639j)     a=$(mk $s); cd "$R/T639" && run qa639j python3 "$R/T639/t639j.py" "$a"; cd "$K" ;;
  qa639k)     a=$(mk $s); cd "$R/T639" && run qa639k python3 "$R/T639/t639k.py" "$a"; cd "$K" ;;
  qa639l)     a=$(mk $s); cd "$R/T639" && run qa639l python3 "$R/T639/t639l.py" "$a"; cd "$K" ;;
  qa635b)    a=$(mk $s); cd "$R/T635B" && run qa635b python3 "$R/T635B/t635b.py" "$a"; cd "$K" ;;
  book610)   a=$(mk $s); cd "$R/T610" && NF_FAKE_NOW=$(date -d '2026-11-01 10:00' +%s) APP="$a" run book610 python3 "$R/T610/a610.py"; cd "$K" ;; # gio gia = 01/11 10:00 (ngay doi gio) cho muc 10 DST
  mod619)    a=$(mk $s); run mod619 python3 "$R/T619/t619m.py" "$a" ;;
  pay619)    a=$(mk $s); run pay619 python3 "$R/T619P/t619p.py" "$a" ;;
  money626)  a=$(mk $s); run money626 python3 "$R/T626/t626.py" "$a" ;;
  money627)  a=$(mk $s); run money627 python3 "$R/T627/t627.py" "$a" ;;
  calls629)  a=$(mk $s); run calls629 python3 "$R/T629/t629.py" "$a" ;;
  sw624)     a=$(mk $s); run sw624 python3 "$R/T624/t624.py" "$a" ;;
  sw605)     a=$(mk $s); run sw605 python3 "$R/T605/t605.py" "$a" ;;
  sw605b)    a=$(mk $s); run sw605b python3 "$R/T605B/t605b.py" "$a" ;;
  sw602b)    a=$(mk $s); run sw602b python3 "$R/T586/t602b.py" "$a" ;;
  sw590)     a=$(mk $s); run sw590 python3 "$R/T586/t590.py" "$a" ;;
  book611a)  a=$(mk $s); b=$(mk $s-base); run book611a node "$R/T611A/t611a.js" "$a" "$b" 19960 "$R/out611a" ;;
  book620)   a=$(mk $s); b=$(mk $s-base); cp "$K/s/T620/base-book-2.js" "$b/assets/book-2.js" 2>/dev/null; cp "$K/s/T620/base-book-2.css" "$b/assets/book-2.css" 2>/dev/null; run book620 node "$R/T620/t620.js" "$a" "$b" 19970 "$R/out620" ;;
  turn609)   a=$(mk $s); run turn609 node "$R/T609/ui609.js" "$a" ;;
  *) echo "unknown suite $s (known: $ALL)" ;;
esac; done
echo "== TONG: PASS $TOTP · FAIL $TOTF · FAIL MOI $TOTNEW  -> $([ $TOTNEW -eq 0 ] && echo 'OK (chi con FAIL cu da biet)' || echo 'CO FAIL MOI - KHONG GUI GOI')" | tee -a "$R/SUMMARY.txt"
[ $TOTNEW -eq 0 ]
