/* LAMWEB 621 A3 - DONG HO GIA cho bo test (tu viet, ~40 dong). LD_PRELOAD=nfclock.so + NF_FAKE_NOW=<unix time luc bat dau>:
   moi tien trinh (php, python, sqlite trong php) thay gio = NF_FAKE_NOW + (thoi gian that troi qua tu NF_FAKE_T0). Chi dung trong ./run-tests.sh. */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
static long off(void) { static int done = 0; static long o = 0; if (!done) { const char *n = getenv("NF_FAKE_NOW"), *t = getenv("NF_FAKE_T0"); if (n && t) o = atol(n) - atol(t); done = 1; } return o; }
int clock_gettime(clockid_t id, struct timespec *ts) {
    static int (*real)(clockid_t, struct timespec *) = 0; if (!real) real = dlsym(RTLD_NEXT, "clock_gettime");
    int r = real(id, ts); if (r == 0 && (id == CLOCK_REALTIME || id == CLOCK_REALTIME_COARSE)) ts->tv_sec += off(); return r; }
int gettimeofday(struct timeval *tv, void *tz) {
    static int (*real)(struct timeval *, void *) = 0; if (!real) real = dlsym(RTLD_NEXT, "gettimeofday");
    int r = real(tv, tz); if (r == 0 && tv) tv->tv_sec += off(); return r; }
time_t time(time_t *t) { struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts); if (t) *t = ts.tv_sec; return ts.tv_sec; }
