# LAMWEB test 637a - QA-0005: a salon that is not the main one cannot change the STOP line (sms_footer) through Settings -> SMS templates either
# (sms_tpl_save / sms_tpl_restore -> 403 "NailFlow ..." + audit nf_only); "Restore default" (it has STOP) stays open; American Nails (main) unchanged.
import sys, json; sys.path.insert(0, '/tmp/claude-0/T637'); from nfenv import Env
T = Env(sys.argv[1], '/tmp/claude-0/T637', 19894, out='test-637a.txt'); T.start()
try:
    T.say('== LAMWEB test 637a - QA-0005 (STOP line via SMS templates)')
    S = 's005'; ck, cs = T.login(S); f0 = T.php(S, 'echo setting("sms_footer");')
    c, b = T.req(S, 'sms_tpl_save', {'key': 'sms_footer', 'text': 'Thanks!', 'force': 1}, ck, cs); f1 = T.php(S, 'echo setting("sms_footer");')
    T.ok('1 salon not main: sms_tpl_save sms_footer -> 403 "NailFlow", the STOP line unchanged', c == 403 and 'NailFlow' in b and f1 == f0 and 'STOP' in f1, (c, b[:150], f1))
    T.php(S, 'set_setting("sms_tpl_hist", json_encode(["sms_footer" => [["at" => now_str(), "text" => "old words no stop"]]]));')
    c, b = T.req(S, 'sms_tpl_restore', {'key': 'sms_footer'}, ck, cs); f2 = T.php(S, 'echo setting("sms_footer");')
    T.ok('1 sms_tpl_restore sms_footer (an old copy without STOP) -> 403, unchanged', c == 403 and f2 == f0, (c, b[:150], f2))
    x = T.php(S, 'echo q("SELECT COUNT(*) FROM audit_log WHERE kind = \'nf_only\' AND target LIKE \'sms_tpl_%\'")->fetchColumn();')
    T.ok('1 each refusal -> audit row kind nf_only', x == '2', x)
    c, b = T.req(S, 'sms_tpl_default', {'key': 'sms_footer'}, ck, cs); T.ok('2 "Restore default" (with STOP) still works', c == 200, (c, b[:150]))
    c, b = T.req(S, 'sms_tpl_save', {'key': 'sms_confirm', 'text': 'Hi {name}, see you {when} at {salon}.', 'force': 1}, ck, cs)
    T.ok('2 the salon still edits its own texts (sms_confirm) -> 200', c == 200, (c, b[:150]))
    c, b = T.req(S, 'sms_samples', None, ck, cs); keys = [i['key'] for i in json.loads(b).get('items', [])] if c == 200 else []
    T.ok('3 Settings -> SMS templates: the STOP line is not in the owner\'s list (status only); the others are', c == 200 and 'sms_footer' not in keys and 'sms_confirm' in keys, keys[:5])
    ck1, cs1 = T.login('s001', '0')
    c, b = T.req('s001', 'sms_tpl_save', {'key': 'sms_footer', 'text': 'This is {salon}. Reply STOP to opt out', 'force': 1}, ck1, cs1); v = T.php('s001', 'echo setting("sms_footer");')
    T.ok('4 American Nails (main): sms_tpl_save sms_footer works as before', c == 200 and v == 'This is {salon}. Reply STOP to opt out', (c, b[:150], v))
    c, b = T.req('s001', 'sms_samples', None, ck1, cs1); keys = [i['key'] for i in json.loads(b).get('items', [])] if c == 200 else []
    T.ok('4 American Nails: the STOP line still in its list', 'sms_footer' in keys, keys[:5])
finally: T.end()
