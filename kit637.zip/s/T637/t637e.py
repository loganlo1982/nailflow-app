# LAMWEB test 637e - QA-0006: behind this server's own proxy (Love Nails: REMOTE_ADDR = 72.167.37.112 / 127.0.0.1) the log keeps the VISITOR's address
# (the last X-Forwarded-For entry = the one our proxy added), and the login lock is per visitor, not one lock for everybody. A visitor that is not the
# proxy cannot fake its address with the header.
import sys, json, os; sys.path.insert(0, '/tmp/claude-0/T637'); from nfenv import Env
T = Env(sys.argv[1], '/tmp/claude-0/T637', 19898, out='test-637e.txt'); T.start()
try:
    T.say('== LAMWEB test 637e - QA-0006 (real IP behind the proxy)')
    S = 's005'; XF = {'X-Forwarded-For': '198.51.100.7, 203.0.113.9'}
    ck, cs = T.login(S, hdr=XF)
    c, b = T.req(S, 'backup_now', {}, ck, cs, hdr=XF)
    ip = T.php(S, 'echo q("SELECT ip FROM audit_log ORDER BY id DESC LIMIT 1")->fetchColumn();')
    T.ok('1 a logged action (refused backup_now -> audit row) through the proxy: the log keeps the visitor (203.0.113.9), not the server', c == 403 and ip == '203.0.113.9', (c, ip))
    c, b = T.req(S, 'backup_now', {}, ck, cs); ip = T.php(S, 'echo q("SELECT ip FROM audit_log ORDER BY id DESC LIMIT 1")->fetchColumn();')
    T.ok('1 without the header: the address as before (127.0.0.1)', c == 403 and ip == '127.0.0.1', (c, ip))
    T.php(S, 'q("DELETE FROM login_attempts");')
    for i in range(5): T.req(S, 'login', {'password': 'wrong-%d' % i}, hdr={'X-Forwarded-For': '203.0.113.10'})
    c1, b1 = T.req(S, 'login', {'password': 'wrong-x'}, hdr={'X-Forwarded-For': '203.0.113.10'})
    c2, b2 = T.req(S, 'login', {'password': 'wrong-y'}, hdr={'X-Forwarded-For': '203.0.113.11'})
    ip = T.php(S, 'echo q("SELECT ip FROM audit_log WHERE kind = \'login_locked\' ORDER BY id DESC LIMIT 1")->fetchColumn();')
    T.ok('2 the "login locked" log row has the visitor\'s address (203.0.113.10)', ip == '203.0.113.10', ip)
    T.ok('2 5 wrong passwords from one visitor lock THAT visitor; another visitor through the same proxy is not locked', c1 == 429 or 'many' in b1.lower(), (c1, b1[:100]))
    T.ok('2 ... the other visitor gets the normal "wrong password", not the lock', 'many' not in b2.lower() and c2 != 429, (c2, b2[:100]))
    x = T.php(S, 'echo client_ip(), "|";', pre='$_SERVER["REMOTE_ADDR"] = "8.8.8.8"; $_SERVER["HTTP_X_FORWARDED_FOR"] = "1.2.3.4";')
    y = T.php(S, 'echo client_ip(), "|";', pre='$_SERVER["REMOTE_ADDR"] = "72.167.37.112"; $_SERVER["HTTP_X_FORWARDED_FOR"] = "1.2.3.4, 5.6.7.8";')
    z = T.php(S, 'echo client_ip(), "|";', pre='$_SERVER["REMOTE_ADDR"] = "72.167.37.112"; $_SERVER["HTTP_X_FORWARDED_FOR"] = "not-an-ip";')
    T.ok('3 a visitor that is not our proxy cannot fake its address (8.8.8.8 stays); from the proxy: the last entry (5.6.7.8); junk header: the proxy address', x == '8.8.8.8|' and y == '5.6.7.8|' and z == '72.167.37.112|', (x, y, z))
finally: T.end()
