# LAMWEB test 637c - QA-0002: "is this American Nails?" follows sites.php ('main'), not config 'noindex'. A salon with 'main' => false is never
# American Nails even when its config.php forgot 'noindex'; it gets the Getting started card + tour + sample menu like a new salon.
# American Nails (main) and the old single copy (no sites.php): as before.
import sys, json, os, shutil, subprocess; sys.path.insert(0, '/tmp/claude-0/T637'); from nfenv import Env, ENV
T = Env(sys.argv[1], '/tmp/claude-0/T637', 19896, n=3, noindex={1: False, 2: False, 3: True}, out='test-637c.txt'); T.start()
try:
    T.say('== LAMWEB test 637c - QA-0002 (main salon = sites.php)')
    q = 'require_once getenv("NFR") . "/inc/outbox.php"; require_once getenv("NFR") . "/inc/calls-agent.php"; require_once getenv("NFR") . "/inc/getstarted.php"; require_once getenv("NFR") . "/inc/svc-tpl.php"; echo (int)main_salon(), (int)cl_agent_allowed(), (int)owner_test_phone("+15156727879"), (int)svc_tpl_new_salon(), (int)gs_show();'
    x = T.php('s002', q); T.ok('1 s002 (main => false, config WITHOUT noindex): main_salon 0, AI phone not on, Logan phone not a test number, sample menu ok, card shown', x == '00011', x)
    x = T.php('s003', q); T.ok('1 s003 (main => false, noindex): same as today', x == '00011', x)
    x = T.php('s001', q); T.ok('2 s001 American Nails (main => true): main_salon 1, AI phone on, its test phone, no sample menu, no card', x == '11100', x)
    ck, cs = T.login('s002'); c, b = T.req('s002', 'getstarted', None, ck, cs); j = json.loads(b) if c == 200 else {}
    T.ok('1 s002 owner Home: "Set up your salon" card + first-time tour', j.get('show') is True and j.get('tour') is True and j.get('stepsAll') == 6, (c, b[:200]))
    for S in ['s002', 's003']:
        c, b = T.req(S, 'info'); j = json.loads(b) if c == 200 else {}
        T.ok('1 %s booking page: no American Nails drinks line (English and Spanish)' % S, c == 200 and j.get('perks') == '' and j.get('perksEs') == '', (c, j.get('perks'), j.get('perksEs')))
    c, b = T.req('s001', 'info'); j = json.loads(b) if c == 200 else {}
    T.ok('2 American Nails booking page: its drinks line (English and Spanish) as before', 'Moscato' in j.get('perks', '') and 'Moscato' in j.get('perksEs', ''), (c, j.get('perks'), j.get('perksEs')))
    ck1, cs1 = T.login('s001', '0'); c, b = T.req('s001', 'getstarted', None, ck1, cs1); j = json.loads(b) if c == 200 else {}
    T.ok('2 American Nails owner Home: no card, no tour', c == 200 and j.get('show') is False and not j.get('tour'), (c, b[:200]))
    D = T.D
    for nm, ni, want in [('old1', False, '1'), ('old2', True, '0')]:
        old = D + '/' + nm; shutil.rmtree(old, ignore_errors=True); shutil.copytree(sys.argv[1], old, symlinks=True); db = D + '/' + nm + '.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', db)
        open(old + '/inc/config.php', 'w').write("<?php\nreturn ['driver' => 'sqlite', 'sqlite_path' => '%s', 'site_url' => 'http://127.0.0.1:1'%s];\n" % (db, ", 'noindex' => true" if ni else ''))
        r = subprocess.run(['php', '-r', 'require "%s/inc/core.php"; echo (int)main_salon();' % old], capture_output=True, text=True, env=ENV)
        T.ok('3 old single copy (no sites.php) %s noindex: main_salon = %s as before' % ('with' if ni else 'without', want), r.stdout.strip() == want, r.stdout + r.stderr)
finally: T.end()
