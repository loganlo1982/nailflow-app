# LAMWEB test 637b - QA-0004: a date that does not exist (2026-11-31, 2026-02-29, 2026-06-31) is NOT a date anywhere: valid_date(), booking page
# (slots, book), the AI phone tools, the customer import. Real dates (2028-02-29, 2026-11-30) still work.
import sys, json; sys.path.insert(0, '/tmp/claude-0/T637'); from nfenv import Env
T = Env(sys.argv[1], '/tmp/claude-0/T637', 19895, out='test-637b.txt'); T.start()
try:
    T.say('== LAMWEB test 637b - QA-0004 (dates that do not exist)')
    x = T.php('s001', 'foreach (["2026-11-31","2026-02-29","2026-06-31","2027-02-29","2026-02-30"] as $d) echo valid_date($d) ? 1 : 0; echo "|"; foreach (["2028-02-29","2026-11-30","2026-12-31","2026-01-01"] as $d) echo valid_date($d) ? 1 : 0; echo "|"; foreach (["2026-13-01","2026-1-01","x"] as $d) echo valid_date($d) ? 1 : 0;')
    T.ok('1 valid_date: 31/11 30/02 31/06 29/02/2027 -> no · 29/02/2028 30/11 31/12 1/1 -> yes · 13th month / bad text -> no', x == '00000|1111|000', x)
    S = 's001'; pd = T.php(S, 'q("INSERT INTO services (name, duration, price, color, sort, turn_value, return_days, name_es, design, short_name) VALUES (\'Pedicure\', 45, 35, \'#3472B9\', 1, 1, 0, \'\', 0, \'PD\')"); $i = db()->lastInsertId(); q("INSERT INTO staff (name, active, sort) VALUES (\'ANNA\', 1, 1)"); if (function_exists("skills_sync")) skills_sync(); echo $i;')
    c, b = T.req(S, 'slots', None, q='&date=2026-11-31&services=%s&people=0&svcs=%s' % (pd, pd))
    T.ok('2 booking page: slots for 2026-11-31 -> "Bad date" (no times offered)', c != 200 and 'Bad date' in b, (c, b[:200]))
    c, b = T.req(S, 'slots', None, q='&date=2026-11-30&services=%s&people=0&svcs=%s' % (pd, pd)); T.ok('2 slots for a real day (2026-11-30) -> 200', c == 200, (c, b[:200]))
    bd = {'lang': 'en', 'date': '2026-11-31', 'start': 660, 'people': [0], 'services': [int(pd)], 'svcs': [[int(pd)]], 'plan': [None], 'design': [0], 'name': 'BADDAY', 'phone': '5555550161', 'note': '', 'sms_ok': False, 'sms_no': False, 'website': '', 'birthday': '', 'bchange': False}
    c, b = T.req(S, 'book', bd); n = T.php(S, 'echo q("SELECT COUNT(*) FROM appointments WHERE appt_date = \'2026-11-31\'")->fetchColumn();')
    T.ok('2 book on 2026-11-31 -> refused, no appointment written', c != 200 and n == '0', (c, b[:200], n))
    bd['date'] = '2027-02-29'; c, b = T.req(S, 'book', bd)
    T.ok('2 book on 2027-02-29 -> refused as a bad date (not "that time was just taken")', c != 200 and 'just taken' not in b, (c, b[:200]))
    x = T.php(S, 'require_once getenv("NFR") . "/inc/calls-agent.php"; echo json_encode([cl_agent_dt(["date" => "2026-11-31", "time" => "11:00"]), cl_agent_dt(["date" => "2026-11-30", "time" => "11:00"])]);')
    T.ok('3 AI phone: "November 31st" is not a day (the AI asks again); 30/11 is', x == '[["",660],["2026-11-30",660]]', x)
    x = T.php(S, 'require_once getenv("NFR") . "/inc/import.php"; $r = customers_import("1 | 5555550162 | F | 2026-02-30\\n2 | 5555550163 | F | 2026-02-28", true); echo json_encode([count($r["errors"] ?? []), $r["errors"][0]["line"] ?? 0]);')
    T.ok('4 customer import: last visit 2026-02-30 -> that line is an error (line 1), 2026-02-28 fine', x == '[1,1]', x)
finally: T.end()
