# LAMWEB 637: shared helper for the 637 tests - a fake SHARED layout like production (app/releases/v + sites.php + sites/<id>/config.php), SQLite each,
# s001 = main (American Nails), s002.. = other salons (noindex like live unless told). One php -S serves all (Host header picks the salon).
import subprocess, json, os, shutil, time, urllib.request, urllib.error
ENV = {**os.environ, 'TZ': 'America/Chicago'}
class Env:
    def __init__(self, app0, d, port, n=5, noindex=None, out='test.txt'):
        self.D = d; self.port = int(os.environ.get('NF_PORT_SHIFT', 0)) + port; self.R = []; self.out = open(d + '/' + out, 'w')
        E = d + '/env'; shutil.rmtree(E, ignore_errors=True); app = E + '/app'; self.REL = app + '/releases/v'
        shutil.copytree(app0, self.REL, symlinks=True, ignore=shutil.ignore_patterns('config.php', 'uploads', 'sessions'))
        lines = []; noindex = noindex if noindex is not None else {i: i > 1 for i in range(1, n + 1)}
        for i in range(1, n + 1):
            sid = 's%03d' % i; web = E + '/web/' + sid; sd = app + '/sites/' + sid
            os.makedirs(web + '/uploads'); os.makedirs(sd + '/data'); shutil.copy('/tmp/claude-0/tdb/base.sqlite', sd + '/data/db.sqlite')
            open(sd + '/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s/data/db.sqlite','site_url'=>'http://%s.qa.test'%s);\n" % (sd, sid, ", 'noindex'=>true" if noindex.get(i) else ''))
            lines.append("  '%s' => ['hosts' => ['%s.qa.test'], 'web' => '%s', 'cron' => [], 'main' => %s]," % (sid, sid, web, 'true' if i == 1 else 'false'))
        open(app + '/sites.php', 'w').write("<?php\nreturn [\n" + "\n".join(lines) + "\n];\n")
        self.srv = None
    def start(self):
        self.srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % self.port, '-t', self.REL], stdout=subprocess.DEVNULL, stderr=open(self.D + '/php.log', 'w'), env=ENV); time.sleep(1.2)
    def stop(self):
        if self.srv: self.srv.terminate()
    def say(self, s): print(s, flush=True); self.out.write(s + '\n'); self.out.flush()
    def ok(self, n, c, i=''): self.R.append(bool(c)); self.say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:300]))
    def php(self, S, code, pre=''):
        r = subprocess.run(['php', '-d', 'error_log=/dev/null', '-r', 'require "%s/inc/core.php"; %s settings(); %s' % (self.REL, pre, code)], capture_output=True, text=True, env={**ENV, 'SALON_ID': S, 'NFR': self.REL})
        return (r.stdout + r.stderr).strip()
    def req(self, S, a, body=None, ck=None, cs=None, q='', hdr=None):
        h = {'Host': S + '.qa.test', 'Content-Type': 'application/json'}; h.update({'Cookie': ck} if ck else {}); h.update({'X-CSRF': cs} if cs else {}); h.update(hdr or {})
        rq = urllib.request.Request('http://127.0.0.1:%d/api.php?action=%s%s' % (self.port, a, q), data=None if body is None else json.dumps(body).encode(), headers=h)
        try: r = urllib.request.urlopen(rq, timeout=30); return r.status, r.read().decode()[:400000]
        except urllib.error.HTTPError as e: return e.code, e.read().decode()[:400000]
    def login(self, S, hq='1', hdr=None):
        pw = 'qa-' + os.urandom(3).hex()
        self.php(S, 'set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on","0"); set_setting("as_hq_only",%r); q("DELETE FROM login_attempts");' % (pw, hq))
        h = {'Host': S + '.qa.test', 'Content-Type': 'application/json'}; h.update(hdr or {})
        rq = urllib.request.Request('http://127.0.0.1:%d/api.php?action=login' % self.port, data=json.dumps({'password': pw}).encode(), headers=h)
        r = urllib.request.urlopen(rq, timeout=30); b = r.read().decode(); sc = r.headers.get_all('Set-Cookie') or []
        return '; '.join(x.split(';')[0] for x in sc), json.loads(b).get('csrf', '')
    def end(self):
        self.stop(); self.say('PASS %d/%d' % (sum(self.R), len(self.R)))
