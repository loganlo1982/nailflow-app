import subprocess, json, os, sys, time, urllib.request, urllib.parse, shutil, datetime as _dt, threading
A = os.environ.get('APP', '/tmp/claude-0/S610'); D = '/tmp/claude-0/T610'; T5 = '/tmp/claude-0/T586'; PORT = int(os.environ.get('P', '19890')); DB = D + '/db.sqlite'
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SHARED_DIR': T5 + '/shared', 'NF_CALLS_DIR': D + '/calls'}
def sh(*a, env=None): return subprocess.run(a, capture_output=True, text=True, env=env or ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
def setup():
    shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
    seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout)
    sh('php', '-r', "require '%s/inc/core.php'; settings(); set_setting('online_booking','1'); set_setting('as_on','0');" % A)
    return seed
def start():
    sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '8'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.2); return sv
B = lambda: 'http://127.0.0.1:%d/api.php' % PORT
def api(action, body=None, q=None, ip=None):
    u = B() + '?action=' + action + ('&' + urllib.parse.urlencode(q) if q else '')
    hd = {'Content-Type': 'application/json'}
    rq = urllib.request.Request(u, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = urllib.request.urlopen(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        t = e.read().decode()
        try: return e.code, json.loads(t)
        except Exception: return e.code, {'raw': t[:300]}
def unlimit(): sql("DELETE FROM login_attempts")
