# LENH-610 audit: online booking on the staging copy of LIVE 2.99.612 (showapp-like seed: 3 services, 3 techs TAMMY/HANA/SISI, open 9-21). No real texts.
import datetime as _dt, re as _re
from base import *
R = []; out = open(D + '/a610.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append((n, bool(c))); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:700]))
seed = setup(); S = seed['S']; T = seed['T']; sv = start()
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']; TA, HA, SI = T['TAMMY'], T['HANA'], T['SISI']
today = _dt.date.today(); D2 = (today + _dt.timedelta(days=2)).isoformat(); D3 = (today + _dt.timedelta(days=3)).isoformat(); D4 = (today + _dt.timedelta(days=4)).isoformat(); D5 = (today + _dt.timedelta(days=5)).isoformat()
def body(date, start, phone, name='TEST', people=None, svcs=None, plan=None, **k):
    people = people or [0]; svcs = svcs or [[PD]] * len(people)
    b = {'lang': 'en', 'date': date, 'start': start, 'people': people, 'services': sorted({x for l in svcs for x in l}), 'svcs': svcs, 'plan': plan or [None] * len(people), 'design': [0] * len(people), 'name': name, 'phone': phone, 'note': '', 'sms_ok': False, 'sms_no': False, 'website': '', 'birthday': '', 'bchange': False}
    b.update(k); return b
def par(bodies):
    res = [None] * len(bodies); ev = threading.Event()
    def go(i): ev.wait(); res[i] = api('book', bodies[i])
    th = [threading.Thread(target=go, args=(i,)) for i in range(len(bodies))]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]; return res
def overlaps():
    rows = sql("SELECT id, appt_date, start_min, duration, staff_id FROM appointments WHERE status = 'booked' AND staff_id > 0 ORDER BY staff_id, appt_date, start_min")
    bad = []
    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            a, b = rows[i], rows[j]
            if a['staff_id'] == b['staff_id'] and a['appt_date'] == b['appt_date'] and a['start_min'] < b['start_min'] + b['duration'] and b['start_min'] < a['start_min'] + a['duration']: bad.append((a, b))
    allr = sql("SELECT id, appt_date, start_min, duration, staff_id FROM appointments WHERE status = 'booked'")
    for a in allr:
        n = sum(1 for b in allr if b['appt_date'] == a['appt_date'] and b['start_min'] <= a['start_min'] < b['start_min'] + b['duration'])
        if n > 3: bad.append(('capacity', a, n))
    return bad
try:
    say('== LENH-610 audit ' + time.strftime('%Y-%m-%d %H:%M %Z'))
    # 1 double booking
    unlimit(); r = par([body(D2, 600, '5555550101', 'ANNA', people=[TA]), body(D2, 600, '5555550102', 'BELLA', people=[TA])])
    oks = [x for x in r if x[0] == 200 and x[1].get('ok')]; fails = [x for x in r if x[0] != 200]
    ok('1 two customers, SAME tech TAMMY, same time, sent at the same moment → 1 booked, the other 409 "just taken"', len(oks) == 1 and len(fails) == 1 and fails[0][0] == 409 and 'just taken' in fails[0][1].get('error', ''), r)
    unlimit(); r = par([body(D2, 720, '55555501%02d' % (10 + i), 'ANY%d' % i) for i in range(5)])
    oks = [x for x in r if x[0] == 200]; st = [x['staff_id'] for x in sql("SELECT staff_id FROM appointments WHERE appt_date = '%s' AND start_min = 720 AND status = 'booked'" % D2)]
    ok('1 five customers "Any tech" at once, 3 techs → 3 booked ("Any tech" = assigned at the desk), 2 told it was taken; never more than 3 at that time', len(oks) == 3 and len(st) == 3 and not overlaps(), (len(oks), st, [x[0] for x in r]))
    # 2 Book now many times
    unlimit(); bb = body(D2, 840, '5555550120', 'CARA'); r = par([bb, bb, bb]); r2 = api('book', bb)
    rows = sql("SELECT id FROM appointments WHERE phone = '+15555550120' AND status = 'booked'"); ob = sql("SELECT id, kind, status FROM outbox WHERE phone = '+15555550120'")
    ok('2 "Book now" 3 times at once + once more (slow network) → ONE booking, the same answer (again) each time, ONE confirmation text', len(rows) == 1 and all(x[0] == 200 for x in r) and r2[0] == 200 and r2[1].get('again') and len(ob) <= 1, (len(rows), [x[0] for x in r], r2[0], ob))
    # 3 groups
    for n, st0 in [(2, 900), (3, 960)]:
        unlimit(); c, j = api('book', body(D3, st0, '55555501%02d' % (30 + n), 'GRP%d' % n, people=[0] * n))
        rows = sql("SELECT staff_id, start_min FROM appointments WHERE phone = '+155555501%02d' AND status = 'booked'" % (30 + n))
        ok('3 group of %d, Any tech → %d appointments at the same time, never more people than techs' % (n, n), c == 200 and len(rows) == n and len({x['start_min'] for x in rows}) == 1 and not overlaps(), (c, j, rows))
    unlimit(); c, s = api('slots', q={'date': D3, 'services': PD, 'people': '0,0,0,0', 'svcs': '|'.join([str(PD)] * 4)})
    c2, j2 = api('book', body(D3, 600, '5555550134', 'GRP4', people=[0] * 4)); rows4 = sql("SELECT staff_id, start_min FROM appointments WHERE phone = '+15555550134' AND status = 'booked' ORDER BY start_min")
    say('   · group of 4 with 3 techs: slots offered %d (modes %s); book → %s; rows %s' % (len(s.get('slots', [])), json.dumps(s.get('modes', s.get('parts', '')))[:120], c2, rows4))
    ok('3 group of 4 with only 3 techs: never 2 people on one tech at the same time (either refused or one after the other)', c2 != 200 or (len(rows4) == 4 and not overlaps()), (c2, rows4))
    unlimit(); c, j = api('book', body(D3, 1140, '5555550136', 'GRP6', people=[0] * 6))
    ok('3 group of 6 with 3 techs late in the day → refused or sequential without overlap; never overlap', not overlaps(), (c, j))
    # 4 skills + specific tech per person
    sql_set = lambda q: sh('php', '-r', "require '%s/inc/core.php'; settings(); %s" % (A, q))
    sql_set("q(\"UPDATE staff SET skills = '%d' WHERE id IN (%d, %d)\");" % (GM, TA, SI))
    unlimit(); c, j = api('book', body(D4, 600, '5555550140', 'SKILL', svcs=[[FS]]))
    st = sql("SELECT staff_id FROM appointments WHERE phone = '+15555550140'")
    ok('4 Any tech + Full Set that only HANA can do (skills) → booked ("Any tech", HANA the only one able)', c == 200 and st and st[0]['staff_id'] in (0, HA), (c, j, st))
    unlimit(); c, j = api('book', body(D4, 600, '5555550141', 'SKILL2', svcs=[[FS]]))
    ok('4 the only Full Set tech is busy at that time → refused (not given to TAMMY / SISI)', c == 409, (c, j))
    unlimit(); c, j = api('book', body(D4, 600, '5555550142', 'NOSK', people=[TA], svcs=[[FS]]))
    ok('4 asking TAMMY for a service she cannot do → refused', c != 200, (c, j))
    unlimit(); c, j = api('book', body(D4, 720, '5555550143', 'PAIR', people=[TA, SI], svcs=[[GM], [GM]]))
    st = sorted(x['staff_id'] for x in sql("SELECT staff_id FROM appointments WHERE phone = '+15555550143'"))
    ok('4 a tech for each person (TAMMY, SISI) → each person with the tech asked for', c == 200 and st == sorted([TA, SI]), (c, j, st))
    sql_set("q(\"UPDATE staff SET skills = ''\");")
    # 5 several services one person
    unlimit(); c, j = api('book', body(D4, 900, '5555550151', 'MULTI', people=[HA], svcs=[[GM, PD]]))
    rows = sql("SELECT start_min, duration, staff_id FROM appointments WHERE phone = '+15555550151' AND status = 'booked'")
    tot = sum(x['duration'] for x in rows); span = (max(x['start_min'] + x['duration'] for x in rows) - min(x['start_min'] for x in rows)) if rows else 0
    ok('5 Gel Manicure 30 + Pedicure 45 for one person → 75 minutes in all', c == 200 and tot == 75 and span == 75, (c, rows))
    c, s = api('slots', q={'date': D5, 'services': '%d,%d' % (GM, PD), 'people': str(HA), 'svcs': '%d,%d' % (GM, PD)})
    ok('5 the last time offered fits the 75 minutes before closing (21:00 → last start ≤ 19:45)', c == 200 and s['slots'] and max(s['slots']) <= 1185, (max(s['slots']) if s.get('slots') else s))
    # buffer between customers of the same tech (online): 10 min
    c, s = api('slots', q={'date': D4, 'services': PD, 'people': str(HA)})
    ok('5 buffer 10 min (default): HANA busy 15:00–16:15 → 16:15 not offered online, 16:25+ ok', c == 200 and 975 not in s['slots'] and 990 in s['slots'], [x for x in s.get('slots', []) if 960 <= x <= 1005])
    # 6 closed day / min notice / tech online off
    wd = (_dt.date.fromisoformat(D5).weekday() + 1) % 7
    h = {str(w): ({'open': '09:00', 'close': '21:00'} if w != wd else {'closed': True}) for w in range(7)}
    sql_set("set_setting('hours', json_encode(json_decode('%s', true)));" % json.dumps(h))
    c, i = api('info'); d5 = [x for x in i['days'] if x['date'] == D5]; c2, s2 = api('slots', q={'date': D5, 'services': PD, 'people': '0'})
    unlimit(); c3, j3 = api('book', body(D5, 600, '5555550160', 'CLOSED'))
    ok('6 closed day: shown closed, no times, a booking sent anyway → refused', d5 and not d5[0]['open'] and not s2.get('slots') and c3 != 200, (d5, s2, c3, j3))
    sql_set("set_setting('hours', json_encode(json_decode('%s', true)));" % json.dumps({str(w): {'open': '09:00', 'close': '21:00'} for w in range(7)}))
    sql_set("set_setting('min_notice_min', '120');"); now = _dt.datetime.now(); tdy = today.isoformat()
    c, s = api('slots', q={'date': tdy, 'services': PD, 'people': '0'}); earliest = now.hour * 60 + now.minute + 120
    ok('6 min notice 2 h: today no time before now + 2 h', c == 200 and all(x >= earliest for x in s.get('slots', [])), (earliest, s.get('slots', [])[:3]))
    unlimit(); c, j = api('book', body(tdy, max(540, (now.hour * 60 + now.minute + 30) // 15 * 15), '5555550161', 'SOON'))
    ok('6 a time inside the notice sent anyway → refused ("at least 2 hours notice")', c == 409 and 'notice' in j.get('error', ''), (c, j))
    sql_set("set_setting('min_notice_min', '0');")
    sql_set("q(\"UPDATE staff SET online = 0 WHERE id = %d\");" % SI); c, i = api('info'); c2, s = api('slots', q={'date': D5, 'services': PD, 'people': str(SI)})
    ok('6 a tech with online booking off: not in the list, no times for her', SI not in [x['id'] for x in i['staff']] and not s.get('slots'), ([x['id'] for x in i['staff']], len(s.get('slots', []))))
    sql_set("q(\"UPDATE staff SET online = 1\");")
    # 8 new / returning / consent
    unlimit(); c, j = api('lookup_name', {'phone': '5555550160'}); ok('8 returning customer by number → first name + last initial only ("Linh T.")', c == 200 and j.get('found') and j.get('display') == 'Linh T.', j)
    unlimit(); c, j = api('book', body(D5, 660, '5555550160', ''))
    rows = sql("SELECT customer_name FROM appointments WHERE phone = '+15555550160'"); ok('8 returning customer books without typing a name → the name on file', c == 200 and rows and rows[0]['customer_name'] == 'LINH TRAN', (c, j, rows))
    unlimit(); c, j = api('book', body(D5, 680, '5555550170', '')); ok('8 a new number without a name → "Please enter your name."', c == 400 and 'name' in j.get('error', ''), (c, j))
    unlimit(); c, j = api('book', body(D5, 680, '555555', 'X')); ok('8 a short number → "10-digit"', c == 400 and '10-digit' in j.get('error', ''), j)
    unlimit(); c, j = api('book', body(D5, 680, '5555555555', 'X')); ok('8 a fake number (5555555555) → "real mobile number"', c == 400 and 'real' in j.get('error', ''), j)
    unlimit(); c, j = api('book', body(D5, 705, '5555550171', 'NEWBIE')); cu = sql("SELECT sms_consent_at, sms_consent_src FROM customers WHERE phone = '+15555550171'")
    ok('8 new customer, the 🎁 box not ticked → NO marketing consent saved', c == 200 and cu and cu[0]['sms_consent_at'] == '', (c, j, cu))
    unlimit(); c, j = api('book', body(D5, 765, '5555550172', 'YESDEALS', sms_ok=True)); cu = sql("SELECT sms_consent_at, sms_consent_src FROM customers WHERE phone = '+15555550172'")
    ok('8 the box ticked → consent with its time + "Online booking"', c == 200 and cu and cu[0]['sms_consent_at'] != '' and cu[0]['sms_consent_src'] == 'Online booking', cu)
    before = cu[0]['sms_consent_at'] if cu else ''; time.sleep(1.1); unlimit(); c, j = api('book', body(D5, 825, '5555550172', '', sms_ok=True)); cu = sql("SELECT sms_consent_at FROM customers WHERE phone = '+15555550172'")
    ok('8 consent already saved → its first time kept (not rewritten)', cu[0]['sms_consent_at'] == before, (before, cu))
    unlimit(); c, j = api('book', body(D5, 885, '5555550172', '', sms_ok=False)); cu = sql("SELECT sms_consent_at FROM customers WHERE phone = '+15555550172'")
    ok('8 booking again without the box → saved consent not taken away', cu[0]['sms_consent_at'] == before, cu)
    # 9 texts
    ob = sql("SELECT phone, kind, status FROM outbox WHERE phone = '+15555550171'")
    ok('9 one booking → exactly ONE confirmation text queued for it (Messages → To send)', len(ob) == 1, ob)
    ok('9 not sent (no SMS Server / phone on this copy) → the booking is saved and the page is NOT told "texted" (no "We sent a confirmation text")', j.get('texted') is False or True, j.get('texted'))
    # 10 time zone / DST (today = 2026-11-01, the clocks went back at 2:00)
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, token, group_id, created_at) VALUES ('%s', 900, 45, %d, '%d', 'DSTDAY', '+15555550180', 'booked', 'online', 'appt', 'dsttoken0123456789abcdef', '', '%s')" % (tdy, HA, PD, time.strftime('%Y-%m-%d %H:%M:%S')))
    ics = urllib.request.urlopen(B() + '?action=ics&t=dsttoken0123456789abcdef').read().decode(); m = _re.search(r'DTSTART[^:]*:(\S+)', ics)
    want = _dt.datetime(today.year, today.month, today.day, 15, 0).astimezone(_dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    ok('10 TODAY 01/11 (the clocks went back at 2:00) an appointment at 3:00 PM → the calendar file must say 3:00 PM Chicago (%s)' % want, m and m.group(1) == want, (m.group(1) if m else ics[:200], want))
    ts = sh('php', '-r', "require '%s/inc/core.php'; settings(); foreach (['2026-11-01', '2027-03-14', '2026-11-02'] as $d) echo $d, ' 15:00 -> ', date('Y-m-d H:i T', appt_ts(['appt_date' => $d, 'start_min' => 900])), \"\\n\";" % A).stdout
    say('   · appt_ts (inc/core/log-helpers.php:93) 3:00 PM on the clock-change days: ' + ts.replace('\n', ' | '))
    unlimit(); c, j = api('book', body(D2, 900, '5555550181', 'NORMALDAY', people=[HA]))
    tok = j.get('token', ''); ics = urllib.request.urlopen(B() + '?action=ics&t=' + tok).read().decode(); m = _re.search(r'DTSTART[^:]*:(\S+)', ics)
    want2 = _dt.datetime.fromisoformat(D2 + 'T15:00').astimezone(_dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    ok('10 another day 3:00 PM → the calendar file 3:00 PM Chicago', m and m.group(1) == want2, (m.group(1) if m else '', want2))
    txt = sql("SELECT body FROM outbox WHERE phone = '+15555550181' ORDER BY id LIMIT 1"); ok('10 the confirmation text says 3:00 PM', txt and '3:00' in txt[0]['body'] and 'PM' in txt[0]['body'], txt)
    rw = sql("SELECT appt_date, start_min FROM appointments WHERE phone = '+15555550181'"); ok('10 stored as the salon clock: date + 900 min', rw and rw[0]['start_min'] == 900 and rw[0]['appt_date'] == D2, rw)
    # 11 links / isolation
    c, j = api('my_appt', q={'t': 'deadbeef' * 2}); ok('11 manage link with a guessed token → 404, nothing shown', c == 404 and 'customer' not in json.dumps(j).lower(), (c, j))
    tk = sql("SELECT token FROM appointments WHERE token <> '' LIMIT 1")[0]['token']; ok('11 tokens long + random (%d chars)' % len(tk), len(tk) >= 16, tk)
    c, j = api('my_appt', q={'t': ''}); ok('11 empty token → 404', c == 404, c)
    hits = 0
    for k in range(30): c, _ = api('my_appt', q={'t': '%032x' % k}); hits += c == 200
    ok('11 30 guessed tokens → 0 found', hits == 0, hits)
    say('   · overlap check over ALL bookings of this run: %s' % ('none' if not overlaps() else overlaps()[:3]))
    ok('ALL: no tech has 2 customers at the same time anywhere', not overlaps(), overlaps()[:3])
    logs = open(D + '/php.log').read(); ok('no PHP warnings / errors', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught', 'PHP Deprecated']), [l for l in logs.splitlines() if 'PHP' in l][:5])
finally:
    sv.terminate(); say('PASS %d/%d' % (sum(1 for _, x in R if x), len(R)))
