# LAMWEB test 635B – QA-0001: a salon that is NOT American Nails never gets Logan's phone as its default (admin_reset_phone / as_iphone),
# on a fake SHARED layout (app/sites.php: an = main, s002 = a new salon with an empty database, lovenails = '' written by hand); the old single copy keeps the default.
#   python3 t635b.py <app folder>
import subprocess, json, os, sys, time, shutil
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T635B'
R = []; out = open(D + '/test-635b.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a, env=None): return subprocess.run(a, capture_output=True, text=True, env=env or ENV)
H = D + '/home'; shutil.rmtree(H, ignore_errors=True); APP = H + '/app'; V = '9.9.9'
REL = APP + '/releases/' + V; shutil.copytree(A0, REL, symlinks=True, ignore=shutil.ignore_patterns('config.php', 'uploads', 'sessions'))
os.makedirs(H + '/public_html'); os.makedirs(H + '/s002'); os.makedirs(H + '/lovenails')
for sid in ['an', 's002', 'lovenails']:
    os.makedirs(APP + '/sites/%s/data' % sid); os.symlink('../../releases/' + V, APP + '/sites/%s/current' % sid)
    db = APP + '/sites/%s/data/db.sqlite' % sid
    if sid == 'an': shutil.copy('/tmp/claude-0/tdb/base.sqlite', db)
    open(APP + '/sites/%s/config.php' % sid, 'w').write("<?php\nreturn ['driver' => 'sqlite', 'sqlite_path' => '%s', 'site_url' => 'https://%s.example.test'];\n" % (db, sid))
open(APP + '/sites.php', 'w').write("""<?php
return [
    'an' => ['hosts' => ['an.example.test'], 'web' => '%s/public_html', 'cron' => [], 'main' => true],
    's002' => ['hosts' => ['s002.example.test'], 'web' => '%s/s002', 'cron' => [], 'main' => false],
    'lovenails' => ['hosts' => ['lovenails.example.test'], 'web' => '%s/lovenails', 'cron' => [], 'main' => false],
];
""" % (H, H, H))
def php(sid, code, setup=''):
    p = '$R = getenv("NF_REL"); require $R . "/inc/core.php"; require_once $R . "/inc/schema.php"; ' + setup + ' settings(true); ' + code
    r = sh('php', '-r', p, env={**ENV, 'SALON_ID': sid, 'NF_REL': REL}); return (r.stdout + r.stderr).strip()
mkdb = 'foreach (schema_sql("sqlite") as $sql) { try { db()->exec($sql); } catch (PDOException $e) {} } ensure_schema();'
say('== LAMWEB test 635B – QA-0001 (no Logan phone at a new salon) ' + time.strftime('%Y-%m-%d %H:%M %Z'))
x = php('s002', 'echo setting("admin_reset_phone"), "|", setting("as_iphone");', mkdb)
ok('1 a NEW salon (not main, nothing written yet): "Forgot password" phone and the texting phone are EMPTY (not +15156727879)', x == '|', x)
x = php('s002', 'require_once getenv("NF_REL") . "/inc/api/_auth.php"; echo json_encode(["smsTo" => (strlen($p = norm_phone(setting("as_iphone"))) === 12 ? substr($p, 2) : "")]);')
ok('1 so its booking page never says "text 5156727879"', '5156727879' not in x, x)
x = php('s002', 'echo "[", setting("salon_name"), "]", "[", salon_title(), "]";')
ok('1 a NEW salon with no name yet: the name is EMPTY (never "AMERICAN NAILS AND SPA" on its pages); salon_title() works', x == '[][]', x)
x = php('lovenails', 'echo setting("admin_reset_phone"), "|", setting("as_iphone");', mkdb + ' set_setting("admin_reset_phone", ""); set_setting("as_iphone", "+15156660000");')
ok('2 Love Nails (its own values written): unchanged', x == '|+15156660000', x)
x = php('an', 'echo setting("admin_reset_phone"), "|", setting("as_iphone");')
ok('3 American Nails (main): the default stays (+15156727879)', x == '+15156727879|+15156727879', x)
x = php('an', 'echo setting("salon_name");'); ok('3 American Nails: its own name from its database (not emptied)', x == 'TEST SALON', x)
x = php('s002', 'set_setting("admin_reset_phone", "+15155550111"); settings(true); echo setting("admin_reset_phone");')
ok('4 a new salon typing its own phone in Settings -> kept', x == '+15155550111', x)
old = D + '/old'; shutil.rmtree(old, ignore_errors=True); shutil.copytree(A0, old, symlinks=True); db = D + '/old.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', db)
open(old + '/inc/config.php', 'w').write("<?php\nreturn ['driver' => 'sqlite', 'sqlite_path' => '%s', 'site_url' => 'http://127.0.0.1:1'];\n" % db)
r = sh('php', '-r', 'require "%s/inc/core.php"; echo setting("admin_reset_phone");' % old)
ok('5 the old single copy (not shared): unchanged default', r.stdout.strip() == '+15156727879', r.stdout + r.stderr)
say('PASS %d/%d' % (sum(R), len(R)))
