<?php // php db.php <db> "<sql>" → JSON rows
$d = new PDO('sqlite:' . $argv[1]); $d->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $s = $d->query($argv[2]); echo json_encode($s ? $s->fetchAll(PDO::FETCH_ASSOC) : [], JSON_UNESCAPED_UNICODE), "\n";
