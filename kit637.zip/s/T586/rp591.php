<?php
[$_, $R, $DB, $IN] = $argv; file_put_contents("$R/inc/config.php", "<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'$DB','site_url'=>'https://american-nails-and-spa.com');\n");
require "$R/inc/core.php"; settings(); ensure_schema(); define('NF_API_LIB', 1);
foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once $R . $f; require_once "$R/api.php"; require_once "$R/inc/calls-job.php";
$I = json_decode(file_get_contents($IN), true); $GLOBALS['actor'] = ['call', 'replay'];
q('DELETE FROM services'); foreach ($I['svc'] as $s) q('INSERT INTO services (id, name, duration, price, sort, active) VALUES (?, ?, ?, 0, ?, ?)', [(int)$s[0], trim($s[1]), (int)$s[2], (int)$s[0], (int)$s[3]]);
q('UPDATE staff SET active = 0'); foreach ($I['tech'] as $t) { q('DELETE FROM staff WHERE id = ?', [(int)$t[0]]); q('INSERT INTO staff (id, name, sort, active, online) VALUES (?, ?, ?, 1, 1)', [(int)$t[0], trim($t[1]), (int)$t[0]]); }
$h = []; for ($w = 0; $w < 7; $w++) $h[$w] = ['open' => '09:00', 'close' => '19:00']; set_setting('hours', json_encode($h)); set_setting('call_on', '1');
cl_table(); q('DELETE FROM appointments'); q('DELETE FROM customers');
foreach ($I['calls'] as $c) {
    $ph = '+1515499' . sprintf('%04d', 7400 + $c['id']); if ($c['cust'] !== '') upsert_customer($ph, $c['cust']);
    q("INSERT INTO calls (id, call_sid, rec_sid, from_phone, kind, started_at, dur_sec, status, text_c, text_s, ai_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'work', ?, ?, ?, ?)",
      [$c['id'], 'CArp' . $c['id'], 'RErp' . $c['id'], $ph, $c['kind'], now_str(), $c['dur'], $c['tc'], $c['ts'], $c['aj'], now_str()]);
    $row = q('SELECT * FROM calls WHERE id = ?', [$c['id']])->fetch(); $j = json_decode($c['aj'], true) ?: [];
    $st = cl_decide($row, $j); $n = q('SELECT * FROM calls WHERE id = ?', [$c['id']])->fetch();
    $a = (int)$n['appt_id'] ? q('SELECT * FROM appointments WHERE id = ?', [(int)$n['appt_id']])->fetch() : null;
    echo "#{$c['id']}  BEFORE ({$c['kind']}): {$c['status']} – {$c['reason']} – {$c['result']}\n      NOW    ({$n['kind']}): $st – {$n['reason']} – {$n['result']}" . ($a ? "  → appt {$a['customer_name']} · " . appt_label($a) . ' · ' . $a['appt_date'] . ' ' . min_to_label((int)$a['start_min']) : '') . "\n";
}
