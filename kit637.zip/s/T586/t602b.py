# LAMWEB test 586 – the whole call flow on a local copy (fake SignalWire / STT / Claude; test numbers 555-01xx only). python3 t586.py <app tree>
import subprocess, json, os, sys, time, hmac, hashlib, base64, urllib.request, urllib.parse, shutil
A = sys.argv[1]; D = '/tmp/claude-0/T586'; PORT = 19861; DB = D + '/db.sqlite'; KEY = 'PSK_test_signing_key_0123456789'
R = []; out = open(D + '/test-602B.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', D + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
for f in os.listdir(D + '/calls') if os.path.isdir(D + '/calls') else []: pass
shutil.rmtree(D + '/calls', ignore_errors=True); os.makedirs(D + '/calls'); open(D + '/fake.log', 'w').close()
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
OAI = True
if OAI: json.dump({}, open(D + '/shared/color-ai.json', 'w'))
else: json.dump({'key': 'sk-ant-test-000000000000000000000000'}, open(D + '/shared/color-ai.json', 'w'))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SHARED_DIR': D + '/shared', 'NF_CALLS_DIR': D + '/calls'}
seed = json.loads(sh('php', D + '/seed.php', A, DB, str(PORT)).stdout); S, T, d1 = seed['S'], seed['T'], seed['d1']
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
def ai(**k): b = {'intent': 'book', 'customer_name': '', 'customer_phone': '', 'service_ids': [], 'service_text': '', 'tech_id': 0, 'tech_text': '', 'date': d1, 'time': '', 'people': 1, 'salon_side': 'person', 'salon_agreed': False, 'salon_quote': '', 'confidence': 0.95, 'missing': [], 'summary': ''}; b.update(k); return b
scen = {'stt': {
  '3': {'c': '#S1 Hi this is Mia, can I get a gel manicure tomorrow at 2?', 's': 'Sure, tomorrow at 2 is open. OK, see you at 2!'},
  '4': {'c': '#S2 This is Linh, pedicure with Tammy tomorrow at 3 please', 's': 'Let me check the book for you.'},
  '5': {'c': '#S3 How much is a full set?', 's': 'Full set is fifty dollars.'},
  '6': {'c': '#S4 Hi this is Anna, I want a full set tomorrow at 11 with Hana. Thanks!'},
  '7': {'c': '#S5 Bella here, gel manicure tomorrow at 4 with Sisi please, call me back'},
  '8': {'c': '#S6 Hi I want a pedicure tomorrow, Cara', 's': 'ok'},
  '9': {'c': '#S7 Hi Dana, gel manicure tomorrow at noon?', 's': 'Yes ok, noon tomorrow.'},
  '10': {'c': '#S8 chị muốn làm bột thứ bảy 2 giờ, tên Hoa', 's': 'Dạ ok chị, 2 giờ nha.'}},
 'ai': {
  '1': ai(customer_name='Mia', service_ids=[GM], time='14:00', salon_agreed=True, salon_quote='OK, see you at 2', summary='Mia wants a gel manicure tomorrow at 2 PM.'),
  '2': ai(customer_name='Linh', service_ids=[PD], tech_id=T['TAMMY'], tech_text='Tammy', time='15:00', salon_agreed=True, salon_quote='ok sure 3pm', summary='Linh wants a pedicure with Tammy tomorrow 3 PM.'),
  '3': ai(intent='info', summary='Asked the price of a full set.'),
  '4': ai(customer_name='Anna', service_ids=[FS], tech_id=T['HANA'], tech_text='Hana', time='11:00', summary='Voicemail: Anna, full set tomorrow 11 AM with Hana.'),
  '5': ai(customer_name='Bella', service_ids=[GM], tech_id=T['SISI'], tech_text='Sisi', time='16:00', summary='Voicemail: Bella, gel manicure tomorrow 4 PM with Sisi.'),
  '6': ai(customer_name='Cara', service_ids=[PD], time='', salon_agreed=True, salon_quote='ok', confidence=0.9, missing=['time'], summary='Cara wants a pedicure tomorrow, no time.'),
  '7': ai(customer_name='Dana', service_ids=[GM], time='12:00', salon_agreed=True, salon_quote='Yes ok, noon tomorrow', summary='Dana, gel manicure tomorrow at noon.'),
  '8': ai(customer_name='Hoa', service_ids=[FS], time='14:00', date=d1, salon_agreed=True, salon_quote='Dạ ok chị, 2 giờ nha', confidence=0.9, summary='Hoa wants a full set at 2 PM.')}}
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
fk = subprocess.Popen(['python3', D + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.3)
B = 'http://127.0.0.1:%d' % PORT
def post(a, p, sign=True, key=KEY, url=None):
    u = url or (B + '/call_in.php?' + a); body = urllib.parse.urlencode(p).encode(); h = {'Content-Type': 'application/x-www-form-urlencoded'}
    if sign: h['X-SignalWire-Signature'] = base64.b64encode(hmac.new(key.encode(), (u + ''.join(k + p[k] for k in sorted(p))).encode(), hashlib.sha1).digest()).decode()
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, data=body, headers=h), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
ACC = '11111111-2222-3333-4444-555555555555'
def call(n, frm, sec, stereo=True, vm=False):
    sid = 'CA%04d' % n; rs = 'RE%04d' % n; subprocess.run(['python3', D + '/mkwav.py', rs, str(sec), '1' if stereo else '0'])
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if vm: post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    c2, x2 = post('a=rec' + ('&vm=1' if vm else ''), {'AccountSid': ACC, 'CallSid': sid, 'RecordingSid': rs, 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/%s' % (ACC, rs), 'RecordingStatus': 'completed', 'RecordingDuration': str(sec), 'RecordingChannels': '2' if stereo else '1'})
    for k in range(80):
        row = sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
        if row and row[0]['status'] not in ('queued', 'work', 'ring') or (row and row[0]['status'] == 'queued' and row[0]['tries'] >= 1): break
        time.sleep(0.25)
    return (c, x, c2, x2), row
def appt(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, customer_name, status, source, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def push(): return sql("SELECT target, kind, title, body FROM push_log ORDER BY id DESC LIMIT 1") if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []



open(D + '/set590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'salon_name' => 'American Nails', 'as_kinds' => json_encode(['confirm' => true, 'change' => true, 'cancel' => true])] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set590.php')
open(D + '/undo.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];\n$a = $argv[1];\nif ($a === 'tick') { cl_tick(); echo 'ticked'; }\n" % (A, A, A, A))
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat(); d3 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=3)).isoformat()
open(D + '/mk592.php', 'w').write("<?php require '%s/inc/core.php'; settings(); [$_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = [];\nupsert_customer($ph, $name);\nfor ($i = 0; $i < (int)$n; $i++) { q(\"INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)\", [$date, (int)$start, 45, (int)$staff + $i * ((int)$staff ? 1 : 0), '%d', $i ? $name . ' +' . $i : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); }\necho implode(',', $ids);" % (A, S['Pedicure']))
def mk(ph, name, date, start, staff=0, n=1): return [int(x) for x in sh('php', D + '/mk592.php', ph, name, date, str(start), str(staff), str(n)).stdout.split(',')]
def ap(i): return sql("SELECT id, appt_date, start_min, staff_id, status FROM appointments WHERE id = %d" % i)[0]
def ob(i, k): return sql("SELECT kind, ref, status FROM outbox WHERE appt_id = %d AND kind = '%s'" % (i, k))
def lastpush(): return sql("SELECT title, body FROM push_log WHERE target = 'admin' ORDER BY id DESC LIMIT 1")
def go(n, ph, j, tc, ts=None, vm=True):
    scen['stt'][str(n)] = {'c': '#S%d ' % (100 + n) + tc} if ts is None else {'c': '#S%d ' % (100 + n) + tc, 's': ts}
    scen['ai'][str(100 + n)] = j; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
    r, row = call(n, ph, n, stereo=not vm, vm=vm); time.sleep(0.8); return mrow('CA%04d' % n)[0]
def mrow(sid): return sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
say('== LAMWEB test 2.99.602 – LENH 602 manicure pedicure type asked by text ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire / STT / AI · texts only into the SMS Server queue')
open(D + '/h594.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; cl_table(); $a = $argv[1];\n"
 "if ($a === 'set') { set_setting($argv[2], $argv[3]); echo 'ok'; }\n"
 "if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }\n"
 "if ($a === 'list') echo json_encode(['l' => cl_list(10), 'n' => cl_badge()]);\n"
 "if ($a === 'poke') { cl_cron_poke(); echo 'poked'; }\n" % (A, A))
def h(*a): r = sh('php', D + '/h594.php', *a); return r.stdout
def P(name='', sids=None, text='', tid=0, tt=''): return {'name': name, 'service_ids': sids or [], 'service_text': text, 'tech_id': tid, 'tech_text': tt}
def grp(ph): return sql("SELECT id, appt_date, start_min, duration, staff_id, service_ids, customer_name, status, source, group_id, note FROM appointments WHERE phone = '%s' AND status <> 'cancelled' ORDER BY id" % ph)
def conf(ph):
    for k in range(12):
        r = sql("SELECT id, kind, ref FROM outbox WHERE phone = '%s' AND kind = 'confirm'" % ph)
        if r: return r
        time.sleep(0.25)
    return r
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat()
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
import atexit; atexit.register(lambda: (sv.terminate(), fk.terminate()))
open(D + '/h602.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; cl_table(); $a = $argv[1];\n"
 "if ($a === 'svc') { $i = 0; foreach (json_decode($argv[2], true) as $s) { q('INSERT INTO services (name, duration, price, sort, active) VALUES (?, ?, ?, ?, 1)', [$s[0], $s[1], $s[2], 10 + $i++]); } echo json_encode(array_column(q('SELECT id, name FROM services WHERE active = 1')->fetchAll(), 'id', 'name')); }\n"
 "if ($a === 'off') { q('UPDATE services SET active = 0 WHERE name = ?', [$argv[2]]); echo '{}'; }\n"
 "if ($a === 'on') { q('UPDATE services SET active = 1 WHERE name = ?', [$argv[2]]); echo '{}'; }\n"
 "if ($a === 'in') { require_once '%s/inc/android.php'; $GLOBALS['actor'] = ['system', 'Android']; echo json_encode(ad_incoming($argv[2], $argv[3])); }\n"
 "if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }\n"
 "if ($a === 'kinds') { require_once '%s/inc/calls-ask.php'; echo json_encode(cla_kinds()); }\n" % (A, A, A, A))
def h(*a):
    r = sh('php', D + '/h602.php', *a)
    try: return json.loads(r.stdout or '{}')
    except Exception: print('RAW', a, r.stdout[:400], r.stderr[:400]); raise
SV = h('svc', json.dumps([['Dip Powder', 45, 40], ['Regular Manicure', 30, 20], ['Gel Pedicure', 50, 45], ['Builder Gel', 75, 60], ['Fill', 45, 35], ['Polish Change', 0, 10]]))
DIP, RMA, GPE, FS2 = SV['Dip Powder'], SV['Regular Manicure'], SV['Gel Pedicure'], SV['Full Set']
K = h('kinds'); ok('K this salon\'s menu → dip = Dip Powder · gel = Gel Manicure (not Builder Gel) · acrylic = Full Set (not Fill) · regular pedicure = Pedicure · gel pedicure = Gel Pedicure', K['dip'] == DIP and K['gel'] == GM and K['acr'] == FS and K['preg'] == PD and K['pgel'] == GPE and K['mreg'] == RMA and K['pdip'] == 0, K)
def asks(ph): return sql("SELECT src, body, state FROM autosend WHERE phone = '%s' AND src LIKE 'ui:callask:%%' ORDER BY id" % ph)
def confs(ph): return sql("SELECT src, kind, state FROM autosend WHERE phone = '%s' AND kind = 'confirm' AND src NOT LIKE 'ui:call%%'" % ph) + sql("SELECT ref FROM outbox WHERE phone = '%s' AND kind = 'confirm'" % ph)
def one(ph): x = sql("SELECT id, service_ids, staff_id, note, duration, status, start_min FROM appointments WHERE phone = '%s' AND status = 'booked' ORDER BY id" % ph); return x
# 0. BỔ SUNG 21:55 (priority #1): "2 people, 2 pedicures + 1 manicure" was booked as 3 people
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat()
def rows(ph): return sql("SELECT id, service_ids, duration, customer_name, group_id FROM appointments WHERE phone = '%s' AND status = 'booked' ORDER BY id" % ph)
r = go(51, '+15555550151', ai(customer_name='Test', people=2, party=[P('', [PD]), P('', [PD]), P('', [RMA])], date=d2, time='12:00', summary='two people, two pedicures and one manicure'), 'on Monday at 12 p.m. for two people, for two pedicures and one manicure')
g = rows('+15555550151')
ok('0a LN call #3 replayed: people 2 but party = 3 entries (one per service) → 2 appointments: [Pedicure + Regular Manicure] (45 + 30 = 75 min, pedicure first) + [Pedicure]', r['status'] == 'booked' and len(g) == 2 and g[0]['service_ids'] == '%d,%d' % (PD, RMA) and g[0]['duration'] == 75 and g[1]['service_ids'] == str(PD) and g[1]['duration'] == 45 and r['result'].endswith('· 2 people'), (r['status'], r['reason'], r['result'], g))
r = go(52, '+15555550152', ai(customer_name='Tri', people=3, party=[P('', [PD]), P('', [PD]), P('', [PD])], date=d2, time='18:00', summary='3 pedis'), 'three people, three pedicures')
ok('0b "3 people, 3 pedicures" → 3 × Pedicure (unchanged)', r['status'] == 'booked' and [x['service_ids'] for x in rows('+15555550152')] == [str(PD)] * 3, (r['status'], r['reason'], rows('+15555550152')))
r = go(53, '+15555550153', ai(customer_name='Uno', service_ids=[PD, RMA], date=d2, time='14:00', summary='pedi and mani'), 'one person, pedicure and manicure')
g = rows('+15555550153'); ok('0c "1 person pedi and mani" → 1 appointment Pedicure + Regular Manicure, 75 min', r['status'] == 'booked' and len(g) == 1 and sorted(g[0]['service_ids'].split(',')) == sorted([str(PD), str(RMA)]) and g[0]['duration'] == 75, (r['status'], r['reason'], g))
r = go(54, '+15555550154', ai(customer_name='Vee', people=2, service_ids=[PD], same_services=True, date=d2, time='15:00', summary='two pedicures'), 'two pedicures please')
ok('0d "two pedicures" (no people word, AI says 2) → 2 people, each Pedicure', r['status'] == 'booked' and [x['service_ids'] for x in rows('+15555550154')] == [str(PD)] * 2, (r['status'], r['reason'], rows('+15555550154')))
r = go(55, '+15555550155', ai(customer_name='Wen', people=2, party=[P('', [PD], tid=T['TAMMY'], tt='Tammy'), P('', [PD]), P('', [RMA])], date=d2, time='16:00', summary='x'), 'two people two pedis one mani with Tammy')
ok('0e 3 entries for 2 people + a tech named → not sure → NOT booked, Call back "techs per person not clear"', r['status'] == 'callback' and not rows('+15555550155') and 'techs per person not clear' in r['reason'].lower(), (r['status'], r['reason']))
# 1. dip / gel real / gel fake → that service, no question
r = go(61, '+15555550161', ai(customer_name='Ana', service_ids=[RMA], service_text='dip manicure', mani_type='dip', time='10:00', summary='Ana dip'), 'Hi this is Ana, dip manicure tomorrow at 10')
ok('1 "dip manicure" → BOOKED Dip Powder, no question text', r['status'] == 'booked' and one('+15555550161')[0]['service_ids'] == str(DIP) and not asks('+15555550161'), (r['status'], r['reason'], one('+15555550161')))
r = go(62, '+15555550162', ai(customer_name='Bea', service_ids=[GM], service_text='gel manicure', mani_type='gel_real', time='10:30', summary='Bea gel real'), 'Bea, gel manicure on my real nails tomorrow 10:30')
ok('1 "gel on my real nails" → Gel Manicure, no question', r['status'] == 'booked' and one('+15555550162')[0]['service_ids'] == str(GM) and not asks('+15555550162'), (r['status'], r['reason']))
r = go(63, '+15555550163', ai(customer_name='Cleo', service_ids=[GM], service_text='shellac', mani_type='gel_fake', time='11:00', summary='Cleo shellac fake'), 'Cleo, shellac on fake nails tomorrow at 11')
ok('1 "shellac on fake nails" → Full Set (acrylic), no question', r['status'] == 'booked' and one('+15555550163')[0]['service_ids'] == str(FS) and not asks('+15555550163'), (r['status'], r['reason'], one('+15555550163')))
# 2. "manicure" → booked + asked → "2" → Gel Manicure
r = go(64, '+15555550164', ai(customer_name='Dora', service_ids=[], service_text='manicure', mani_type='plain', time='12:00', summary='Dora manicure'), 'Dora, a manicure tomorrow at noon')
a = one('+15555550164'); q = asks('+15555550164')
ok('2 just "manicure" → BOOKED at once (Regular Manicure kept as the nearest) + note "⏳ Chờ khách chọn loại mani"', r['status'] == 'booked' and a and a[0]['service_ids'] == str(RMA) and a[0]['note'].startswith('⏳ Chờ khách chọn loại mani'), (r['status'], r['reason'], a))
ok('2 (621.9 doi y: 612m/n CHAT - the menu 1 Gel / 2 Dip / 3 Acrylic powder) ONE text, sent now: "American Nails: For your manicure on <day> 12:00 PM, which one? Reply 1 = Gel, 2 = Dip, 3 = Acrylic (powder). See all services: <link>"', len(q) == 1 and q[0]['state'] == 'taken' and q[0]['body'].startswith('American Nails: For your manicure on ') and '12:00 PM, which one? Reply 1 = Gel, 2 = Dip, 3 = Acrylic (powder). See all services: http' in q[0]['body'] and '❌' not in q[0]['body'], q)
say('   text: ' + (q[0]['body'] if q else '-'))
ok('2 the usual YOU\'RE BOOKED held (the question says the day / time – 1 text)', not confs('+15555550164'), confs('+15555550164'))
ok('2 Calls list "… · ⏳ asked: manicure type"', r['result'].endswith('⏳ asked: manicure type'), r['result'])
x = h('in', '+15555550164', '1'); a = one('+15555550164')
ok('2 (621.9 doi y: 612m/n - Gel is 1 now) reply "1" → Gel Manicure on the appointment, same time, note cleaned', x.get('kind') == 'call-choice' and a[0]['service_ids'] == str(GM) and a[0]['start_min'] == 720 and not a[0]['note'].startswith('⏳'), (x, a))
c2 = sql("SELECT body FROM autosend WHERE phone = '+15555550164' AND src LIKE 'ui:callpick:%'")
ok('2 … + short confirmation "American Nails: Got it! Gel Manicure – <day> 12:00 PM. See you!"', len(c2) == 1 and c2[0]['body'].replace(' - ', ' – ').startswith('American Nails: Got it! Gel Manicure – ') and '12:00 PM. See you!' in c2[0]['body'], c2)
ok('2 the reply is kept in Messages (read)', sql("SELECT id FROM messages WHERE phone = '+15555550164' AND dir = 'in' AND body = '1'"), '')
cr = sql("SELECT result FROM calls WHERE call_sid = 'CA0064'"); ok('2 Calls list "… · ✓ customer picked Gel Manicure"', cr and cr[0]['result'].endswith('✓ customer picked Gel Manicure'), cr)
x = h('in', '+15555550164', '1'); ok('2 a 2nd "1" later → NOT taken again (Messages as a normal text)', x.get('kind') != 'call-choice' and one('+15555550164')[0]['service_ids'] == str(GM), x)
# 3. pedicure → asked → "1" → Regular
r = go(65, '+15555550165', ai(customer_name='Eva', service_ids=[PD], service_text='pedicure', pedi_type='plain', time='13:00', summary='Eva pedicure'), 'Eva, pedicure tomorrow at 1')
q = asks('+15555550165')
ok('3 just "pedicure" → booked (Pedicure) + "For your pedicure on … which one? Reply 1 = Regular polish, 2 = Gel/Shellac. See all services: …"', r['status'] == 'booked' and len(q) == 1 and 'For your pedicure on ' in q[0]['body'] and 'Reply 1 = Regular polish, 2 = Gel/Shellac. See all services: ' in q[0]['body'], (r['status'], r['reason'], q))
x = h('in', '+15555550165', '2'); ok('3 reply "2" → Gel Pedicure (50 min)', one('+15555550165')[0]['service_ids'] == str(GPE) and one('+15555550165')[0]['duration'] == 50, (x, one('+15555550165')))
# 4. manicure + pedicure in one appointment → 1 text, 2 questions, "2 1"
r = go(66, '+15555550166', ai(customer_name='Faye', service_ids=[PD], service_text='mani pedi', mani_type='plain', pedi_type='plain', time='14:00', summary='Faye mani pedi'), 'Faye, mani and pedi tomorrow at 2')
q = asks('+15555550166'); a = one('+15555550166')
ok('4 (621.9 doi y: 612m/n menu) mani + pedi → 1 appointment (Pedicure + Regular Manicure) + ONE text with 2 questions "Reply both numbers (e.g. "2 1")"', r['status'] == 'booked' and len(q) == 1 and 'Manicure: 1 = Gel, 2 = Dip, 3 = Acrylic (powder). Pedicure: 1 = Regular polish, 2 = Gel/Shellac. Reply both numbers' in q[0]['body'] and sorted(a[0]['service_ids'].split(',')) == sorted([str(PD), str(RMA)]) and a[0]['note'].startswith('⏳ Chờ khách chọn loại mani + pedi'), (r['status'], r['reason'], q, a))
x = h('in', '+15555550166', '2'); ok('4 only ONE number for 2 questions → not taken (Messages), still waiting', x.get('kind') != 'call-choice' and one('+15555550166')[0]['note'].startswith('⏳'), x)
x = h('in', '+15555550166', '3, 2'); a = one('+15555550166')
ok('4 reply "3, 2" → Full Set + Gel Pedicure', x.get('kind') == 'call-choice' and sorted(a[0]['service_ids'].split(',')) == sorted([str(FS), str(GPE)]), (x, a))
# 5. group of 2 "both pedicure" → 1 question, reply → both
r = go(67, '+15555550167', ai(customer_name='Gia', people=2, service_ids=[PD], same_services=True, pedi_type='plain', time='15:00', summary='2 pedis'), 'Gia, me and my daughter both want a pedicure tomorrow at 3')
g = one('+15555550167'); q = asks('+15555550167')
ok('5 group of 2 "both pedicure" → 2 rows booked, ONE question', r['status'] == 'booked' and len(g) == 2 and len(q) == 1 and all(x['note'].startswith('⏳') for x in g), (r['status'], r['reason'], g, q))
x = h('in', '+15555550167', '2'); g = one('+15555550167')
ok('5 reply "2" → BOTH people Gel Pedicure + 1 confirmation "(2 people)"', all(x2['service_ids'] == str(GPE) for x2 in g) and sql("SELECT body FROM autosend WHERE phone = '+15555550167' AND src LIKE 'ui:callpick:%'")[0]['body'].split('\n')[0].endswith('(2 people). See you!'), (x, g))
# 6. no answer → kept + label · odd answers → Messages
r = go(68, '+15555550168', ai(customer_name='Hana', service_ids=[], service_text='manicure', mani_type='plain', time='16:00', summary='Hana manicure'), 'Hana, manicure tomorrow 4')
x = h('in', '+15555550168', 'Yes thank you'); y = h('in', '+15555550168', '7')
ok('6 "Yes thank you" / "7" (no such choice) → Messages as before, nothing changed, still "⏳ waiting"', x.get('kind') == 'reply' and y.get('kind') == 'reply' and one('+15555550168')[0]['service_ids'] == str(RMA) and one('+15555550168')[0]['note'].startswith('⏳'), (x, y))
ok('6 no answer → the appointment stays booked (never cancelled)', one('+15555550168')[0]['status'] == 'booked', '')
x = h('in', '+15555550150', '2'); ok('6 "2" from a number with NO question (ROSA TEST) → a normal text (Messages) as before', x.get('kind') == 'reply', x)
# 7. the menu has no Dip → that choice left out; the tech who cannot do it → Any tech
h('off', 'Dip Powder')
sql("UPDATE staff SET skills = '%d' WHERE id = %d" % (RMA, T['TAMMY']))
r = go(69, '+15555550169', ai(customer_name='Ivy', service_ids=[], service_text='manicure', mani_type='plain', tech_id=T['TAMMY'], tech_text='Tammy', time='17:00', summary='Ivy manicure Tammy'), 'Ivy, manicure with Tammy tomorrow 5')
q = asks('+15555550169')
ok('7 (621.9 doi y: 612m/n menu) no Dip on the menu → "Reply 1 = Gel, 2 = Acrylic (powder)" (renumbered)', r['status'] == 'booked' and q and 'Reply 1 = Gel, 2 = Acrylic (powder).' in q[0]['body'], (r['status'], r['reason'], q))
x = h('in', '+15555550169', '1'); a = one('+15555550169')
ok('7 reply "1" → Gel Manicure; TAMMY does only Regular Manicure → Any tech (as the booking rules)', a[0]['service_ids'] == str(GM) and a[0]['staff_id'] == 0, (x, a))
sql("UPDATE staff SET skills = '' WHERE id = %d" % T['TAMMY']); h('on', 'Dip Powder')
# 8. a specific service said / old flow
r = go(70, '+15555550170', ai(customer_name='Jo', service_ids=[GM], service_text='gel manicure', mani_type='specific', time='18:00', summary='Jo gel manicure'), 'Jo, the gel manicure tomorrow 6')
ok('8 an exact menu service ("specific") → booked as said, no question, YOU\'RE BOOKED as before', r['status'] == 'booked' and not asks('+15555550170') and one('+15555550170')[0]['service_ids'] == str(GM), (r['status'], r['reason']))
r = go(71, '+15555550171', ai(customer_name='Kay', service_ids=[FS], time='19:00', summary='Kay full set'), 'Kay full set tomorrow 7')
ok('8 old AI answer without mani_type / pedi_type → exactly as before (booked, no question)', r['status'] == 'booked' and not asks('+15555550171'), (r['status'], r['reason']))
# 9. Spanish customer
sql("UPDATE customers SET lang = 'es' WHERE phone = '+15555550172'") if sql("SELECT id FROM customers WHERE phone = '+15555550172'") else None
sh('php', '-r', "require '%s/inc/core.php'; settings(); upsert_customer('+15555550172', 'LUZ'); q(\"UPDATE customers SET lang = 'es' WHERE phone = '+15555550172'\");" % A)
r = go(72, '+15555550172', ai(customer_name='Luz', service_ids=[PD], pedi_type='plain', time='20:00', summary='Luz pedicure'), 'Luz, pedicura mañana a las 8')
q = asks('+15555550172'); ok('9 a Spanish customer → "Para su pedicura el …, ¿cuál? Responda 1 = Esmalte regular, 2 = Gel/Shellac. Ver todos los servicios: …"', q and 'Para su pedicura el ' in q[0]['body'] and 'Responda 1 = Esmalte regular, 2 = Gel/Shellac. Ver todos los servicios: ' in q[0]['body'], q)
# 10. voicemail words
st, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CA0990', 'From': '+15555550190', 'To': '+15156061616', 'CallStatus': 'ringing'})
st2, x2 = post('a=done', {'AccountSid': ACC, 'CallSid': 'CA0990', 'DialCallStatus': 'no-answer'})
ok('10 voicemail: "…after the beep. For a manicure or pedicure, please say Dip, or Gel on your real nails, or Gel on fake nails. Thank you!"', 'after the beep. For a manicure or pedicure, please say Dip, or Gel on your real nails, or Gel on fake nails. Thank you!' in x2.replace('&#039;', "'").replace('&apos;', "'"), x2[:400])
# ==== 602B v4 (2.99.604): the switchboard talks – listen until done, the AI follows the conversation, the code checks + does it ====
say('\n==== 602B v4 – the switchboard talks ====')
ALLDAY = {str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)}
h('set', json.dumps({'call_ivr': '', 'hours': json.dumps(ALLDAY), 'call_owner': '5155550177'}))
import re as _re, datetime as _dt
ME = '+15154997409'  # anh Logan's own test phone (499) - local copy only: texts only into the fake SMS Server queue
_t = _dt.date.today()
def nextwd(k): return (_t + _dt.timedelta(days=((k - _t.weekday()) % 7) or 7)).isoformat()
def W(k): return (_dt.date.fromisoformat(nextwd(k)) + _dt.timedelta(days=7)).isoformat()  # the week after: free of the 602 tests' bookings
dmon, dfri = nextwd(0), nextwd(4)
def says(xml): return ' | '.join(_re.findall(r'<Say[^>]*>([^<]*)</Say>', xml)).replace('&apos;', "'").replace('&#039;', "'")
def callreq(ph): return sql("SELECT src, body, state FROM autosend WHERE phone = '%s' AND src LIKE 'ui:callreq:%%' ORDER BY id" % ph)
def st_of(ph): return sql("SELECT id, customer_name, status, appt_date, start_min, staff_id, service_ids, note, color FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def TJ(**k):
    b = {'action': 'unclear', 'say': '', 'more': False, 'appt_id': 0, 'name': '', 'people': 0, 'persons': [], 'date': '', 'time': '', 'window_from': '', 'window_to': '', 'person_name': '',
         'service_ids': [], 'from_service_ids': [], 'mani_type': 'none', 'pedi_type': 'none', 'note': '', 'question_topic': '', 'minutes_late': 0, 'missing': []}
    b.update(k); return b
def PP(sids, name='', tech=0, text=''): return {'name': name, 'service_ids': sids, 'service_text': text, 'tech_id': tech}
def both(t, a): x = dict(a); x.update(t); return x  # the talk answer + the voicemail reader's answer (the cron reads a call hung up half-way)
def setai(k, j): scen['ai'][str(k)] = j; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
CALLS = {}
def sw(n, frm, said, ais=None, answer=True):
    for k, j in (ais or {}).items(): setai(k, j)
    sid = 'CW%04d' % n; CALLS[n] = sid
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if answer and '<Dial' in x: c, x = post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    out = [x]
    for s in said:
        if s is None: break
        m = _re.search(r'<Gather[^>]*action="([^"]+)"', x) or _re.search(r'<Dial[^>]*action="([^"]+)"', x)
        if not m: break
        p = {'AccountSid': ACC, 'CallSid': sid, 'SpeechResult': s, 'Confidence': '0.72'} if not s.startswith('DIAL:') else {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': s[5:]}
        c, x = post(None, p, url=m.group(1).replace('&amp;', '&')); out.append(x)
    time.sleep(0.6); return out
def S(out): return [says(x) for x in out]
def crow(n): return mrow(CALLS[n])[0]
GREET = "Thank you for calling American Nails. This call may be recorded. Sorry, we can't take your call right now. Please tell me the reason for your call."
FILL = SV['Fill']; BG = SV['Builder Gel']
# T1 Jessica: booking + a detail + a question, all in one breath
o = sw(1, '+15555550101', ["Hi this is Jessica #S801, I'd like a gel manicure Friday around 2, can you do French tips? and how much is it?", 'yes'],
       {801: TJ(action='book_new', name='Jessica', persons=[PP([GM])], date=dfri, time='14:00', mani_type='gel_real', note='French tip', question_topic='the price')})
ok('T1 (621.9 doi y: CHAT 01/11 echo fix - speak FIRST, then listen: the line echo was heard as the caller) ONE open sentence "' + GREET + '" · voice Polly.Joanna-Neural · <Say> then <Gather speechTimeout 4>', S(o)[0] == GREET and 'voice="Polly.Joanna-Neural"' in o[0] and _re.search(r'</Say>\s*<Gather[^>]*speechTimeout="4"', o[0]) is not None and _re.search(r'<Gather[^>]*>\s*<Say', o[0]) is None and 'enhanced="true" speechModel="phone_call"' in o[0], o[0][:400])
ok('T1 the caller said it all → ONE read-back, the way a front desk says it: "… a gel manicure this Friday at 2, for Jessica. Sound good? I noted your request." (no price, no long note)', 'a gel manicure this Friday at 2' in S(o)[1] and 'Jessica' in S(o)[1] and S(o)[1].endswith('I noted your request.') and '$' not in S(o)[1] and 'French' not in S(o)[1], S(o))
a1 = st_of('+15555550101')
ok('T1 "yes" → BOOKED Gel Manicure Fri 2 PM with the note "📞 French tip" → then "You\'re all set. You also asked about the price. Let me connect you to the salon." + the owner\'s phone', a1 and a1[0]['service_ids'] == str(GM) and a1[0]['start_min'] == 840 and '📞 French tip' in a1[0]['note'] and S(o)[2] == "You're all set. You also asked about the price. Let me connect you to the salon." and '<Dial' in o[2] and '+15155550177' in o[2], (S(o), a1))
# T2 LN #5: a half sentence → listened to again (only "Mm-hmm.") → joined; "Medicare" = manicure; type not said → Regular Manicure + the 1/2/3 text
o = sw(2, '+15555550102', ['My name is my name is uh', 'Love #S802. I would like I want a Medicare. Day and time uh I want on Monday at 1:00 p.m.', 'yes'],
       {802: both(TJ(action='book_new', name='Love', persons=[PP([RMA])], date=W(0), time='13:00', mani_type='plain'), ai(customer_name='Love', service_ids=[RMA], mani_type='plain', date=W(0), time='13:00', summary='x'))})
ok('T2 "My name is my name is uh" → not finished → only "Mm-hmm." and listening again (never a question in the middle)', S(o)[1] == 'Mm-hmm.' and '<Gather' in o[1], S(o))
ok('T2 the words joined + "Medicare" heard as manicure (what is kept / read)', crow(2)['text_c'].startswith('My name is my name is uh Love #S802. I would like I want a manicure.'), crow(2)['text_c'])
ok('T2 read back "… a regular manicure Monday the … at 1 …" → yes → booked Regular Manicure + the 602 text (1 = Dip, 2 = Gel…)', 'a regular manicure' in S(o)[2] and ' at 1' in S(o)[2] and one('+15555550102') and one('+15555550102')[0]['service_ids'] == str(RMA) and len(asks('+15555550102')) == 1, (S(o), one('+15555550102'), asks('+15555550102')))
aj = json.loads(crow(2)['ai_json'] or '{}')
ok('T2 every turn (caller + switchboard), the AI actions and Confidence kept in ai_json.ivr', any(x[0] == 'c' for x in aj.get('ivr', {}).get('log', [])) and any(x[0] == 's' for x in aj.get('ivr', {}).get('log', [])) and aj.get('ivr', {}).get('ai') and aj.get('ivr', {}).get('conf', {}).get('open', [None])[0] == 0.72, str(aj.get('ivr'))[:400])
# T3 something missing → ONE short question → the answer → read back
h('set', json.dumps({'salon_name': 'Love Nails'}))
o = sw(3, '+15555550103', ['Hi this is Mia #S803 I want a gel manicure', '#S804 Monday at 2 please', 'yes'],
       {803: TJ(action='book_new', name='Mia', persons=[PP([GM])], mani_type='gel_real'), 804: TJ(action='book_new', date=W(0), time='14:00')})
ok('T3 Love Nails greeting · no day said → ONE question for it ("… what day and time …") → "Monday at 2" → read back "… a gel manicure Monday the … at 2 …" → booked', S(o)[0].startswith('Thank you for calling Love Nails.') and 'day and time' in S(o)[1] and 'a gel manicure Monday the' in S(o)[2] and ' at 2' in S(o)[2] and one('+15555550103'), (S(o), one('+15555550103')))
h('set', json.dumps({'salon_name': 'American Nails'}))
# T4 two people, each their own services
o = sw(4, '+15555550104', ['#S805 two people, two pedicures and one manicure Monday at 12, my name is Quinn', 'yes'], {805: TJ(action='book_new', name='Quinn', people=2, persons=[PP([PD, RMA]), PP([PD])], date=W(0), time='12:00')})
g = rows('+15555550104')
ok('T4 "… for 2 people …" read back → yes → [Pedicure + Regular Manicure] + [Pedicure] (pedicure first)', 'for 2 people' in S(o)[1] and len(g) == 2 and g[0]['service_ids'] == '%d,%d' % (PD, RMA) and g[1]['service_ids'] == str(PD), (S(o), g))
# T5 taken → 2 nearest → "the first one"
for k, tn in enumerate(['TAMMY', 'HANA', 'SISI']): mk('+1555555014%d' % k, 'BUSY' + str(k), W(2), 900, T[tn], 1)
o = sw(5, '+15555550105', ['#S806 Nia here, gel manicure Wednesday at 3 pm', 'the first one', 'yes'], {806: TJ(action='book_new', name='Nia', persons=[PP([GM])], date=W(2), time='15:00', mani_type='gel_real')})
m5 = _re.match(r"Sorry, 3 is taken – I've got (\S+) or (\S+)\. Would either work\?$", S(o)[1])
ok('T5 every tech busy → "Sorry, 3 is taken – I\'ve got … or …. Would either work?"', bool(m5), S(o))
ok('T5 "the first one" → read back at that time → yes → booked then', m5 and (' at ' + m5.group(1)) in S(o)[2] and one('+15555550105') and S(o)[3].startswith("You're all set!"), (S(o), one('+15555550105')))
# T6 6:30 PM + 75 min, closing 7
H7 = dict(ALLDAY); H7[str((_dt.date.fromisoformat(W(3)).weekday() + 1) % 7)] = {'open': '09:00', 'close': '19:00'}; h('set', json.dumps({'hours': json.dumps(H7)}))
o = sw(6, '+15555550106', ['#S807 Olga, a pedicure and a regular manicure Thursday at 6:30 pm', None], {807: TJ(action='book_new', name='Olga', persons=[PP([PD, RMA])], date=W(3), time='18:30')})
ok('T6 6:30 + 75 min, the salon closes 7 → "Sorry, we close at 7, so that\'s too late – I\'ve got 5:30 or 5:45. Would either work?"', S(o)[1] == "Sorry, we close at 7, so that's too late – I've got 5:30 or 5:45. Would either work?", S(o))
h('set', json.dumps({'hours': json.dumps(ALLDAY)}))
# T7 Builder Gel only Tammy / Hana, both busy (Sisi free but cannot)
sql("UPDATE staff SET skills = '%s' WHERE id = %d" % (','.join(str(x) for x in [GM, PD, FS, DIP, RMA, GPE, FILL]), T['SISI']))
for k, tn in enumerate(['TAMMY', 'HANA']): mk('+1555555015%d' % k, 'BG' + str(k), W(4), 660, T[tn], 1)
o = sw(7, '+15555550107', ['#S808 Pam, builder gel Friday at 11 am', None], {808: TJ(action='book_new', name='Pam', persons=[PP([BG])], date=W(4), time='11:00')})
ok('T7 Builder Gel (only Tammy / Hana), both busy, Sisi cannot → "Sorry, 11 in the morning is taken – I\'ve got …"', S(o)[1].startswith("Sorry, 11 in the morning is taken – I've got "), S(o))
sql("UPDATE staff SET skills = '' WHERE id = %d" % T['SISI'])
# T8 fill + Tammy + gift card (a detail → the note)
o = sw(8, '+15555550108', ['#S809 Hi, I need a fill on my acrylics with Tammy Tuesday at 10, I have a gift card', 'yes'], {809: TJ(action='book_new', name='Kay', persons=[PP([FILL], tech=T['TAMMY'])], date=W(1), time='10:00', note='has a gift card')})
a8 = st_of('+15555550108')
ok('T8 read back "… a fill with Tammy …. I noted your request." → booked Fill with TAMMY, note "📞 has a gift card"', 'a fill with Tammy' in S(o)[1] and S(o)[1].endswith('I noted your request.') and a8 and a8[0]['staff_id'] == T['TAMMY'] and '📞 has a gift card' in a8[0]['note'], (S(o), a8))
o = sw(9, '+15555550109', ['#S810 pedicure for me and my 8 year old Tuesday at 1, I am Dee', 'yes'], {810: TJ(action='book_new', name='Dee', people=2, persons=[PP([PD]), PP([PD])], date=W(1), time='13:00', note='child 8 years old')})
ok('T9 "me and my 8 year old" → 2 people, each Pedicure, note "📞 child 8 years old"', len(rows('+15555550109')) == 2 and all('child 8' in x['note'] for x in st_of('+15555550109')), (S(o), st_of('+15555550109')))
# T10 "anytime Saturday morning" → 2 open times (no "what time?")
o = sw(10, '+15555550110', ['#S811 Eve, gel manicure anytime Saturday morning'], {811: TJ(action='book_new', name='Eve', persons=[PP([GM])], date=W(5), window_from='09:00', window_to='12:00')})
ok('T10 "anytime Saturday morning" → 2 open times offered at once ("… or …. Which one works?"), not "what time?"', S(o)[1].endswith('Which one works?') and ' or ' in S(o)[1] and 'what time' not in S(o)[1].lower(), S(o))
if _t.weekday() == 5:
    o = sw(11, '+15555550111', ['#S812 Fay, pedicure Saturday at 3'], {812: TJ(action='book_new', name='Fay', persons=[PP([PD])], date=(_t + _dt.timedelta(days=7)).isoformat(), time='15:00')})
    ok('T11 today is Saturday + "Saturday" → "Today, or next Saturday?"', S(o)[1] == 'Today, or next Saturday?', S(o))
# T12 another appointment that day
mk('+15555550112', 'RITA', W(0), 600, 0, 1)
o = sw(12, '+15555550112', ['#S813 Rita again, a pedicure Monday at 3', 'yes', 'yes'], {813: TJ(action='book_new', name='Rita', persons=[PP([PD])], date=W(0), time='15:00', pedi_type='regular')})
ok('T12 "You already have an appointment Monday the … at 10 in the morning – is this a new one?" → yes → read back → yes → 2 appointments', S(o)[1].startswith('You already have an appointment Monday the ') and 'is this a new one?' in S(o)[1] and len([x for x in st_of('+15555550112') if x['status'] == 'booked']) == 2, (S(o), st_of('+15555550112')))
# T13 LN #7 cancel a party of 3 / T14 no / T15 one person
ids = mk('+15555550113', 'LOVE', dmon, 720, 0, 3)
o = sw(13, '+15555550113', ['#S814 I have appointment Monday at 12 but I want to cancel it', 'yes'], {814: TJ(action='cancel_all', appt_id=ids[0], date=dmon, time='12:00')})
ok('T13 LN #7 → "I see your appointment this Monday at 12 for 3 people. Do you want me to cancel it?" → yes → all 3 cancelled → "Okay, it\'s cancelled. …"', S(o)[1] == 'I see your appointment this Monday at 12 for 3 people. Do you want me to cancel it?' and S(o)[2].startswith("Okay, it's cancelled.") and [x['status'] for x in st_of('+15555550113')] == ['cancelled'] * 3, (S(o), st_of('+15555550113'), crow(13)['reason']))
ids = mk('+15555550114', 'NORA', dmon, 720, 0, 2)
o = sw(14, '+15555550114', ['#S815 I want to cancel my appointment', 'no'], {815: TJ(action='cancel_all', appt_id=ids[0])})
ok('T14 "no" → "Okay, your appointment stays. …" → nothing cancelled', S(o)[2].startswith('Okay, your appointment stays.') and [x['status'] for x in st_of('+15555550114')] == ['booked'] * 2, (S(o), st_of('+15555550114')))
ids = mk('+15555550115', 'KIM', dmon, 840, 0, 2); sql("UPDATE appointments SET customer_name = 'LILY' WHERE id = %d" % ids[1])
o = sw(15, '+15555550115', ["#S816 my daughter Lily can't come Monday", 'yes'], {816: TJ(action='cancel_one', appt_id=ids[0], person_name='Lily')})
ok('T15 "my daughter Lily can\'t come" → "Just to confirm – cancel Lily from this Monday at 2, and keep the others?" → yes → only LILY cancelled', S(o)[1] == 'Just to confirm – cancel Lily from this Monday at 2, and keep the others?' and [x['status'] for x in st_of('+15555550115')] == ['booked', 'cancelled'], (S(o), st_of('+15555550115')))
# T16 change the time (open) / T17 taken → 2 times → the second
ids = mk('+15555550116', 'OLGA', W(0), 660, 0, 1)
o = sw(16, '+15555550116', ['#S817 can you change my Monday to 4 pm', 'yes'], {817: TJ(action='change_time', appt_id=ids[0], date=W(0), time='16:00')})
ok('T16 "change my Monday to 4 pm" (open) → "… move it to Monday the … at 4 …" → yes → moved → "You\'re all set – it\'s moved. …"', 'Monday the' in S(o)[1] and ' at 4' in S(o)[1] and S(o)[2].startswith("You're all set – it's moved.") and st_of('+15555550116')[0]['start_min'] == 960, (S(o), st_of('+15555550116')))
ids = mk('+15555550117', 'PIA', W(2), 600, 0, 1)
o = sw(17, '+15555550117', ['#S818 can I move my Wednesday to 3', 'the second one', 'yes'], {818: TJ(action='change_time', appt_id=ids[0], date=W(2), time='15:00')})
m17 = _re.match(r"Sorry, 3 is taken – I've got (\S+) or (\S+)\. Would either work\?$", S(o)[1])
ok('T17 taken → 2 times → "the second one" → read back → yes → moved to the second', bool(m17) and (' at ' + m17.group(2)) in S(o)[2] and st_of('+15555550117')[0]['start_min'] != 600, (S(o), st_of('+15555550117')))
# T18 add a friend / T19 add a service
ids = mk('+15555550118', 'GIA', W(0), 1020, 0, 2)
o = sw(18, '+15555550118', ['#S819 I have an appointment Monday at 12, I want to add my friend Ann for a pedicure', 'yes'], {819: TJ(action='add_person', appt_id=ids[0], persons=[PP([PD], name='Ann')])})
ok('T18 "add my friend for a pedicure" → "Adding 1 person with a pedicure to this Monday at 12 – that makes 3. Sound good?" → yes → 3 people', S(o)[1].startswith('Adding 1 person with a pedicure to Monday the ') and S(o)[1].endswith(' at 5 – that makes 3. Sound good?') and len([x for x in st_of('+15555550118') if x['status'] == 'booked']) == 3, (S(o), st_of('+15555550118'), crow(18)['reason']))
ids = mk('+15555550119', 'HAL', dmon, 600, 0, 1)
o = sw(19, '+15555550119', ['#S820 add a gel manicure to my Monday appointment', 'yes'], {820: TJ(action='add_service', appt_id=ids[0], service_ids=[GM])})
ok('T19 "add a gel manicure" → "Okay – that\'s a pedicure and a gel manicure this Monday at 10 in the morning. Sound good?" → yes → Pedicure + Gel Manicure (75 min)', S(o)[1] == "Okay – that's a pedicure and a gel manicure this Monday at 10 in the morning. Sound good?" and st_of('+15555550119')[0]['service_ids'] == '%d,%d' % (PD, GM), (S(o), st_of('+15555550119')))
# T20 two things at once: cancel Monday AND book Friday at 2
ids = mk('+15555550120', 'IDA', dmon, 900, 0, 1)
o = sw(20, '+15555550120', ['#S821 cancel my Monday and book Friday at 2 for a pedicure', 'yes #S822', 'yes'], {821: TJ(action='cancel_all', appt_id=ids[0], more=True), 822: TJ(action='book_new', name='Ida', persons=[PP([PD])], date=W(4), time='14:00')})
ok('T20 "cancel Monday and book Friday at 2" → cancel read back → yes → cancelled → the booking read back → yes → booked (one after the other)', S(o)[1].startswith('I see your appointment this Monday at 3') and 'a pedicure Friday the' in S(o)[2] and st_of('+15555550120')[0]['status'] == 'cancelled' and len([x for x in st_of('+15555550120') if x['status'] == 'booked']) == 1, (S(o), st_of('+15555550120')))
o = sw(21, '+15555550121', ['#S823 Jo, a pedicure Saturday... no wait, Sunday at 1', 'yes'], {823: TJ(action='book_new', name='Jo', persons=[PP([PD])], date=W(6), time='13:00')})
ok('T21 "Saturday… no wait, Sunday at 1" → read back with SUNDAY → booked Sunday', 'Sunday the' in S(o)[1] and one('+15555550121') and _dt.date.fromisoformat(sql("SELECT appt_date FROM appointments WHERE phone = '+15555550121'")[0]['appt_date']).weekday() == 6, (S(o)))
# T22 two appointments, "cancel my appointment" → which one?
i1 = mk('+15555550123', 'KAY', dmon, 600, 0, 1); i2 = mk('+15555550123', 'KAY', dfri, 600, 0, 1)
o = sw(22, '+15555550123', ['#S824 I need to cancel my appointment', '#S825 the Friday one', 'yes'], {824: TJ(action='cancel_all'), 825: TJ(action='cancel_all', appt_id=i2[0])})
ok('T22 (621 sua test: thu tu = ngay som truoc, khong co dinh Monday truoc) 2 appointments → "Sure – your appointment on <earlier> or on <later>?" → "Friday" → read → yes → only Friday cancelled', S(o)[1] == ('Sure – your appointment on Monday or on Friday?' if dmon < dfri else 'Sure – your appointment on Friday or on Monday?') and [x['status'] for x in st_of('+15555550123')] == ['booked', 'cancelled'], (S(o), st_of('+15555550123')))
h('set', json.dumps({'call_block': '0'}))
o = sw(23, '', ['#S826 I want to cancel my appointment'], {826: TJ(action='cancel_all')})
ok('T23 a hidden number + "cancel" → the owner (nothing looked up)', 'Let me connect you to the salon.' in S(o)[1] and '<Dial' in o[1], S(o))
h('set', json.dumps({'call_block': ''}))
o = sw(24, '+15555550124', ['#S827 what time is my appointment'] + ['and what time was it again #S827'] * 8, {827: TJ(action='repeat_appt')})
ok('T24 more than 8 turns → the owner', any('Let me connect you to the salon.' in x for x in S(o)), S(o)[-2:])
today = time.strftime('%Y-%m-%d'); mk('+15555550125', 'TINA', today, 1430, 0, 1)
o = sw(25, '+15555550125', ["Hi I'm running 10 minutes late"])
r25 = st_of('+15555550125')[0]
ok('T25 "I\'m running 10 minutes late" → "Thanks, we\'ll let the salon know. See you soon!" · note "📞 running late ~10 min" · nothing moved · the owner\'s push', S(o)[1] == "Thanks, we'll let the salon know. See you soon!" and r25['note'].startswith('📞 running late ~10 min') and r25['start_min'] == 1430 and lastpush() and 'running late' in (lastpush()[0]['title'] + lastpush()[0]['body']).lower(), (S(o), r25))
o = sw(26, '+15555550126', ['#S828 how much is a pedicure?', 'DIAL:no-answer'], {828: TJ(action='question_connect', question_topic='the price')})
ok('T26 "how much is a pedicure?" → "Let me connect you to the salon." + Dial the owner 25 s → not answered → the old voicemail', S(o)[1] == 'Let me connect you to the salon.' and '<Dial timeout="25"' in o[1] and '<Record maxLength="120"' in o[2], S(o))
o = sw(27, '+15555550127', ['Hola, quiero una cita para mañana'])
ok('T27 Spanish → the owner', 'Let me connect you to the salon.' in S(o)[1] and '<Dial' in o[1], S(o))
o = sw(28, '+15555550128', ['', ''])
ok('T28 silence → "Are you still there? Please tell me the reason for your call." → silence → the old voicemail', S(o)[1] == 'Are you still there? Please tell me the reason for your call.' and '<Record maxLength="120"' in o[2], S(o))
o = sw(29, '+15555550129', ['#S829 Uma, gel manicure Tuesday at 4', None], {829: both(TJ(action='book_new', name='Uma', persons=[PP([GM])], date=W(1), time='16:00', mani_type='gel_real'), ai(customer_name='Uma', service_ids=[GM], mani_type='gel_real', date=W(1), time='16:00', summary='x'))})
sql("UPDATE calls SET next_at = '2020-01-01 00:00:00' WHERE call_sid = '%s'" % CALLS[29]); sh('php', D + '/undo.php', 'tick'); time.sleep(0.5)
ok('T29 hung up at "Sound good?" → read by the cron like a voicemail → BOOKED (everything was said)', crow(29)['status'] == 'booked' and one('+15555550129'), (crow(29)['status'], crow(29)['reason']))
sql("UPDATE autosend SET created_at = '2020-01-01 00:00:00' WHERE src LIKE 'ui:callreq:%'")
o = sw(30, ME, ['#S830 I want a pedicure', None], {830: both(TJ(action='book_new', persons=[PP([PD])], pedi_type='regular'), ai(customer_name='', service_ids=[PD], pedi_type='regular', date='', time='', missing=['date', 'time'], summary='a pedicure'))})
sql("UPDATE calls SET next_at = '2020-01-01 00:00:00' WHERE call_sid = '%s'" % CALLS[30]); sh('php', D + '/undo.php', 'tick'); time.sleep(0.5)
ok('T30 hung up at the question → Call back + ONE text "…request for a Pedicure. Please reply with the day and time…"', crow(30)['status'] == 'callback' and callreq(ME) and 'request for a Pedicure. Please reply with the day and time' in callreq(ME)[-1]['body'], (crow(30)['status'], crow(30)['reason'], callreq(ME)[-1:]))
HC = dict(ALLDAY); HC[str((_t.weekday() + 1) % 7)] = {'open': '00:00', 'close': '00:01'}; h('set', json.dumps({'hours': json.dumps(HC)}))
o = sw(31, '+15555550130', [], answer=False)
ok('T31 (621.9 doi y: CHAT 01/11 ring - anh Logan "always ring the iPhone first", also when closed) outside the opening hours → the iPhone rings first (<Dial>), the switchboard after', '<Dial' in o[0] and 'This call may be recorded' in o[0], o[0][:300])
h('set', json.dumps({'hours': json.dumps(ALLDAY), 'call_approve': '1'}))
o = sw(32, '+15555550131', ['#S831 Vi, gel manicure Tuesday at 5', 'yes'], {831: TJ(action='book_new', name='Vi', persons=[PP([GM])], date=W(1), time='17:00', mani_type='gel_real')})
a32 = st_of('+15555550131')
ok('T32 "Owner approves phone bookings" ON → booked, the place kept, "⏳ Chờ duyệt" + amber, the customer\'s text as usual', a32 and a32[0]['status'] == 'booked' and a32[0]['note'].startswith('⏳ Chờ duyệt') and a32[0]['color'].upper() == '#F5A623' and sql("SELECT id FROM autosend WHERE phone = '+15555550131'") + sql("SELECT id FROM outbox WHERE phone = '+15555550131' AND kind = 'confirm'"), a32)
open(D + '/pend.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner']; echo json_encode(cl_pend_answer((int)$argv[1], $argv[2] === 'ok', 'Owner'));" % (A, A, A, A))
x = sh('php', D + '/pend.php', str(crow(32)['id']), 'ok').stdout; a32 = st_of('+15555550131')
ok('T32 the owner taps ✓ OK → back to normal', '"pend":false' in x and not a32[0]['note'].startswith('⏳') and a32[0]['color'].upper() != '#F5A623', (x[:300], a32))
h('set', json.dumps({'call_approve': '0'}))
o = sw(33, '+15555550132', ['My name is is.', 'I would like enough. Day and time: uh', '', ''])
ok('T33 AN #31 ("My name is is." … "Day and time: uh") → never cut in: "Mm-hmm." → "Mm-hmm." → "Go ahead, I\'m listening."', S(o)[1:4] == ['Mm-hmm.', 'Mm-hmm.', "Go ahead, I'm listening."], S(o))
c, x = post('a=ask&s=talk&n=0', {'AccountSid': ACC, 'CallSid': 'CW0001', 'SpeechResult': 'yes'}, key='PSK_wrong_key_000000000000000')
ok('T34 an answer with a wrong signature → 403', c == 403, c)
scen['oai_delay'] = 5; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
o = sw(35, '+15555550135', ['#S835 Zoe, a pedicure Tuesday at 6'], {835: TJ(action='book_new', name='Zoe', persons=[PP([PD])], date=W(1), time='18:00', pedi_type='regular')})
ok('T35 the AI is slow (5 s) → never quiet: "Okay, let me check that for you…" at once + <Redirect> → the read-back comes on the next request', S(o)[1] == 'Okay, let me check that for you…' and '<Redirect' in o[1], S(o))
m = _re.search(r'<Redirect[^>]*>([^<]+)</Redirect>', o[1]); c, x = post(None, {'AccountSid': ACC, 'CallSid': CALLS[35]}, url=m.group(1).replace('&amp;', '&')) if m else (0, '')
ok('T35 … then the read-back "… a pedicure Tuesday the … at 6 …"', 'a pedicure Tuesday the' in says(x) and ' at 6' in says(x), says(x))
scen['oai_delay'] = 0; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)

# ---- the phone questions of 602 Cách A were replaced by the 602B switchboard (2.99.604) – its tests: t602b.py / test-602B.txt
h('set', json.dumps({'call_ivr': '', 'hours': json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)})}))
c, x = post('a=ask&s=open&n=0', {'AccountSid': ACC, 'CallSid': 'CI0001', 'SpeechResult': 'Mia'}, key='PSK_wrong_key_000000000000000')
ok('I7 a question answer with a wrong signature → 403', c == 403, c)
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CI0008', 'From': '+15555550188', 'To': '+15156061616', 'CallStatus': 'ringing'})
c, x = post('a=done', {'AccountSid': ACC, 'CallSid': 'CI0008', 'DialCallStatus': 'completed'})
ok('I8 an answered call → unchanged (hang up after the talk, no questions)', x.strip().endswith('<Response><Hangup/></Response>'), x)
h('set', json.dumps({'call_ivr': '0'}))
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors in the server log', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:5])
say('PASS %d/%d' % (sum(R), len(R)))
