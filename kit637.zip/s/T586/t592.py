# LAMWEB test 586 – the whole call flow on a local copy (fake SignalWire / STT / Claude; test numbers 555-01xx only). python3 t586.py <app tree>
import subprocess, json, os, sys, time, hmac, hashlib, base64, urllib.request, urllib.parse, shutil
A = sys.argv[1]; D = '/tmp/claude-0/T586'; PORT = 19861; DB = D + '/db.sqlite'; KEY = 'PSK_test_signing_key_0123456789'
R = []; out = open(D + '/test-592.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', D + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
for f in os.listdir(D + '/calls') if os.path.isdir(D + '/calls') else []: pass
shutil.rmtree(D + '/calls', ignore_errors=True); os.makedirs(D + '/calls'); open(D + '/fake.log', 'w').close()
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
OAI = True
if OAI: json.dump({}, open(D + '/shared/color-ai.json', 'w'))
else: json.dump({'key': 'sk-ant-test-000000000000000000000000'}, open(D + '/shared/color-ai.json', 'w'))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SHARED_DIR': D + '/shared', 'NF_CALLS_DIR': D + '/calls'}
seed = json.loads(sh('php', D + '/seed.php', A, DB, str(PORT)).stdout); S, T, d1 = seed['S'], seed['T'], seed['d1']
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
def ai(**k): b = {'intent': 'book', 'customer_name': '', 'customer_phone': '', 'service_ids': [], 'service_text': '', 'tech_id': 0, 'tech_text': '', 'date': d1, 'time': '', 'people': 1, 'salon_side': 'person', 'salon_agreed': False, 'salon_quote': '', 'confidence': 0.95, 'missing': [], 'summary': ''}; b.update(k); return b
scen = {'stt': {
  '3': {'c': '#S1 Hi this is Mia, can I get a gel manicure tomorrow at 2?', 's': 'Sure, tomorrow at 2 is open. OK, see you at 2!'},
  '4': {'c': '#S2 This is Linh, pedicure with Tammy tomorrow at 3 please', 's': 'Let me check the book for you.'},
  '5': {'c': '#S3 How much is a full set?', 's': 'Full set is fifty dollars.'},
  '6': {'c': '#S4 Hi this is Anna, I want a full set tomorrow at 11 with Hana. Thanks!'},
  '7': {'c': '#S5 Bella here, gel manicure tomorrow at 4 with Sisi please, call me back'},
  '8': {'c': '#S6 Hi I want a pedicure tomorrow, Cara', 's': 'ok'},
  '9': {'c': '#S7 Hi Dana, gel manicure tomorrow at noon?', 's': 'Yes ok, noon tomorrow.'},
  '10': {'c': '#S8 chị muốn làm bột thứ bảy 2 giờ, tên Hoa', 's': 'Dạ ok chị, 2 giờ nha.'}},
 'ai': {
  '1': ai(customer_name='Mia', service_ids=[GM], time='14:00', salon_agreed=True, salon_quote='OK, see you at 2', summary='Mia wants a gel manicure tomorrow at 2 PM.'),
  '2': ai(customer_name='Linh', service_ids=[PD], tech_id=T['TAMMY'], tech_text='Tammy', time='15:00', salon_agreed=True, salon_quote='ok sure 3pm', summary='Linh wants a pedicure with Tammy tomorrow 3 PM.'),
  '3': ai(intent='info', summary='Asked the price of a full set.'),
  '4': ai(customer_name='Anna', service_ids=[FS], tech_id=T['HANA'], tech_text='Hana', time='11:00', summary='Voicemail: Anna, full set tomorrow 11 AM with Hana.'),
  '5': ai(customer_name='Bella', service_ids=[GM], tech_id=T['SISI'], tech_text='Sisi', time='16:00', summary='Voicemail: Bella, gel manicure tomorrow 4 PM with Sisi.'),
  '6': ai(customer_name='Cara', service_ids=[PD], time='', salon_agreed=True, salon_quote='ok', confidence=0.9, missing=['time'], summary='Cara wants a pedicure tomorrow, no time.'),
  '7': ai(customer_name='Dana', service_ids=[GM], time='12:00', salon_agreed=True, salon_quote='Yes ok, noon tomorrow', summary='Dana, gel manicure tomorrow at noon.'),
  '8': ai(customer_name='Hoa', service_ids=[FS], time='14:00', date=d1, salon_agreed=True, salon_quote='Dạ ok chị, 2 giờ nha', confidence=0.9, summary='Hoa wants a full set at 2 PM.')}}
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
fk = subprocess.Popen(['python3', D + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.3)
B = 'http://127.0.0.1:%d' % PORT
def post(a, p, sign=True, key=KEY, url=None):
    u = url or (B + '/call_in.php?' + a); body = urllib.parse.urlencode(p).encode(); h = {'Content-Type': 'application/x-www-form-urlencoded'}
    if sign: h['X-SignalWire-Signature'] = base64.b64encode(hmac.new(key.encode(), (u + ''.join(k + p[k] for k in sorted(p))).encode(), hashlib.sha1).digest()).decode()
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, data=body, headers=h), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
ACC = '11111111-2222-3333-4444-555555555555'
def call(n, frm, sec, stereo=True, vm=False):
    sid = 'CA%04d' % n; rs = 'RE%04d' % n; subprocess.run(['python3', D + '/mkwav.py', rs, str(sec), '1' if stereo else '0'])
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if vm: post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    c2, x2 = post('a=rec' + ('&vm=1' if vm else ''), {'AccountSid': ACC, 'CallSid': sid, 'RecordingSid': rs, 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/%s' % (ACC, rs), 'RecordingStatus': 'completed', 'RecordingDuration': str(sec), 'RecordingChannels': '2' if stereo else '1'})
    for k in range(80):
        row = sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
        if row and row[0]['status'] not in ('queued', 'work', 'ring') or (row and row[0]['status'] == 'queued' and row[0]['tries'] >= 1): break
        time.sleep(0.25)
    return (c, x, c2, x2), row
def appt(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, customer_name, status, source, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def push(): return sql("SELECT target, kind, title, body FROM push_log ORDER BY id DESC LIMIT 1") if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []



say('== LAMWEB test 2.99.592 – cancel / move from a call · ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire / STT / AI · texts go to the SMS Server queue (nothing really sent)')
open(D + '/set590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'salon_name' => 'American Nails', 'as_kinds' => json_encode(['confirm' => true, 'change' => true, 'cancel' => true])] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set590.php')
open(D + '/undo.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];\n$a = $argv[1];\nif ($a === 'tick') { cl_tick(); echo 'ticked'; }\n" % (A, A, A, A))
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat(); d3 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=3)).isoformat()
open(D + '/mk592.php', 'w').write("<?php require '%s/inc/core.php'; settings(); [$_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = [];\nupsert_customer($ph, $name);\nfor ($i = 0; $i < (int)$n; $i++) { q(\"INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)\", [$date, (int)$start, 45, (int)$staff + $i * ((int)$staff ? 1 : 0), '%d', $i ? $name . ' +' . $i : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); }\necho implode(',', $ids);" % (A, S['Pedicure']))
def mk(ph, name, date, start, staff=0, n=1): return [int(x) for x in sh('php', D + '/mk592.php', ph, name, date, str(start), str(staff), str(n)).stdout.split(',')]
def ap(i): return sql("SELECT id, appt_date, start_min, staff_id, status FROM appointments WHERE id = %d" % i)[0]
def ob(i, k): return sql("SELECT kind, ref, status FROM outbox WHERE appt_id = %d AND kind = '%s'" % (i, k))
def lastpush(): return sql("SELECT title, body FROM push_log WHERE target = 'admin' ORDER BY id DESC LIMIT 1")
def go(n, ph, j, tc, ts=None, vm=True):
    scen['stt'][str(n)] = {'c': '#S%d ' % (100 + n) + tc} if ts is None else {'c': '#S%d ' % (100 + n) + tc, 's': ts}
    scen['ai'][str(100 + n)] = j; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
    r, row = call(n, ph, n, stereo=not vm, vm=vm); time.sleep(0.8); return mrow('CA%04d' % n)[0]
def mrow(sid): return sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
# ---- CANCEL ----
a1 = mk('+15555550171', 'MIA', d2, 14 * 60, T1)[0]
r = go(21, '+15555550171', ai(intent='cancel', customer_name='Mia', date='', time='', summary='Mia wants to cancel.'), 'Hi this is Mia, I need to cancel my appointment')
ok('C1 voicemail "cancel", 1 upcoming → CANCELLED (status cancelled, list "Cancelled ✓")', r['status'] == 'cancelled' and ap(a1)['status'] == 'cancelled' and r['result'].startswith('Cancelled ✓ Mia – Pedicure –'), (r['status'], r['reason'], r['result'], ap(a1)))
ok('C1 the CANCELLED text by the existing rules (selfcxl) + no missed-call text', ob(a1, 'cancel') and ob(a1, 'cancel')[0]['ref'] == 'selfcxl:%d' % a1 and r['tb_state'] == 'skip', (ob(a1, 'cancel'), r['tb_state']))
lp = lastpush(); ok('C1 one owner push "📞 Cancelled: Mia – Pedicure – <day> 2:00 PM (from a call)"', lp and lp[0]['title'].startswith('📞') and 'Cancelled' in lp[0]['title'] and lp[0]['body'].startswith('Mia – Pedicure –') and lp[0]['body'].endswith('(from a call)'), lp)
ok('C1 only ONE owner notification for it', len(sql("SELECT id FROM push_log WHERE target = 'admin' AND body LIKE '%%Mia – Pedicure%%'")) == 1, sql("SELECT title, body FROM push_log WHERE target = 'admin'"))
lg = sql("SELECT action, detail FROM appt_log WHERE appt_id = %d AND action = 'cancelled'" % a1); ok('C1 Activity log 1 line "Huỷ qua cuộc gọi (lời nhắn) – call #…"', len(lg) == 1 and 'Huỷ qua cuộc gọi' in lg[0]['detail'], lg)
a2 = mk('+15555550172', 'NINA', d2, 15 * 60, T1)[0]
r = go(22, '+15555550172', ai(date='', intent='cancel', customer_name='Nina', salon_side='person', salon_agreed=False, summary='Nina cancel.'), 'This is Nina, cancel my appointment', ts='Let me check.', vm=False)
ok('C2 answered call, no OK from the salon → NOT cancelled, Needs review', r['status'] == 'review' and ap(a2)['status'] == 'booked' and 'no OK' in r['reason'], (r['status'], r['reason']))
r = go(23, '+15555550172', ai(date='', intent='cancel', customer_name='Nina', salon_side='person', salon_agreed=True, salon_quote='OK Nina, cancelled', summary='Nina cancel.'), 'This is Nina, cancel my appointment please', ts='OK Nina, cancelled.', vm=False)
ok('C3 answered call + the salon\'s real OK → CANCELLED', r['status'] == 'cancelled' and ap(a2)['status'] == 'cancelled', (r['status'], r['reason']))
b1 = mk('+15555550173', 'OLGA', d2, 11 * 60, T2)[0]; b2 = mk('+15555550173', 'OLGA', d3, 16 * 60, T2)[0]
r = go(24, '+15555550173', ai(date='', intent='cancel', customer_name='Olga', summary='cancel'), 'Olga, cancel please')
ok('C4 two upcoming and no day said → NOT cancelled, Call back', r['status'] == 'callback' and ap(b1)['status'] == 'booked' and ap(b2)['status'] == 'booked' and '2 upcoming' in r['reason'], (r['status'], r['reason']))
r = go(25, '+15555550173', ai(intent='cancel', customer_name='Olga', date=d3, time='16:00', summary='cancel'), 'Olga, cancel the one on the third at 4')
ok('C4 … the day / time said picks 1 → only that one cancelled', r['status'] == 'cancelled' and ap(b2)['status'] == 'cancelled' and ap(b1)['status'] == 'booked', (r['status'], r['reason'], ap(b1)['status'], ap(b2)['status']))
b3 = mk('+15555550173', 'OLGA', d3, 17 * 60, T2)[0]
r = go(26, '+15555550173', ai(date='', intent='cancel', customer_name='Olga', cancel_all=True, summary='cancel all'), 'Olga, cancel all my appointments')
ok('C4 … "all" → every upcoming one cancelled', r['status'] == 'cancelled' and ap(b1)['status'] == 'cancelled' and ap(b3)['status'] == 'cancelled', (r['status'], r['reason']))
g = mk('+15555550174', 'PIA', d2, 13 * 60, T1, 2)
r = go(27, '+15555550174', ai(date='', intent='cancel', customer_name='Pia', summary='cancel'), 'Pia here, cancel our appointment')
ok('C5 a party 🔗 (2 people) → both cancelled, ONE cancelled text', r['status'] == 'cancelled' and all(ap(i)['status'] == 'cancelled' for i in g) and len(sql("SELECT id FROM outbox WHERE kind = 'cancel' AND phone = '+15555550174'")) == 1, (r['status'], [ap(i)['status'] for i in g], sql("SELECT ref FROM outbox WHERE kind = 'cancel' AND phone = '+15555550174'")))
r = go(28, '+15555550175', ai(date='', intent='cancel', customer_name='Zed', summary='cancel'), 'Zed, cancel')
ok('C6 no upcoming appointment for the number → Call back', r['status'] == 'callback' and 'no upcoming' in r['reason'], (r['status'], r['reason']))
c1 = mk('+15555550176', 'RITA', d2, 12 * 60, T3)[0]
r = go(29, '+15555550176', ai(date='', intent='cancel', customer_name='Sara', summary='cancel'), 'This is Sara, cancel')
ok('C6 the name said is not on that number\'s appointment → NOT cancelled, Call back', r['status'] == 'callback' and ap(c1)['status'] == 'booked' and 'name said' in r['reason'], (r['status'], r['reason']))
# ---- MOVE ----
m1 = mk('+15555550181', 'MIA', d2, 14 * 60, T1)[0]
r = go(31, '+15555550181', ai(intent='change', customer_name='Mia', date=d2, time='14:00', new_date=d3, new_time='11:00', summary='move'), 'Mia, move my Tuesday 2 to Wednesday 11')
x = ap(m1); ok('M1 voicemail: 1 appointment → MOVED (same row, same tech, new day 11:00 AM; list "Moved ✓")', r['status'] == 'moved' and x['appt_date'] == d3 and x['start_min'] == 660 and x['staff_id'] == T1 and x['status'] == 'booked' and r['result'].startswith('Moved ✓ Mia – Pedicure –') and '→' in r['result'], (r['status'], r['reason'], x))
ok('M1 the NEW TIME text (out_moved) goes, no missed-call text', ob(m1, 'change') or ob(m1, 'confirm'), (ob(m1, 'change'), ob(m1, 'confirm'), r['tb_state']))
lp = lastpush(); ok('M1 owner push "📞 Moved: Mia – Pedicure – <old> → <new>"', lp and lp[0]['title'] == '📞 Moved' and '→' in lp[0]['body'], lp)
lg = sql("SELECT detail FROM appt_log WHERE appt_id = %d AND action = 'changed'" % m1); ok('M1 Activity log 1 line "… · 📞 moved from a call"', len(lg) == 1 and 'moved from a call' in lg[0]['detail'], lg)
g2 = mk('+15555550182', 'NORA', d2, 13 * 60, T1, 2)
r = go(32, '+15555550182', ai(date='', intent='change', customer_name='Nora', new_date=d3, new_time='15:00', summary='move'), 'Nora, move our appointment to Wednesday 3')
ok('M2 a party 🔗 moves together (both rows, same new day / time, techs kept)', r['status'] == 'moved' and all(ap(i)['appt_date'] == d3 and ap(i)['start_min'] == 900 for i in g2) and ap(g2[0])['staff_id'] == T1 and ap(g2[1])['staff_id'] == T2, (r['status'], r['reason'], [ap(i) for i in g2]))
mk('+15555550189', 'BUSY', d3, 10 * 60, T3); m3 = mk('+15555550183', 'OPAL', d2, 10 * 60, T3)[0]
r = go(33, '+15555550183', ai(date='', intent='change', customer_name='Opal', new_date=d3, new_time='10:00', summary='move'), 'Opal, move to Wednesday 10')
ok('M3 the new time is taken (SISI busy) → NOT moved, Call back "SISI already has BUSY …"', r['status'] == 'callback' and ap(m3)['appt_date'] == d2 and 'SISI already has BUSY' in r['reason'] and '→' in r['reason'], (r['status'], r['reason']))
lp = lastpush(); ok('M3 push "📞 Call back: … wants to move … → … – SISI already has …"', lp and 'Call back' in lp[0]['title'], lp)
m4 = mk('+15555550184', 'PAM', d2, 16 * 60, T1)[0]
r = go(34, '+15555550184', ai(date='', intent='change', customer_name='Pam', new_date=d3, new_time='12:00', salon_side='person', salon_agreed=False, summary='move'), 'Pam, can I move to Wednesday noon', ts='Hmm let me see.', vm=False)
ok('M4 answered call without the salon\'s OK → NOT moved, Needs review', r['status'] == 'review' and ap(m4)['appt_date'] == d2 and 'no OK' in r['reason'], (r['status'], r['reason']))
m5 = mk('+15555550185', 'QUEENIE', d2, 17 * 60, 0)[0]
r = go(35, '+15555550185', ai(date='', intent='change', customer_name='Queenie', new_date=d3, new_time='13:00', summary='move'), 'Queenie, move to Wednesday 1')
ok('M5 Any tech appointment → moved (Any tech has free techs)', r['status'] == 'moved' and ap(m5)['appt_date'] == d3 and ap(m5)['start_min'] == 780 and ap(m5)['staff_id'] == 0, (r['status'], r['reason']))
r = go(36, '+15555550185', ai(date='', intent='change', customer_name='Queenie', new_date='', new_time='', summary='move'), 'Queenie, I need another day')
ok('M6 no new day / time said → Call back', r['status'] == 'callback' and 'new day / time' in r['reason'], (r['status'], r['reason']))
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors in the server log', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:5])
say('PASS %d/%d' % (sum(R), len(R)))
sv.terminate(); fk.terminate()
