<?php require '/tmp/claude-0/L598/inc/core.php'; settings(); require_once '/tmp/claude-0/L598/inc/calls.php'; cl_table(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'who') echo json_encode(['space' => cl_space(), 'project' => cl_project(), 'tok' => cl_sec('sw_token') !== '' ? substr(cl_sec('sw_token'), 0, 7) : '', 'sig' => cl_sec('sw_signing') !== '', 'own' => cl_own()]);
if ($a === 'cfg') echo json_encode(cl_cfg());
if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
