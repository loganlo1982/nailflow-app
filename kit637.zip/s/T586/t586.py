# LAMWEB test 586 – the whole call flow on a local copy (fake SignalWire / STT / Claude; test numbers 555-01xx only). python3 t586.py <app tree>
import subprocess, json, os, sys, time, hmac, hashlib, base64, urllib.request, urllib.parse, shutil
A = sys.argv[1]; D = '/tmp/claude-0/T586'; PORT = 19861; DB = D + '/db.sqlite'; KEY = 'PSK_test_signing_key_0123456789'
R = []; out = open(D + ('/test-587-oai.txt' if os.environ.get('MODE') == 'oai' else '/test-587-claude.txt'), 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', D + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
for f in os.listdir(D + '/calls') if os.path.isdir(D + '/calls') else []: pass
shutil.rmtree(D + '/calls', ignore_errors=True); os.makedirs(D + '/calls'); open(D + '/fake.log', 'w').close()
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
OAI = os.environ.get('MODE') == 'oai'
if OAI: json.dump({}, open(D + '/shared/color-ai.json', 'w'))
else: json.dump({'key': 'sk-ant-test-000000000000000000000000'}, open(D + '/shared/color-ai.json', 'w'))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SHARED_DIR': D + '/shared', 'NF_CALLS_DIR': D + '/calls'}
seed = json.loads(sh('php', D + '/seed.php', A, DB, str(PORT)).stdout); S, T, d1 = seed['S'], seed['T'], seed['d1']
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
def ai(**k): b = {'intent': 'book', 'customer_name': '', 'customer_phone': '', 'service_ids': [], 'service_text': '', 'tech_id': 0, 'tech_text': '', 'date': d1, 'time': '', 'people': 1, 'salon_agreed': False, 'salon_quote': '', 'confidence': 0.95, 'missing': [], 'summary': ''}; b.update(k); return b
scen = {'stt': {
  '3': {'c': '#S1 Hi this is Mia, can I get a gel manicure tomorrow at 2?', 's': 'Sure, tomorrow at 2 is open. OK, see you at 2!'},
  '4': {'c': '#S2 This is Linh, pedicure with Tammy tomorrow at 3 please', 's': 'Let me check the book for you.'},
  '5': {'c': '#S3 How much is a full set?', 's': 'Full set is fifty dollars.'},
  '6': {'c': '#S4 Hi this is Anna, I want a full set tomorrow at 11 with Hana. Thanks!'},
  '7': {'c': '#S5 Bella here, gel manicure tomorrow at 4 with Sisi please, call me back'},
  '8': {'c': '#S6 Hi I want a pedicure tomorrow, Cara', 's': 'ok'},
  '9': {'c': '#S7 Hi Dana, gel manicure tomorrow at noon?', 's': 'Yes ok, noon tomorrow.'},
  '10': {'c': '#S8 chị muốn làm bột thứ bảy 2 giờ, tên Hoa', 's': 'Dạ ok chị, 2 giờ nha.'}},
 'ai': {
  '1': ai(customer_name='Mia', service_ids=[GM], time='14:00', salon_agreed=True, salon_quote='OK, see you at 2', summary='Mia wants a gel manicure tomorrow at 2 PM.'),
  '2': ai(customer_name='Linh', service_ids=[PD], tech_id=T['TAMMY'], tech_text='Tammy', time='15:00', salon_agreed=True, salon_quote='ok sure 3pm', summary='Linh wants a pedicure with Tammy tomorrow 3 PM.'),
  '3': ai(intent='info', summary='Asked the price of a full set.'),
  '4': ai(customer_name='Anna', service_ids=[FS], tech_id=T['HANA'], tech_text='Hana', time='11:00', summary='Voicemail: Anna, full set tomorrow 11 AM with Hana.'),
  '5': ai(customer_name='Bella', service_ids=[GM], tech_id=T['SISI'], tech_text='Sisi', time='16:00', summary='Voicemail: Bella, gel manicure tomorrow 4 PM with Sisi.'),
  '6': ai(customer_name='Cara', service_ids=[PD], time='', salon_agreed=True, salon_quote='ok', confidence=0.9, missing=['time'], summary='Cara wants a pedicure tomorrow, no time.'),
  '7': ai(customer_name='Dana', service_ids=[GM], time='12:00', salon_agreed=True, salon_quote='Yes ok, noon tomorrow', summary='Dana, gel manicure tomorrow at noon.'),
  '8': ai(customer_name='Hoa', service_ids=[FS], time='14:00', date=d1, salon_agreed=True, salon_quote='Dạ ok chị, 2 giờ nha', confidence=0.9, summary='Hoa wants a full set at 2 PM.')}}
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
fk = subprocess.Popen(['python3', D + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.3)
B = 'http://127.0.0.1:%d' % PORT
def post(a, p, sign=True, key=KEY, url=None):
    u = url or (B + '/call_in.php?' + a); body = urllib.parse.urlencode(p).encode(); h = {'Content-Type': 'application/x-www-form-urlencoded'}
    if sign: h['X-SignalWire-Signature'] = base64.b64encode(hmac.new(key.encode(), (u + ''.join(k + p[k] for k in sorted(p))).encode(), hashlib.sha1).digest()).decode()
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, data=body, headers=h), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
ACC = '11111111-2222-3333-4444-555555555555'
def call(n, frm, sec, stereo=True, vm=False):
    sid = 'CA%04d' % n; rs = 'RE%04d' % n; subprocess.run(['python3', D + '/mkwav.py', rs, str(sec), '1' if stereo else '0'])
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if vm: post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    c2, x2 = post('a=rec' + ('&vm=1' if vm else ''), {'AccountSid': ACC, 'CallSid': sid, 'RecordingSid': rs, 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/%s' % (ACC, rs), 'RecordingStatus': 'completed', 'RecordingDuration': str(sec), 'RecordingChannels': '2' if stereo else '1'})
    for k in range(80):
        row = sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
        if row and row[0]['status'] not in ('queued', 'work', 'ring') or (row and row[0]['status'] == 'queued' and row[0]['tries'] >= 1): break
        time.sleep(0.25)
    return (c, x, c2, x2), row
def appt(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, customer_name, status, source, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def push(): return sql("SELECT target, kind, title, body FROM push_log ORDER BY id DESC LIMIT 1") if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []

say('== LAMWEB test ' + ('2.99.587 – NO Claude key, OpenAI reads' if OAI else '2.99.587 – Claude key in HQ (as 586)') + ' · ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · tomorrow = ' + d1 + ' · numbers 555-01xx only, fake SignalWire / STT / AI')
# 1) signature
c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAbad', 'From': '+15555550141'}, sign=False); ok('No signature → 403', c == 403, (c, x))
c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAbad', 'From': '+15555550141'}, key='wrong-key-xxxxxxxxxxxxxxxx'); ok('Wrong Signing Key → 403', c == 403, (c, x))
c, x = post('a=answer', {'AccountSid': 'other-project', 'CallSid': 'CAbad2', 'From': '+15555550141'}); ok('Another SignalWire project → 403', c == 403, (c, x))
r = urllib.request.urlopen(B + '/call_in.php?a=tick&t=000', timeout=10) if False else None
try: urllib.request.urlopen(B + '/call_in.php?a=tick&t=bad', timeout=10); tk = 200
except urllib.error.HTTPError as e: tk = e.code
ok('Cron tick with a wrong token → 403', tk == 403, tk)
# 2) answer cXML
c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CA9999', 'From': '+15555550141', 'To': '+15156061616'})
ok('Answer: notice "This call may be recorded." + Dial iPhone 20 s, 2 channels, recording callback', c == 200 and '<Say voice="woman" language="en-US">This call may be recorded.</Say>' in x and 'timeout="20"' in x and 'record="record-from-answer-dual"' in x and 'a=rec' in x and '<Number>+15555550199</Number>' in x, x)
c, x = post('a=done', {'AccountSid': ACC, 'CallSid': 'CA9999', 'DialCallStatus': 'no-answer'})
ok('No answer → voicemail <Record> (120 s, beep) with its own callback', c == 200 and '<Record maxLength="120"' in x and 'a=rec&amp;vm=1' in x, x)
c, x = post('a=done', {'AccountSid': ACC, 'CallSid': 'CA9998', 'DialCallStatus': 'completed'}); ok('Answered → Hangup after the call', '<Hangup/>' in x, x)
# 3) S1 booked
r, row = call(1, '+15555550141', 3); a = appt('+15555550141')
ok('S1 Mia: answered, salon said OK → BOOKED (Gel Manicure tomorrow 2:00 PM, Any tech, source call)', row and row[0]['status'] == 'booked' and len(a) == 1 and a[0]['start_min'] == 840 and a[0]['source'] == 'call' and a[0]['staff_id'] == 0 and a[0]['service_ids'] == str(GM), (row and row[0]['status'], row and row[0]['reason'], a))
ok('S1: rec callback answered 200 <Response/>', r[2] == 200 and r[3].strip() == '<Response/>', r[2:])
ok('S1: the recording is kept outside the web folder, 0600', row and row[0]['file'] and os.path.exists(D + '/calls/' + row[0]['file']) and oct(os.stat(D + '/calls/' + row[0]['file']).st_mode)[-3:] == '600', row and row[0]['file'])
ok('S1: what was said kept (customer / salon split by channel)', row and 'Mia' in (row[0]['text_c'] or '') and 'see you at 2' in (row[0]['text_s'] or ''), row and (row[0]['text_c'], row[0]['text_s']))
ok('S1: Undo window 10 min (conf_at) and no text yet', row and row[0]['conf_at'] and not sql("SELECT id FROM outbox WHERE appt_id = %d" % a[0]['id']), row and row[0]['conf_at'])
fl = open(D + '/fake.log').read()
ok('S1: SignalWire download used Basic auth (Project ID + token) and the copy there was DELETED', 'GET rec RE0001 auth True' in fl and 'DELETE /api/laml/2010-04-01/Accounts/%s/Recordings/RE0001.json' % ACC in fl, fl[-600:])
if OAI: ok('S1 (no Claude key in HQ): STT + the AI reading both used the OpenAI key (gpt-4o-mini, JSON mode), Claude never called', 'STT auth Bearer sk-te' in fl and "OAI auth Bearer sk-te scen 1 model gpt-4o-mini json {'type': 'json_object'}" in fl and 'AI key' not in fl, fl[-500:])
else: ok('S1: STT got the OpenAI key + model; AI got the Claude HQ key (OpenAI chat not used)', 'STT auth Bearer sk-te' in fl and 'AI key sk-ant-tes' in fl and 'claude-haiku-4-5' in fl and 'OAI ' not in fl, fl[-400:])
pl = push(); ok('S1: owner push "📞 Booked: Mia – Gel Manicure – <day> 2:00 PM · Undo 10 min"', pl and pl[0]['title'].endswith('📞 Booked') is not None and 'Mia – Gel Manicure' in (pl[0]['body'] or '') and '2:00 PM' in pl[0]['body'], pl)
# duplicate callback
c, x = post('a=rec', {'AccountSid': ACC, 'CallSid': 'CA0001', 'RecordingSid': 'RE0001', 'RecordingUrl': '/x', 'RecordingStatus': 'completed', 'RecordingDuration': '3'})
ok('Same RecordingSid sent again → nothing new (1 call, 1 appointment)', len(sql("SELECT id FROM calls WHERE rec_sid = 'RE0001'")) == 1 and len(appt('+15555550141')) == 1, sql("SELECT id, call_sid FROM calls"))
# 4) S2 known customer, AI says OK but the salon never said it
r, row = call(2, '+15555550160', 4); ok('S2 Linh: AI claims OK but the salon\'s words have no OK → NEEDS REVIEW, nothing booked', row and row[0]['status'] == 'review' and 'No OK from the salon' in row[0]['reason'] and not appt('+15555550160'), row and (row[0]['status'], row[0]['reason']))
pl = push(); ok('S2: push "📞 Needs review"', pl and 'Needs review' in (pl[0]['title'] or ''), pl)
# 5) S3 info
n0 = len(sql("SELECT id FROM push_log")); r, row = call(3, '+15555550142', 5)
ok('S3 asks the price only → INFO, nothing booked, no push', row and row[0]['status'] == 'info' and len(sql("SELECT id FROM push_log")) == n0, row and (row[0]['status'], row[0]['result']))
# 6) S4 voicemail → booked with HANA
r, row = call(4, '+15555550143', 6, stereo=False, vm=True); a = appt('+15555550143')
ok('S4 voicemail Anna: full set tomorrow 11 AM HANA → BOOKED (no OK needed on a voicemail)', row and row[0]['kind'] == 'vm' and row[0]['status'] == 'booked' and a and a[0]['staff_id'] == T['HANA'] and a[0]['start_min'] == 660, row and (row[0]['kind'], row[0]['status'], row[0]['reason'], a))
# 7) S5 voicemail, SISI busy at 4 → call back
r, row = call(5, '+15555550144', 7, stereo=False, vm=True)
ok('S5 voicemail Bella: SISI already has ROSA at 4 PM → CALL BACK, nothing booked', row and row[0]['status'] == 'callback' and 'SISI already has ROSA TEST' in row[0]['reason'] and not appt('+15555550144'), row and (row[0]['status'], row[0]['reason']))
pl = push(); ok('S5: push "📞 Call back: <name/number> – <summary>"', pl and 'Call back' in pl[0]['title'] and 'Bella' in pl[0]['body'], pl)
# 8) S6 no time
r, row = call(6, '+15555550145', 8); ok('S6 Cara: no time said → NEEDS REVIEW (no time)', row and row[0]['status'] == 'review' and 'No time' in row[0]['reason'], row and row[0]['reason'])
# 9) S7 booked then Undo (via the cl_undo function, the API test does it again over HTTP)
r, row = call(7, '+15555550146', 9); a = appt('+15555550146')
ok('S7 Dana booked noon', row and row[0]['status'] == 'booked' and a and a[0]['start_min'] == 720, row and (row[0]['status'], row[0]['reason']))
# 10) S8 Vietnamese
r, row = call(8, '+15555550147', 10); a = appt('+15555550147')
ok('S8 Vietnamese call ("Dạ ok chị, 2 giờ nha") → BOOKED Full Set 2 PM (accents ignored when the OK is checked)', row and row[0]['status'] == 'booked' and a and a[0]['start_min'] == 840, row and (row[0]['status'], row[0]['reason']))
# 11) STT down → retry, then works
scen['stt_fail'] = True; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
r, row = call(9, '+15555550148', 3); ok('STT error → kept, tried again later (queued, tries 1, next_at +1 min)', row and row[0]['status'] == 'queued' and row[0]['tries'] == 1 and row[0]['next_at'] > row[0]['created_at'], row and (row[0]['status'], row[0]['tries'], row[0]['err']))
scen['stt_fail'] = False; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
sql("UPDATE calls SET next_at = '2000-01-01 00:00:00' WHERE call_sid = 'CA0009'")
open('/tmp/claude-0/T586/tick.php', 'w').write("<?php // ask the cron way: the token of this minute\nrequire '%s/inc/core.php'; require_once '%s/inc/calls.php'; settings(); echo cl_tick_token();" % (A, A))
tok = sh('php', D + '/tick.php').stdout.strip()
c = urllib.request.urlopen(B + '/call_in.php?a=tick&t=' + tok, timeout=60).status; time.sleep(0.5); row = sql("SELECT * FROM calls WHERE call_sid = 'CA0009'")
ok('Cron tick (signed by this server) → the waiting call is read again → its result', c == 200 and row and row[0]['status'] in ('booked', 'review'), row and (row[0]['status'], row[0]['reason'], row[0]['tries']))
# 12) the 10-min text: S1 due now, S7 undone first
s7 = sql("SELECT id FROM calls WHERE call_sid = 'CA0007'")[0]['id']
open(D + '/undo.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];\n$a = $argv[1];\nif ($a === 'undo') { try { echo json_encode(cl_undo((int)$argv[2], 'Owner')); } catch (Throwable $e) { echo 'ERR ' . $e->getMessage(); } }\nif ($a === 'tick') { cl_tick(); echo 'ticked'; }\nif ($a === 'purge') { echo cl_purge(); }\n" % (A, A, A, A))
u = sh('php', D + '/undo.php', 'undo', str(s7)); a = appt('+15555550146')
ok('S7 Undo within 10 min → appointment cancelled, call "undone"', '"status":"undone"' in u.stdout and a and a[0]['status'] == 'cancelled', (u.stdout[:200], u.stderr[:300], a))
u2 = sh('php', D + '/undo.php', 'undo', str(s7)); ok('Undo twice → "Undo is over"', 'ERR Undo is over' in u2.stdout, u2.stdout)
sql("UPDATE calls SET conf_at = '2000-01-01 00:00:00' WHERE call_sid IN ('CA0001', 'CA0007')")
t = sh('php', D + '/undo.php', 'tick'); a1 = appt('+15555550141')[0]['id']; a7 = appt('+15555550146')[0]['id']
ob1 = sql("SELECT kind, status, body FROM outbox WHERE appt_id = %d" % a1); ob7 = sql("SELECT kind FROM outbox WHERE appt_id = %d" % a7)
ok('After 10 min: S1 gets its YOU\'RE BOOKED (Confirm) like the owner\'s booking', ob1 and ob1[0]['kind'] == 'confirm', (t.stdout, t.stderr[:300], ob1))
ok('After 10 min: S7 (undone) → no text at all', not ob7, ob7)
s1 = sql("SELECT id FROM calls WHERE call_sid = 'CA0001'")[0]['id']; u3 = sh('php', D + '/undo.php', 'undo', str(s1)); ok('Undo after the 10 min → refused', 'ERR Undo is over' in u3.stdout, u3.stdout)
# 13) auto send hand-off for source call (as_on + as_conf_owner)
ok('autosend.php: a booking from a call is sent like the owner\'s own (as_conf_owner)', "($src === 'call' && setting('as_conf_owner') !== '0')" in open(A + '/inc/autosend.php').read())
# 14) purge
sql("UPDATE calls SET purge_at = '2000-01-01' WHERE call_sid = 'CA0001'"); f1 = sql("SELECT file FROM calls WHERE call_sid = 'CA0001'")[0]['file']
p = sh('php', D + '/undo.php', 'purge'); row = sql("SELECT * FROM calls WHERE call_sid = 'CA0001'")[0]
ok('30 days: recording file + what was said deleted, the appointment stays', not os.path.exists(D + '/calls/' + f1) and row['file'] == '' and (row['text_c'] or '') == '' and (row['ai_json'] or '') == '' and row['purged'] == 1 and appt('+15555550141')[0]['status'] == 'booked', (p.stdout, row['file'], row['purged']))
# 15) tokens never in logs / pages
# 16) (2.99.587) a call that stopped only for a missing key is read again once the key is there (CHAT test #1, call 2)
json.dump({}, open(D + '/shared/call-ai.json', 'w'))
scen['stt']['11'] = {'c': '#S9 Hi this is Ella, gel manicure tomorrow at 5', 's': 'OK, 5 tomorrow, see you.'}
scen['ai']['9'] = ai(customer_name='Ella', service_ids=[GM], time='17:00', salon_agreed=True, salon_quote='OK, 5 tomorrow, see you', summary='Ella, gel manicure tomorrow 5 PM.')
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
r, row = call(11, '+15555550149', 11)
ok('No speech-to-text key → kept as Needs review "No speech-to-text key yet", the recording kept', row and row[0]['status'] == 'review' and 'No speech-to-text key yet' in row[0]['reason'] and row[0]['file'], row and (row[0]['status'], row[0]['reason']))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
t = sh('php', D + '/undo.php', 'tick'); row = sql("SELECT * FROM calls WHERE call_sid = 'CA0011'"); a = appt('+15555550149')
ok('Key added → the next tick reads that call again → BOOKED Ella 5 PM', row and row[0]['status'] == 'booked' and a and a[0]['start_min'] == 1020, (t.stdout, t.stderr[-300:], row and (row[0]['status'], row[0]['reason'])))
n2 = len(sql("SELECT id FROM calls WHERE status = 'queued'")); t = sh('php', D + '/undo.php', 'tick')
ok('Other Needs review calls (real reasons) are NOT read again', n2 == 0 and sql("SELECT status FROM calls WHERE call_sid = 'CA0002'")[0]['status'] == 'review', n2)
logs = open(D + '/php.log').read() + open(D + '/fake.log').read()
ok('Tokens never written to the logs', 'PT_test_token' not in logs and 'PSK_test_signing' not in logs and 'sk-test-0000' not in logs, '')
ok('Tokens kept encrypted in the database', all('PT_test_token' not in str(x) and 'PSK_test' not in str(x) for x in sql("SELECT v FROM settings WHERE k IN ('sw_token','sw_signing')")))
say('PASS %d/%d' % (sum(R), len(R)))
sv.terminate(); fk.terminate()
