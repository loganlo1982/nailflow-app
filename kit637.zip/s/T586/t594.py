# LAMWEB test 586 – the whole call flow on a local copy (fake SignalWire / STT / Claude; test numbers 555-01xx only). python3 t586.py <app tree>
import subprocess, json, os, sys, time, hmac, hashlib, base64, urllib.request, urllib.parse, shutil
A = sys.argv[1]; D = '/tmp/claude-0/T586'; PORT = 19861; DB = D + '/db.sqlite'; KEY = 'PSK_test_signing_key_0123456789'
R = []; out = open(D + '/test-594.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', D + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
for f in os.listdir(D + '/calls') if os.path.isdir(D + '/calls') else []: pass
shutil.rmtree(D + '/calls', ignore_errors=True); os.makedirs(D + '/calls'); open(D + '/fake.log', 'w').close()
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
OAI = True
if OAI: json.dump({}, open(D + '/shared/color-ai.json', 'w'))
else: json.dump({'key': 'sk-ant-test-000000000000000000000000'}, open(D + '/shared/color-ai.json', 'w'))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SHARED_DIR': D + '/shared', 'NF_CALLS_DIR': D + '/calls'}
seed = json.loads(sh('php', D + '/seed.php', A, DB, str(PORT)).stdout); S, T, d1 = seed['S'], seed['T'], seed['d1']
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
def ai(**k): b = {'intent': 'book', 'customer_name': '', 'customer_phone': '', 'service_ids': [], 'service_text': '', 'tech_id': 0, 'tech_text': '', 'date': d1, 'time': '', 'people': 1, 'salon_side': 'person', 'salon_agreed': False, 'salon_quote': '', 'confidence': 0.95, 'missing': [], 'summary': ''}; b.update(k); return b
scen = {'stt': {
  '3': {'c': '#S1 Hi this is Mia, can I get a gel manicure tomorrow at 2?', 's': 'Sure, tomorrow at 2 is open. OK, see you at 2!'},
  '4': {'c': '#S2 This is Linh, pedicure with Tammy tomorrow at 3 please', 's': 'Let me check the book for you.'},
  '5': {'c': '#S3 How much is a full set?', 's': 'Full set is fifty dollars.'},
  '6': {'c': '#S4 Hi this is Anna, I want a full set tomorrow at 11 with Hana. Thanks!'},
  '7': {'c': '#S5 Bella here, gel manicure tomorrow at 4 with Sisi please, call me back'},
  '8': {'c': '#S6 Hi I want a pedicure tomorrow, Cara', 's': 'ok'},
  '9': {'c': '#S7 Hi Dana, gel manicure tomorrow at noon?', 's': 'Yes ok, noon tomorrow.'},
  '10': {'c': '#S8 chị muốn làm bột thứ bảy 2 giờ, tên Hoa', 's': 'Dạ ok chị, 2 giờ nha.'}},
 'ai': {
  '1': ai(customer_name='Mia', service_ids=[GM], time='14:00', salon_agreed=True, salon_quote='OK, see you at 2', summary='Mia wants a gel manicure tomorrow at 2 PM.'),
  '2': ai(customer_name='Linh', service_ids=[PD], tech_id=T['TAMMY'], tech_text='Tammy', time='15:00', salon_agreed=True, salon_quote='ok sure 3pm', summary='Linh wants a pedicure with Tammy tomorrow 3 PM.'),
  '3': ai(intent='info', summary='Asked the price of a full set.'),
  '4': ai(customer_name='Anna', service_ids=[FS], tech_id=T['HANA'], tech_text='Hana', time='11:00', summary='Voicemail: Anna, full set tomorrow 11 AM with Hana.'),
  '5': ai(customer_name='Bella', service_ids=[GM], tech_id=T['SISI'], tech_text='Sisi', time='16:00', summary='Voicemail: Bella, gel manicure tomorrow 4 PM with Sisi.'),
  '6': ai(customer_name='Cara', service_ids=[PD], time='', salon_agreed=True, salon_quote='ok', confidence=0.9, missing=['time'], summary='Cara wants a pedicure tomorrow, no time.'),
  '7': ai(customer_name='Dana', service_ids=[GM], time='12:00', salon_agreed=True, salon_quote='Yes ok, noon tomorrow', summary='Dana, gel manicure tomorrow at noon.'),
  '8': ai(customer_name='Hoa', service_ids=[FS], time='14:00', date=d1, salon_agreed=True, salon_quote='Dạ ok chị, 2 giờ nha', confidence=0.9, summary='Hoa wants a full set at 2 PM.')}}
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
fk = subprocess.Popen(['python3', D + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.3)
B = 'http://127.0.0.1:%d' % PORT
def post(a, p, sign=True, key=KEY, url=None):
    u = url or (B + '/call_in.php?' + a); body = urllib.parse.urlencode(p).encode(); h = {'Content-Type': 'application/x-www-form-urlencoded'}
    if sign: h['X-SignalWire-Signature'] = base64.b64encode(hmac.new(key.encode(), (u + ''.join(k + p[k] for k in sorted(p))).encode(), hashlib.sha1).digest()).decode()
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, data=body, headers=h), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
ACC = '11111111-2222-3333-4444-555555555555'
def call(n, frm, sec, stereo=True, vm=False):
    sid = 'CA%04d' % n; rs = 'RE%04d' % n; subprocess.run(['python3', D + '/mkwav.py', rs, str(sec), '1' if stereo else '0'])
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if vm: post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    c2, x2 = post('a=rec' + ('&vm=1' if vm else ''), {'AccountSid': ACC, 'CallSid': sid, 'RecordingSid': rs, 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/%s' % (ACC, rs), 'RecordingStatus': 'completed', 'RecordingDuration': str(sec), 'RecordingChannels': '2' if stereo else '1'})
    for k in range(80):
        row = sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
        if row and row[0]['status'] not in ('queued', 'work', 'ring') or (row and row[0]['status'] == 'queued' and row[0]['tries'] >= 1): break
        time.sleep(0.25)
    return (c, x, c2, x2), row
def appt(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, customer_name, status, source, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def push(): return sql("SELECT target, kind, title, body FROM push_log ORDER BY id DESC LIMIT 1") if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []



open(D + '/set590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'salon_name' => 'American Nails', 'as_kinds' => json_encode(['confirm' => true, 'change' => true, 'cancel' => true])] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set590.php')
open(D + '/undo.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];\n$a = $argv[1];\nif ($a === 'tick') { cl_tick(); echo 'ticked'; }\n" % (A, A, A, A))
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat(); d3 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=3)).isoformat()
open(D + '/mk592.php', 'w').write("<?php require '%s/inc/core.php'; settings(); [$_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = [];\nupsert_customer($ph, $name);\nfor ($i = 0; $i < (int)$n; $i++) { q(\"INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)\", [$date, (int)$start, 45, (int)$staff + $i * ((int)$staff ? 1 : 0), '%d', $i ? $name . ' +' . $i : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); }\necho implode(',', $ids);" % (A, S['Pedicure']))
def mk(ph, name, date, start, staff=0, n=1): return [int(x) for x in sh('php', D + '/mk592.php', ph, name, date, str(start), str(staff), str(n)).stdout.split(',')]
def ap(i): return sql("SELECT id, appt_date, start_min, staff_id, status FROM appointments WHERE id = %d" % i)[0]
def ob(i, k): return sql("SELECT kind, ref, status FROM outbox WHERE appt_id = %d AND kind = '%s'" % (i, k))
def lastpush(): return sql("SELECT title, body FROM push_log WHERE target = 'admin' ORDER BY id DESC LIMIT 1")
def go(n, ph, j, tc, ts=None, vm=True):
    scen['stt'][str(n)] = {'c': '#S%d ' % (100 + n) + tc} if ts is None else {'c': '#S%d ' % (100 + n) + tc, 's': ts}
    scen['ai'][str(100 + n)] = j; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
    r, row = call(n, ph, n, stereo=not vm, vm=vm); time.sleep(0.8); return mrow('CA%04d' % n)[0]
def mrow(sid): return sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
say('== LAMWEB test 2.99.594 – group booking / blocked numbers + 594-B party cancel part / add (item 3 balance dropped by anh Logan 20:05) · ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire / STT / AI · texts only into the SMS Server queue')
open(D + '/h594.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; cl_table(); $a = $argv[1];\n"
 "if ($a === 'set') { set_setting($argv[2], $argv[3]); echo 'ok'; }\n"
 "if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }\n"
 "if ($a === 'list') echo json_encode(['l' => cl_list(10), 'n' => cl_badge()]);\n"
 "if ($a === 'poke') { cl_cron_poke(); echo 'poked'; }\n" % (A, A))
def h(*a): r = sh('php', D + '/h594.php', *a); return r.stdout
def P(name='', sids=None, text='', tid=0, tt=''): return {'name': name, 'service_ids': sids or [], 'service_text': text, 'tech_id': tid, 'tech_text': tt}
def grp(ph): return sql("SELECT id, appt_date, start_min, duration, staff_id, service_ids, customer_name, status, source, group_id, note FROM appointments WHERE phone = '%s' AND status <> 'cancelled' ORDER BY id" % ph)
def conf(ph):
    for k in range(12):
        r = sql("SELECT id, kind, ref FROM outbox WHERE phone = '%s' AND kind = 'confirm'" % ph)
        if r: return r
        time.sleep(0.25)
    return r
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat()
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
# ---- 1. GROUP ----
r = go(41, '+15555550141', ai(customer_name='Mia', people=2, party=[P('Mia', [PD]), P('')], same_services=True, time='14:00', summary='Mia and her daughter, 2 pedicures tomorrow 2 PM.'), 'Hi this is Mia, me and my daughter both want a pedicure tomorrow at 2')
g = grp('+15555550141')
ok('G1 voicemail "me and my daughter … both pedicure" → BOOKED 2 rows, same time 2:00 PM, linked 🔗 (one group id), source call', r['status'] == 'booked' and len(g) == 2 and all(x['start_min'] == 840 and x['appt_date'] == d1 and x['service_ids'] == str(PD) and x['source'] == 'call' for x in g) and g[0]['group_id'] != '' and g[0]['group_id'] == g[1]['group_id'], (r['status'], r['reason'], g))
ok('G1 names MIA / MIA +1 (like Book for several people), Any tech for both', [x['customer_name'] for x in g] == ['MIA', 'MIA +1'] and all(x['staff_id'] == 0 for x in g), g)
ok('G1 ONE YOU\'RE BOOKED for the group', len(conf('+15555550141')) == 1, conf('+15555550141'))
lp = lastpush(); ok('G1 owner push "📞 Booked: Mia – Pedicure – … 2:00 PM · 2 people"', lp and '2 people' in lp[0]['body'] and lp[0]['body'].startswith('Mia – Pedicure'), lp)
ok('G1 list line "… · 2 people"', r['result'].endswith('· 2 people'), r['result'])
r = go(42, '+15555550142', ai(customer_name='Kim', people=2, party=[P('Kim', [GM]), P('Lily', [PD], tid=T2, tt='Hana')], time='11:00', salon_agreed=True, salon_quote='OK see you both at 11', summary='Kim gel, Lily pedicure with Hana, tomorrow 11.'),
  'This is Kim, a gel manicure for me and a pedicure for my friend Lily with Hana tomorrow at 11', ts='Sure. OK see you both at 11.', vm=False)
g = grp('+15555550142')
ok('G2 answered + the salon\'s real OK, each person own service / tech → BOOKED: KIM Gel Any 30 min · LILY Pedicure HANA 45 min, same 11:00', r['status'] == 'booked' and len(g) == 2 and g[0]['service_ids'] == str(GM) and g[0]['staff_id'] == 0 and g[0]['duration'] == 30 and g[1]['service_ids'] == str(PD) and g[1]['staff_id'] == T2 and g[1]['duration'] == 45 and g[1]['customer_name'] == 'LILY' and all(x['start_min'] == 660 for x in g), (r['status'], r['reason'], g))
r = go(43, '+15555550143', ai(customer_name='Ann', people=2, party=[P('Ann', [GM]), P('', [GM])], time='15:00', salon_agreed=False, summary='Ann x2 gel'), 'Ann, two gel manicures tomorrow at 3', ts='Let me look.', vm=False)
ok('G3 answered call WITHOUT the salon\'s OK → nothing booked, Needs review', r['status'] == 'review' and not grp('+15555550143') and 'no ok' in r['reason'].lower(), (r['status'], r['reason']))
r = go(44, '+15555550144', ai(customer_name='Bea', people=2, party=[P('Bea', [PD]), P('daughter')], same_services=False, time='15:00', summary='Bea pedicure + daughter ?'), 'Bea, pedicure for me tomorrow at 3 and my daughter too, not sure what she wants')
ok('G4 the 2nd person\'s service not clear (no "both / same") → Call back "services for each person not clear"', r['status'] == 'callback' and not grp('+15555550144') and 'services for each person not clear' in r['reason'].lower(), (r['status'], r['reason']))
r = go(45, '+15555550145', ai(customer_name='Cat', people=2, service_ids=[PD], party=[], same_services=True, time='16:00', summary='2 people pedicure'), 'Cat here, 2 people pedicure tomorrow at 4')
g = grp('+15555550145'); ok('G5 "2 people pedicure" (no list, same) → BOOKED 2 × Pedicure at 4:00 PM (SISI busy 4 PM: still 2 techs free)', r['status'] == 'booked' and len(g) == 2 and all(x['service_ids'] == str(PD) and x['start_min'] == 960 for x in g), (r['status'], r['reason'], g))
r = go(46, '+15555550146', ai(customer_name='Dee', people=5, service_ids=[PD], same_services=True, time='12:00', summary='5 people'), 'Dee, 5 pedicures tomorrow noon')
ok('G6 5 people → nothing booked, Call back "5 people (4 at most on a call)"', r['status'] == 'callback' and not grp('+15555550146') and '5 people' in r['reason'], (r['status'], r['reason']))
r = go(47, '+15555550147', ai(customer_name='Eve', people=4, service_ids=[GM], same_services=True, time='18:00', summary='4 gel'), 'Eve, 4 gel manicures tomorrow at 6')
ok('G7 4 people but only 3 techs work → nothing booked, Call back "Not enough techs free for 4 people at 6:00 PM"', r['status'] == 'callback' and not grp('+15555550147') and 'Not enough techs free for 4 people' in r['reason'], (r['status'], r['reason']))
mk('+15555550190', 'BUSY', d1, 17 * 60, T1, 2)
r = go(48, '+15555550148', ai(customer_name='Fay', people=2, service_ids=[GM], same_services=True, time='17:00', summary='2 gel'), 'Fay, two gel manicures tomorrow at 5')
ok('G8 TAMMY + HANA busy at 5 PM (1 tech free) → group of 2 NOT booked, Call back', r['status'] == 'callback' and not grp('+15555550148') and 'Not enough techs' in r['reason'], (r['status'], r['reason']))
r = go(49, '+15555550149', ai(customer_name='Gia', people=2, party=[P('Gia', [GM], tid=T3, tt='Sisi'), P('Ivy', [GM], tid=T3, tt='Sisi')], time='10:00', summary='both with Sisi'), 'Gia, me and Ivy both with Sisi tomorrow at 10, gel')
ok('G9 the same tech asked for both at the same time → Call back', r['status'] == 'callback' and not grp('+15555550149') and 'asked for 2 people' in r['reason'], (r['status'], r['reason']))
r = go(50, '+15555550151', ai(customer_name='Hope', people=3, party=[P('Hope', [FS], tid=T1, tt='Tammy'), P('Jo', [PD]), P('Kay', [GM])], time='13:00', salon_agreed=True, salon_quote='ok 1 pm for three', summary='3 people'), 'Hope, full set with Tammy, Jo pedicure, Kay gel, tomorrow 1', ts='Yes ok 1 pm for three.', vm=False)
g = grp('+15555550151'); ok('G10 3 people, one with TAMMY + 2 Any → BOOKED 3 rows (TAMMY, Any, Any), same 1:00 PM, ONE text', r['status'] == 'booked' and [x['staff_id'] for x in g] == [T1, 0, 0] and len(conf('+15555550151')) == 1 and all(x['start_min'] == 780 for x in g), (r['status'], r['reason'], g))
# Undo on a group (589 sends at once; here the 10 minutes are put back to test cl_undo)
cid = r['id']; sql("UPDATE calls SET conf_done = 0, conf_at = '%s' WHERE id = %d" % (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + 300)), cid))
open(D + '/undo594.php', 'w').write(open(D + '/undo.php').read().replace("if ($a === 'tick')", "if ($a === 'undo') { cl_undo((int)$argv[2], 'Owner'); echo 'undone'; }\nif ($a === 'tick')"))
u = sh('php', D + '/undo594.php', 'undo', str(cid)).stdout
ok('G11 ↩ Undo on a group from a call → EVERY person cancelled', u.strip().endswith('undone') and not grp('+15555550151'), (u, grp('+15555550151')))
r = go(51, '+15555550152', ai(customer_name='Lee', service_ids=[GM], time='19:00', summary='1 person'), 'Lee, gel manicure tomorrow at 7')
ok('G12 one person still books like before (592)', r['status'] == 'booked' and len(grp('+15555550152')) == 1 and grp('+15555550152')[0]['group_id'] == '', (r['status'], r['reason']))
# ---- 594-B: a party cancel part / add / cancel both ----
def ap(i): return sql("SELECT id, appt_date, start_min, staff_id, status, group_id, customer_name, service_ids FROM appointments WHERE id = %d" % i)[0]
def ob2(ph, k): return sql("SELECT kind, ref, body FROM outbox WHERE phone = '%s' AND kind = '%s' ORDER BY id" % (ph, k))
d3 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=3)).isoformat()
g = mk('+15555550161', 'MIA', d2, 14 * 60, T1, 2)
r = go(61, '+15555550161', ai(intent='cancel', customer_name='Mia', date='', time='', cancel_part=True, cancel_names=[], cancel_n=1, who_text='my daughter', summary='Mia cancels only her daughter.'), 'Hi this is Mia, please cancel only my daughter, I still come')
ok('BB1 voicemail "cancel only my daughter" (party of 2) → ONLY the 2nd person cancelled, Mia still booked', r['status'] == 'cancelled' and ap(g[0])['status'] == 'booked' and ap(g[1])['status'] == 'cancelled', (r['status'], r['reason'], [ap(i)['status'] for i in g]))
lp = lastpush(); ok('BB1 owner push "📞 <salon> – Cancelled 1 of 2" · "Mia\'s daughter – Pedicure – <day> 2:00 PM (from a call)"', lp and lp[0]['title'].startswith('📞') and lp[0]['title'].endswith('Cancelled 1 of 2') and lp[0]['body'].startswith("Mia's daughter – Pedicure –") and lp[0]['body'].endswith('2:00 PM (from a call)'), lp)
t = ob2('+15555550161', 'cancel'); ok('BB1 ONE CANCELLED text: "CANCELLED: Mia\'s daughter" + "Still booked: 1 person (Mia)"', len(t) == 1 and "CANCELLED: Mia's daughter" in t[0]['body'] and 'Still booked: 1 person (Mia)' in t[0]['body'] and '{' not in t[0]['body'], t)
say('   text: ' + (t[0]['body'].replace('\n', ' / ') if t else '-'))
ok('BB1 list "Cancelled ✓ 1 of 2: … · 1 still booked"', r['result'].startswith('Cancelled ✓ 1 of 2:') and r['result'].endswith('1 still booked'), r['result'])
g3 = mk('+15555550162', 'NOVA', d2, 15 * 60, 0, 3)
r = go(62, '+15555550162', ai(intent='cancel', customer_name='Nova', date='', time='', cancel_part=True, cancel_n=1, summary='one person'), 'Nova, cancel one person please')
ok('BB2 party of 3, "one person" no name → not clear → nothing cancelled, Call back', r['status'] == 'callback' and all(ap(i)['status'] == 'booked' for i in g3) and 'not clear which person' in r['reason'], (r['status'], r['reason']))
sql("UPDATE appointments SET customer_name = 'LILY' WHERE id = %d" % g3[2])
r = go(63, '+15555550162', ai(intent='cancel', customer_name='Nova', date='', time='', cancel_part=True, cancel_names=['Lily'], cancel_n=1, summary='cancel Lily'), 'Nova here, cancel Lily only')
ok('BB3 by name "Lily" → only LILY cancelled, the other 2 stay', r['status'] == 'cancelled' and [ap(i)['status'] for i in g3] == ['booked', 'booked', 'cancelled'], (r['status'], r['reason']))
t = ob2('+15555550162', 'cancel'); ok('BB3 the text says "Still booked: 2 people"', t and 'Still booked: 2 people' in t[-1]['body'], t)
r = go(64, '+15555550162', ai(intent='cancel', customer_name='Nova', date='', time='', cancel_part=True, cancel_names=['Zoe'], summary='cancel Zoe'), 'Nova, cancel Zoe')
ok('BB4 a name not on the party → Call back, nothing cancelled', r['status'] == 'callback' and ap(g3[0])['status'] == 'booked' and ap(g3[1])['status'] == 'booked', (r['status'], r['reason']))
g4 = mk('+15555550163', 'OTTO', d2, 16 * 60, T2, 2)
r = go(65, '+15555550163', ai(intent='cancel', customer_name='Otto', date='', time='', cancel_part=True, cancel_n=1, salon_side='person', salon_agreed=False, summary='cancel one'), 'Otto, cancel my son only', ts='Hmm wait.', vm=False)
ok('BB5 answered call without the salon\'s OK → nothing cancelled, Needs review', r['status'] == 'review' and all(ap(i)['status'] == 'booked' for i in g4), (r['status'], r['reason']))
# add
a5 = mk('+15555550164', 'PIA', d2, 11 * 60, T1)[0]
r = go(66, '+15555550164', ai(intent='add', customer_name='Pia', date=d2, time='11:00', add_n=1, party=[P('', [], 'pedicure')], who_text='my friend', summary='add a friend'), 'Pia, add my friend to my appointment, a pedicure')
rows = sql("SELECT id, staff_id, start_min, appt_date, group_id, customer_name, service_ids, status FROM appointments WHERE phone = '+15555550164' AND status = 'booked' ORDER BY id")
ok('BB6 "add my friend" → a 2nd person at the SAME time (11:00 AM), Pedicure, Any tech, linked 🔗 with Pia', r['status'] == 'booked' and len(rows) == 2 and rows[1]['start_min'] == 660 and rows[1]['appt_date'] == d2 and rows[1]['service_ids'] == str(PD) and rows[1]['staff_id'] == 0 and rows[0]['group_id'] != '' and rows[0]['group_id'] == rows[1]['group_id'] and rows[0]['staff_id'] == T1, (r['status'], r['reason'], rows))
ok('BB6 ONE YOU\'RE BOOKED (the whole party) + push "📞 Added 1 person"', len(ob2('+15555550164', 'confirm')) == 1 and lastpush() and '📞 Added 1 person' in lastpush()[0]['title'] and "Pia's friend" in lastpush()[0]['body'] and 'now 2 people' in lastpush()[0]['body'], (ob2('+15555550164', 'confirm'), lastpush()))
say('   text: ' + (ob2('+15555550164', 'confirm')[0]['body'].replace('\n', ' / ') if ob2('+15555550164', 'confirm') else '-'))
ok('BB6 not Undo-able like a new booking (no 10-min timer), list "Added ✓ …"', r['result'].startswith('Added ✓') and r['conf_at'] == '', (r['result'], r['conf_at']))
mk('+15555550191', 'BUSY', d3, 10 * 60, T2, 2); a6 = mk('+15555550165', 'QUIN', d3, 10 * 60, T1)[0]
r = go(67, '+15555550165', ai(intent='add', customer_name='Quin', date=d3, time='', add_n=1, same_services=True, party=[], summary='add same'), 'Quin, add one more person, same as me')
ok('BB7 all 3 techs busy then → nobody added, Call back', r['status'] == 'callback' and len(sql("SELECT id FROM appointments WHERE phone = '+15555550165' AND status = 'booked'")) == 1, (r['status'], r['reason']))
a7 = mk('+15555550166', 'RUE', d2, 18 * 60, T1)[0]
r = go(68, '+15555550166', ai(intent='add', customer_name='Rue', date='', time='', add_n=1, party=[P('Sol')], summary='add Sol'), 'Rue, add my friend Sol')
ok('BB8 the new person\'s service not said (not "same") → Call back', r['status'] == 'callback' and 'service for the new person' in r['reason'], (r['status'], r['reason']))
r = go(69, '+15555550166', ai(intent='add', customer_name='Rue', date='', time='', add_n=1, same_services=True, party=[P('Sol')], salon_side='person', salon_agreed=True, salon_quote='Sure we can add Sol', summary='add Sol same'), 'Rue, add my friend Sol, same as me', ts='Sure we can add Sol.', vm=False)
rows = sql("SELECT customer_name, service_ids, start_min FROM appointments WHERE phone = '+15555550166' AND status = 'booked' ORDER BY id")
ok('BB9 answered + OK, "same as me" → SOL added with Pedicure at 6:00 PM', r['status'] == 'booked' and len(rows) == 2 and rows[1]['customer_name'] == 'SOL' and rows[1]['service_ids'] == str(PD) and rows[1]['start_min'] == 1080, (r['status'], r['reason'], rows))
g5 = mk('+15555550167', 'TESS', d2, 12 * 60, 0, 4)
r = go(70, '+15555550167', ai(intent='add', customer_name='Tess', date='', time='', add_n=1, same_services=True, summary='add 5th'), 'Tess, add one more')
ok('BB10 already 4 → a 5th person not added, Call back "5 people (4 at most …)"', r['status'] == 'callback' and '5 people' in r['reason'], (r['status'], r['reason']))
# c. two SEPARATE appointments, "cancel both"
s1 = mk('+15555550168', 'UMA', d2, 9 * 60 + 30, T3)[0]; s2 = mk('+15555550168', 'UMA', d3, 13 * 60, T3)[0]
r = go(71, '+15555550168', ai(intent='cancel', customer_name='Uma', date='', time='', cancel_all=True, summary='cancel both'), 'Uma, cancel both my appointments')
ok('BB11 2 separate (not 🔗) appointments, "cancel both" → both cancelled', r['status'] == 'cancelled' and ap(s1)['status'] == 'cancelled' and ap(s2)['status'] == 'cancelled', (r['status'], r['reason']))
# ---- 2. BLOCKED ----
def ans(n, frm):
    p = {'AccountSid': ACC, 'CallSid': 'CB%04d' % n, 'To': '+15156061616', 'CallStatus': 'ringing'}
    if frm is not None: p['From'] = frm
    return post('a=answer', p)
c, x = ans(1, '')
ok('B1 From empty → the greeting + "Sorry, we can\'t take calls from a blocked or private number. Please call us again from your real phone number. Thank you!" + Hangup (no <Dial>, no <Record>)', c == 200 and 'Thank you for calling American Nails. Sorry, we can&#039;t take calls from a blocked or private number. Please call us again from your real phone number. Thank you!' in x.replace("&apos;", "&#039;").replace("'", "&#039;") and '<Hangup/>' in x and '<Dial' not in x and '<Record' not in x, x)
b = mrow('CB0001'); ok('B1 Calls list row: status blocked (chip "🚫 Blocked number"), no text back, not in the red number', b and b[0]['status'] == 'blocked' and b[0]['result'] == '' and b[0]['tb_state'] == 'off' and b[0]['seen'] == 1, b)
res = [ans(i, f) for i, f in [(2, 'anonymous'), (3, 'Restricted'), (4, '+266696687'), (5, 'unknown'), (6, '5550123'), (7, '+15550123456')]]
ok('B2 anonymous / Restricted / +266696687 / unknown / 7 digits / bad US number → all hung up', all('<Dial' not in x and 'blocked or private' in x for _, x in res), [x[:80] for _, x in res])
c, x = ans(8, None); ok('B2 no From at all → hung up', '<Dial' not in x and 'blocked or private' in x, x)
c, x = ans(9, '+15555550153'); ok('B3 a real number → rings the iPhone like before (greeting + notice + <Dial>)', '<Dial' in x and 'blocked' not in x and 'This call may be recorded.' in x, x)
h('set', 'call_block', '0'); c, x = ans(10, 'anonymous'); h('set', 'call_block', '')
ok('B4 Settings "Hang up on blocked numbers" OFF → a private number rings like before', '<Dial' in x, x)
L = json.loads(h('list')); bl = [c for c in L['l'] if c['status'] == 'blocked']
ok('B5 cl_list: blocked rows shown ("Unknown number" + chip Blocked number), not counted in the red number', len(bl) >= 8 and all(c['phone'] == 'Unknown number' for c in bl), (len(bl), L['n']))
ok('B6 no recording / no text for blocked calls', not sql("SELECT id FROM calls WHERE call_sid LIKE 'CB%' AND (rec_sid <> '' AND rec_sid IS NOT NULL OR tb_state = 'sent')"), sql("SELECT call_sid, rec_sid, tb_state FROM calls WHERE call_sid LIKE 'CB%'"))
# ---- the cron poke (fixed: schema 2) ----
sql("INSERT INTO calls (call_sid, from_phone, kind, status, result, tb_state, tb_at, created_at, purge_at) VALUES ('CP0001', '+15555550154', 'call', 'missed', 'Missed', 'wait', '2020-01-01 00:00:00', '%s', '2099-01-01')" % time.strftime('%Y-%m-%d %H:%M:%S'))
h('poke'); time.sleep(3); x = mrow('CP0001')
ok('P1 cron poke works on the table schema 2 (was never poking since 590): the missed-call text waiting is done', x and x[0]['tb_state'] not in ('wait', ''), x)
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors in the server log', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:5])
ok('No token in the logs', not any(t in logs + open(D + '/fake.log').read() for t in ['PT_test_token_abc', 'PSK_test_signing']), '')
say('PASS %d/%d' % (sum(R), len(R)))
sv.terminate(); fk.terminate()
