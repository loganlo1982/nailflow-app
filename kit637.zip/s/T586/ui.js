// LAMWEB 586 UI: Messages → Calls (list, booked + Undo, needs review + Book), Settings → Calls · iPhone SE / 13 / iPad
process.env.NF_CALLS_DIR = '/tmp/claude-0/T586/calls-ui'; process.env.NF_SHARED_DIR = '/tmp/claude-0/T586/shared';
const { run } = require('/tmp/claude-0/t561/lib.js'); const { execSync } = require('child_process'); const fs = require('fs');
const A = process.argv[2], PORT = 19862, OUT = '/tmp/claude-0/T586/o';
fs.rmSync(process.env.NF_CALLS_DIR, { recursive: true, force: true });
run(A, PORT, OUT, async ({ open, ok, sleep, devices, OUT, B, pe }) => {
  const W = `/tmp/claude-0/t561/w${PORT}/db.sqlite`;
  execSync(`php /tmp/claude-0/T586/seed.php ${A} ${W} ${PORT}`, { env: { ...process.env, TZ: 'America/Chicago' } });
  for (const [name, dev] of [['se', devices['iPhone SE']], ['13', devices['iPhone 13']], ['ipad', devices['iPad (gen 7)']]]) {
    execSync(`php /tmp/claude-0/T586/uiseed.php ${A}`, { env: { ...process.env, TZ: 'America/Chicago' } });
    const { ctx, p } = await open(dev, true, false, name);
    await p.evaluate(async () => { await callsState(); setTab('messages'); }); await sleep(1500);
    const seg = await p.evaluate(() => [...document.querySelectorAll('#p-messages .msg-seg button, #homeBar .msg-seg button')].map(b => b.textContent.trim()));
    ok(name + ': Messages has "Calls" as the 4th button (To send · Sent · Calls…), red number 2', seg.some(t => /^Calls/.test(t)) && seg.some(t => /Calls\s*2/.test(t)), seg);
    await p.evaluate(() => { M.view = 'calls'; renderMessages(); }); await sleep(1500);
    const rows = await p.evaluate(() => [...document.querySelectorAll('#p-messages [data-call]')].map(b => b.innerText.replace(/\s+/g, ' ')));
    ok(name + ': Calls list – 5 calls, chips Booked / Needs review / Call back / Missed / Info', rows.length === 5 && /Booked/.test(rows[0]) && /Needs review/.test(rows[1]) && /Call back/.test(rows[2]) && /Missed/.test(rows[3]) && /Info/.test(rows[4]), rows);
    await p.screenshot({ path: `${OUT}/${name}-1-calls.png` });
    await p.click('#p-messages [data-call]'); await sleep(1200);
    const s1 = await p.evaluate(() => ({ t: (document.querySelector('.sheet') || document.body).innerText, undo: !!document.querySelector('#clUndo'), audio: !!document.querySelector('.cl-audio') }));
    ok(name + ': booked call – result line, Undo with the minutes left, ▶ recording, What was said', s1.undo && s1.audio && /Mia – Gel Manicure/.test(s1.t) && /What was said/.test(s1.t), s1.t.slice(0, 300));
    await p.screenshot({ path: `${OUT}/${name}-2-booked.png` });
    if (name === '13') { // the recording plays from the api (owner only, Range)
      const au = await p.evaluate(async () => { const id = document.querySelector('.cl-audio').src.match(/id=(\d+)/)[1]; const r = await fetch('../api.php?action=call_audio&id=' + id, { headers: { Range: 'bytes=0-99' } }); return [r.status, r.headers.get('content-type'), (await r.arrayBuffer()).byteLength]; });
      ok('▶ recording: 206 audio/wav, 100 bytes for Range 0-99', au[0] === 206 && au[1] === 'audio/wav' && au[2] === 100, au);
      await p.click('#clUndo'); await sleep(300); await p.click('#clUndo'); await sleep(1500);
      const ap = await p.evaluate(async () => { const r = await api('calls_list'); return r.calls[0].status; });
      ok('Undo (tap twice) → the call is Undone', ap === 'undone', ap);
    }
    await p.evaluate(() => closeSheet()); await sleep(500); await p.evaluate(() => renderCalls()); await sleep(1000);
    await p.click('#p-messages [data-call]:nth-child(2)'); await sleep(1200);
    const s2 = await p.evaluate(() => ({ t: (document.querySelector('.sheet') || document.body).innerText, book: !!document.querySelector('#clBook'), done: !!document.querySelector('#clDone') }));
    ok(name + ': Needs review – reason + Book + Done', s2.book && s2.done && /No OK from the salon heard/.test(s2.t), s2.t.slice(0, 300));
    await p.screenshot({ path: `${OUT}/${name}-3-review.png` });
    if (name === '13') {
      await p.click('#clBook'); await sleep(1800);
      const bk = await p.evaluate(() => (document.querySelector('.sheet') || document.body).innerText.replace(/\s+/g, ' '));
      ok('Book from the call → the Book form opens on that day + time (3:00 PM), the customer kept for the next step', /3:00 PM/.test(bk), bk);
      await p.screenshot({ path: `${OUT}/13-4-book-filled.png` }); await p.evaluate(() => closeSheet()); await sleep(600);
      await p.evaluate(async () => { const r = await api('calls_list'); const c = r.calls.find(x => x.status === 'callback'); openFromUrl('?call=' + c.id); }); await sleep(1800);
      const nt = await p.evaluate(() => ({ tab: S.tab, view: M.view, t: (document.querySelector('.sheet') || document.body).innerText.slice(0, 120) }));
      ok('Notification tapped (?call=3) → Messages → Calls → that call opens', nt.tab === 'messages' && nt.view === 'calls' && /Voicemail/.test(nt.t), nt);
      await p.evaluate(() => closeSheet()); await sleep(400);
    }
    await p.evaluate(() => { closeSheet(); setTab('settings'); S.home = 'settings'; S.setSec = null; renderSettings(); }); await sleep(1500);
    const grp = await p.evaluate(() => { const r = SET_GROUPS.find(g => g[1].includes('review')); return r[1].join(','); });
    ok(name + ': Settings "Texts & alerts": Calls added at the END, nothing else moved', grp === 'sms,asend,smstpl,notify,promo,winback,birthday,review,calls', grp);
    await p.evaluate(() => { S.setSec = 'calls'; renderSettings(); }); await sleep(1800);
    const st = await p.evaluate(() => document.querySelector('#setBody').innerText);
    ok(name + ': Settings → Calls page (on, iPhone, record + notice, voicemail, 30 days, Setup)', /Call assistant on/.test(st) && /This call may be recorded\./.test(st) && /30 days/.test(st), st.slice(0, 300));
    await p.screenshot({ path: `${OUT}/${name}-5-settings.png`, fullPage: true });
    await ctx.close();
  }
  ok('No page errors', pe.length === 0, pe);
});
