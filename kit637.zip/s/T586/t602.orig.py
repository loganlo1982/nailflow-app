# LAMWEB test 586 – the whole call flow on a local copy (fake SignalWire / STT / Claude; test numbers 555-01xx only). python3 t586.py <app tree>
import subprocess, json, os, sys, time, hmac, hashlib, base64, urllib.request, urllib.parse, shutil
A = sys.argv[1]; D = '/tmp/claude-0/T586'; PORT = 19861; DB = D + '/db.sqlite'; KEY = 'PSK_test_signing_key_0123456789'
R = []; out = open(D + '/test-602.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', D + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
for f in os.listdir(D + '/calls') if os.path.isdir(D + '/calls') else []: pass
shutil.rmtree(D + '/calls', ignore_errors=True); os.makedirs(D + '/calls'); open(D + '/fake.log', 'w').close()
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
OAI = True
if OAI: json.dump({}, open(D + '/shared/color-ai.json', 'w'))
else: json.dump({'key': 'sk-ant-test-000000000000000000000000'}, open(D + '/shared/color-ai.json', 'w'))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SHARED_DIR': D + '/shared', 'NF_CALLS_DIR': D + '/calls'}
seed = json.loads(sh('php', D + '/seed.php', A, DB, str(PORT)).stdout); S, T, d1 = seed['S'], seed['T'], seed['d1']
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
def ai(**k): b = {'intent': 'book', 'customer_name': '', 'customer_phone': '', 'service_ids': [], 'service_text': '', 'tech_id': 0, 'tech_text': '', 'date': d1, 'time': '', 'people': 1, 'salon_side': 'person', 'salon_agreed': False, 'salon_quote': '', 'confidence': 0.95, 'missing': [], 'summary': ''}; b.update(k); return b
scen = {'stt': {
  '3': {'c': '#S1 Hi this is Mia, can I get a gel manicure tomorrow at 2?', 's': 'Sure, tomorrow at 2 is open. OK, see you at 2!'},
  '4': {'c': '#S2 This is Linh, pedicure with Tammy tomorrow at 3 please', 's': 'Let me check the book for you.'},
  '5': {'c': '#S3 How much is a full set?', 's': 'Full set is fifty dollars.'},
  '6': {'c': '#S4 Hi this is Anna, I want a full set tomorrow at 11 with Hana. Thanks!'},
  '7': {'c': '#S5 Bella here, gel manicure tomorrow at 4 with Sisi please, call me back'},
  '8': {'c': '#S6 Hi I want a pedicure tomorrow, Cara', 's': 'ok'},
  '9': {'c': '#S7 Hi Dana, gel manicure tomorrow at noon?', 's': 'Yes ok, noon tomorrow.'},
  '10': {'c': '#S8 chị muốn làm bột thứ bảy 2 giờ, tên Hoa', 's': 'Dạ ok chị, 2 giờ nha.'}},
 'ai': {
  '1': ai(customer_name='Mia', service_ids=[GM], time='14:00', salon_agreed=True, salon_quote='OK, see you at 2', summary='Mia wants a gel manicure tomorrow at 2 PM.'),
  '2': ai(customer_name='Linh', service_ids=[PD], tech_id=T['TAMMY'], tech_text='Tammy', time='15:00', salon_agreed=True, salon_quote='ok sure 3pm', summary='Linh wants a pedicure with Tammy tomorrow 3 PM.'),
  '3': ai(intent='info', summary='Asked the price of a full set.'),
  '4': ai(customer_name='Anna', service_ids=[FS], tech_id=T['HANA'], tech_text='Hana', time='11:00', summary='Voicemail: Anna, full set tomorrow 11 AM with Hana.'),
  '5': ai(customer_name='Bella', service_ids=[GM], tech_id=T['SISI'], tech_text='Sisi', time='16:00', summary='Voicemail: Bella, gel manicure tomorrow 4 PM with Sisi.'),
  '6': ai(customer_name='Cara', service_ids=[PD], time='', salon_agreed=True, salon_quote='ok', confidence=0.9, missing=['time'], summary='Cara wants a pedicure tomorrow, no time.'),
  '7': ai(customer_name='Dana', service_ids=[GM], time='12:00', salon_agreed=True, salon_quote='Yes ok, noon tomorrow', summary='Dana, gel manicure tomorrow at noon.'),
  '8': ai(customer_name='Hoa', service_ids=[FS], time='14:00', date=d1, salon_agreed=True, salon_quote='Dạ ok chị, 2 giờ nha', confidence=0.9, summary='Hoa wants a full set at 2 PM.')}}
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
fk = subprocess.Popen(['python3', D + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.3)
B = 'http://127.0.0.1:%d' % PORT
def post(a, p, sign=True, key=KEY, url=None):
    u = url or (B + '/call_in.php?' + a); body = urllib.parse.urlencode(p).encode(); h = {'Content-Type': 'application/x-www-form-urlencoded'}
    if sign: h['X-SignalWire-Signature'] = base64.b64encode(hmac.new(key.encode(), (u + ''.join(k + p[k] for k in sorted(p))).encode(), hashlib.sha1).digest()).decode()
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, data=body, headers=h), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
ACC = '11111111-2222-3333-4444-555555555555'
def call(n, frm, sec, stereo=True, vm=False):
    sid = 'CA%04d' % n; rs = 'RE%04d' % n; subprocess.run(['python3', D + '/mkwav.py', rs, str(sec), '1' if stereo else '0'])
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if vm: post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    c2, x2 = post('a=rec' + ('&vm=1' if vm else ''), {'AccountSid': ACC, 'CallSid': sid, 'RecordingSid': rs, 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/%s' % (ACC, rs), 'RecordingStatus': 'completed', 'RecordingDuration': str(sec), 'RecordingChannels': '2' if stereo else '1'})
    for k in range(80):
        row = sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
        if row and row[0]['status'] not in ('queued', 'work', 'ring') or (row and row[0]['status'] == 'queued' and row[0]['tries'] >= 1): break
        time.sleep(0.25)
    return (c, x, c2, x2), row
def appt(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, customer_name, status, source, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def push(): return sql("SELECT target, kind, title, body FROM push_log ORDER BY id DESC LIMIT 1") if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []



open(D + '/set590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'salon_name' => 'American Nails', 'as_kinds' => json_encode(['confirm' => true, 'change' => true, 'cancel' => true])] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set590.php')
open(D + '/undo.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];\n$a = $argv[1];\nif ($a === 'tick') { cl_tick(); echo 'ticked'; }\n" % (A, A, A, A))
d2 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 2 * 86400)); d3 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 3 * 86400))
open(D + '/mk592.php', 'w').write("<?php require '%s/inc/core.php'; settings(); [$_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = [];\nupsert_customer($ph, $name);\nfor ($i = 0; $i < (int)$n; $i++) { q(\"INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)\", [$date, (int)$start, 45, (int)$staff + $i * ((int)$staff ? 1 : 0), '%d', $i ? $name . ' +' . $i : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); }\necho implode(',', $ids);" % (A, S['Pedicure']))
def mk(ph, name, date, start, staff=0, n=1): return [int(x) for x in sh('php', D + '/mk592.php', ph, name, date, str(start), str(staff), str(n)).stdout.split(',')]
def ap(i): return sql("SELECT id, appt_date, start_min, staff_id, status FROM appointments WHERE id = %d" % i)[0]
def ob(i, k): return sql("SELECT kind, ref, status FROM outbox WHERE appt_id = %d AND kind = '%s'" % (i, k))
def lastpush(): return sql("SELECT title, body FROM push_log WHERE target = 'admin' ORDER BY id DESC LIMIT 1")
def go(n, ph, j, tc, ts=None, vm=True):
    scen['stt'][str(n)] = {'c': '#S%d ' % (100 + n) + tc} if ts is None else {'c': '#S%d ' % (100 + n) + tc, 's': ts}
    scen['ai'][str(100 + n)] = j; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
    r, row = call(n, ph, n, stereo=not vm, vm=vm); time.sleep(0.8); return mrow('CA%04d' % n)[0]
def mrow(sid): return sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
say('== LAMWEB test 2.99.602 – LENH 602 manicure pedicure type asked by text ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire / STT / AI · texts only into the SMS Server queue')
open(D + '/h594.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; cl_table(); $a = $argv[1];\n"
 "if ($a === 'set') { set_setting($argv[2], $argv[3]); echo 'ok'; }\n"
 "if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }\n"
 "if ($a === 'list') echo json_encode(['l' => cl_list(10), 'n' => cl_badge()]);\n"
 "if ($a === 'poke') { cl_cron_poke(); echo 'poked'; }\n" % (A, A))
def h(*a): r = sh('php', D + '/h594.php', *a); return r.stdout
def P(name='', sids=None, text='', tid=0, tt=''): return {'name': name, 'service_ids': sids or [], 'service_text': text, 'tech_id': tid, 'tech_text': tt}
def grp(ph): return sql("SELECT id, appt_date, start_min, duration, staff_id, service_ids, customer_name, status, source, group_id, note FROM appointments WHERE phone = '%s' AND status <> 'cancelled' ORDER BY id" % ph)
def conf(ph):
    for k in range(12):
        r = sql("SELECT id, kind, ref FROM outbox WHERE phone = '%s' AND kind = 'confirm'" % ph)
        if r: return r
        time.sleep(0.25)
    return r
d2 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 2 * 86400))
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
import atexit; atexit.register(lambda: (sv.terminate(), fk.terminate()))
open(D + '/h602.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; cl_table(); $a = $argv[1];\n"
 "if ($a === 'svc') { $i = 0; foreach (json_decode($argv[2], true) as $s) { q('INSERT INTO services (name, duration, price, sort, active) VALUES (?, ?, ?, ?, 1)', [$s[0], $s[1], $s[2], 10 + $i++]); } echo json_encode(array_column(q('SELECT id, name FROM services WHERE active = 1')->fetchAll(), 'id', 'name')); }\n"
 "if ($a === 'off') { q('UPDATE services SET active = 0 WHERE name = ?', [$argv[2]]); echo '{}'; }\n"
 "if ($a === 'on') { q('UPDATE services SET active = 1 WHERE name = ?', [$argv[2]]); echo '{}'; }\n"
 "if ($a === 'in') { require_once '%s/inc/android.php'; $GLOBALS['actor'] = ['system', 'Android']; echo json_encode(ad_incoming($argv[2], $argv[3])); }\n"
 "if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }\n"
 "if ($a === 'kinds') { require_once '%s/inc/calls-ask.php'; echo json_encode(cla_kinds()); }\n" % (A, A, A, A))
def h(*a):
    r = sh('php', D + '/h602.php', *a)
    try: return json.loads(r.stdout or '{}')
    except Exception: print('RAW', a, r.stdout[:400], r.stderr[:400]); raise
SV = h('svc', json.dumps([['Dip Powder', 45, 40], ['Regular Manicure', 30, 20], ['Gel Pedicure', 50, 45], ['Builder Gel', 75, 60], ['Fill', 45, 35], ['Polish Change', 0, 10]]))
DIP, RMA, GPE, FS2 = SV['Dip Powder'], SV['Regular Manicure'], SV['Gel Pedicure'], SV['Full Set']
K = h('kinds'); ok('K this salon\'s menu → dip = Dip Powder · gel = Gel Manicure (not Builder Gel) · acrylic = Full Set (not Fill) · regular pedicure = Pedicure · gel pedicure = Gel Pedicure', K['dip'] == DIP and K['gel'] == GM and K['acr'] == FS and K['preg'] == PD and K['pgel'] == GPE and K['mreg'] == RMA and K['pdip'] == 0, K)
def asks(ph): return sql("SELECT src, body, state FROM autosend WHERE phone = '%s' AND src LIKE 'ui:callask:%%' ORDER BY id" % ph)
def confs(ph): return sql("SELECT src, kind, state FROM autosend WHERE phone = '%s' AND kind = 'confirm' AND src NOT LIKE 'ui:call%%'" % ph) + sql("SELECT ref FROM outbox WHERE phone = '%s' AND kind = 'confirm'" % ph)
def one(ph): x = sql("SELECT id, service_ids, staff_id, note, duration, status, start_min FROM appointments WHERE phone = '%s' AND status = 'booked' ORDER BY id" % ph); return x
# 0. BỔ SUNG 21:55 (priority #1): "2 people, 2 pedicures + 1 manicure" was booked as 3 people
d2 = time.strftime('%Y-%m-%d', time.localtime(time.time() + 2 * 86400))
def rows(ph): return sql("SELECT id, service_ids, duration, customer_name, group_id FROM appointments WHERE phone = '%s' AND status = 'booked' ORDER BY id" % ph)
r = go(51, '+15555550151', ai(customer_name='Test', people=2, party=[P('', [PD]), P('', [PD]), P('', [RMA])], date=d2, time='12:00', summary='two people, two pedicures and one manicure'), 'on Monday at 12 p.m. for two people, for two pedicures and one manicure')
g = rows('+15555550151')
ok('0a LN call #3 replayed: people 2 but party = 3 entries (one per service) → 2 appointments: [Pedicure + Regular Manicure] (45 + 30 = 75 min, pedicure first) + [Pedicure]', r['status'] == 'booked' and len(g) == 2 and g[0]['service_ids'] == '%d,%d' % (PD, RMA) and g[0]['duration'] == 75 and g[1]['service_ids'] == str(PD) and g[1]['duration'] == 45 and r['result'].endswith('· 2 people'), (r['status'], r['reason'], r['result'], g))
r = go(52, '+15555550152', ai(customer_name='Tri', people=3, party=[P('', [PD]), P('', [PD]), P('', [PD])], date=d2, time='18:00', summary='3 pedis'), 'three people, three pedicures')
ok('0b "3 people, 3 pedicures" → 3 × Pedicure (unchanged)', r['status'] == 'booked' and [x['service_ids'] for x in rows('+15555550152')] == [str(PD)] * 3, (r['status'], r['reason'], rows('+15555550152')))
r = go(53, '+15555550153', ai(customer_name='Uno', service_ids=[PD, RMA], date=d2, time='14:00', summary='pedi and mani'), 'one person, pedicure and manicure')
g = rows('+15555550153'); ok('0c "1 person pedi and mani" → 1 appointment Pedicure + Regular Manicure, 75 min', r['status'] == 'booked' and len(g) == 1 and sorted(g[0]['service_ids'].split(',')) == sorted([str(PD), str(RMA)]) and g[0]['duration'] == 75, (r['status'], r['reason'], g))
r = go(54, '+15555550154', ai(customer_name='Vee', people=2, service_ids=[PD], same_services=True, date=d2, time='15:00', summary='two pedicures'), 'two pedicures please')
ok('0d "two pedicures" (no people word, AI says 2) → 2 people, each Pedicure', r['status'] == 'booked' and [x['service_ids'] for x in rows('+15555550154')] == [str(PD)] * 2, (r['status'], r['reason'], rows('+15555550154')))
r = go(55, '+15555550155', ai(customer_name='Wen', people=2, party=[P('', [PD], tid=T['TAMMY'], tt='Tammy'), P('', [PD]), P('', [RMA])], date=d2, time='16:00', summary='x'), 'two people two pedis one mani with Tammy')
ok('0e 3 entries for 2 people + a tech named → not sure → NOT booked, Call back "techs per person not clear"', r['status'] == 'callback' and not rows('+15555550155') and 'techs per person not clear' in r['reason'].lower(), (r['status'], r['reason']))
# 1. dip / gel real / gel fake → that service, no question
r = go(61, '+15555550161', ai(customer_name='Ana', service_ids=[RMA], service_text='dip manicure', mani_type='dip', time='10:00', summary='Ana dip'), 'Hi this is Ana, dip manicure tomorrow at 10')
ok('1 "dip manicure" → BOOKED Dip Powder, no question text', r['status'] == 'booked' and one('+15555550161')[0]['service_ids'] == str(DIP) and not asks('+15555550161'), (r['status'], r['reason'], one('+15555550161')))
r = go(62, '+15555550162', ai(customer_name='Bea', service_ids=[GM], service_text='gel manicure', mani_type='gel_real', time='10:30', summary='Bea gel real'), 'Bea, gel manicure on my real nails tomorrow 10:30')
ok('1 "gel on my real nails" → Gel Manicure, no question', r['status'] == 'booked' and one('+15555550162')[0]['service_ids'] == str(GM) and not asks('+15555550162'), (r['status'], r['reason']))
r = go(63, '+15555550163', ai(customer_name='Cleo', service_ids=[GM], service_text='shellac', mani_type='gel_fake', time='11:00', summary='Cleo shellac fake'), 'Cleo, shellac on fake nails tomorrow at 11')
ok('1 "shellac on fake nails" → Full Set (acrylic), no question', r['status'] == 'booked' and one('+15555550163')[0]['service_ids'] == str(FS) and not asks('+15555550163'), (r['status'], r['reason'], one('+15555550163')))
# 2. "manicure" → booked + asked → "2" → Gel Manicure
r = go(64, '+15555550164', ai(customer_name='Dora', service_ids=[], service_text='manicure', mani_type='plain', time='12:00', summary='Dora manicure'), 'Dora, a manicure tomorrow at noon')
a = one('+15555550164'); q = asks('+15555550164')
ok('2 just "manicure" → BOOKED at once (Regular Manicure kept as the nearest) + note "⏳ Chờ khách chọn loại mani"', r['status'] == 'booked' and a and a[0]['service_ids'] == str(RMA) and a[0]['note'].startswith('⏳ Chờ khách chọn loại mani'), (r['status'], r['reason'], a))
ok('2 ONE text, sent now: "American Nails: For your manicure on <day> 12:00 PM, which one? Reply 1 = Dip, 2 = Gel on your real nails, 3 = Gel on fake nails (acrylic). See all services: <link>"', len(q) == 1 and q[0]['state'] == 'taken' and q[0]['body'].startswith('American Nails: For your manicure on ') and '12:00 PM, which one? Reply 1 = Dip, 2 = Gel on your real nails, 3 = Gel on fake nails (acrylic). See all services: http' in q[0]['body'] and '❌' not in q[0]['body'], q)
say('   text: ' + (q[0]['body'] if q else '-'))
ok('2 the usual YOU\'RE BOOKED held (the question says the day / time – 1 text)', not confs('+15555550164'), confs('+15555550164'))
ok('2 Calls list "… · ⏳ asked: manicure type"', r['result'].endswith('⏳ asked: manicure type'), r['result'])
x = h('in', '+15555550164', '2'); a = one('+15555550164')
ok('2 reply "2" → Gel Manicure on the appointment, same time, note cleaned', x.get('kind') == 'call-choice' and a[0]['service_ids'] == str(GM) and a[0]['start_min'] == 720 and not a[0]['note'].startswith('⏳'), (x, a))
c2 = sql("SELECT body FROM autosend WHERE phone = '+15555550164' AND src LIKE 'ui:callpick:%'")
ok('2 … + short confirmation "American Nails: Got it! Gel Manicure – <day> 12:00 PM. See you!"', len(c2) == 1 and c2[0]['body'].replace(' - ', ' – ').startswith('American Nails: Got it! Gel Manicure – ') and '12:00 PM. See you!' in c2[0]['body'], c2)
ok('2 the reply is kept in Messages (read)', sql("SELECT id FROM messages WHERE phone = '+15555550164' AND dir = 'in' AND body = '2'"), '')
cr = sql("SELECT result FROM calls WHERE call_sid = 'CA0064'"); ok('2 Calls list "… · ✓ customer picked Gel Manicure"', cr and cr[0]['result'].endswith('✓ customer picked Gel Manicure'), cr)
x = h('in', '+15555550164', '1'); ok('2 a 2nd "1" later → NOT taken again (Messages as a normal text)', x.get('kind') != 'call-choice' and one('+15555550164')[0]['service_ids'] == str(GM), x)
# 3. pedicure → asked → "1" → Regular
r = go(65, '+15555550165', ai(customer_name='Eva', service_ids=[PD], service_text='pedicure', pedi_type='plain', time='13:00', summary='Eva pedicure'), 'Eva, pedicure tomorrow at 1')
q = asks('+15555550165')
ok('3 just "pedicure" → booked (Pedicure) + "For your pedicure on … which one? Reply 1 = Regular polish, 2 = Gel/Shellac. See all services: …"', r['status'] == 'booked' and len(q) == 1 and 'For your pedicure on ' in q[0]['body'] and 'Reply 1 = Regular polish, 2 = Gel/Shellac. See all services: ' in q[0]['body'], (r['status'], r['reason'], q))
x = h('in', '+15555550165', '2'); ok('3 reply "2" → Gel Pedicure (50 min)', one('+15555550165')[0]['service_ids'] == str(GPE) and one('+15555550165')[0]['duration'] == 50, (x, one('+15555550165')))
# 4. manicure + pedicure in one appointment → 1 text, 2 questions, "2 1"
r = go(66, '+15555550166', ai(customer_name='Faye', service_ids=[PD], service_text='mani pedi', mani_type='plain', pedi_type='plain', time='14:00', summary='Faye mani pedi'), 'Faye, mani and pedi tomorrow at 2')
q = asks('+15555550166'); a = one('+15555550166')
ok('4 mani + pedi → 1 appointment (Pedicure + Regular Manicure) + ONE text with 2 questions "Reply both numbers (e.g. "2 1")"', r['status'] == 'booked' and len(q) == 1 and 'Manicure: 1 = Dip, 2 = Gel on your real nails, 3 = Gel on fake nails (acrylic). Pedicure: 1 = Regular polish, 2 = Gel/Shellac. Reply both numbers' in q[0]['body'] and sorted(a[0]['service_ids'].split(',')) == sorted([str(PD), str(RMA)]) and a[0]['note'].startswith('⏳ Chờ khách chọn loại mani + pedi'), (r['status'], r['reason'], q, a))
x = h('in', '+15555550166', '2'); ok('4 only ONE number for 2 questions → not taken (Messages), still waiting', x.get('kind') != 'call-choice' and one('+15555550166')[0]['note'].startswith('⏳'), x)
x = h('in', '+15555550166', '3, 2'); a = one('+15555550166')
ok('4 reply "3, 2" → Full Set + Gel Pedicure', x.get('kind') == 'call-choice' and sorted(a[0]['service_ids'].split(',')) == sorted([str(FS), str(GPE)]), (x, a))
# 5. group of 2 "both pedicure" → 1 question, reply → both
r = go(67, '+15555550167', ai(customer_name='Gia', people=2, service_ids=[PD], same_services=True, pedi_type='plain', time='15:00', summary='2 pedis'), 'Gia, me and my daughter both want a pedicure tomorrow at 3')
g = one('+15555550167'); q = asks('+15555550167')
ok('5 group of 2 "both pedicure" → 2 rows booked, ONE question', r['status'] == 'booked' and len(g) == 2 and len(q) == 1 and all(x['note'].startswith('⏳') for x in g), (r['status'], r['reason'], g, q))
x = h('in', '+15555550167', '2'); g = one('+15555550167')
ok('5 reply "2" → BOTH people Gel Pedicure + 1 confirmation "(2 people)"', all(x2['service_ids'] == str(GPE) for x2 in g) and sql("SELECT body FROM autosend WHERE phone = '+15555550167' AND src LIKE 'ui:callpick:%'")[0]['body'].split('\n')[0].endswith('(2 people). See you!'), (x, g))
# 6. no answer → kept + label · odd answers → Messages
r = go(68, '+15555550168', ai(customer_name='Hana', service_ids=[], service_text='manicure', mani_type='plain', time='16:00', summary='Hana manicure'), 'Hana, manicure tomorrow 4')
x = h('in', '+15555550168', 'Yes thank you'); y = h('in', '+15555550168', '7')
ok('6 "Yes thank you" / "7" (no such choice) → Messages as before, nothing changed, still "⏳ waiting"', x.get('kind') == 'reply' and y.get('kind') == 'reply' and one('+15555550168')[0]['service_ids'] == str(RMA) and one('+15555550168')[0]['note'].startswith('⏳'), (x, y))
ok('6 no answer → the appointment stays booked (never cancelled)', one('+15555550168')[0]['status'] == 'booked', '')
x = h('in', '+15555550150', '2'); ok('6 "2" from a number with NO question (ROSA TEST) → a normal text (Messages) as before', x.get('kind') == 'reply', x)
# 7. the menu has no Dip → that choice left out; the tech who cannot do it → Any tech
h('off', 'Dip Powder')
sql("UPDATE staff SET skills = '%d' WHERE id = %d" % (RMA, T['TAMMY']))
r = go(69, '+15555550169', ai(customer_name='Ivy', service_ids=[], service_text='manicure', mani_type='plain', tech_id=T['TAMMY'], tech_text='Tammy', time='17:00', summary='Ivy manicure Tammy'), 'Ivy, manicure with Tammy tomorrow 5')
q = asks('+15555550169')
ok('7 no Dip on the menu → "Reply 1 = Gel on your real nails, 2 = Gel on fake nails (acrylic)" (renumbered)', r['status'] == 'booked' and q and 'Reply 1 = Gel on your real nails, 2 = Gel on fake nails (acrylic).' in q[0]['body'], (r['status'], r['reason'], q))
x = h('in', '+15555550169', '1'); a = one('+15555550169')
ok('7 reply "1" → Gel Manicure; TAMMY does only Regular Manicure → Any tech (as the booking rules)', a[0]['service_ids'] == str(GM) and a[0]['staff_id'] == 0, (x, a))
sql("UPDATE staff SET skills = '' WHERE id = %d" % T['TAMMY']); h('on', 'Dip Powder')
# 8. a specific service said / old flow
r = go(70, '+15555550170', ai(customer_name='Jo', service_ids=[GM], service_text='gel manicure', mani_type='specific', time='18:00', summary='Jo gel manicure'), 'Jo, the gel manicure tomorrow 6')
ok('8 an exact menu service ("specific") → booked as said, no question, YOU\'RE BOOKED as before', r['status'] == 'booked' and not asks('+15555550170') and one('+15555550170')[0]['service_ids'] == str(GM), (r['status'], r['reason']))
r = go(71, '+15555550171', ai(customer_name='Kay', service_ids=[FS], time='19:00', summary='Kay full set'), 'Kay full set tomorrow 7')
ok('8 old AI answer without mani_type / pedi_type → exactly as before (booked, no question)', r['status'] == 'booked' and not asks('+15555550171'), (r['status'], r['reason']))
# 9. Spanish customer
sql("UPDATE customers SET lang = 'es' WHERE phone = '+15555550172'") if sql("SELECT id FROM customers WHERE phone = '+15555550172'") else None
sh('php', '-r', "require '%s/inc/core.php'; settings(); upsert_customer('+15555550172', 'LUZ'); q(\"UPDATE customers SET lang = 'es' WHERE phone = '+15555550172'\");" % A)
r = go(72, '+15555550172', ai(customer_name='Luz', service_ids=[PD], pedi_type='plain', time='20:00', summary='Luz pedicure'), 'Luz, pedicura mañana a las 8')
q = asks('+15555550172'); ok('9 a Spanish customer → "Para su pedicura el …, ¿cuál? Responda 1 = Esmalte regular, 2 = Gel/Shellac. Ver todos los servicios: …"', q and 'Para su pedicura el ' in q[0]['body'] and 'Responda 1 = Esmalte regular, 2 = Gel/Shellac. Ver todos los servicios: ' in q[0]['body'], q)
# 10. voicemail words
st, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CA0990', 'From': '+15555550190', 'To': '+15156061616', 'CallStatus': 'ringing'})
st2, x2 = post('a=done', {'AccountSid': ACC, 'CallSid': 'CA0990', 'DialCallStatus': 'no-answer'})
ok('10 voicemail: "…after the beep. For a manicure or pedicure, please say Dip, or Gel on your real nails, or Gel on fake nails. Thank you!"', 'after the beep. For a manicure or pedicure, please say Dip, or Gel on your real nails, or Gel on fake nails. Thank you!' in x2.replace('&#039;', "'").replace('&apos;', "'"), x2[:400])
# ---- 602 Cách A: the questions on the phone (no answer) ----
h('set', json.dumps({'call_ivr': ''}))
import re as _re
def ivr(n, frm, answers, j=None, hang_after=None):
    sid = 'CI%04d' % n
    if j is not None: scen['ai'][str(400 + n)] = j; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
    post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    c, x = post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'}); said = []; steps = [x]
    for k, ans in enumerate(answers):
        m = _re.search(r'<Gather[^>]*action="([^"]+)"', x); said.append(_re.findall(r'<Say[^>]*>([^<]*)</Say>', x))
        if not m or (hang_after is not None and k >= hang_after): break
        c, x = post(None, {'AccountSid': ACC, 'CallSid': sid, 'SpeechResult': ans}, url=m.group(1).replace('&amp;', '&')); steps.append(x)
    time.sleep(1.2)
    return sid, steps, said
def says(xml): return ' | '.join(_re.findall(r'<Say[^>]*>([^<]*)</Say>', xml)).replace('&apos;', "'").replace('&#039;', "'")
sid, st, sd = ivr(1, '+15555550181', ['Mia #S401', 'a manicure', 'gel', 'my real nails', 'Saturday at 2 pm'],
    ai(customer_name='Mia', service_ids=[GM], mani_type='gel_real', date=d1, time='14:00', summary='Mia gel real'))
ok('I1 no answer → "Sorry, we can\'t take your call right now. I\'ll take your appointment. May I have your name, please?" (speech Gather, hints, 5 s)', "I'll take your appointment. May I have your name, please?" in says(st[0]) and 'input="speech"' in st[0] and 'hints="manicure' in st[0] and 'timeout="5"' in st[0] and '<Record' not in st[0], st[0][:400])
ok('I1 then "What service would you like?" → "manicure" → "Would you like Dip, or Gel Shellac?" → "gel" → "On your real nails, or on fake nails?" → "What day and time would you like?" → "Thank you! We\'ll text you to confirm." + hang up',
   [says(x) for x in st[1:]] == ['What service would you like?', 'Would you like Dip, or Gel Shellac?', 'On your real nails, or on fake nails?', 'What day and time would you like?', "Thank you! We'll text you to confirm."] and '<Hangup/>' in st[-1], [says(x) for x in st])
r = mrow(sid)[0]
ok('I1 the AI reads the answers: "My name is Mia #S401. I would like a manicure. Dip or gel: gel. Real or fake nails: my real nails. Day and time: Saturday at 2 pm. Manicure: Gel on my real nails." → BOOKED (voicemail rules: no salon OK needed)', r['status'] == 'booked' and 'Manicure: Gel on my real nails.' in r['text_c'] and 'Day and time: Saturday at 2 pm.' in r['text_c'] and r['kind'] == 'vm', (r['status'], r['reason'], r['text_c']))
ok('I1 Gel Manicure booked, no question text (already said)', one('+15555550181') and one('+15555550181')[0]['service_ids'] == str(GM) and not asks('+15555550181'), one('+15555550181'))
sid, st, sd = ivr(2, '+15555550182', ['Nia #S402', 'dip pedicure and gel manicure on real nails', 'regular', 'tomorrow at 4'], ai(customer_name='Nia', service_ids=[PD, GM], mani_type='gel_real', pedi_type='regular', time='16:00', summary='x'))
ok('I2 "dip pedicure and gel manicure on real nails" → NO manicure question · pedicure asked "Regular polish, or Gel Shellac?" → time → end', [says(x) for x in st[1:]] == ['What service would you like?', 'Regular polish, or Gel Shellac?', 'What day and time would you like?', "Thank you! We'll text you to confirm."], [says(x) for x in st])
sid, st, sd = ivr(3, '+15555550183', ['', ''])
ok('I3 silence → "Sorry, could you say that again? May I have your name, please?" → silence again → the old free voicemail (Record) with "…say Dip, or Gel on your real nails, or Gel on fake nails."', says(st[1]).startswith('Sorry, could you say that again? May I have your name') and '<Record maxLength="120"' in st[2] and 'please say Dip, or Gel on your real nails, or Gel on fake nails.' in says(st[2]), [says(x) for x in st])
sid, st, sd = ivr(4, '+15555550184', ['Ola', 'I need to cancel my appointment'])
ok('I4 "cancel my appointment" → the old free voicemail ("Okay. Please tell me about your appointment after the beep." + Record) – the AI cancels it as in 592', '<Record maxLength="120"' in st[2] and 'Please tell me about your appointment after the beep.' in says(st[2]), [says(x) for x in st])
r = mrow(sid)[0]; ok('I4 … the answers so far are kept for the AI (added to the recording)', '"rec":1' in r['ai_json'] and 'I need to cancel' in r['ai_json'], r['ai_json'][:200])
sid, st, sd = ivr(5, '+15555550185', ['Opal #S405', 'a manicure tomorrow at 9:30', 'x'], ai(customer_name='Opal', service_ids=[], service_text='manicure', mani_type='plain', time='09:30', summary='Opal manicure'), hang_after=2)
r = mrow(sid)[0]; ok('I5 hangs up at "Dip, or Gel Shellac?" → nothing read yet (waits ~2.5 min for the cron)', r['status'] == 'queued' and r['next_at'] > time.strftime('%Y-%m-%d %H:%M:%S'), (r['status'], r['next_at']))
sql("UPDATE calls SET next_at = '2020-01-01 00:00:00' WHERE call_sid = '%s'" % sid); sh('php', D + '/undo.php', 'tick'); time.sleep(0.5); r = mrow(sid)[0]
ok('I5 … the cron reads what was said → BOOKED (time kept) + the TEXT question for the manicure type', r['status'] == 'booked' and len(asks('+15555550185')) == 1 and 'For your manicure on ' in asks('+15555550185')[0]['body'], (r['status'], r['reason'], asks('+15555550185')))
sid, st, sd = ivr(6, '+15555550186', ['Pia #S406', 'me and my daughter both want a pedicure', 'gel', 'tomorrow at 5', 'two'], ai(customer_name='Pia', people=2, service_ids=[GPE], same_services=True, pedi_type='gel', time='17:00', summary='2 gel pedis'))
ok('I6 two people → "Regular polish, or Gel Shellac?" → time → "How many people?" → end → 2 rows booked', [says(x) for x in st[1:]] == ['What service would you like?', 'Regular polish, or Gel Shellac?', 'What day and time would you like?', 'How many people?', "Thank you! We'll text you to confirm."] and len(one('+15555550186')) == 2, ([says(x) for x in st], one('+15555550186')))
c, x = post('a=ask&s=name&n=0', {'AccountSid': ACC, 'CallSid': 'CI0001', 'SpeechResult': 'Mia'}, key='PSK_wrong_key_000000000000000')
ok('I7 a question answer with a wrong signature → 403', c == 403, c)
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CI0008', 'From': '+15555550188', 'To': '+15156061616', 'CallStatus': 'ringing'})
c, x = post('a=done', {'AccountSid': ACC, 'CallSid': 'CI0008', 'DialCallStatus': 'completed'})
ok('I8 an answered call → unchanged (hang up after the talk, no questions)', x.strip().endswith('<Response><Hangup/></Response>'), x)
h('set', json.dumps({'call_ivr': '0'}))
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors in the server log', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:5])
say('PASS %d/%d' % (sum(R), len(R)))
