# LAMWEB test 586 – the whole call flow on a local copy (fake SignalWire / STT / Claude; test numbers 555-01xx only). python3 t586.py <app tree>
import subprocess, json, os, sys, time, hmac, hashlib, base64, urllib.request, urllib.parse, shutil
A = sys.argv[1]; D = '/tmp/claude-0/T586'; PORT = 19861; DB = D + '/db.sqlite'; KEY = 'PSK_test_signing_key_0123456789'
R = []; out = open(D + '/test-590.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', D + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
for f in os.listdir(D + '/calls') if os.path.isdir(D + '/calls') else []: pass
shutil.rmtree(D + '/calls', ignore_errors=True); os.makedirs(D + '/calls'); open(D + '/fake.log', 'w').close()
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
OAI = True
if OAI: json.dump({}, open(D + '/shared/color-ai.json', 'w'))
else: json.dump({'key': 'sk-ant-test-000000000000000000000000'}, open(D + '/shared/color-ai.json', 'w'))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SHARED_DIR': D + '/shared', 'NF_CALLS_DIR': D + '/calls'}
seed = json.loads(sh('php', D + '/seed.php', A, DB, str(PORT)).stdout); S, T, d1 = seed['S'], seed['T'], seed['d1']
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
def ai(**k): b = {'intent': 'book', 'customer_name': '', 'customer_phone': '', 'service_ids': [], 'service_text': '', 'tech_id': 0, 'tech_text': '', 'date': d1, 'time': '', 'people': 1, 'salon_side': 'person', 'salon_agreed': False, 'salon_quote': '', 'confidence': 0.95, 'missing': [], 'summary': ''}; b.update(k); return b
scen = {'stt': {
  '3': {'c': '#S1 Hi this is Mia, can I get a gel manicure tomorrow at 2?', 's': 'Sure, tomorrow at 2 is open. OK, see you at 2!'},
  '4': {'c': '#S2 This is Linh, pedicure with Tammy tomorrow at 3 please', 's': 'Let me check the book for you.'},
  '5': {'c': '#S3 How much is a full set?', 's': 'Full set is fifty dollars.'},
  '6': {'c': '#S4 Hi this is Anna, I want a full set tomorrow at 11 with Hana. Thanks!'},
  '7': {'c': '#S5 Bella here, gel manicure tomorrow at 4 with Sisi please, call me back'},
  '8': {'c': '#S6 Hi I want a pedicure tomorrow, Cara', 's': 'ok'},
  '9': {'c': '#S7 Hi Dana, gel manicure tomorrow at noon?', 's': 'Yes ok, noon tomorrow.'},
  '10': {'c': '#S8 chị muốn làm bột thứ bảy 2 giờ, tên Hoa', 's': 'Dạ ok chị, 2 giờ nha.'}},
 'ai': {
  '1': ai(customer_name='Mia', service_ids=[GM], time='14:00', salon_agreed=True, salon_quote='OK, see you at 2', summary='Mia wants a gel manicure tomorrow at 2 PM.'),
  '2': ai(customer_name='Linh', service_ids=[PD], tech_id=T['TAMMY'], tech_text='Tammy', time='15:00', salon_agreed=True, salon_quote='ok sure 3pm', summary='Linh wants a pedicure with Tammy tomorrow 3 PM.'),
  '3': ai(intent='info', summary='Asked the price of a full set.'),
  '4': ai(customer_name='Anna', service_ids=[FS], tech_id=T['HANA'], tech_text='Hana', time='11:00', summary='Voicemail: Anna, full set tomorrow 11 AM with Hana.'),
  '5': ai(customer_name='Bella', service_ids=[GM], tech_id=T['SISI'], tech_text='Sisi', time='16:00', summary='Voicemail: Bella, gel manicure tomorrow 4 PM with Sisi.'),
  '6': ai(customer_name='Cara', service_ids=[PD], time='', salon_agreed=True, salon_quote='ok', confidence=0.9, missing=['time'], summary='Cara wants a pedicure tomorrow, no time.'),
  '7': ai(customer_name='Dana', service_ids=[GM], time='12:00', salon_agreed=True, salon_quote='Yes ok, noon tomorrow', summary='Dana, gel manicure tomorrow at noon.'),
  '8': ai(customer_name='Hoa', service_ids=[FS], time='14:00', date=d1, salon_agreed=True, salon_quote='Dạ ok chị, 2 giờ nha', confidence=0.9, summary='Hoa wants a full set at 2 PM.')}}
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
fk = subprocess.Popen(['python3', D + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.3)
B = 'http://127.0.0.1:%d' % PORT
def post(a, p, sign=True, key=KEY, url=None):
    u = url or (B + '/call_in.php?' + a); body = urllib.parse.urlencode(p).encode(); h = {'Content-Type': 'application/x-www-form-urlencoded'}
    if sign: h['X-SignalWire-Signature'] = base64.b64encode(hmac.new(key.encode(), (u + ''.join(k + p[k] for k in sorted(p))).encode(), hashlib.sha1).digest()).decode()
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, data=body, headers=h), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
ACC = '11111111-2222-3333-4444-555555555555'
def call(n, frm, sec, stereo=True, vm=False):
    sid = 'CA%04d' % n; rs = 'RE%04d' % n; subprocess.run(['python3', D + '/mkwav.py', rs, str(sec), '1' if stereo else '0'])
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if vm: post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    c2, x2 = post('a=rec' + ('&vm=1' if vm else ''), {'AccountSid': ACC, 'CallSid': sid, 'RecordingSid': rs, 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/%s' % (ACC, rs), 'RecordingStatus': 'completed', 'RecordingDuration': str(sec), 'RecordingChannels': '2' if stereo else '1'})
    for k in range(80):
        row = sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
        if row and row[0]['status'] not in ('queued', 'work', 'ring') or (row and row[0]['status'] == 'queued' and row[0]['tries'] >= 1): break
        time.sleep(0.25)
    return (c, x, c2, x2), row
def appt(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, customer_name, status, source, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def push(): return sql("SELECT target, kind, title, body FROM push_log ORDER BY id DESC LIMIT 1") if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []


say('== LAMWEB test 2.99.590 – missed call → text back · ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire / STT / AI · texts go to the SMS Server queue (nothing really sent)')
open(D + '/set590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'salon_name' => 'American Nails'] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
print(sh('php', D + '/set590.php').stdout)
open(D + '/undo.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];\n$a = $argv[1];\nif ($a === 'tick') { cl_tick(); echo 'ticked'; }\n" % (A, A, A, A))
ME = '+15154997409'  # anh Logan's own test phone (499) – local copy only, nothing is really sent
def mrow(sid): return sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
def mtexts(ph): return sql("SELECT kind, src, body, state, via FROM autosend WHERE phone = '%s' AND kind = 'missed' ORDER BY id" % ph)
def tick(): return sh('php', D + '/undo.php', 'tick')
c, x = post('a=done', {'AccountSid': ACC, 'CallSid': 'CAm0', 'DialCallStatus': 'no-answer'})
ok('No answer → the words of LỖI 591 E: "Sorry, we can\'t take your call right now. Please leave your name, your phone number, the service you want, and the day and time you would like, after the beep. Thank you!" + voicemail', "Sorry, we can&apos;t take your call right now. Please leave your name, your phone number, the service you want, and the day and time you would like, after the beep." in x and "Thank you!" in x and '<Record maxLength="120"' in x, x)
# M1: no answer, hung up during the voicemail greeting (recording 'absent') → text now
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAm1', 'From': ME, 'To': '+15156061616'})
post('a=done', {'AccountSid': ACC, 'CallSid': 'CAm1', 'DialCallStatus': 'no-answer'})
r = mrow('CAm1'); ok('M1 after no answer: text back waits for the voicemail (tb wait, ~130 s)', r and r[0]['tb_state'] == 'wait' and r[0]['tb_at'] > r[0]['created_at'], r and (r[0]['tb_state'], r[0]['tb_at']))
post('a=rec&vm=1', {'AccountSid': ACC, 'CallSid': 'CAm1', 'RecordingSid': '', 'RecordingStatus': 'absent'})
t = tick(); r = mrow('CAm1'); tx = mtexts(ME)
ok('M1 no voicemail left → texted back at once: 1 text, via SMS Server', len(tx) == 1 and tx[0]['src'] == 'ui:call:%d' % r[0]['id'] and tx[0]['via'] == 'winsms', (t.stderr[-300:], tx, r and r[0]['tb_state']))
ok('M1 text words: "Hi! Sorry we missed your call at American Nails. Book online: <link> or reply…"', tx and tx[0]['body'].startswith('Hi! Sorry we missed your call at American Nails. Book online: http://127.0.0.1:%d/' % PORT) and "or reply to this text and we'll get back to you." in tx[0]['body'], tx and tx[0]['body'])
ok('M1 Calls list line "Missed · texted back ✓"', r[0]['status'] == 'missed' and r[0]['result'] == 'Missed · texted back ✓' and r[0]['tb_state'] == 'sent', (r[0]['status'], r[0]['result']))
# M2: same number again 5 min later, hangs up while ringing → no 2nd text (30 min)
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAm2', 'From': ME, 'To': '+15156061616'})
post('a=done', {'AccountSid': ACC, 'CallSid': 'CAm2', 'DialCallStatus': 'canceled'}); tick()
ok('M2 same number again within 30 min (hung up while ringing) → NO 2nd text', len(mtexts(ME)) == 1 and mrow('CAm2')[0]['tb_state'] == 'skip', (mtexts(ME), mrow('CAm2')[0]['tb_state']))
# M3: 31 min later, voicemail that BOOKS → YOU'RE BOOKED only, no missed text
sql("UPDATE calls SET tb_at = '2000-01-01 00:00:00' WHERE tb_state = 'sent'")
scen['stt']['12'] = {'c': '#S10 Hi this is Gina, gel manicure tomorrow at 6, thanks'}
scen['ai']['10'] = ai(customer_name='Gina', service_ids=[GM], time='18:00', summary='Voicemail: Gina, gel manicure tomorrow 6 PM.')
scen['stt']['13'] = {'c': '#S11 Hi this is Gina again, please call me back'}
scen['ai']['11'] = ai(customer_name='Gina', intent='book', time='', summary='Voicemail: Gina asks for a call back.')
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CA0012', 'From': ME, 'To': '+15156061616'})
r3, row = call(12, ME, 12, stereo=False, vm=True); tick()
ob = sql("SELECT kind FROM outbox WHERE phone = '%s'" % ME)
ok('M3 voicemail books (Gina 6 PM) → YOU\'RE BOOKED goes, NO missed-call text (1 text per customer)', row and row[0]['status'] == 'booked' and len(mtexts(ME)) == 1 and mrow('CA0012')[0]['tb_state'] == 'skip' and any(o['kind'] == 'confirm' for o in ob), (row and row[0]['status'], mrow('CA0012')[0]['tb_state'], ob))
# M4: voicemail not enough → Call back + texted at once (31 min after the last text)
sql("UPDATE calls SET tb_at = '2000-01-01 00:00:00' WHERE tb_state = 'sent'")
r4, row = call(13, ME, 13, stereo=False, vm=True)
time.sleep(1.5); row = mrow('CA0013')
ok('M4 voicemail without a time → Call back + missed-call text at once', row and row[0]['status'] == 'callback' and row[0]['tb_state'] == 'sent' and len(mtexts(ME)) == 2, (row and (row[0]['status'], row[0]['tb_state'], row[0]['reason']), len(mtexts(ME))))
# M5: the salon's own numbers / not a real mobile number / STOP
for sid, ph, why in [('CAm5', '+15555550199', "salon's own number (owner iPhone)"), ('CAm6', '+15555550152', 'test 555 number = not a real US mobile'), ('CAm7', '+15156061616', 'the SignalWire number')]:
    post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': ph, 'To': '+15156061616'}); post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'canceled'}); tick()
    ok('M5 ' + why + ' → no text', not mtexts(ph) and mrow(sid)[0]['tb_state'] == 'skip', (mtexts(ph), mrow(sid)[0]['tb_state']))
sql("UPDATE calls SET tb_at = '2000-01-01 00:00:00' WHERE tb_state = 'sent'")
open(D + '/stop590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); upsert_customer('%s', 'LOGAN'); q('UPDATE customers SET opted_out = 1 WHERE phone = ?', ['%s']); echo 'ok';" % (A, ME, ME)); print(sh('php', D + '/stop590.php').stdout)
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAm8', 'From': ME, 'To': '+15156061616'}); post('a=done', {'AccountSid': ACC, 'CallSid': 'CAm8', 'DialCallStatus': 'canceled'}); tick()
ok('M6 customer opted out (STOP) → no text', len(mtexts(ME)) == 2 and mrow('CAm8')[0]['tb_state'] == 'skip', (len(mtexts(ME)), mrow('CAm8')[0]['tb_state']))
sh('php', '-r', "require '%s/inc/core.php'; settings(); q('UPDATE customers SET opted_out = 0 WHERE phone = ?', ['%s']);" % (A, ME))
# M7: timer path – no answer, no callback at all
sql("UPDATE calls SET tb_at = '2000-01-01 00:00:00' WHERE tb_state = 'sent'")
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAm9', 'From': ME, 'To': '+15156061616'}); post('a=done', {'AccountSid': ACC, 'CallSid': 'CAm9', 'DialCallStatus': 'no-answer'}); tick()
ok('M7 no recording yet → still waiting (no text before 130 s)', mrow('CAm9')[0]['tb_state'] == 'wait' and len(mtexts(ME)) == 2, mrow('CAm9')[0]['tb_state'])
sql("UPDATE calls SET tb_at = '2000-01-01 00:00:00' WHERE call_sid = 'CAm9'"); tick()
ok('M7 … 130 s passed, nothing came → texted back', mrow('CAm9')[0]['tb_state'] == 'sent' and len(mtexts(ME)) == 3, (mrow('CAm9')[0]['tb_state'], len(mtexts(ME))))
# M8: Text back off
sql("UPDATE calls SET tb_at = '2000-01-01 00:00:00' WHERE tb_state = 'sent'")
sh('php', '-r', "require '%s/inc/core.php'; settings(); set_setting('call_tb_on', '0');" % A)
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAm10', 'From': ME, 'To': '+15156061616'}); post('a=done', {'AccountSid': ACC, 'CallSid': 'CAm10', 'DialCallStatus': 'canceled'}); tick()
ok('M8 Settings "Text back missed calls" OFF → no text', len(mtexts(ME)) == 3 and mrow('CAm10')[0]['tb_state'] == 'off', mrow('CAm10')[0]['tb_state'])
sh('php', '-r', "require '%s/inc/core.php'; settings(); set_setting('call_tb_on', '');" % A)
# M9: the cron sees the waiting text (cl_due)
post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAm11', 'From': '+15154997409', 'To': '+15156061616'}); post('a=done', {'AccountSid': ACC, 'CallSid': 'CAm11', 'DialCallStatus': 'no-answer'})
sql("UPDATE calls SET tb_at = '2000-01-01 00:00:00' WHERE call_sid = 'CAm11'")
open(D + '/due590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; echo cl_due() ? 'due' : 'none';" % (A, A))
ok('M9 cron minute sees a text back that is due (cl_due) → pokes call_in tick', sh('php', D + '/due590.php').stdout == 'due', '')
# ===== LỖI 591 =====
say('== LỖI 591 (A confidence · B "pedicure" · C/F iPhone voicemail · D name) ==')
open(D + '/svc591.php', 'w').write("<?php require '%s/inc/core.php'; settings(); foreach ([['Regular Pedicure', 45, 30], ['Deluxe Pedicure', 60, 45], ['Spa Pedicure', 50, 40]] as $i => $s) q('INSERT INTO services (name, duration, price, sort, active) VALUES (?, ?, ?, ?, 1)', [$s[0], $s[1], $s[2], 10 + $i]); q(\"UPDATE services SET active = 0 WHERE name = 'Pedicure'\"); echo json_encode(q(\"SELECT id, name FROM services WHERE name LIKE '%%Pedicure%%'\")->fetchAll(PDO::FETCH_KEY_PAIR));" % A)
P = json.loads(sh('php', D + '/svc591.php').stdout); RP = int([k for k, v in P.items() if v == 'Regular Pedicure'][0])
# F – the iPhone side is listened to first
c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAf1', 'From': '+15154997409', 'To': '+15156061616'})
ok('F answer: <Number url="…a=screen&p=CAf1"> (the iPhone side is listened to first)', '<Number url="http://127.0.0.1:%d/call_in.php?a=screen&amp;p=CAf1" method="POST">' % PORT in x, x)
c, x = post('a=screen&p=CAf1', {'AccountSid': ACC, 'CallSid': 'CAchild1', 'CallStatus': 'in-progress'})
ok('F screen: <Gather input="speech" timeout 3, speechTimeout 1, actionOnEmptyResult> – nobody presses anything', c == 200 and '<Gather input="speech"' in x and 'actionOnEmptyResult="true"' in x and 'a=screened&amp;p=CAf1' in x, x)
c, x = post('a=screened&p=CAf1', {'AccountSid': ACC, 'CallSid': 'CAchild1', 'SpeechResult': 'Hello?'})
ok('F a person says "Hello?" → <Response/> (connected), call marked person', x.strip().endswith('<Response/>') and mrow('CAf1')[0]['screen'] == 'person', (x, mrow('CAf1')[0]['screen']))
c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CAf2', 'From': '+15154997409', 'To': '+15156061616'})
c, x = post('a=screened&p=CAf2', {'AccountSid': ACC, 'CallSid': 'CAchild2', 'SpeechResult': 'The person you are calling is not available. Please leave a message'})
ok('F iPhone voicemail greeting → <Hangup/> on the iPhone side, call marked vm', '<Hangup/>' in x and mrow('CAf2')[0]['screen'] == 'vm', (x, mrow('CAf2')[0]['screen']))
c, x = post('a=done', {'AccountSid': ACC, 'CallSid': 'CAf2', 'DialCallStatus': 'completed'})
ok('F … the Dial ends ("completed") → OUR voicemail sentence + <Record> (not the iPhone\'s)', '<Record maxLength="120"' in x and 'Please leave your name, your phone number' in x, x)
subprocess.run(['python3', D + '/mkwav.py', 'REf2a', '4', '1'])
c, x = post('a=rec', {'AccountSid': ACC, 'CallSid': 'CAf2', 'RecordingSid': 'REf2a', 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/REf2a' % ACC, 'RecordingStatus': 'completed', 'RecordingDuration': '4'})
ok('F … the Dial\'s own recording (only the greeting) is NOT read as a call', not sql("SELECT id FROM calls WHERE rec_sid = 'REf2a'"), sql("SELECT id, call_sid, status FROM calls WHERE rec_sid = 'REf2a'"))
c, x = post('a=screened&p=CAf3', {'AccountSid': ACC, 'CallSid': 'CAchild3', 'SpeechResult': 'Hi you have reached Tho please leave your name and number and I will call you back thanks'})
ok('F a custom greeting ("you have reached … leave your name") → voicemail', '<Hangup/>' in x, x)
c, x = post('a=screened&p=CAf4', {'AccountSid': ACC, 'CallSid': 'CAchild4', 'SpeechResult': 'American Nails, how can I help you?'})
ok('F "American Nails, how can I help you?" → a person (connected)', x.strip().endswith('<Response/>'), x)
# C – after the call: the salon channel was the iPhone's greeting (the second net) → treated as a voicemail: books without an OK + no salon OK needed
scen['stt']['14'] = {'c': '#S12 Hi this is Mia, I would like a pedicure on Tuesday at 2 with Nancy. Thank you', 's': 'Hi, you have reached Tho. I am not available right now, please leave a message after the tone.'}
scen['ai']['12'] = ai(customer_name='Mia', service_ids=[], service_text='pedicure', time='14:00', salon_side='voicemail', salon_agreed=False, confidence=0.9, summary='Mia wants a pedicure 2 PM.')
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
r, row = call(14, '+15154997409', 14); time.sleep(1); row = mrow('CA0014'); a14 = sql("SELECT start_min, service_ids, status FROM appointments WHERE id = %d" % (row[0]['appt_id'] or 0))
ok('C/#8 answered by the iPhone\'s voicemail (salon side = greeting) → treated as VOICEMAIL, no OK needed → BOOKED', row and row[0]['kind'] == 'vm' and row[0]['status'] == 'booked', row and (row[0]['kind'], row[0]['status'], row[0]['reason']))
ok('B/#7 "pedicure" (no id from the AI) → the REGULAR Pedicure', a14 and a14[0]['service_ids'] == str(RP), (a14, RP))
scen['stt']['20'] = {'c': '#S17 Hi this is Quinn, gel manicure tomorrow at 10. Thanks', 's': 'You have reached the voicemail of Tho. Please leave a message.'}
scen['ai']['17'] = ai(customer_name='Quinn', service_ids=[GM], time='10:00', salon_side='person', salon_agreed=False, confidence=0.9, summary='Quinn gel manicure 10 AM.')
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
r, row = call(20, '+15555550165', 20); time.sleep(1); row = mrow('CA0020')
ok('C second net: the AI says "person" but the salon side is only a greeting → still a voicemail → BOOKED', row and row[0]['kind'] == 'vm' and row[0]['status'] == 'booked', row and (row[0]['kind'], row[0]['status'], row[0]['reason']))
# A – confidence missing / as text
sql("UPDATE calls SET tb_at = '2000-01-01 00:00:00' WHERE tb_state = 'sent'")
scen['stt']['15'] = {'c': '#S13 This is Nina, regular pedicure tomorrow at 1', 's': 'OK Nina, see you tomorrow at 1.'}
a13 = ai(customer_name='Nina', service_ids=[RP], time='13:00', salon_side='person', salon_agreed=True, salon_quote='OK Nina, see you tomorrow at 1', summary='Nina pedicure 1 PM.'); del a13['confidence']
scen['ai']['13'] = a13
scen['stt']['16'] = {'c': '#S14 This is Olga, regular pedicure tomorrow at 3', 's': 'Sure Olga, 3 tomorrow is fine.'}
scen['ai']['14'] = ai(customer_name='Olga', service_ids=[RP], time='15:00', salon_side='person', salon_agreed=True, salon_quote='Sure Olga, 3 tomorrow is fine', confidence='90%', summary='Olga pedicure 3 PM.')
scen['stt']['17'] = {'c': '#S15 This is Pia, maybe a pedicure sometime tomorrow afternoon around 4?', 's': 'OK see you.'}
scen['ai']['15'] = ai(customer_name='Pia', service_ids=[RP], time='16:00', salon_side='person', salon_agreed=True, salon_quote='OK see you', confidence=0.4, summary='Pia maybe pedicure.')
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
r, row = call(15, '+15555550161', 15); ok('A/#8 no "confidence" key at all + everything else there → BOOKED (never "AI not sure (0%)")', row and row[0]['status'] == 'booked', row and (row[0]['status'], row[0]['reason']))
r, row = call(16, '+15555550162', 16); ok('A confidence as text "90%" → read as 0.9 → BOOKED', row and row[0]['status'] == 'booked', row and (row[0]['status'], row[0]['reason']))
r, row = call(17, '+15555550163', 17); ok('A a real low confidence 0.4 → still Needs review "AI not sure (40%)"', row and row[0]['status'] == 'review' and 'AI not sure (40%)' in row[0]['reason'], row and (row[0]['status'], row[0]['reason']))
fl = open(D + '/fake.log').read()
ok('OpenAI asked with Structured Outputs (json_schema strict, every key required)', "'type': 'json_schema'" in fl, fl[-300:])
# D – no name said, the number is a customer on file → that name
scen['stt']['18'] = {'c': '#S16 Hi, regular pedicure tomorrow at 11 please', 's': 'OK, 11 tomorrow, see you.'}
scen['ai']['16'] = ai(customer_name='', service_ids=[RP], time='11:00', salon_side='person', salon_agreed=True, salon_quote='OK, 11 tomorrow, see you', confidence=0.9, summary='Pedicure 11 AM, no name.')
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
r, row = call(18, '+15555550160', 18); a18 = sql("SELECT customer_name FROM appointments WHERE id = %d" % (row[0]['appt_id'] or 0)) if row else []
ok('D/#6 no name said, the number is LINH TRAN on Customers → booked as LINH TRAN', row and row[0]['status'] == 'booked' and a18 and a18[0]['customer_name'] == 'LINH TRAN', (row and (row[0]['status'], row[0]['reason']), a18))
r, row = call(19, '+15555550164', 18); ok('D no name said, number NOT on Customers → Needs review "No name" (never booked nameless)', row and row[0]['status'] == 'review' and 'No name' in row[0]['reason'], row and (row[0]['status'], row[0]['reason']))
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors in the server log', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:5])
say('PASS %d/%d' % (sum(R), len(R)))
sv.terminate(); fk.terminate()
