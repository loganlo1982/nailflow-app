// 2.99.594 UI: Calls list "Blocked number", Settings → Calls: "Hang up on blocked numbers" (ON) (iPhone 13 / SE)
process.env.NF_CALLS_DIR = '/tmp/claude-0/T586/calls-ui'; process.env.NF_SHARED_DIR = '/tmp/claude-0/T586/shared';
const { run } = require('/tmp/claude-0/t561/lib.js'); const { execSync } = require('child_process');
const A = process.argv[2], PORT = 19865, OUT = '/tmp/claude-0/T586/o594b';
run(A, PORT, OUT, async ({ open, ok, sleep, devices, pe }) => {
  const W = `/tmp/claude-0/t561/w${PORT}/db.sqlite`, E = { env: { ...process.env, TZ: 'America/Chicago' } };
  execSync(`php /tmp/claude-0/T586/seed.php ${A} ${W} ${PORT}`, E); execSync(`php /tmp/claude-0/T586/uiseed.php ${A}`, E);
  execSync(`php -r "require '${A}/inc/core.php'; settings(); require_once '${A}/inc/calls.php'; cl_table(); q(\\"INSERT INTO calls (call_sid, from_phone, kind, started_at, status, result, seen, tb_state, created_at, purge_at) VALUES ('CAb1', '', 'call', ?, 'blocked', '', 1, 'off', ?, '2099-01-01')\\", [date('Y-m-d H:i:s', time() - 600), date('Y-m-d H:i:s', time() - 600)]);"`, E);
  for (const dv of ['iPhone 13', 'iPhone SE']) {
    const { ctx, p } = await open(devices[dv], true, false, dv === 'iPhone SE' ? 'se' : '13');
    await p.evaluate(async () => { await callsState(); setTab('messages'); M.view = 'calls'; renderMessages(); }); await sleep(3000);
    for (let k = 0; k < 10 && !(await p.$('#p-messages [data-call]')); k++) { await p.evaluate(() => renderMessages()); await sleep(800); }
    const rows = await p.evaluate(() => [...document.querySelectorAll('#p-messages [data-call]')].map(b => b.innerText.replace(/\s+/g, ' ')));
    ok(dv + ': Calls list shows "Unknown number · 🚫 Blocked number"', rows.some(r => /Unknown number.*🚫 Blocked number/.test(r)), rows);
    const red = await p.evaluate(async () => (await api('calls_state')).n); ok(dv + ': blocked call not in the red number (2 = the old review + call back)', red === 2, red);
    await p.screenshot({ path: OUT + '/594-calls-' + (dv === 'iPhone SE' ? 'se' : '13') + '.png' });
    await p.evaluate(() => { setTab('settings'); goHome(); }); await sleep(1200); await p.evaluate(() => homeGo('s-calls')); await sleep(2500);
    await p.evaluate(() => { const d = document.querySelector('.cl-setup'); if (d) d.open = true; });
    const st = await p.evaluate(() => ({ t: document.querySelector('#setBody').innerText, blk: document.querySelector('#clBlk')?.checked, warn: document.querySelector('.cl-bal')?.innerText, pat: !!document.querySelector('#clPat'), w: document.documentElement.scrollWidth, vw: innerWidth }));
    ok(dv + ': "Hang up on blocked numbers" ON by default', st.blk === true && /Hang up on blocked numbers/.test(st.t), st.blk);
    ok(dv + ': the old Settings → Calls items still there, nothing about balance', /Catch the iPhone/.test(st.t) && /Text back missed calls/.test(st.t) && !st.warn && !st.pat, st.warn);
    ok(dv + ': no sideways scroll', st.w <= st.vw, st);
    await p.screenshot({ path: OUT + '/594-settings-' + (dv === 'iPhone SE' ? 'se' : '13') + '.png' });
    if (dv === 'iPhone 13') {
      await p.evaluate(() => { document.querySelector('#clBlk').scrollIntoView({ block: 'center' }); }); await sleep(300); await p.screenshot({ path: OUT + '/594-settings-block.png' });
      await p.evaluate(() => { document.querySelector('#clBlk').checked = false; document.querySelector('#clSave').click(); }); await sleep(2000);
      const r = await p.evaluate(async () => (await api('calls_cfg')).cfg); ok('Save: switch OFF kept, the other settings kept (ring 20, text back on)', r.block === false && r.ring === 20 && r.tb === true && r.screen === true, r);
      await p.evaluate(() => { document.querySelector('#clBlk').checked = true; document.querySelector('#clSave').click(); }); await sleep(2000);
      const r2 = await p.evaluate(async () => (await api('calls_cfg')).cfg); ok('Switch ON again; no token in what the page gets', r2.block === true && !/swpat_|PT_test|PSK_test/.test(JSON.stringify(r2)), r2);
    }
    ok(dv + ': no page errors', pe.length === 0, pe);
    await ctx.close();
  }
});
