<?php // ask the cron way: the token of this minute
require '/tmp/claude-0/FX605c/inc/core.php'; require_once '/tmp/claude-0/FX605c/inc/calls.php'; settings(); echo cl_tick_token();