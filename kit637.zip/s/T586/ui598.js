// 2.99.598 UI: a salon set up by NailFlow (HQ) – Settings → Calls: the AI number + Test call + how to forward (Verizon *72 …), no SignalWire setup; the old switches kept (iPhone 13 / SE)
process.env.NF_CALLS_DIR = '/tmp/claude-0/T586/calls-ui'; process.env.NF_SHARED_DIR = '/tmp/claude-0/T586/shared';
const { run } = require('/tmp/claude-0/t561/lib.js'); const { execSync } = require('child_process'); const fs = require('fs');
const A = process.argv[2], PORT = 19865, OUT = '/tmp/claude-0/T586/o598';
run(A, PORT, OUT, async ({ open, ok, sleep, devices, pe }) => {
  const W = `/tmp/claude-0/t561/w${PORT}/db.sqlite`, E = { env: { ...process.env, TZ: 'America/Chicago' } };
  execSync(`php /tmp/claude-0/T586/seed.php ${A} ${W} ${PORT}`, E); execSync(`php /tmp/claude-0/T586/uiseed.php ${A}`, E);
  fs.writeFileSync('/tmp/claude-0/T586/shared/call-sw.json', JSON.stringify({ space: 'nailflowapp', project: '11111111-2222-3333-4444-555555555555', token: 'PT_test_token_abcdefgh123456', signing: 'PSK_test_signing_key_0123456789' }));
  execSync(`php -r "require '${A}/inc/core.php'; settings(); foreach (['sw_token' => '', 'sw_signing' => '', 'sw_space' => '', 'sw_project' => '', 'sw_by' => 'hq', 'sw_number' => '+15155551616', 'salon_phone' => '(515) 555-0300', 'salon_name' => 'Love Nails'] as \\$k => \\$v) set_setting(\\$k, \\$v);"`, E);
  try {
    for (const dv of ['iPhone 13', 'iPhone SE']) {
      const { ctx, p } = await open(devices[dv], true, false, dv === 'iPhone SE' ? 'se' : '13');
      await p.evaluate(() => { setTab('settings'); goHome(); }); await sleep(1200); await p.evaluate(() => homeGo('s-calls')); await sleep(2500);
      const st = await p.evaluate(() => ({ t: document.querySelector('#setBody').innerText, setup: !!document.querySelector('.cl-setup'), tel: (document.querySelector('.cl-hq a[href^="tel:"]') || {}).href, how: (document.querySelector('#clCarTxt') || {}).innerText, w: document.documentElement.scrollWidth, vw: innerWidth }));
      ok(dv + ': "Your AI phone number: (515) 555-1616 · Set up by NailFlow ✓", no SignalWire Setup', /Your AI phone number: \(515\) 555-1616/.test(st.t) && /Set up by NailFlow/.test(st.t) && !st.setup && !/Project ID|API token|Signing Key/.test(st.t), st.t.slice(0, 500));
      ok(dv + ': Test call button tel:5155551616', /tel:5155551616$/.test(st.tel || ''), st.tel);
      ok(dv + ': Verizon (default): all calls *725155551616 · off *73 · only when nobody answers *715155551616', /\*725155551616/.test(st.how) && /\*73/.test(st.how) && /\*715155551616/.test(st.how), st.how);
      await p.selectOption('#clCar', 'att'); await sleep(150); const att = await p.evaluate(() => document.querySelector('#clCarTxt').innerText);
      ok(dv + ': AT&T: *21*5155551616# · off #21#', /\*21\*5155551616#/.test(att) && /#21#/.test(att), att);
      await p.selectOption('#clCar', 'tmo'); await sleep(150); const tmo = await p.evaluate(() => document.querySelector('#clCarTxt').innerText);
      ok(dv + ': T-Mobile: **21*15155551616# · off ##21#', /\*\*21\*15155551616#/.test(tmo) && /##21#/.test(tmo), tmo);
      ok(dv + ': the old switches are all still there (Record, Voicemail, Catch the iPhone voicemail, Text back, Blocked numbers, Ring seconds)', ['Record calls', 'Voicemail when no one answers', "Catch the iPhone's voicemail", 'Text back missed calls', 'Hang up on blocked numbers', 'Ring the iPhone'].every(x => st.t.includes(x)), st.t.slice(0, 900));
      ok(dv + ': no sideways scroll', st.w <= st.vw, st);
      await p.evaluate(() => document.querySelector('.cl-hq').scrollIntoView({ block: 'start' })); await sleep(300);
      await p.screenshot({ path: OUT + '/598-settings-hq-' + (dv === 'iPhone SE' ? 'se' : '13') + '.png' });
      if (dv === 'iPhone 13') { await p.evaluate(() => { document.querySelector('#clFwd').value = '(515) 555-0300'; document.querySelector('#clSave').click(); }); await sleep(1500);
        const e1 = await p.evaluate(() => (document.querySelector('.toast, #toast, .nf-toast') || {}).innerText || document.body.innerText.match(/ring in a loop[^\n]*/)?.[0] || '');
        ok('Save with the iPhone = the salon line → refused (loop)', /loop/.test(e1), e1);
        await p.evaluate(() => { document.querySelector('#clFwd').value = '(555) 555-0199'; document.querySelector('#clSave').click(); }); await sleep(1800);
        const r = await p.evaluate(async () => (await api('calls_cfg')).cfg); ok('Save in Settings keeps the AI number set by NailFlow', r.number === '(515) 555-1616' && r.byHq === true && r.fwd === '(555) 555-0199', r); }
      ok(dv + ': no page errors', pe.length === 0, pe); await ctx.close();
    }
  } finally { try { fs.unlinkSync('/tmp/claude-0/T586/shared/call-sw.json'); } catch (e) {} }
});
