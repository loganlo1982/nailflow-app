# mkwav.py SID seconds stereo(1/0) [salonSilent]  → wav/SID.wav  (8 kHz 16-bit; ch1 = caller amp 6000, ch2 = salon amp 12000)
import sys, struct, math
sid, sec, st = sys.argv[1], int(sys.argv[2]), sys.argv[3] == '1'; rate = 8000; ch = 2 if st else 1; fr = []
for i in range(rate * sec):
    a = int(6000 * math.sin(2 * math.pi * 440 * i / rate)); b = int(12000 * math.sin(2 * math.pi * 300 * i / rate))
    fr.append(struct.pack('<hh', a, b) if st else struct.pack('<h', a))
data = b''.join(fr); fmt = struct.pack('<HHIIHH', 1, ch, rate, rate * 2 * ch, 2 * ch, 16)
open('/tmp/claude-0/T586/wav/' + sid + '.wav', 'wb').write(b'RIFF' + struct.pack('<I', 4 + 8 + 16 + 8 + len(data)) + b'WAVE' + b'fmt ' + struct.pack('<I', 16) + fmt + b'data' + struct.pack('<I', len(data)) + data)
