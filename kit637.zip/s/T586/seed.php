<?php
// T586 seed: php seed.php <app> <db> <port> – 3 services, 3 techs, open every day 9-21, call assistant set up (test keys only), a known customer.
declare(strict_types=1); [$_, $R, $DB, $PORT] = $argv;
file_put_contents("$R/inc/config.php", "<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'$DB','site_url'=>'http://127.0.0.1:$PORT');\n");
require "$R/inc/core.php"; settings(); ensure_schema(); require_once "$R/inc/android.php";
q('DELETE FROM services'); $S = [];
foreach ([['Gel Manicure', 30, 40], ['Pedicure', 45, 35], ['Full Set', 60, 50]] as $i => $s) { q("INSERT INTO services (name, duration, price, sort, active) VALUES (?, ?, ?, ?, 1)", [$s[0], $s[1], $s[2], $i]); $S[$s[0]] = (int)db()->lastInsertId(); }
q('UPDATE staff SET active = 0'); $T = [];
foreach (['TAMMY', 'HANA', 'SISI'] as $i => $n) { q("INSERT INTO staff (name, sort, active, online) VALUES (?, ?, 1, 1)", [$n, $i]); $T[$n] = (int)db()->lastInsertId(); }
q('DELETE FROM appointments'); q('DELETE FROM outbox'); q('DELETE FROM staff_clock');
$h = []; for ($w = 0; $w < 7; $w++) $h[$w] = ['open' => '09:00', 'close' => '21:00']; set_setting('hours', json_encode($h)); set_setting('min_notice_min', '0');
$d1 = date('Y-m-d', strtotime('+1 day'));
q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?)", [$d1, 960, 60, $T['SISI'], (string)$S['Full Set'], 'ROSA TEST', '+15555550150', now_str()]);
upsert_customer('+15555550160', 'LINH TRAN');
foreach (['call_on' => '1', 'call_rec_on' => '1', 'call_vm_on' => '1', 'call_fwd' => '+15555550199', 'sw_space' => 'nailflowapp', 'sw_project' => '11111111-2222-3333-4444-555555555555',
    'sw_number' => '+15156061616', 'sw_token' => ad_enc('PT_test_token_abcdefgh123456'), 'sw_signing' => ad_enc('PSK_test_signing_key_0123456789'), 'as_on' => '0', 'calls_schema' => '', 'call_ivr' => '0'] as $k => $v) set_setting($k, $v);
echo json_encode(['S' => $S, 'T' => $T, 'd1' => $d1]) . "\n";
