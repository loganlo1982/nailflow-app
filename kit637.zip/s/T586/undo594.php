<?php require '/tmp/claude-0/L598/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '/tmp/claude-0/L598' . $f; require_once '/tmp/claude-0/L598/api.php'; require_once '/tmp/claude-0/L598/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];
$a = $argv[1];
if ($a === 'undo') { cl_undo((int)$argv[2], 'Owner'); echo 'undone'; }
if ($a === 'tick') { cl_tick(); echo 'ticked'; }
