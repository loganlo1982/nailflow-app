<?php require '/tmp/claude-0/FX616/inc/core.php'; settings(); require_once '/tmp/claude-0/FX616/inc/calls.php'; cl_table(); $a = $argv[1];
if ($a === 'set') { set_setting($argv[2], $argv[3]); echo 'ok'; }
if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
if ($a === 'list') echo json_encode(['l' => cl_list(10), 'n' => cl_badge()]);
if ($a === 'poke') { cl_cron_poke(); echo 'poked'; }
