# Fake SignalWire (recordings download/delete) + fake OpenAI STT + fake Claude for the 586 test. Port 19870. Scenarios: scen.json
import time, http.server, json, re, struct, os, base64, sys, math
D = '/tmp/claude-0/T586'; LOG = open(D + '/fake.log', 'a')
def scen(): return json.load(open(D + '/scen.json'))
def log(*a): LOG.write(' '.join(str(x) for x in a) + '\n'); LOG.flush()
def wavinfo(b):
    i = b.find(b'RIFF'); b = b[i:]; p = 12; ch = rate = bits = 0; data = b''
    while p + 8 <= len(b):
        cid = b[p:p+4]; ln = struct.unpack('<I', b[p+4:p+8])[0]
        if cid == b'fmt ': _, ch, rate, _, _, bits = struct.unpack('<HHIIHH', b[p+8:p+24])
        elif cid == b'data': data = b[p+8:p+8+ln]; break
        p += 8 + ln + (ln % 2)
    n = len(data) // (2 * ch); sec = round(n / rate)
    pk = max(abs(struct.unpack('<h', data[k:k+2])[0]) for k in range(0, min(len(data), 4000), 2 * ch))
    return ch, sec, pk
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def out(self, code, body=b'', ct='application/json', hd=None):
        self.send_response(code); self.send_header('Content-Type', ct); self.send_header('Content-Length', str(len(body)))
        for k, v in (hd or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        m = re.match(r'^/api/laml/2010-04-01/Accounts/([^/]+)/Recordings/([A-Za-z0-9]+)\.wav$', self.path)
        if m:
            au = self.headers.get('Authorization', ''); ok = au == 'Basic ' + base64.b64encode(b'11111111-2222-3333-4444-555555555555:PT_test_token_abcdefgh123456').decode()
            log('GET rec', m.group(2), 'auth', ok)
            if not ok: return self.out(401)
            return self.out(302, b'', hd={'Location': '/media/' + m.group(2) + '.wav'})
        m = re.match(r'^/api/relay/rest/recordings/([0-9a-f-]{36})\.wav$', self.path)  # (605B) the SWML recording REST file
        if m:
            au = self.headers.get('Authorization', ''); ok = au == 'Basic ' + base64.b64encode(b'11111111-2222-3333-4444-555555555555:PT_test_token_abcdefgh123456').decode()
            f = D + '/wav/' + m.group(1) + '.wav'; log('GET relay', m.group(1), 'auth', ok, 'exists', os.path.exists(f))
            if not ok: return self.out(401)
            if not os.path.exists(f): return self.out(404)
            return self.out(200, open(f, 'rb').read(), 'audio/wav')
        if self.path == '/api/space/balance':
            au = self.headers.get('Authorization', ''); S = scen(); log('GET balance', 'pat' if au == 'Basic ' + base64.b64encode(b':swpat_test_0123456789abcdefghij0123456789').decode() else 'other')
            if au != 'Basic ' + base64.b64encode(b':swpat_test_0123456789abcdefghij0123456789').decode(): return self.out(401, b'Unauthorized', 'text/plain')
            if S.get('bal_fail'): return self.out(502, b'{}')
            v = S.get('bal', 4.2); return self.out(200, json.dumps({'type': 'balance', 'balance_in_microdollars': int(v * 1000000), 'current_balance': v, 'low_balance_threshold': 5, 'auto_topup_enabled': False}).encode())
        m = re.match(r'^/media/([A-Za-z0-9]+)\.wav$', self.path)
        if m:
            f = D + '/wav/' + m.group(1) + '.wav'
            if not os.path.exists(f): return self.out(404)
            log('GET media', m.group(1)); return self.out(200, open(f, 'rb').read(), 'audio/wav')
        self.out(404)
    def do_DELETE(self):
        log('DELETE', self.path); self.out(204)
    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0)); b = self.rfile.read(n)
        if self.path == '/stt':
            S = scen()
            if S.get('stt_fail'): log('STT fail'); return self.out(500, b'{}')
            ch, sec, pk = wavinfo(b); who = 'c' if pk < 9000 else 's'
            t = S['stt'].get(str(sec), {}).get(who, '')
            log('STT', 'auth', self.headers.get('Authorization', '')[:12], 'model' in b.decode('latin1'), 'sec', sec, 'pk', pk, who, repr(t[:40]))
            return self.out(200, json.dumps({'text': t}).encode())
        if self.path == '/ai':
            j = json.loads(b); pr = j['messages'][0]['content']; m = (lambda f: re.search(r'#S(' + f[-1] + r')\b', pr) if f else None)(re.findall(r'#S(\d+)', pr))  # the LAST marker (602B: several answers in one call)
            ans = scen()['ai'].get(m.group(1) if m else '0', {'intent': 'other', 'confidence': 0})
            log('AI', 'key', self.headers.get('x-api-key', '')[:10], 'scen', m.group(1) if m else None, 'model', j.get('model'))
            return self.out(200, json.dumps({'content': [{'type': 'text', 'text': 'Here: ' + json.dumps(ans)}], 'usage': {'input_tokens': 900, 'output_tokens': 120}}).encode())
        if self.path == '/oai':
            if scen().get('oai_delay'): time.sleep(float(scen()['oai_delay']))  # (602B) a slow AI
            j = json.loads(b); pr = j['messages'][-1]['content']; m = (lambda f: re.search(r'#S(' + f[-1] + r')\b', pr) if f else None)(re.findall(r'#S(\d+)', pr))  # the LAST marker (602B: several answers in one call)
            ans = scen()['ai'].get(m.group(1) if m else '0', {'intent': 'other', 'confidence': 0})
            log('OAI', 'auth', self.headers.get('Authorization', '')[:12], 'scen', m.group(1) if m else None, 'model', j.get('model'), 'json', j.get('response_format'))
            return self.out(200, json.dumps({'choices': [{'message': {'role': 'assistant', 'content': json.dumps(ans)}}]}).encode())
        self.out(404)
http.server.ThreadingHTTPServer(('127.0.0.1', 19870), H).serve_forever()
