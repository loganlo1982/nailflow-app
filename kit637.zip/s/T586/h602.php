<?php require '/tmp/claude-0/FX616/inc/core.php'; settings(); require_once '/tmp/claude-0/FX616/inc/calls.php'; cl_table(); $a = $argv[1];
if ($a === 'svc') { $i = 0; foreach (json_decode($argv[2], true) as $s) { q('INSERT INTO services (name, duration, price, sort, active) VALUES (?, ?, ?, ?, 1)', [$s[0], $s[1], $s[2], 10 + $i++]); } echo json_encode(array_column(q('SELECT id, name FROM services WHERE active = 1')->fetchAll(), 'id', 'name')); }
if ($a === 'off') { q('UPDATE services SET active = 0 WHERE name = ?', [$argv[2]]); echo '{}'; }
if ($a === 'on') { q('UPDATE services SET active = 1 WHERE name = ?', [$argv[2]]); echo '{}'; }
if ($a === 'in') { require_once '/tmp/claude-0/FX616/inc/android.php'; $GLOBALS['actor'] = ['system', 'Android']; echo json_encode(ad_incoming($argv[2], $argv[3])); }
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'kinds') { require_once '/tmp/claude-0/FX616/inc/calls-ask.php'; echo json_encode(cla_kinds()); }
