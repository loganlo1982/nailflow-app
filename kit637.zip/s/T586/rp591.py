# Replay the REAL calls of diag591.txt (CHAT, read-only on the server) on a LOCAL copy: the same services / techs / customer, the stored words + AI answers
# → what cl_decide of 2.99.590 does with them now. python3 rp591.py <app tree> <diag591.txt>
import sys, re, json, subprocess, shutil, os
A, F = sys.argv[1], sys.argv[2]; D = '/tmp/claude-0/T586'; DB = D + '/rp.sqlite'; T = open(F, encoding='utf-8').read()
svc = [l.split(' | ') for l in T.split('== services (id | name | min | active | addon?)\n')[1].split('\n\n')[0].strip().splitlines()]
tech = [l.split(' | ') for l in T.split('== techs (id | name | active)\n')[1].split('\n\n')[0].strip().splitlines()]
calls = []
for blk in re.split(r'\n== call #', T)[1:]:
    head = blk.splitlines()[0]; m = re.match(r'(\d+)\s+kind (\w+)\s+status (\w+)\s+dur (\d+)s', head)
    if not m: continue
    cust = re.search(r"customer on file: '([^']*)'", blk)
    tc = blk.split('--- CUSTOMER channel (text_c):\n')[1].split('\n--- SALON channel (text_s):\n')[0]
    ts = blk.split('--- SALON channel (text_s):\n')[1].split('\n--- ai_json:\n')[0]
    aj = blk.split('--- ai_json:\n')[1].split('\n')[0]
    calls.append({'id': int(m.group(1)), 'kind': m.group(2), 'status': m.group(3), 'dur': int(m.group(4)), 'cust': cust.group(1) if cust else '', 'tc': tc, 'ts': ts, 'aj': aj,
                  'reason': re.search(r'\nreason: (.*)', blk).group(1), 'result': re.search(r'\nresult: (.*)', blk).group(1)})
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
inp = json.dumps({'svc': svc, 'tech': tech, 'calls': calls}); open(D + '/rp-in.json', 'w').write(inp)
php = r'''<?php
[$_, $R, $DB, $IN] = $argv; file_put_contents("$R/inc/config.php", "<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'$DB','site_url'=>'https://american-nails-and-spa.com');\n");
require "$R/inc/core.php"; settings(); ensure_schema(); define('NF_API_LIB', 1);
foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once $R . $f; require_once "$R/api.php"; require_once "$R/inc/calls-job.php";
$I = json_decode(file_get_contents($IN), true); $GLOBALS['actor'] = ['call', 'replay'];
q('DELETE FROM services'); foreach ($I['svc'] as $s) q('INSERT INTO services (id, name, duration, price, sort, active) VALUES (?, ?, ?, 0, ?, ?)', [(int)$s[0], trim($s[1]), (int)$s[2], (int)$s[0], (int)$s[3]]);
q('UPDATE staff SET active = 0'); foreach ($I['tech'] as $t) { q('DELETE FROM staff WHERE id = ?', [(int)$t[0]]); q('INSERT INTO staff (id, name, sort, active, online) VALUES (?, ?, ?, 1, 1)', [(int)$t[0], trim($t[1]), (int)$t[0]]); }
$h = []; for ($w = 0; $w < 7; $w++) $h[$w] = ['open' => '09:00', 'close' => '19:00']; set_setting('hours', json_encode($h)); set_setting('call_on', '1');
cl_table(); q('DELETE FROM appointments'); q('DELETE FROM customers');
foreach ($I['calls'] as $c) {
    $ph = '+1515499' . sprintf('%04d', 7400 + $c['id']); if ($c['cust'] !== '') upsert_customer($ph, $c['cust']);
    q("INSERT INTO calls (id, call_sid, rec_sid, from_phone, kind, started_at, dur_sec, status, text_c, text_s, ai_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'work', ?, ?, ?, ?)",
      [$c['id'], 'CArp' . $c['id'], 'RErp' . $c['id'], $ph, $c['kind'], now_str(), $c['dur'], $c['tc'], $c['ts'], $c['aj'], now_str()]);
    $row = q('SELECT * FROM calls WHERE id = ?', [$c['id']])->fetch(); $j = json_decode($c['aj'], true) ?: [];
    $st = cl_decide($row, $j); $n = q('SELECT * FROM calls WHERE id = ?', [$c['id']])->fetch();
    $a = (int)$n['appt_id'] ? q('SELECT * FROM appointments WHERE id = ?', [(int)$n['appt_id']])->fetch() : null;
    echo "#{$c['id']}  BEFORE ({$c['kind']}): {$c['status']} – {$c['reason']} – {$c['result']}\n      NOW    ({$n['kind']}): $st – {$n['reason']} – {$n['result']}" . ($a ? "  → appt {$a['customer_name']} · " . appt_label($a) . ' · ' . $a['appt_date'] . ' ' . min_to_label((int)$a['start_min']) : '') . "\n";
}
'''
open(D + '/rp591.php', 'w').write(php)
r = subprocess.run(['php', D + '/rp591.php', A, DB, D + '/rp-in.json'], capture_output=True, text=True, env={**os.environ, 'TZ': 'America/Chicago', 'NF_CALLS_DIR': D + '/calls', 'NF_SHARED_DIR': D + '/shared'})
print(r.stdout + r.stderr[-1500:])
open(A + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'/tmp/x.sqlite');\n")
