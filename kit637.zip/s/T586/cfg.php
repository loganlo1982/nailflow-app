<?php require '/tmp/claude-0/L586/inc/core.php'; settings(); require_once '/tmp/claude-0/L586/inc/calls.php';
try { cl_cfg_save(['token' => 'short']); } catch (RuntimeException $e) { echo 'bad token → ', $e->getMessage(), "\n"; }
try { $r = cl_cfg_save(['fwd' => '(515) 555-0177', 'token' => 'NEW_token_value_1234567890']); echo json_encode($r), "\n"; } catch (RuntimeException $e) { echo 'ERR ', $e->getMessage(), "\n"; }
echo strpos(json_encode(cl_cfg()), 'NEW_token') === false ? "token never shown ✓\n" : "TOKEN LEAK\n";
