# LAMWEB test 586 – the whole call flow on a local copy (fake SignalWire / STT / Claude; test numbers 555-01xx only). python3 t586.py <app tree>
import subprocess, json, os, sys, time, hmac, hashlib, base64, urllib.request, urllib.parse, shutil
A = sys.argv[1]; D = '/tmp/claude-0/T586'; PORT = 19861; DB = D + '/db.sqlite'; KEY = 'PSK_test_signing_key_0123456789'
R = []; out = open(D + '/test-598-salon.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', D + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
for f in os.listdir(D + '/calls') if os.path.isdir(D + '/calls') else []: pass
shutil.rmtree(D + '/calls', ignore_errors=True); os.makedirs(D + '/calls'); open(D + '/fake.log', 'w').close()
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
OAI = True
if OAI: json.dump({}, open(D + '/shared/color-ai.json', 'w'))
else: json.dump({'key': 'sk-ant-test-000000000000000000000000'}, open(D + '/shared/color-ai.json', 'w'))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SHARED_DIR': D + '/shared', 'NF_CALLS_DIR': D + '/calls'}
seed = json.loads(sh('php', D + '/seed.php', A, DB, str(PORT)).stdout); S, T, d1 = seed['S'], seed['T'], seed['d1']
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
def ai(**k): b = {'intent': 'book', 'customer_name': '', 'customer_phone': '', 'service_ids': [], 'service_text': '', 'tech_id': 0, 'tech_text': '', 'date': d1, 'time': '', 'people': 1, 'salon_side': 'person', 'salon_agreed': False, 'salon_quote': '', 'confidence': 0.95, 'missing': [], 'summary': ''}; b.update(k); return b
scen = {'stt': {
  '3': {'c': '#S1 Hi this is Mia, can I get a gel manicure tomorrow at 2?', 's': 'Sure, tomorrow at 2 is open. OK, see you at 2!'},
  '4': {'c': '#S2 This is Linh, pedicure with Tammy tomorrow at 3 please', 's': 'Let me check the book for you.'},
  '5': {'c': '#S3 How much is a full set?', 's': 'Full set is fifty dollars.'},
  '6': {'c': '#S4 Hi this is Anna, I want a full set tomorrow at 11 with Hana. Thanks!'},
  '7': {'c': '#S5 Bella here, gel manicure tomorrow at 4 with Sisi please, call me back'},
  '8': {'c': '#S6 Hi I want a pedicure tomorrow, Cara', 's': 'ok'},
  '9': {'c': '#S7 Hi Dana, gel manicure tomorrow at noon?', 's': 'Yes ok, noon tomorrow.'},
  '10': {'c': '#S8 chị muốn làm bột thứ bảy 2 giờ, tên Hoa', 's': 'Dạ ok chị, 2 giờ nha.'}},
 'ai': {
  '1': ai(customer_name='Mia', service_ids=[GM], time='14:00', salon_agreed=True, salon_quote='OK, see you at 2', summary='Mia wants a gel manicure tomorrow at 2 PM.'),
  '2': ai(customer_name='Linh', service_ids=[PD], tech_id=T['TAMMY'], tech_text='Tammy', time='15:00', salon_agreed=True, salon_quote='ok sure 3pm', summary='Linh wants a pedicure with Tammy tomorrow 3 PM.'),
  '3': ai(intent='info', summary='Asked the price of a full set.'),
  '4': ai(customer_name='Anna', service_ids=[FS], tech_id=T['HANA'], tech_text='Hana', time='11:00', summary='Voicemail: Anna, full set tomorrow 11 AM with Hana.'),
  '5': ai(customer_name='Bella', service_ids=[GM], tech_id=T['SISI'], tech_text='Sisi', time='16:00', summary='Voicemail: Bella, gel manicure tomorrow 4 PM with Sisi.'),
  '6': ai(customer_name='Cara', service_ids=[PD], time='', salon_agreed=True, salon_quote='ok', confidence=0.9, missing=['time'], summary='Cara wants a pedicure tomorrow, no time.'),
  '7': ai(customer_name='Dana', service_ids=[GM], time='12:00', salon_agreed=True, salon_quote='Yes ok, noon tomorrow', summary='Dana, gel manicure tomorrow at noon.'),
  '8': ai(customer_name='Hoa', service_ids=[FS], time='14:00', date=d1, salon_agreed=True, salon_quote='Dạ ok chị, 2 giờ nha', confidence=0.9, summary='Hoa wants a full set at 2 PM.')}}
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
fk = subprocess.Popen(['python3', D + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.3)
B = 'http://127.0.0.1:%d' % PORT
def post(a, p, sign=True, key=KEY, url=None):
    u = url or (B + '/call_in.php?' + a); body = urllib.parse.urlencode(p).encode(); h = {'Content-Type': 'application/x-www-form-urlencoded'}
    if sign: h['X-SignalWire-Signature'] = base64.b64encode(hmac.new(key.encode(), (u + ''.join(k + p[k] for k in sorted(p))).encode(), hashlib.sha1).digest()).decode()
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, data=body, headers=h), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
ACC = '11111111-2222-3333-4444-555555555555'
def call(n, frm, sec, stereo=True, vm=False):
    sid = 'CA%04d' % n; rs = 'RE%04d' % n; subprocess.run(['python3', D + '/mkwav.py', rs, str(sec), '1' if stereo else '0'])
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if vm: post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    c2, x2 = post('a=rec' + ('&vm=1' if vm else ''), {'AccountSid': ACC, 'CallSid': sid, 'RecordingSid': rs, 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/%s' % (ACC, rs), 'RecordingStatus': 'completed', 'RecordingDuration': str(sec), 'RecordingChannels': '2' if stereo else '1'})
    for k in range(80):
        row = sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
        if row and row[0]['status'] not in ('queued', 'work', 'ring') or (row and row[0]['status'] == 'queued' and row[0]['tries'] >= 1): break
        time.sleep(0.25)
    return (c, x, c2, x2), row
def appt(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, customer_name, status, source, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def push(): return sql("SELECT target, kind, title, body FROM push_log ORDER BY id DESC LIMIT 1") if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []



open(D + '/set590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'salon_name' => 'American Nails', 'as_kinds' => json_encode(['confirm' => true, 'change' => true, 'cancel' => true])] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set590.php')
open(D + '/undo.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];\n$a = $argv[1];\nif ($a === 'tick') { cl_tick(); echo 'ticked'; }\n" % (A, A, A, A))
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat(); d3 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=3)).isoformat()
open(D + '/mk592.php', 'w').write("<?php require '%s/inc/core.php'; settings(); [$_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = [];\nupsert_customer($ph, $name);\nfor ($i = 0; $i < (int)$n; $i++) { q(\"INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)\", [$date, (int)$start, 45, (int)$staff + $i * ((int)$staff ? 1 : 0), '%d', $i ? $name . ' +' . $i : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); }\necho implode(',', $ids);" % (A, S['Pedicure']))
def mk(ph, name, date, start, staff=0, n=1): return [int(x) for x in sh('php', D + '/mk592.php', ph, name, date, str(start), str(staff), str(n)).stdout.split(',')]
def ap(i): return sql("SELECT id, appt_date, start_min, staff_id, status FROM appointments WHERE id = %d" % i)[0]
def ob(i, k): return sql("SELECT kind, ref, status FROM outbox WHERE appt_id = %d AND kind = '%s'" % (i, k))
def lastpush(): return sql("SELECT title, body FROM push_log WHERE target = 'admin' ORDER BY id DESC LIMIT 1")
def go(n, ph, j, tc, ts=None, vm=True):
    scen['stt'][str(n)] = {'c': '#S%d ' % (100 + n) + tc} if ts is None else {'c': '#S%d ' % (100 + n) + tc, 's': ts}
    scen['ai'][str(100 + n)] = j; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
    r, row = call(n, ph, n, stereo=not vm, vm=vm); time.sleep(0.8); return mrow('CA%04d' % n)[0]
def mrow(sid): return sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
say('== LAMWEB test 2.99.598 – LỆNH 595, part A: a salon on NailFlow SignalWire account (HQ) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire / STT / AI · texts only into the SMS Server queue')
open(D + '/h594.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; cl_table(); $a = $argv[1];\n"
 "if ($a === 'set') { set_setting($argv[2], $argv[3]); echo 'ok'; }\n"
 "if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }\n"
 "if ($a === 'list') echo json_encode(['l' => cl_list(10), 'n' => cl_badge()]);\n"
 "if ($a === 'poke') { cl_cron_poke(); echo 'poked'; }\n" % (A, A))
def h(*a): r = sh('php', D + '/h594.php', *a); return r.stdout
def P(name='', sids=None, text='', tid=0, tt=''): return {'name': name, 'service_ids': sids or [], 'service_text': text, 'tech_id': tid, 'tech_text': tt}
def grp(ph): return sql("SELECT id, appt_date, start_min, duration, staff_id, service_ids, customer_name, status, source, group_id, note FROM appointments WHERE phone = '%s' AND status <> 'cancelled' ORDER BY id" % ph)
def conf(ph):
    for k in range(12):
        r = sql("SELECT id, kind, ref FROM outbox WHERE phone = '%s' AND kind = 'confirm'" % ph)
        if r: return r
        time.sleep(0.25)
    return r
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat()
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
import atexit; atexit.register(lambda: (sv.terminate(), fk.terminate()))
SH = D + '/shared/call-sw.json'
json.dump({'space': 'nailflowapp', 'project': '11111111-2222-3333-4444-555555555555', 'token': 'PT_test_token_abcdefgh123456', 'signing': 'PSK_test_signing_key_0123456789', 'at': 'x'}, open(SH, 'w'))
atexit.register(lambda: os.path.exists(SH) and os.remove(SH))
open(D + '/h598.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; cl_table(); $a = $argv[1];\n"
 "if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }\n"
 "if ($a === 'who') echo json_encode(['space' => cl_space(), 'project' => cl_project(), 'tok' => cl_sec('sw_token') !== '' ? substr(cl_sec('sw_token'), 0, 7) : '', 'sig' => cl_sec('sw_signing') !== '', 'own' => cl_own()]);\n"
 "if ($a === 'cfg') echo json_encode(cl_cfg());\n"
 "if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }\n" % (A, A))
def h(*a):
    r = sh('php', D + '/h598.php', *a)
    try: return json.loads(r.stdout or '{}')
    except Exception: print('RAW', a, r.stdout[:300], r.stderr[:300]); raise
w = h('who'); ok('A0 American Nails style (its OWN token): own values, the shared file ignored', w['own'] is True and w['project'] == '11111111-2222-3333-4444-555555555555' and w['tok'] == 'PT_test', w)
h('set', json.dumps({'sw_token': '', 'sw_signing': '', 'sw_space': '', 'sw_project': '', 'sw_number': '+15156061616', 'sw_by': 'hq', 'salon_phone': '(515) 555-0300'}))
w = h('who'); ok('A1 a salon WITHOUT its own token → NailFlow\'s account (space, project, token, signing key from HQ)', w['own'] is False and w['space'] == 'nailflowapp' and w['project'] == '11111111-2222-3333-4444-555555555555' and w['tok'] == 'PT_test' and w['sig'] is True, w)
c = h('cfg'); ok('A1 Settings → Calls gets byHq + the number, never NailFlow\'s Project ID / token', c['byHq'] is True and c['number'] == '(515) 606-1616' and c['project'] == '' and c['space'] == '' and c['tokenSet'] is False and 'PT_test' not in json.dumps(c), c)
r = go(81, '+15555550181', ai(customer_name='Mia', service_ids=[GM], time='13:00', summary='Mia gel 1 PM'), 'Hi this is Mia, gel manicure tomorrow at 1')
ok('A2 a real call flow on NailFlow\'s account: signature (shared Signing Key) ✓, recording fetched with the shared token ✓ → BOOKED', r['status'] == 'booked' and r['file'] != '', (r['status'], r['reason'], r['err']))
st, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CA0982', 'From': '+15555550182', 'To': '+15156061616', 'CallStatus': 'ringing'}, key='PSK_wrong_key_000000000000000')
ok('A2 a wrong signature → 403 (as before)', st == 403, (st, x[:100]))
st, x = post('a=answer', {'AccountSid': '00000000-0000-0000-0000-000000000000', 'CallSid': 'CA0983', 'From': '+15555550182', 'To': '+15156061616', 'CallStatus': 'ringing'})
ok('A2 another SignalWire project → refused (as before)', st in (403, 400), (st, x[:100]))
st, x = post('a=answer', {'AccountSid': ACC, 'CallSid': 'CA0984', 'From': '+15555550184', 'To': '+15155559999', 'CallStatus': 'ringing'})
ok('A3 "To" is not this salon\'s number → the call still goes on (Dial) + 1 log line "598 calls: To …9999"', '<Dial' in x and '598 calls: To …9999' in open(D + '/php.log').read(), (x[:120], open(D + '/php.log').read()[-300:]))
s = h('save', json.dumps({'on': True, 'fwd': '(555) 555-0199', 'number': '', 'space': '', 'project': '', 'token': ''}))
ok('A4 the owner presses Save in Settings (the page sends number "") → the AI number set by NailFlow is KEPT', s.get('number') == '(515) 606-1616' and s.get('byHq') is True, s)
s = h('save', json.dumps({'fwd': '(515) 555-0300'})); ok('A5 iPhone to ring = the salon line → refused (it would ring in a loop)', 'loop' in s.get('err', ''), s)
s = h('save', json.dumps({'fwd': '(515) 606-1616'})); ok('A5 iPhone to ring = the AI number → refused', 'loop' in s.get('err', ''), s)
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors in the server log', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:5])
ok('No token in the logs', 'PT_test_token' not in logs, '')
say('PASS %d/%d' % (sum(R), len(R)))
