# LAMWEB test 586 – the whole call flow on a local copy (fake SignalWire / STT / Claude; test numbers 555-01xx only). python3 t586.py <app tree>
import subprocess, json, os, sys, time, hmac, hashlib, base64, urllib.request, urllib.parse, shutil
A = sys.argv[1]; D = '/tmp/claude-0/T586'; PORT = 19861; DB = D + '/db.sqlite'; KEY = 'PSK_test_signing_key_0123456789'
R = []; out = open(D + '/test-596.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:400]))
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', D + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
for f in os.listdir(D + '/calls') if os.path.isdir(D + '/calls') else []: pass
shutil.rmtree(D + '/calls', ignore_errors=True); os.makedirs(D + '/calls'); open(D + '/fake.log', 'w').close()
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
OAI = True
if OAI: json.dump({}, open(D + '/shared/color-ai.json', 'w'))
else: json.dump({'key': 'sk-ant-test-000000000000000000000000'}, open(D + '/shared/color-ai.json', 'w'))
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(D + '/shared/call-ai.json', 'w'))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_AI_URL': 'http://127.0.0.1:19870/ai', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_SHARED_DIR': D + '/shared', 'NF_CALLS_DIR': D + '/calls'}
seed = json.loads(sh('php', D + '/seed.php', A, DB, str(PORT)).stdout); S, T, d1 = seed['S'], seed['T'], seed['d1']
GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
def ai(**k): b = {'intent': 'book', 'customer_name': '', 'customer_phone': '', 'service_ids': [], 'service_text': '', 'tech_id': 0, 'tech_text': '', 'date': d1, 'time': '', 'people': 1, 'salon_side': 'person', 'salon_agreed': False, 'salon_quote': '', 'confidence': 0.95, 'missing': [], 'summary': ''}; b.update(k); return b
scen = {'stt': {
  '3': {'c': '#S1 Hi this is Mia, can I get a gel manicure tomorrow at 2?', 's': 'Sure, tomorrow at 2 is open. OK, see you at 2!'},
  '4': {'c': '#S2 This is Linh, pedicure with Tammy tomorrow at 3 please', 's': 'Let me check the book for you.'},
  '5': {'c': '#S3 How much is a full set?', 's': 'Full set is fifty dollars.'},
  '6': {'c': '#S4 Hi this is Anna, I want a full set tomorrow at 11 with Hana. Thanks!'},
  '7': {'c': '#S5 Bella here, gel manicure tomorrow at 4 with Sisi please, call me back'},
  '8': {'c': '#S6 Hi I want a pedicure tomorrow, Cara', 's': 'ok'},
  '9': {'c': '#S7 Hi Dana, gel manicure tomorrow at noon?', 's': 'Yes ok, noon tomorrow.'},
  '10': {'c': '#S8 chị muốn làm bột thứ bảy 2 giờ, tên Hoa', 's': 'Dạ ok chị, 2 giờ nha.'}},
 'ai': {
  '1': ai(customer_name='Mia', service_ids=[GM], time='14:00', salon_agreed=True, salon_quote='OK, see you at 2', summary='Mia wants a gel manicure tomorrow at 2 PM.'),
  '2': ai(customer_name='Linh', service_ids=[PD], tech_id=T['TAMMY'], tech_text='Tammy', time='15:00', salon_agreed=True, salon_quote='ok sure 3pm', summary='Linh wants a pedicure with Tammy tomorrow 3 PM.'),
  '3': ai(intent='info', summary='Asked the price of a full set.'),
  '4': ai(customer_name='Anna', service_ids=[FS], tech_id=T['HANA'], tech_text='Hana', time='11:00', summary='Voicemail: Anna, full set tomorrow 11 AM with Hana.'),
  '5': ai(customer_name='Bella', service_ids=[GM], tech_id=T['SISI'], tech_text='Sisi', time='16:00', summary='Voicemail: Bella, gel manicure tomorrow 4 PM with Sisi.'),
  '6': ai(customer_name='Cara', service_ids=[PD], time='', salon_agreed=True, salon_quote='ok', confidence=0.9, missing=['time'], summary='Cara wants a pedicure tomorrow, no time.'),
  '7': ai(customer_name='Dana', service_ids=[GM], time='12:00', salon_agreed=True, salon_quote='Yes ok, noon tomorrow', summary='Dana, gel manicure tomorrow at noon.'),
  '8': ai(customer_name='Hoa', service_ids=[FS], time='14:00', date=d1, salon_agreed=True, salon_quote='Dạ ok chị, 2 giờ nha', confidence=0.9, summary='Hoa wants a full set at 2 PM.')}}
json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
fk = subprocess.Popen(['python3', D + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.3)
import atexit; atexit.register(lambda: (sv.terminate(), fk.terminate()))
B = 'http://127.0.0.1:%d' % PORT
def post(a, p, sign=True, key=KEY, url=None):
    u = url or (B + '/call_in.php?' + a); body = urllib.parse.urlencode(p).encode(); h = {'Content-Type': 'application/x-www-form-urlencoded'}
    if sign: h['X-SignalWire-Signature'] = base64.b64encode(hmac.new(key.encode(), (u + ''.join(k + p[k] for k in sorted(p))).encode(), hashlib.sha1).digest()).decode()
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, data=body, headers=h), timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
ACC = '11111111-2222-3333-4444-555555555555'
def call(n, frm, sec, stereo=True, vm=False):
    sid = 'CA%04d' % n; rs = 'RE%04d' % n; subprocess.run(['python3', D + '/mkwav.py', rs, str(sec), '1' if stereo else '0'])
    c, x = post('a=answer', {'AccountSid': ACC, 'CallSid': sid, 'From': frm, 'To': '+15156061616', 'CallStatus': 'ringing'})
    if vm: post('a=done', {'AccountSid': ACC, 'CallSid': sid, 'DialCallStatus': 'no-answer'})
    c2, x2 = post('a=rec' + ('&vm=1' if vm else ''), {'AccountSid': ACC, 'CallSid': sid, 'RecordingSid': rs, 'RecordingUrl': '/api/laml/2010-04-01/Accounts/%s/Recordings/%s' % (ACC, rs), 'RecordingStatus': 'completed', 'RecordingDuration': str(sec), 'RecordingChannels': '2' if stereo else '1'})
    for k in range(80):
        row = sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
        if row and row[0]['status'] not in ('queued', 'work', 'ring') or (row and row[0]['status'] == 'queued' and row[0]['tries'] >= 1): break
        time.sleep(0.25)
    return (c, x, c2, x2), row
def appt(ph): return sql("SELECT id, appt_date, start_min, staff_id, service_ids, customer_name, status, source, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
def push(): return sql("SELECT target, kind, title, body FROM push_log ORDER BY id DESC LIMIT 1") if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []



open(D + '/set590.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'salon_name' => 'American Nails', 'as_kinds' => json_encode(['confirm' => true, 'change' => true, 'cancel' => true])] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set590.php')
open(D + '/undo.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner'];\n$a = $argv[1];\nif ($a === 'tick') { cl_tick(); echo 'ticked'; }\n" % (A, A, A, A))
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat(); d3 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=3)).isoformat()
open(D + '/mk592.php', 'w').write("<?php require '%s/inc/core.php'; settings(); [$_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = [];\nupsert_customer($ph, $name);\nfor ($i = 0; $i < (int)$n; $i++) { q(\"INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)\", [$date, (int)$start, 45, (int)$staff + $i * ((int)$staff ? 1 : 0), '%d', $i ? $name . ' +' . $i : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); }\necho implode(',', $ids);" % (A, S['Pedicure']))
def mk(ph, name, date, start, staff=0, n=1): return [int(x) for x in sh('php', D + '/mk592.php', ph, name, date, str(start), str(staff), str(n)).stdout.split(',')]
def ap(i): return sql("SELECT id, appt_date, start_min, staff_id, status FROM appointments WHERE id = %d" % i)[0]
def ob(i, k): return sql("SELECT kind, ref, status FROM outbox WHERE appt_id = %d AND kind = '%s'" % (i, k))
def lastpush(): return sql("SELECT title, body FROM push_log WHERE target = 'admin' ORDER BY id DESC LIMIT 1")
def go(n, ph, j, tc, ts=None, vm=True):
    scen['stt'][str(n)] = {'c': '#S%d ' % (100 + n) + tc} if ts is None else {'c': '#S%d ' % (100 + n) + tc, 's': ts}
    scen['ai'][str(100 + n)] = j; json.dump(scen, open(D + '/scen.json', 'w'), ensure_ascii=False)
    r, row = call(n, ph, n, stereo=not vm, vm=vm); time.sleep(0.8); return mrow('CA%04d' % n)[0]
def mrow(sid): return sql("SELECT * FROM calls WHERE call_sid = '%s'" % sid)
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
say('== LAMWEB test 2.99.596 – LỖI 596: replay of the real calls #21 #22 ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire / STT / AI · texts only into the SMS Server queue')
open(D + '/h594.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; cl_table(); $a = $argv[1];\n"
 "if ($a === 'set') { set_setting($argv[2], $argv[3]); echo 'ok'; }\n"
 "if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }\n"
 "if ($a === 'list') echo json_encode(['l' => cl_list(10), 'n' => cl_badge()]);\n"
 "if ($a === 'poke') { cl_cron_poke(); echo 'poked'; }\n" % (A, A))
def h(*a): r = sh('php', D + '/h594.php', *a); return r.stdout
def P(name='', sids=None, text='', tid=0, tt=''): return {'name': name, 'service_ids': sids or [], 'service_text': text, 'tech_id': tid, 'tech_text': tt}
def grp(ph): return sql("SELECT id, appt_date, start_min, duration, staff_id, service_ids, customer_name, status, source, group_id, note FROM appointments WHERE phone = '%s' AND status <> 'cancelled' ORDER BY id" % ph)
def conf(ph):
    for k in range(12):
        r = sql("SELECT id, kind, ref FROM outbox WHERE phone = '%s' AND kind = 'confirm'" % ph)
        if r: return r
        time.sleep(0.25)
    return r
d2 = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=2)).isoformat()
T1, T2, T3 = T['TAMMY'], T['HANA'], T['SISI']
def ap(i): return sql("SELECT id, appt_date, start_min, staff_id, status, group_id, customer_name FROM appointments WHERE id = %d" % i)[0]
PH = '+15555550171'
T21 = "Me and my daughter both want a pedicure tomorrow at 2."
T22 = "Hi, my name is Logan. I have an appointment tomorrow at 2, and I would like to cancel one appointment. Thank you."
J22 = ai(intent='cancel', customer_name='Logan', date='', time='', cancel_part=True, cancel_names=['Logan'], cancel_n=1, who_text='one appointment', missing=['date', 'time', 'service_ids'], summary='Logan wants to cancel one appointment.')
r = go(21, PH, ai(customer_name='Logan', people=2, party=[P('Logan', [PD]), P('')], same_services=True, time='14:00', summary='Logan and his daughter, 2 pedicures tomorrow 2 PM.'), T21)
g = grp(PH); ok('#21 (unchanged) "me and my daughter both … pedicure tomorrow at 2" → BOOKED LOGAN + LOGAN +1, 🔗, 2:00 PM', r['status'] == 'booked' and [x['customer_name'] for x in g] == ['LOGAN', 'LOGAN +1'] and g[0]['group_id'] != '' and g[0]['group_id'] == g[1]['group_id'], (r['status'], r['reason'], g))
other = mk(PH, 'LOGAN', d2, 11 * 60, T3)[0] # like the real number: one more upcoming appointment (another day)
r = go(22, PH, J22, T22)
ok('#22 real words + the real AI answer (date/time empty, cancel_names ["Logan"]) → CANCELLED 1 of 2: LOGAN +1 cancelled, LOGAN kept, the other day kept', r['status'] == 'cancelled' and ap(g[0]['id'])['status'] == 'booked' and ap(g[1]['id'])['status'] == 'cancelled' and ap(other)['status'] == 'booked', (r['status'], r['reason'], r['result']))
lp = lastpush(); ok('#22 owner push "📞 <salon> – Cancelled 1 of 2" · "Logan\'s guest – Pedicure – … 2:00 PM (from a call)"', lp and lp[0]['title'].endswith('Cancelled 1 of 2') and lp[0]['body'].startswith("Logan's guest – Pedicure –") and '2:00 PM (from a call)' in lp[0]['body'], lp)
t = sql("SELECT body FROM outbox WHERE phone = '%s' AND kind = 'cancel'" % PH); ok('#22 ONE CANCELLED text "Still booked: 1 person (Logan)"', len(t) == 1 and 'Still booked: 1 person (Logan)' in t[0]['body'], t)
say('   list: ' + r['result']); say('   text: ' + (t[0]['body'].replace('\n', ' / ') if t else '-'))
# the same with NO words for day / time: the one party of the number is picked
PH2 = '+15555550172'; g2 = mk(PH2, 'LOGAN', d2, 15 * 60, T1, 2); o2 = mk(PH2, 'LOGAN', d1, 10 * 60, T2)[0]
r = go(23, PH2, ai(intent='cancel', customer_name='Logan', date='', time='', cancel_part=True, cancel_names=['Logan'], cancel_n=1, who_text='one person', summary='cancel one'), 'Hi my name is Logan, please cancel one person')
ok('#22b no day / time said, 2 upcoming (a party + a single one) → the PARTY is picked, its 2nd person cancelled', r['status'] == 'cancelled' and ap(g2[0])['status'] == 'booked' and ap(g2[1])['status'] == 'cancelled' and ap(o2)['status'] == 'booked', (r['status'], r['reason']))
PH3 = '+15555550173'; g3 = mk(PH3, 'LOGAN', d2, 16 * 60, T1, 2)
r = go(24, PH3, ai(intent='cancel', customer_name='Logan', date='', time='', cancel_part=True, cancel_names=['Logan'], cancel_n=1, who_text='me', summary='cancel me'), 'This is Logan, cancel me, my daughter still comes')
ok('#22c "cancel ME, my daughter still comes" → LOGAN cancelled, LOGAN +1 kept', r['status'] == 'cancelled' and ap(g3[0])['status'] == 'cancelled' and ap(g3[1])['status'] == 'booked', (r['status'], r['reason']))
PH4 = '+15555550174'; mk(PH4, 'LOGAN', d2, 16 * 60, T1, 2); mk(PH4, 'LOGAN', d1, 12 * 60, T1, 2)
r = go(25, PH4, ai(intent='cancel', customer_name='Logan', date='', time='', cancel_part=True, cancel_n=1, summary='cancel one'), 'Logan, cancel one person please')
ok('#22d two parties and no day said → not sure → nothing cancelled, Call back', r['status'] == 'callback' and len(sql("SELECT id FROM appointments WHERE phone = '%s' AND status = 'cancelled'" % PH4)) == 0, (r['status'], r['reason']))
# the words → day / time (only when the AI left both empty)
open(D + '/w596.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls-job.php'; foreach (json_decode($argv[1], true) as $t) echo json_encode(cl_said_when(['text_c' => $t], ['date' => '', 'time' => ''])) . \"\\n\";" % (A, A))
W = ["I have an appointment tomorrow at 2", "cancel my Saturday at 11:30 please", "my appointment today at 3 pm", "tomorrow at 10", "tomorrow or Monday at 2", "at 2 or at 4 tomorrow", "cancel my appointment"]
WO = [json.loads(l) for l in sh('php', D + '/w596.php', json.dumps(W)).stdout.splitlines()]
tm = (__import__('datetime').date.today() + __import__('datetime').timedelta(days=1)).isoformat(); td = time.strftime('%Y-%m-%d')
ok('words: "tomorrow at 2" → tomorrow 14:00 · "Saturday at 11:30" → 11:30 · "today at 3 pm" → today 15:00 · "tomorrow at 10" → 10:00', WO[0] == {'date': tm, 'time': '14:00'} and WO[1]['time'] == '11:30' and WO[1]['date'] != '' and WO[2] == {'date': td, 'time': '15:00'} and WO[3] == {'date': tm, 'time': '10:00'}, WO)
ok('words: 2 days or 2 times said → that part left empty (no guessing); nothing said → empty', WO[4]['date'] == '' and WO[4]['time'] == '14:00' and WO[5] == {'date': tm, 'time': ''} and WO[6] == {'date': '', 'time': ''}, WO)
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors in the server log', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:5])
say('PASS %d/%d' % (sum(R), len(R)))
sv.terminate(); fk.terminate()
