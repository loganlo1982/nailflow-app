# LAMWEB test 636H - LUAT CHUNG AN / MO (DUYET-636-AN-MO, CHAT 22:35): a salon owner who is not American Nails (shared layout, SQLite) is REFUSED on the
# SERVER for the 7 NailFlow groups (403 "NailFlow ..." + an audit row), the open pages still work, a hidden key sent UNCHANGED is ignored (Save works);
# American Nails (main), a NailFlow support session and the old single copy: as before. Part 1 = CHAT's QA-CHAT/p1_hide.py (same 14 checks).
#   python3 t636h.py <app folder>
import subprocess, json, os, sys, time, shutil, urllib.request, urllib.error, re
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T636H'; PORT = 19893; BASE = 'http://127.0.0.1:%d' % PORT
R = []; out = open(D + '/test-636h.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:300]))
ENV = {**os.environ, 'TZ': 'America/Chicago'}
E = D + '/env'; shutil.rmtree(E, ignore_errors=True); app = E + '/app'; REL = app + '/releases/v'
shutil.copytree(A0, REL, symlinks=True, ignore=shutil.ignore_patterns('config.php', 'uploads', 'sessions'))
lines = []
for i in range(1, 6):
    sid = 's%03d' % i; web = E + '/web/' + sid; sd = app + '/sites/' + sid
    os.makedirs(web + '/uploads'); os.makedirs(sd + '/data'); shutil.copy('/tmp/claude-0/tdb/base.sqlite', sd + '/data/db.sqlite')
    open(sd + '/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s/data/db.sqlite','site_url'=>'http://%s.qa.test'%s);\n" % (sd, sid, ", 'noindex'=>true" if i > 1 else ''))
    lines.append("  '%s' => ['hosts' => ['%s.qa.test'], 'web' => '%s', 'cron' => [], 'main' => %s]," % (sid, sid, web, 'true' if i == 1 else 'false'))
open(app + '/sites.php', 'w').write("<?php\nreturn [\n" + "\n".join(lines) + "\n];\n")
def php(S, code, sess=''):
    r = subprocess.run(['php', '-d', 'error_log=/dev/null', '-r', 'require "%s/inc/core.php"; %s settings(); %s' % (REL, sess, code)], capture_output=True, text=True, env={**ENV, 'SALON_ID': S})
    return (r.stdout + r.stderr).strip()
def req(S, a, body=None, ck=None, cs=None):
    h = {'Host': S + '.qa.test', 'Content-Type': 'application/json'}; h.update({'Cookie': ck} if ck else {}); h.update({'X-CSRF': cs} if cs else {})
    rq = urllib.request.Request(BASE + '/api.php?action=' + a, data=None if body is None else json.dumps(body).encode(), headers=h)
    try: r = urllib.request.urlopen(rq, timeout=30); return r.status, r.read().decode()[:20000], r.headers.get_all('Set-Cookie') or []
    except urllib.error.HTTPError as e: return e.code, e.read().decode()[:20000], []
def login(S, hq='1'):
    pw = 'qa-hide-' + os.urandom(3).hex()
    php(S, 'set_setting("admin_hash", password_hash(%r, PASSWORD_DEFAULT)); set_setting("admin_totp_on","0"); set_setting("as_hq_only",%r); q("DELETE FROM login_attempts");' % (pw, hq))
    c, b, sc = req(S, 'login', {'password': pw}); ck = '; '.join(x.split(';')[0] for x in sc)
    return c, b, ck, (json.loads(b).get('csrf', '') if c == 200 else '')
srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', REL], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=ENV); time.sleep(1.2)
try:
    say('== LAMWEB test 636H - LUAT CHUNG AN / MO ' + time.strftime('%Y-%m-%d %H:%M %Z'))
    S = 's005'; c, b, ck, cs = login(S)
    ok('1.0 p1_hide: chu tiem thuong (s005, as_hq_only=1) dang nhap', c == 200, (c, b))
    HIDE = {'1 may Android': [('autosend_save', {'iphone': '5550009999'}), ('autosend_device', {}), ('android_test', {})],
            '2 AI Telnyx': [('tx_setup', {}), ('calls_cfg', {'call_on': 0})], '3 the/PayPal': [('dep_test', {})],
            '5 sao luu': [('backup_key', None), ('backup_now', {})], '6 noi bo': [('qa_set', {}), ('test_mode_start', {})]}
    for g, acts in HIDE.items():
        for a, body in acts:
            c, b, _ = req(S, a, body, ck, cs); ok('1 p1_hide AN %s: %s -> bi tu choi' % (g, a), c in (401, 403) or 'NailFlow' in b, (c, b))
    c, b, _ = req(S, 'save_settings', {'paypal_client_id': 'X', 'sw_token': 'X', 'tx_key': 'X', 'sms_footer': 'no stop'}, ck, cs)
    v = php(S, 'echo setting("paypal_client_id"), "|", setting("sms_footer");')
    ok('1 p1_hide AN 3+4: save_settings khong doi PayPal key / dong STOP', 'X' not in v.split('|')[0] and 'no stop' not in v, (c, b, v))
    for a, body in [('save_settings', {'salon_name': 'QA SALON S005 MOI'}), ('save_staff_one', {'id': 0, 'name': 'QAHIDE', 'skillAll': 1})]:
        c, b, _ = req(S, a, body, ck, cs); ok('1 p1_hide MO: %s van dung duoc' % a, c == 200, (c, b))
    # 2 the refusal itself
    c, b, _ = req(S, 'backup_now', {}, ck, cs)
    ok('2 refused = 403 with "NailFlow quản lý" (not some other error)', c == 403 and 'NailFlow quản lý' in json.loads(b).get('error', ''), (c, b))
    cnt = lambda: php(S, 'echo q("SELECT COUNT(*) FROM audit_log WHERE kind = \'nf_only\' AND target = \'backup_now\'")->fetchColumn();')
    x0 = cnt(); req(S, 'backup_now', {}, ck, cs); x1 = cnt()
    ok('2 each refusal leaves an audit row (kind nf_only, target = the action)', x0.isdigit() and x1.isdigit() and int(x1) == int(x0) + 1 and int(x0) >= 1, (x0, x1))
    for a, body in [('stop_del_all', {}), ('test_clear', {}), ('autosend_save', {'iphone': ''}), ('fcm_key', {})]:
        c, b, _ = req(S, a, body, ck, cs); ok('2 also refused: %s' % a, (c == 403 and 'NailFlow' in b) or (a == 'stop_del_all' and c == 410), (c, b)) # stop_del_all: gone since 2.99.251 (410) - refused either way
    # 3 Save keeps working: the hidden keys sent back unchanged (the Settings page sends the whole form) are ignored
    cur = php(S, 'echo json_encode(["p" => setting("paypal_client_id"), "f" => setting("sms_footer"), "m" => setting("paypal_mode")]);'); cur = json.loads(cur)
    c, b, _ = req(S, 'save_settings', {'salon_name': 'QA SALON S005 B', 'paypal_client_id': cur['p'], 'paypal_secret': '', 'sms_footer': cur['f'], 'paypal_mode': cur['m']}, ck, cs)
    v = php(S, 'echo setting("salon_name");')
    ok('3 Save with the hidden keys UNCHANGED (+ an empty secret) -> 200 and the salon name saved', c == 200 and v == 'QA SALON S005 B', (c, b, v))
    c, b, _ = req(S, 'save_settings', {'salon_name': 'QA SALON S005 C', 'stop_hook_on': '0' if php(S, 'echo setting("stop_hook_on");') == '1' else '1'}, ck, cs)
    v = php(S, 'echo setting("salon_name");')
    ok('3 a CHANGED hidden key -> 403 and nothing of that Save written', c == 403 and v == 'QA SALON S005 B', (c, b, v))
    # 4 open stays open
    for a, body in [('calls_list', None), ('calls_cfg', None), ('activity', None), ('checkin_newkey', {}), ('sms_preview_all', None)]:
        c, b, _ = req(S, a, body, ck, cs); ok('4 OPEN for the owner: %s -> 200' % a, c == 200, (c, b))
    c, b, _ = req(S, 'me', None, ck, cs); j = json.loads(b) if c == 200 else {}
    ok('4 me: nfOnly = true, asDev = false (status line "NailFlow sẽ cài giúp")', j.get('nfOnly') is True and j.get('asDev') is False, (c, b))
    # 5 a new salon on SQLite with as_hq_only NOT set (sqlite default = off): still refused (nf_only works on SQLite)
    c, b, ck4, cs4 = login('s004', '')
    c, b, _ = req('s004', 'autosend_save', {'iphone': '5550001111'}, ck4, cs4)
    v = php('s004', 'echo setting("as_iphone");')
    ok('5 s004 (SQLite, as_hq_only unset): autosend_save refused, the texting number not written', c == 403 and '5550001111' not in v, (c, b, v))
    c, b, _ = req('s004', 'calls_cfg', {'call_on': 1}, ck4, cs4); ok('5 s004: calls_cfg POST refused', c == 403, (c, b))
    # 6 American Nails (main): as before
    c, b, ck1, cs1 = login('s001', '0')
    c, b, _ = req('s001', 'calls_cfg', {'call_on': 0}, ck1, cs1); ok('6 American Nails (main): calls_cfg POST works (200)', c == 200, (c, b))
    c, b, _ = req('s001', 'save_settings', {'sms_footer': 'Reply STOP to end'}, ck1, cs1); v = php('s001', 'echo setting("sms_footer");')
    ok('6 American Nails: save_settings sms_footer works', c == 200 and v == 'Reply STOP to end', (c, b, v))
    c, b, _ = req('s001', 'me', None, ck1, cs1); ok('6 American Nails: me nfOnly = false', c == 200 and json.loads(b).get('nfOnly') is False, (c, b))
    # 7 a NailFlow support session / qa-bot on that salon: not refused
    x = php(S, 'echo nf_only() ? 1 : 0, "|"; $_SESSION["support"] = ["until" => time() + 600]; echo nf_only() ? 1 : 0, "|"; unset($_SESSION["support"]); $_SESSION["qa"] = 1; echo nf_only() ? 1 : 0;', 'require_once "%s/inc/support.php"; $_SESSION = ["admin" => 1];' % REL)
    ok('7 nf_only(): owner 1 | NailFlow support session 0 | qa-bot 0', x == '1|0|0', x)
    old = D + '/old'; shutil.rmtree(old, ignore_errors=True); shutil.copytree(A0, old, symlinks=True); db = D + '/old.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', db)
    open(old + '/inc/config.php', 'w').write("<?php\nreturn ['driver' => 'sqlite', 'sqlite_path' => '%s', 'site_url' => 'http://127.0.0.1:1'];\n" % db)
    r = subprocess.run(['php', '-r', 'require "%s/inc/core.php"; require_once "%s/inc/support.php"; echo function_exists("nf_only") ? (nf_only() ? 1 : 0) : "none";' % (old, old)], capture_output=True, text=True, env=ENV)
    ok('7 the old single copy (not shared): nf_only() = 0', r.stdout.strip() == '0', r.stdout + r.stderr)
    # 8 Getting started "Máy gửi tin": NailFlow sets it up, ✓ by itself when connected
    g = 'require_once getenv("NFR") . "/inc/getstarted.php"; foreach (gs_list()["items"] as $i) if ($i["k"] === "texts") echo json_encode($i, JSON_UNESCAPED_UNICODE);'
    os.environ['NFR'] = REL; ENV['NFR'] = REL
    x = php('s003', g); j = json.loads(x) if x.startswith('{') else {}
    ok('8 Getting started "Máy gửi tin": "NailFlow sẽ cài giúp", no Settings page to open, not "Mark done"', 'NailFlow sẽ cài giúp' in j.get('hv', '') and j.get('go') == '' and j.get('manual') is False and j.get('done') is False, x)
    x = php('s003', 'set_setting("as_device", "android"); settings(true); ' + g); j = json.loads(x) if x.startswith('{') else {}
    ok('8 ... and ✓ by itself once the Android is connected', j.get('done') is True, x)
    # 9 the screens
    rd = lambda f: open(REL + '/' + f, encoding='utf-8').read()
    m = re.search(r"var SUP_ONLY = new Set\(\[(.*?)\]\);", rd('assets/admin-core.js')); su = re.findall(r"'([a-z]+)'", re.sub(r'/\*.*?\*/', '', m.group(1))) if m else []
    ok('9 only NailFlow-only pages hidden: SUP_ONLY = ash asend backup testmode test (apps checkin desk look receipt activity pay sms salon calls ... open)', sorted(su) == sorted(['ash', 'asend', 'backup', 'testmode', 'test']), su)
    ok('9 nf-only.js loads with Settings (LAZY_FILES)', "'nf-only'" in rd('assets/admin-core.js') and os.path.exists(REL + '/assets/admin/nf-only.js'), '')
    bl = [l for l in rd('assets/admin/boot.js').split('\n') if 'S.support = me.support' in l]
    ok('9 boot.js: S.support / supBar() really run (not after a // comment) + S.nfOnly', bool(bl) and '//' not in bl[0].split('S.support = me.support')[0] and 'S.nfOnly = !!me.nfOnly' in bl[0], bl[:1])
    nj = rd('assets/admin/nf-only.js') if os.path.exists(REL + '/assets/admin/nf-only.js') else ''
    ok('9 status lines: Text messages "Máy gửi tin" + "NailFlow sẽ cài giúp", PayPal, backups, phone AI', all(t in nj for t in ['Máy gửi tin', 'NailFlow sẽ cài giúp', 'Sao lưu gần nhất', 'AI điện thoại']), '')
    ok('9 Text messages: the "Auto send (Android)" button is not shown to the owner of a salon that is not the main one', '!(S.nfOnly && !S.support)' in rd('assets/admin/settings-texts.js'), '')
    ok('9 check-in / desk new link: the 2nd tap says the iPad in use must open the new link', rd('assets/admin/settings-salon.js').count('iPad đang dùng sẽ phải mở link mới') == 2, '')
finally:
    srv.terminate()
say('PASS %d/%d' % (sum(R), len(R)))
