# LAMWEB test 632 – the salon setup link (/setup/?t=): token, own address only, allowed keys only, the SAME save code as Settings / Staff, undo.
#   python3 t632.py <app folder>      Local copies, SQLite of their own, 2 salons (A + B), nothing real.
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, http.cookiejar, re
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T632'; T5 = '/tmp/claude-0/T586'; PA, PB = 19957, 19958
R = []; out = open(D + '/test-632.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
S = {}
def mk(tag, port):
    app = D + '/app' + tag; db = D + '/db' + tag + '.sqlite'; shutil.rmtree(app, ignore_errors=True); shutil.copytree(A0, app, symlinks=True); shutil.copy('/tmp/claude-0/tdb/base.sqlite', db)
    seed = json.loads(sh('php', T5 + '/seed.php', app, db, str(port)).stdout); h = D + '/h' + tag + '.php'
    open(h, 'w').write("""<?php require '%s/inc/core.php'; settings(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'get') { $k = json_decode($argv[2], true); echo json_encode(array_combine($k, array_map('setting', $k))); }
if ($a === 'hash') { echo password_hash($argv[2], PASSWORD_DEFAULT); }
if ($a === 'cfg') { require_once '%s/inc/turnq.php'; echo json_encode(tq_cfg()); }
""" % (app, app))
    sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', app, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php' + tag + '.log', 'w'))
    atexit.register(sv.terminate); return {'app': app, 'db': db, 'h': h, 'port': port, 'seed': seed}
X = {'A': mk('A', PA), 'B': mk('B', PB)}; time.sleep(1.3)
def h(t, *a):
    r = sh('php', X[t]['h'], *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
def sql(t, q): r = sh('php', T5 + '/db.php', X[t]['db'], q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
def api(t, action, body=None, jar=None, csrf=None, host=None, get=None):
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)) if jar is not None else urllib.request.build_opener()
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': csrf} if csrf else {}); hd.update({'Host': host} if host else {})
    u = 'http://127.0.0.1:%d/api.php?action=%s%s' % (X[t]['port'], action, get or '')
    rq = urllib.request.Request(u, data=None if body is None else json.dumps(body).encode(), headers=hd)
    try: r = op.open(rq, timeout=60); b = r.read().decode(); return r.status, (json.loads(b or '{}') if b.strip().startswith('{') else {'_raw': b[:300]})
    except urllib.error.HTTPError as e:
        b = e.read().decode()
        try: return e.code, json.loads(b or '{}')
        except Exception: return e.code, {'_raw': b[:300]}
PW = 'adm632-' + os.urandom(4).hex()
ALLDAY = {str(w): {'open': '09:00', 'close': '21:00'} for w in range(7)}
for t, nm in (('A', 'AMERICAN NAILS TEST'), ('B', 'SALON B TEST')):
    h(t, 'set', json.dumps({'admin_hash': h(t, 'hash', PW), 'salon_name': nm, 'hours': json.dumps(ALLDAY), 'turn_req_mode': 'half', 'turn_count_req': '1', 'turn_min': '25', 'turn_hold_min': '15',
        'turn_skip_max': '3', 'turn_tie': 'clock', 'turn_under': 'bonus', 'turn_multi': 'cust', 'turn_rare_keep': '1', 'turn_pre_open': '1', 'turn_auto_on': '1', 'ck_pick_tech': '0', 'turn_half_svcs': '', 'payroll_week_start': '0'}))
sql('A', "UPDATE staff SET commission_pct = 40, pay_method = 'check', notify = 1, online_hours = '{\"1\":[\"10:00\",\"18:00\"]}' WHERE name = 'TAMMY'")
sql('A', "UPDATE staff SET notify = 1, pay_method = 'cash', pay_note = 'old note', off_days = '2', mix_check_pct = 70, online = 0 WHERE name = 'HANA'")
def login(t):
    j = http.cookiejar.CookieJar(); c, r = api(t, 'login', {'password': PW}, j); return j, r.get('csrf')
say('== LAMWEB test 2.99.632 – LENH 632 salon setup link ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · 2 local salons (A, B), SQLite, nothing real')
JA, CA = login('A'); JB, CB = login('B')
c, r = api('A', 'setup_new', {}, JA, CA); url = r.get('url', ''); tok = (re.search(r'[?&]t=([0-9a-f]+)', url) or [None, ''])[1]
ok('1 owner: Settings -> "Make a setup link" -> link on the salon\'s OWN address (pub_url) /setup/?t=<64 hex>', c == 200 and url.startswith('http://127.0.0.1:%d/setup/?t=' % PA) and len(tok) == 64, (c, r))
c2, r2 = api('A', 'setup_new', {}, None, None); ok('1 without the owner login -> 401 (nobody else makes links)', c2 == 401, (c2, r2))
st = h('A', 'get', json.dumps(['setup_link'])); ok('1 the token itself is never kept (only its sha256)', tok and tok not in json.dumps(st), st)
c, I = api('A', 'setup_info', get='&t=' + tok)
cur = I.get('turn', {})
ok('2 good token -> the salon name + logo + the CURRENT turn settings (not the defaults: req half, $25, bonus, hold 15, skip 3)', c == 200 and I.get('salon') == 'AMERICAN NAILS TEST' and cur.get('turn_req_mode') == 'half' and float(cur.get('turn_min', 0)) == 25 and cur.get('turn_under') == 'bonus' and cur.get('turn_hold_min') == 15 and cur.get('turn_skip_max') == 3, (c, I))
ok('2 the techs of THIS salon (TAMMY, HANA, SISI) with commission / skills, no PIN', [s['name'] for s in I.get('staff', [])] == ['TAMMY', 'HANA', 'SISI'] and not any('pin' in json.dumps(s).lower() for s in I.get('staff', [])), I.get('staff'))
for nm, g, hst in [('a wrong token', '&t=' + 'f' * 64, None), ('no token', '', None), ('another address (Host evil.example)', '&t=' + tok, 'evil.example'), ('localhost instead of the salon address', '&t=' + tok, 'localhost:%d' % PA)]:
    c, r = api('A', 'setup_info', get=g, host=hst); ok('2 %s -> 403, says nothing about the salon' % nm, c == 403 and 'AMERICAN' not in json.dumps(r), (c, r))
c, r = api('B', 'setup_info', get='&t=' + tok); ok('2 salon A\'s token on salon B -> 403', c == 403 and 'SALON B' not in json.dumps(r), (c, r))
c, r = api('B', 'setup_turn', {'t': tok, 'turn_req_mode': 'none'}); ok('2 salon A\'s token writing salon B -> 403, B unchanged', c == 403 and h('B', 'get', '["turn_req_mode"]')['turn_req_mode'] == 'half', (c, r))
try: pg = urllib.request.urlopen('http://127.0.0.1:%d/setup/?t=%s' % (PA, 'f' * 64)).read().decode()
except Exception as e: pg = 'ERR ' + str(e)
ok('2 the page /setup/ (200, noindex, no-referrer) has nothing of the salon in it', 'AMERICAN' not in pg and 'no-referrer' in pg and 'noindex' in pg, pg[:200])
# 3 a wrong value -> refused exactly like Settings, nothing saved, the link still works
c, r = api('A', 'setup_turn', {'t': tok, 'turn_min': 5000, 'turn_req_mode': 'none'})
ok('3 $ for 1 turn = 5000 -> 400 with the SAME words as Settings -> Turn rules; nothing saved', c == 400 and r.get('error') == 'Turn rules: $ for 1 turn must be 0 – 1000.' and h('A', 'get', '["turn_req_mode"]')['turn_req_mode'] == 'half', (c, r))
c, r = api('A', 'setup_info', get='&t=' + tok); ok('3 the link still works after a refused save', c == 200 and 'turn' not in r.get('done', []), (c, r.get('done')))
# 4 save: allowed keys only
before = h('A', 'get', json.dumps(['salon_name', 'admin_hash', 'turn_half_svcs', 'turn_none_svcs', 'turn_x_la', 'online_booking']))
body = {'t': tok, 'turn_req_mode': 'none', 'turn_min': 30, 'turn_under': 'half', 'turn_multi': 'svc', 'turn_svc_amt': 35, 'turn_hold_min': 25, 'turn_skip_max': 1, 'turn_brk_max': 45, 'turn_tie': 'done',
        'turn_rare_keep': 0, 'turn_pre_open': 0, 'turn_auto_on': 1, 'ck_pick_tech': 1, 'notes': [{'q': 'q10', 'pick': 'giveback', 'text': 'tra turn'}],
        'salon_name': 'HACKED', 'admin_hash': 'x', 'turn_half_svcs': [1, 2], 'turn_none_svcs': [3], 'turn_x_la': '1', 'online_booking': '0', 'sms_confirm': 'spam'}
c, r = api('A', 'setup_turn', body); after = h('A', 'get', json.dumps(list(before.keys())))
cfg = h('A', 'cfg'); got = h('A', 'get', json.dumps(['turn_req_mode', 'turn_count_req', 'turn_min', 'turn_under', 'turn_multi', 'turn_svc_amt', 'turn_hold_min', 'turn_skip_max', 'turn_brk_max', 'turn_tie', 'turn_rare_keep', 'turn_pre_open', 'ck_pick_tech', 'turn_setup_notes']))
ok('4 save -> 200; every allowed key written (req none -> count_req 0, $30 half, svc $35, hold 25, skip 1, break 45, tie done, rare 0, pre-open 0, kiosk pick 1)', c == 200 and got['turn_req_mode'] == 'none' and got['turn_count_req'] == '0' and got['turn_min'] == '30' and got['turn_under'] == 'half'
   and got['turn_multi'] == 'svc' and got['turn_svc_amt'] == '35' and got['turn_hold_min'] == '25' and got['turn_skip_max'] == '1' and got['turn_brk_max'] == '45' and got['turn_tie'] == 'done' and got['turn_rare_keep'] == '0' and got['turn_pre_open'] == '0' and got['ck_pick_tech'] == '1', (c, r, got))
ok('4 NOT allowed keys dropped (salon_name, admin_hash, turn_half_svcs, turn_none_svcs, turn_x_la, online_booking, sms_confirm)', before == after and h('A', 'get', '["sms_confirm"]')['sms_confirm'] != 'spam', (before, after))
ok('4 the turn line now uses the new rules (tq_cfg: reqMode none, min 30, multi svc, tie done, rareKeep off)', cfg.get('reqMode') == 'none' and float(cfg.get('min', 0)) == 30 and cfg.get('multi') == 'svc' and cfg.get('tie') == 'done' and cfg.get('rareKeep') is False, cfg)
ok('4 what the app does not have yet -> turn_setup_notes (q10 giveback)', 'giveback' in (got.get('turn_setup_notes') or ''), got.get('turn_setup_notes'))
au = sql('A', "SELECT kind, target, before_v, after_v FROM audit_log WHERE kind = 'turn_setup' ORDER BY id") if not isinstance(sql('A', "SELECT 1 FROM audit_log LIMIT 1"), tuple) else []
if isinstance(au, tuple) or not au: au = sql('A', "SELECT * FROM audit WHERE kind = 'turn_setup' ORDER BY id")
ok('4 audit: each changed key old -> new ("turn_setup")', isinstance(au, list) and any('turn_req_mode' in json.dumps(x) and 'half' in json.dumps(x) for x in au), au if isinstance(au, tuple) else au[:3])
ev = sql('A', "SELECT kind, text FROM events WHERE target = 'admin' AND kind = 'setup'"); ok('4 the owner gets 1 notification "Turn rules updated through the setup link"', isinstance(ev, list) and len(ev) == 1 and 'setup link' in ev[0]['text'], ev)
c, r = api('A', 'setup_turn', {'t': tok, 'turn_req_mode': 'count'}); ok('4 the turn part again -> 409 (saved once), nothing changed', c == 409 and h('A', 'get', '["turn_req_mode"]')['turn_req_mode'] == 'none', (c, r))
# 5 staff
tm = sql('A', "SELECT id FROM staff WHERE name = 'TAMMY' AND active = 1")[0]['id']; si = sql('A', "SELECT id FROM staff WHERE name = 'SISI' AND active = 1")[0]['id']
def one(**b): return api('A', 'setup_staff_one', {'t': tok, **b})
c, r = one(id=0, name='hana', skillAll=1, commission=50); ok('5 new tech with the name of another tech (HANA) -> 400 "already has the name"', c == 400 and 'HANA' in r.get('error', ''), (c, r))
c, r = one(id=0, name='MAI', phone='12345', skillAll=1, commission=50); ok('5 phone 12345 -> 400 (the Staff screen\'s words: 10 digits)', c == 400 and '10 digits' in r.get('error', ''), (c, r))
c, r = one(id=0, name='MAI', skillAll=1, commission=150); ok('5 commission 150 -> 400 "0 to 100%"', c == 400 and '0 to 100' in r.get('error', ''), (c, r))
c, r = one(id=0, name='MAI', skillAll=0, skillCats=[], commission=50); ok('5 no services -> 400', c == 400 and 'kind of service' in r.get('error', ''), (c, r))
c, r = one(id=99999, name='GHOST', skillAll=1, commission=50); ok('5 an id that is not a tech of this salon (another salon\'s) -> 404, nothing written', c == 404 and not sql('A', "SELECT 1 FROM staff WHERE name = 'GHOST'"), (c, r))
ok('5 none of the refused ones made a tech', not sql('A', "SELECT 1 FROM staff WHERE name IN ('MAI', 'HANA') AND id > 3 AND name = 'MAI'"), sql('A', "SELECT id, name FROM staff"))
c, r = one(id=0, name='mai', phone='515-555-0123', offDays=[1], skillAll=1, commission=55, payMethod='mix', mixCheck=60, online=1, deskOk=1, voice='vi', payNote='new', pin='1234', pin_hash='x')
m = sql('A', "SELECT * FROM staff WHERE name = 'MAI'")
ok('5 new tech MAI: phone, day off Mon, 55%, mix 60% check, online, front desk, VI voice; the PIN sent is IGNORED (no PIN)', c == 200 and m and m[0]['phone'] == '+15155550123' and m[0]['off_days'] == '1' and float(m[0]['commission_pct']) == 55 and m[0]['pay_method'] == 'mix'
   and float(m[0]['mix_check_pct']) == 60 and int(m[0]['desk_ok']) == 1 and m[0]['pin_hash'] == '', (c, r, m))
c, r = one(id=tm, name='TAMMY', skillAll=1, commission=60, payMethod='check')
t1 = sql('A', "SELECT commission_pct, pct_hist FROM staff WHERE id = %d" % tm)[0]
ok('5 TAMMY 40% -> 60%: saved by the Staff code (payroll history keeps 40% for the earlier weeks)', c == 200 and float(t1['commission_pct']) == 60 and '40' in str(t1['pct_hist']), (c, r, t1))
t2 = sql('A', "SELECT notify, online_hours FROM staff WHERE id = %d" % tm)[0]; m2 = sql('A', "SELECT notify FROM staff WHERE name = 'MAI'")
ok('5 (SUA-632) TAMMY edited through the link: "Send this tech alerts" stays ON, online hours unchanged', int(t2['notify']) == 1 and '10:00' in str(t2['online_hours']), t2)
ok('5 (SUA-632) new tech MAI: alerts ON (like + Add in Staff)', m2 and int(m2[0]['notify']) == 1, m2)
hn = sql('A', "SELECT id FROM staff WHERE name = 'HANA'")[0]['id']
c, r = one(id=hn, name='HANA', commission=45)
h2 = sql('A', "SELECT notify, pay_method, pay_note, off_days, mix_check_pct, online, skill_all FROM staff WHERE id = %d" % hn)[0]
ok('5 (SUA-632) HANA: only name + commission sent -> everything not sent stays (alerts, cash, note, day off Tue, 70%% check, not online)', c == 200 and int(h2['notify']) == 1 and h2['pay_method'] == 'cash' and h2['pay_note'] == 'old note' and h2['off_days'] == '2' and float(h2['mix_check_pct']) == 70 and int(h2['online']) == 0, (c, r, h2))
c, r = api('A', 'setup_staff_off', {'t': tok, 'id': si}); s1 = sql('A', "SELECT active FROM staff WHERE id = %d" % si)
ok('5 SISI "no longer works here" -> turned off, NOT deleted (history / pay kept)', c == 200 and s1 and int(s1[0]['active']) == 0, (c, r, s1))
c, r = api('A', 'setup_shop', {'t': tok, 'payroll_week_start': 1, 'closed': [0], 'hours': {'1': {'open': '01:00', 'close': '02:00'}}})
hh = json.loads(h('A', 'get', '["hours"]')['hours']); hh = {str(i): v for i, v in enumerate(hh)} if isinstance(hh, list) else hh; wk = h('A', 'get', '["payroll_week_start"]')['payroll_week_start']
ok('5 salon: week starts Monday + closed Sunday; the opening TIMES cannot be changed by the link', c == 200 and wk == '1' and hh['0']['closed'] is True and hh['1']['open'] == '09:00' and hh['1']['close'] == '21:00', (c, r, wk, hh.get('0'), hh.get('1')))
c, r = api('A', 'setup_staff_end', {'t': tok}); ok('5 staff part saved -> 200 + notification', c == 200 and len(sql('A', "SELECT 1 FROM events WHERE kind = 'setup'")) == 2, (c, r))
c, r = api('A', 'setup_info', get='&t=' + tok); ok('5 both parts saved -> the link is used up (403)', c == 403, (c, r))
c, r = api('A', 'setup_staff_one', {'t': tok, 'id': 0, 'name': 'LATE', 'skillAll': 1, 'commission': 50}); ok('5 used link cannot add a tech', c == 403 and not sql('A', "SELECT 1 FROM staff WHERE name = 'LATE'"), (c, r))
# 6 undo (the owner, with the SAME actions as the screens)
c, P = api('A', 'setup_prev', None, JA, CA, get='')
ok('6 Settings "Undo the link setup": the old turn values (req half, $25, bonus...) + the old techs + the new tech id + the old week / hours', c == 200 and P.get('turn', {}).get('turn_req_mode') == 'half' and str(tm) in (P.get('staff') or {}).get('rows', {}) and len((P.get('staff') or {}).get('new', [])) == 1 and (P.get('staff') or {}).get('shop'), (c, P))
P = P if P.get('staff') else {'turn': {}, 'staff': {'rows': {}, 'new': [], 'shop': {}}}
c1, _ = api('A', 'save_settings', P['turn'], JA, CA)
for x in P['staff']['rows'].values(): api('A', 'save_staff_one', x, JA, CA)
for i in P['staff']['new']: api('A', 'remove_staff', {'id': i}, JA, CA)
c3, _ = api('A', 'save_settings', P['staff']['shop'], JA, CA)
g = h('A', 'get', json.dumps(['turn_req_mode', 'turn_min', 'turn_under', 'turn_multi', 'turn_hold_min', 'turn_skip_max', 'turn_tie', 'payroll_week_start']))
ok('6 after undo: turn back (half, $25, bonus, cust, hold 15, skip 3, clock), TAMMY back to 40%, MAI off, week Sunday', c1 == 200 and c3 == 200 and g == {'turn_req_mode': 'half', 'turn_min': '25', 'turn_under': 'bonus', 'turn_multi': 'cust', 'turn_hold_min': '15', 'turn_skip_max': '3', 'turn_tie': 'clock', 'payroll_week_start': '0'}
   and float(sql('A', "SELECT commission_pct FROM staff WHERE id = %d" % tm)[0]['commission_pct']) == 40 and int(sql('A', "SELECT active FROM staff WHERE name = 'MAI'")[0]['active']) == 0, (g, sql('A', "SELECT name, commission_pct, active FROM staff")))
# 7 a new link stops the old one; expired
c, r = api('A', 'setup_new', {}, JA, CA); t2 = r.get('url', 't=x').split('t=')[1]; c, r = api('A', 'setup_new', {}, JA, CA); t3 = r.get('url', 't=x').split('t=')[1]
c1, _ = api('A', 'setup_info', get='&t=' + t2); c2, _ = api('A', 'setup_info', get='&t=' + t3)
ok('7 a new link -> the previous one 403, the new one 200', c1 == 403 and c2 == 200, (c1, c2))
L = json.loads(h('A', 'get', '["setup_link"]')['setup_link'] or '{}'); L['exp'] = int(time.time()) - 5; h('A', 'set', json.dumps({'setup_link': json.dumps(L)}))
c, r = api('A', 'setup_info', get='&t=' + t3); ok('7 after 7 days (expired) -> 403', c == 403, (c, r))
logs = open(D + '/phpA.log').read() + open(D + '/phpB.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
