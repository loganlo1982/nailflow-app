# LAMWEB test 626 – KIEM TOAN BO HE THONG TIEN: 15 tinh huong quay (so tien vao -> mong doi -> thuc te), khop so (hoa don / tip / commission / $1 / payroll / close day / void / refund),
#   B1-B4 dong thoi + rollback (SQLite; MySQL: xem BAO-CAO-626). Ban sao + SQLite rieng, khach 555-01xx, khong tien / the / gift card that.
# Local copy, SQLite of its own, nothing real (no PayPal / SMS / card). Every check reads the DB (receipts, appointments, giftcards, customers) itself.
#   python3 t619m.py <app folder>
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, threading, http.cookiejar, datetime as _dt, glob
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T626'; T5 = '/tmp/claude-0/T586'; PORT = 19947; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-626.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
A = D + '/app'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True)
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; T = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA, HA = T['TAMMY'], T['HANA']
H = D + '/h626.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'hash') { echo password_hash($argv[2], PASSWORD_DEFAULT); }
if ($a === 'sig') { $p = json_decode($argv[3], true); ksort($p); $t = ''; foreach ($p as $k => $v) $t .= $k . $v; echo base64_encode(hash_hmac('sha1', $argv[2] . $t, setting('twilio_token'), true)); }
""" % A)
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
PW = 'adm619-' + os.urandom(4).hex()
h('set', json.dumps({'admin_hash': h('hash', PW), 'gift_on': '1', 'hours': json.dumps({str(w): {'open': '09:00', 'close': '21:00'} for w in range(7)})}))
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '6'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w'))
atexit.register(lambda: sv.terminate()); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
say('== LAMWEB test 626 (he thong tien) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
TODAY = time.strftime('%Y-%m-%d')
def mk(ph, name, staff, sid, start):
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', '%s', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), '%s')" % (TODAY, start, staff, sid, name, ph, os.urandom(8).hex()))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def price(sid): return float(sql("SELECT price FROM services WHERE id = %d" % sid)[0]['price'])
def pay(aid, sid, staff, pays, **k):
    b = {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid, 'price': price(sid), 'staff': staff}], 'pays': pays}; b.update(k); return api('checkout2', b)
def st(aid): return sql("SELECT status FROM appointments WHERE id = %d" % aid)[0]['status']
def nrc(): return int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n'])
P = price(PD)
FS = S['Full Set']; SI = T['SISI']
PR = {sid: price(sid) for sid in (PD, GM, FS)}   # Pedicure 35, Gel Manicure 40, Full Set 50 (test menu)
sql("UPDATE staff SET commission_pct = 60, pct_hist = '' WHERE id = %d" % TA); sql("UPDATE staff SET commission_pct = 50, pct_hist = '' WHERE id = %d" % HA)
h('set', json.dumps({'admin_fee_on': '1', 'admin_fee_staff': str(SI), 'admin_fee_min': '39', 'admin_fee_amt': '1', 'payroll_split_on': '0', 'tax_pct': '0'}))
TAB = []   # the 15 cases: no | case | money in | expected | actual | PASS/FAIL
def case(no, name, money, want, got, cond):
    TAB.append((no, name, money, want, got, 'PASS' if cond else 'FAIL')); ok('D%02d %s' % (no, name), cond, 'mong doi: %s | thuc te: %s' % (want, got))
NUM = [100]
def new(name, staff, sid):
    NUM[0] += 1; return mk('+151555501%02d' % NUM[0], name, staff, sid, 540 + NUM[0] * 5)
def co(aid, lines, pays, splits=None, **k):
    ls = [{'appt': aid, 'sid': sid, 'price': p, 'staff': st} for sid, st, p in lines]
    sp = splits if splits is not None else [{'staff': st, 'amt': p} for sid, st, p in lines]
    b = {'ids': [aid], 'lines': ls, 'pays': pays, 'splits': sp}; b.update(k); return api('checkout2', b)
def rc(rid): x = sql("SELECT * FROM receipts WHERE id = %d" % rid); return x[0] if x else {}
def rid_of(r): return int(((r or {}).get('receipt') or {}).get('id', 0))
def gbal(code): x = sql("SELECT balance FROM giftcards WHERE code = '%s'" % code); return round(float(x[0]['balance']), 2) if x else None
def shares(r): return {int(x['staff']): x for x in json.loads(r.get('pay_splits') or '[]')}
def gift(code, amt): sql("INSERT INTO giftcards (code, amount, balance, status, buyer_phone, to_phone, created_at) VALUES ('%s', %s, %s, 'active', '+15155550190', '', datetime('now'))" % (code, amt, amt))
R1 = {}
# ---------- D: 15 cases at the desk (the same JSON the Checkout screen sends: lines + splits + pays + tips) ----------
a = new('D ONE', TA, PD); c, r = co(a, [(PD, TA, 35)], [{'m': 'Cash', 'amt': 35, 'given': 40}]); x = rc(rid_of(r)); R1[1] = x
case(1, '1 ve 1 tho, tien mat', 'Pedicure 35 · khach dua 40', 'hoa don 35, tien mat 35, thoi 5, TAMMY 35 (duoi 39: khong $1)',
     '%s, cash %s, thoi %s, TAMMY %s' % (x.get('total'), x.get('cash_amt'), (json.loads(x.get('pays') or '[{}]')[0]).get('change'), shares(x).get(TA, {}).get('amt')),
     c == 200 and float(x['total']) == 35 and float(x['cash_amt']) == 35 and json.loads(x['pays'])[0]['change'] == 5 and shares(x)[TA]['amt'] == 35 and float(x['admin_fee']) == 0)
a = new('D TWO', TA, GM); c, r = co(a, [(GM, TA, 40)], [{'m': 'Card', 'amt': 40, 'last4': '4242'}], tips=[{'staff': TA, 'amt': 8}]); x = rc(rid_of(r)); R1[2] = x
case(2, 'the + tip', 'Gel Manicure 40 the · tip 8 TAMMY', 'hoa don 40 (tip ngoai tong), the 40, tip 8 TAMMY, luat $1: TAMMY 39 + SISI 1',
     '%s, the %s, tip %s, TAMMY %s, SISI %s' % (x.get('total'), x.get('card_amt'), x.get('tip'), shares(x).get(TA, {}).get('amt'), shares(x).get(SI, {}).get('amt')),
     c == 200 and float(x['total']) == 40 and float(x['card_amt']) == 40 and float(x['tip']) == 8 and shares(x)[TA]['amt'] == 39 and shares(x)[SI]['amt'] == 1)
a = new('D THREE', TA, PD); c, r = co(a, [(PD, TA, 35), (GM, HA, 40)], [{'m': 'Card', 'amt': 75}], tips=[{'staff': TA, 'amt': 5}, {'staff': HA, 'amt': 7}]); x = rc(rid_of(r)); R1[3] = x
tp = {int(t['staff']): t['amt'] for t in json.loads(x.get('tips') or '[]')}
case(3, 'chia 2 tho + tip chia', 'Pedicure 35 TAMMY + Gel 40 HANA, the 75 · tip 5 TAMMY + 7 HANA', 'hoa don 75, tip 12 (5/7), TAMMY 35, HANA 39 + SISI 1',
     '%s, tip %s %s, TAMMY %s, HANA %s, SISI %s' % (x.get('total'), x.get('tip'), tp, shares(x).get(TA, {}).get('amt'), shares(x).get(HA, {}).get('amt'), shares(x).get(SI, {}).get('amt')),
     c == 200 and float(x['total']) == 75 and float(x['tip']) == 12 and tp == {TA: 5, HA: 7} and shares(x)[TA]['amt'] == 35 and shares(x)[HA]['amt'] == 39 and shares(x)[SI]['amt'] == 1)
a = new('D FOUR', TA, FS); c, r = co(a, [(FS, TA, 50)], [{'m': 'Card', 'amt': 30}, {'m': 'Cash', 'amt': 20, 'given': 20}]); x = rc(rid_of(r)); R1[4] = x
case(4, 'mot phan the + mot phan tien mat', 'Full Set 50 = the 30 + tien mat 20', 'the 30, tien mat 20, method Split, TAMMY 49 + SISI 1',
     'the %s, cash %s, %s, TAMMY %s' % (x.get('card_amt'), x.get('cash_amt'), x.get('method'), shares(x).get(TA, {}).get('amt')),
     c == 200 and float(x['card_amt']) == 30 and float(x['cash_amt']) == 20 and x['method'] == 'Split' and shares(x)[TA]['amt'] == 49)
gift('GIFT-6260-0005', 60)
a = new('D FIVE', HA, PD); c, r = co(a, [(PD, HA, 35)], [], gift_code='GIFT-6260-0005', gift_amount=35); x = rc(rid_of(r)); R1[5] = x
case(5, 'gift card du tien', 'the qua tang 60$ · Pedicure 35', 'tra het bang gift, so du 25, the/tien mat 0, HANA van 35 (salon tra)',
     'gift %s, so du %s, the %s cash %s, HANA %s' % (x.get('gift'), gbal('GIFT-6260-0005'), x.get('card_amt'), x.get('cash_amt'), shares(x).get(HA, {}).get('amt')),
     c == 200 and float(x['gift']) == 35 and gbal('GIFT-6260-0005') == 25 and float(x['card_amt']) == 0 and float(x['cash_amt']) == 0 and shares(x)[HA]['amt'] == 35)
a = new('D SIX', HA, GM); c0, r0 = co(a, [(GM, HA, 40)], [], gift_code='GIFT-6260-0005', gift_amount=40)
c, r = co(a, [(GM, HA, 40)], [{'m': 'Cash', 'amt': 15, 'given': 20}], gift_code='GIFT-6260-0005', gift_amount=25); x = rc(rid_of(r)); R1[6] = x
case(6, 'gift card thieu + tra them', 'the con 25 · Gel 40: thu dung gift 40 -> tu choi; roi gift 25 + tien mat 15', 'lan 1 tu choi (so du giu 25); lan 2: gift 25 + cash 15, so du 0',
     'lan1 %s %s; gift %s cash %s so du %s' % (c0, (r0 or {}).get('error', '')[:40], x.get('gift'), x.get('cash_amt'), gbal('GIFT-6260-0005')),
     c0 >= 400 and c == 200 and float(x['gift']) == 25 and float(x['cash_amt']) == 15 and gbal('GIFT-6260-0005') == 0)
h('set', json.dumps({'gift_on': '1'}))
a = new('D SEVEN', TA, PD); c, r = co(a, [(PD, TA, 35)], [{'m': 'Card', 'amt': 85}], gift_sale={'amount': 50, 'phone': '5155550188'}); x = rc(rid_of(r)); R1[7] = x
gs = json.loads(x.get('gift_sale') or '{}'); gcode = gs.get('code', '')
case(7, 'ban gift card moi (cung bill)', 'Pedicure 35 + ban gift 50, the 85', 'hoa don dich vu 35 (the 35), gift moi so du 50, KHONG tinh vao tien tho',
     'total %s, the dv %s, gift moi %s so du %s, TAMMY %s' % (x.get('total'), x.get('card_amt'), gs.get('amount'), gbal(gcode) if gcode else None, shares(x).get(TA, {}).get('amt')),
     c == 200 and float(x['total']) == 35 and float(x['card_amt']) == 35 and gcode and gbal(gcode) == 50 and shares(x)[TA]['amt'] == 35)
a = new('D EIGHT', HA, FS); c, r = co(a, [(FS, HA, 50)], [{'m': 'Card', 'amt': 40}], disc_type='%', disc_val=20); x = rc(rid_of(r)); R1[8] = x
case(8, 'giam gia %', 'Full Set 50 · giam 20% · the 40', 'giam 10, hoa don 40, HANA van 50 truoc $1 (salon chiu giam) -> 49 + SISI 1',
     'giam %s (%s), total %s, HANA %s' % (x.get('discount'), x.get('disc_note'), x.get('total'), shares(x).get(HA, {}).get('amt')),
     c == 200 and float(x['discount']) == 10 and float(x['total']) == 40 and shares(x)[HA]['amt'] == 49)
cd0 = api('close_day', None, '&day=' + TODAY)[1]['totals']
c, r = api('receipt_void', {'id': int(R1[1]['id']), 'reason': 'test 626 void'}); x = rc(int(R1[1]['id'])); ap = sql("SELECT status FROM appointments WHERE receipt_id = 0 AND phone = '%s'" % R1[1]['phone'])
cd1 = api('close_day', None, '&day=' + TODAY)[1]['totals']
case(9, 'void truoc khi dong ngay', 'void hoa don #1 (tien mat 35)', 'hoa don VOID, hen ve "arrived", close day: tien mat -35, voids +1',
     '%s, hen %s, cash %s->%s, voids %s->%s' % (x.get('status'), [y['status'] for y in ap], cd0['cash'], cd1['cash'], cd0['voids'], cd1['voids']),
     c == 200 and x['status'] == 'void' and ap and ap[0]['status'] == 'arrived' and round(cd0['cash'] - cd1['cash'], 2) == 35 and cd1['voids'] == cd0['voids'] + 1)
c, r = api('receipt_refund', {'id': int(R1[4]['id']), 'amount': 10, 'how': 'Cash', 'reason': 'test 626 refund'}); x = rc(int(R1[4]['id']))
cd2 = api('close_day', None, '&day=' + TODAY)[1]['totals']
case(10, 'refund mot phan', 'hoa don #4 (50) · tra lai 10 tien mat', 'refund 10, hoa don van paid, close day refundCash +10, ngan keo -10',
     'refund %s, %s, refundCash %s, cashDrawer %s->%s' % (x.get('refund'), x.get('status'), cd2['refundCash'], cd1['cashDrawer'], cd2['cashDrawer']),
     c == 200 and float(x['refund']) == 10 and x['status'] == 'paid' and cd2['refundCash'] == 10 and round(cd1['cashDrawer'] - cd2['cashDrawer'], 2) == 10)
c, r = api('receipt_refund', {'id': int(R1[1]['id']), 'amount': 5, 'how': 'Cash', 'reason': 'test 626'}); x = rc(int(R1[1]['id']))
c2, r2 = api('receipt_void', {'id': int(R1[4]['id']), 'reason': 'test 626', 'dps_done': 1}); x4 = rc(int(R1[4]['id']))
case(11, 'refund sau void (phai chan) + void sau refund (phai chan)', 'refund 5 tren hoa don da void · void hoa don da refund', 'ca 2 bi tu choi, khong doi gi',
     'refund %s "%s" (refund=%s) · void %s "%s" (%s)' % (c, (r or {}).get('error', '')[:30], x.get('refund'), c2, (r2 or {}).get('error', '')[:40], x4.get('status')),
     c >= 400 and float(x['refund']) == 0 and c2 >= 400 and x4['status'] == 'paid')
# ---------- 14: payroll of the week, 2 techs (commission + tip + $1) – computed here from the receipts in the DB, then compared ----------
def payrow(sid):
    for y in (api('payroll_week', None, '&day=' + TODAY)[1].get('rows') or []):
        if int(y['staff']) == sid: return y
    return {}
def exp_pay(sid, pct):
    sales = tips = 0.0
    for y in sql("SELECT * FROM receipts WHERE status = 'paid' AND test = 0"):
        for s in json.loads(y['pay_splits'] or '[]'):
            if int(s['staff']) == sid and int(s['staff']) != SI: sales += float(s['amt'])
        for t in json.loads(y['tips'] or '[]'):
            if int(t['staff']) == sid: tips += float(t['amt'])
        for f in json.loads(y['refunds'] or '[]'):
            for t in f.get('techs') or []:
                if int(t['staff']) == sid: sales -= float(t['amt'])
            for t in f.get('fee') or []:
                if int(t['staff']) == sid: sales += 0   # the $1 a refund gives back stays with the tech (shown in the payroll's own math)
    sales = round(sales, 2); comm = round(sales * pct / 100, 2); return sales, comm, round(tips, 2), round(comm + tips, 2)
pt, ph = payrow(TA), payrow(HA); et, eh = exp_pay(TA, 60), exp_pay(HA, 50)
got = lambda y: (round(float(y.get('sales', -1)), 2), round(float(y.get('commission', -1)), 2), round(float(y.get('tips', -1)), 2), round(float(y.get('total', -1)), 2))
case(14, 'luong tuan 2 tho (commission + tip + $1)', 'TAMMY 60% · HANA 50% · cac hoa don tren', 'TAMMY %s · HANA %s (doanh so, commission, tip, tong – tinh tu DB)' % (et, eh),
     'TAMMY %s · HANA %s' % (got(pt), got(ph)), got(pt) == et and got(ph) == eh)
# ---------- C: numbers match ----------
bad = []
for y in sql("SELECT * FROM receipts WHERE status = 'paid' AND test = 0"):
    gsa = float((json.loads(y['gift_sale'] or '{}') or {}).get('amount', 0) or 0)
    if round(float(y['total']) - float(y['deposit']) - float(y['gift']) - float(y['card_amt']) - float(y['cash_amt']) - float(y['other_amt']), 2) != 0: bad.append(('total', y['rno']))
    if round(sum(float(p['amt']) for p in json.loads(y['pays'] or '[]')) - float(y['card_amt']) - float(y['cash_amt']) - float(y['other_amt']), 2) != 0: bad.append(('pays', y['rno']))
    if round(sum(float(s['amt']) for s in json.loads(y['pay_splits'] or '[]')) - float(y['subtotal']), 2) != 0: bad.append(('techs+$1 != dich vu', y['rno']))
    if round(sum(float(t['amt']) for t in json.loads(y['tips'] or '[]')) - float(y['tip']), 2) != 0: bad.append(('tips', y['rno']))
ok('C1 moi hoa don: tong = tien mat + the + khac + gift (+coc) · pays = the+cash+khac · tien tho + $1 = dich vu · tip tung tho = tip', not bad, bad)
cd = api('close_day', None, '&day=' + TODAY)[1]; T_ = cd['totals']; P_ = sql("SELECT * FROM receipts WHERE status = 'paid' AND test = 0 AND day = '%s'" % TODAY)
dbs = {k: round(sum(float(y[k]) for y in P_), 2) for k in ('card_amt', 'cash_amt', 'gift', 'subtotal', 'tip', 'admin_fee')}
ok('C2 Close day = DB: the %s / tien mat %s / gift %s / dich vu %s / tip %s / $1 %s' % (dbs['card_amt'], dbs['cash_amt'], dbs['gift'], dbs['subtotal'], dbs['tip'], dbs['admin_fee']),
   (T_['card'], T_['cash'], T_['gift'], T_['services'], T_['tips'], T_['adminFee']) == (dbs['card_amt'], dbs['cash_amt'], dbs['gift'], dbs['subtotal'], dbs['tip'], dbs['admin_fee']), T_)
ok('C3 Close day: ban gift card trong ngay = 50 (the), KHONG nam trong dich vu', round(T_['giftCard'], 2) == 50 and T_['services'] == dbs['subtotal'], (T_['giftCard'], T_['services']))
mr = api('money_report', None, '&from=%s&to=%s' % (TODAY, TODAY))[1]; MT = mr.get('totals') or {}
ok('C4 Bao cao tien = DB (tong %s, tip the %s)' % (round(sum(float(y['total']) for y in P_), 2), dbs['tip']), abs(float(MT.get('total', -1)) - round(sum(float(y['total']) for y in P_), 2)) < .01 and abs(float(MT.get('cardTips', -1)) - dbs['tip']) < .01, MT)
ct = {int(t['staff']): t for t in cd['techs']}
TAB_C5 = (ct.get(TA, {}).get('sales'), pt.get('sales'), ct.get(HA, {}).get('sales'), ph.get('sales'))
ok('C5 Close day tung tho = Payroll (doanh so sau $1 va refund, 1 ngay): TAMMY %s/%s · HANA %s/%s' % TAB_C5, abs(float(TAB_C5[0]) - float(TAB_C5[1])) < .01 and abs(float(TAB_C5[2]) - float(TAB_C5[3])) < .01, TAB_C5)
mo = api('money_overview', None, '&day=' + TODAY)[1]
say('   (money_overview keys: %s)' % list(mo.keys())[:12])
ok('C7 Gift card: void / refund cap nhat so du DUNG 1 lan', gbal('GIFT-6260-0005') == 0, gbal('GIFT-6260-0005'))
c, r = api('receipt_void', {'id': int(R1[6]['id']), 'reason': 'test 626 void gift'}); b1 = gbal('GIFT-6260-0005')
c2, r2 = api('receipt_void', {'id': int(R1[6]['id']), 'reason': 'test 626 void gift lan 2'}); b2 = gbal('GIFT-6260-0005')
ok('C8 void hoa don tra 25$ bang gift card -> so du +25 DUNG 1 lan (void lan 2 bi chan, so du van 25)', c == 200 and b1 == 25 and c2 >= 400 and b2 == 25, (c, b1, c2, b2))
c, r = api('receipt_refund', {'id': int(R1[5]['id']), 'amount': 10, 'how': 'Gift card', 'reason': 'test 626 refund gift'}); b3 = gbal('GIFT-6260-0005')
ok('C9 refund 10$ ve gift card (hoa don tra bang gift) -> so du +10 (35), refund ghi 10', c == 200 and b3 == 35 and float(rc(int(R1[5]['id']))['refund']) == 10, (c, (r or {}).get('error'), b3))
cdA = api('close_day', None, '&day=' + TODAY)[1]['totals']
c, r = api('receipt_void', {'id': int(R1[7]['id']), 'reason': 'test 626 void ban gift', 'dps_done': 1}); cdB = api('close_day', None, '&day=' + TODAY)[1]['totals']
gst = sql("SELECT status, balance FROM giftcards WHERE code = '%s'" % gcode)
GS7 = (c, cdA['card'], cdB['card'], cdA['giftCard'], cdB['giftCard'], gst)
ok('C10 void bill co BAN gift card (dv 35 + gift 50) -> (627, anh Logan: VOID HET) void ca the gift: the void so du 0, Close day the -35 (dich vu) va gift ban 50 -> 0',
   c == 200 and round(cdA['card'] - cdB['card'], 2) == 35 and cdA['giftCard'] == 50 and cdB['giftCard'] == 0 and gst and gst[0]['status'] == 'void' and float(gst[0]['balance']) == 0, GS7)
gift('GIFT-6260-0011', 20); a = new('C ELEVEN', HA, GM); c, r = co(a, [(GM, HA, 40)], [{'m': 'Cash', 'amt': 20}], gift_code='GIFT-6260-0011', gift_amount=20); r11 = rid_of(r)
c1, x1 = api('receipt_refund', {'id': r11, 'amount': 20, 'how': 'Gift card', 'reason': 'test 626 C11 phan gift'})
c2, x2 = api('receipt_refund', {'id': r11, 'amount': 20, 'how': 'Cash', 'reason': 'test 626 C11 phan tien mat'})
ok('C11 hoa don 40 = gift 20 + tien mat 20: refund 20 ve gift card, roi refund 20 TIEN MAT (phan khach tra tien mat) -> phai duoc (tong refund 40 = tong hoa don)',
   c == 200 and c1 == 200 and c2 == 200 and float(rc(r11)['refund']) == 40, (c, c1, c2, (x2 or {}).get('error'), rc(r11).get('refund')))
# ---------- B (SQLite here; MySQL: BAO-CAO-626) ----------
a = new('B THREE', TA, PD); n0 = int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n'])
res = [co(a, [(PD, TA, 35)], [{'m': 'Cash', 'amt': 35}]) for _ in range(3)]
ok('B3 bam "Thanh toan" 3 lan (mang cham gui lai) -> DUNG 1 hoa don, lan 2-3 "already paid"', int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n']) == n0 + 1 and [x[0] for x in res][0] == 200 and all(x[0] >= 400 for x in res[1:]), [(x[0], (x[1] or {}).get('error', '')[:30]) for x in res])
a = new('B ONE', HA, GM); n0 = int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n']); res = [None] * 4; ev = threading.Event()
def g1(k): ev.wait(); res[k] = co(a, [(GM, HA, 40)], [{'m': 'Card', 'amt': 40}])
th = [threading.Thread(target=g1, args=(k,)) for k in range(4)]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
ok('B1 4 may checkout CUNG 1 ve CUNG LUC -> 1 hoa don, the tru 1 lan', int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n']) == n0 + 1 and sum(1 for x in res if x[0] == 200) == 1, [x[0] for x in res])
gift('GIFT-6260-0002', 40); b1, b2 = new('B TWO A', TA, PD), new('B TWO B', HA, PD); res = [None, None]; ev = threading.Event()
def g2(k, aid, st): ev.wait(); res[k] = co(aid, [(PD, st, 35)], [], gift_code='GIFT-6260-0002', gift_amount=35)
th = [threading.Thread(target=g2, args=(0, b1, TA)), threading.Thread(target=g2, args=(1, b2, HA))]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
ok('B2 2 may dung CUNG 1 gift card (40$, moi may 35$) CUNG LUC -> 1 may duoc, so du 5, khong am', sum(1 for x in res if x[0] == 200) == 1 and gbal('GIFT-6260-0002') == 5, ([x[0] for x in res], gbal('GIFT-6260-0002')))
# B4: an error half-way (after the receipt row is written): the DB refuses the gift card update -> everything rolls back
pw = payrow(TA); gift('GIFT-6260-0004', 50); a = new('B FOUR', TA, FS); n0 = int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n'])
sql("CREATE TRIGGER t626_fail BEFORE UPDATE OF balance ON giftcards WHEN OLD.code = 'GIFT-6260-0004' BEGIN SELECT RAISE(ABORT, 'test626 DB error'); END")
c, r = co(a, [(FS, TA, 50)], [{'m': 'Cash', 'amt': 20}], gift_code='GIFT-6260-0004', gift_amount=30)
sql("DROP TRIGGER t626_fail")
st4 = sql("SELECT status, receipt_id FROM appointments WHERE id = %d" % a)[0]
ok('B4 loi DB giua chung (sau khi da ghi hoa don) -> ROLLBACK het: khong hoa don, hen chua tra, gift card van 50, luong khong doi',
   c >= 400 and int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n']) == n0 and st4['status'] != 'paid' and int(st4['receipt_id']) == 0 and gbal('GIFT-6260-0004') == 50 and got(pw) == got(payrow(TA)),
   (c, (r or {}).get('error', '')[:60], st4, gbal('GIFT-6260-0004')))
c, r = co(a, [(FS, TA, 50)], [{'m': 'Cash', 'amt': 20}], gift_code='GIFT-6260-0004', gift_amount=30)
ok('B4b sau loi, bam lai -> thanh cong binh thuong (gift con 20)', c == 200 and gbal('GIFT-6260-0004') == 20, (c, (r or {}).get('error'), gbal('GIFT-6260-0004')))
# ---------- 12 / 13: close day + lock, unlock ----------
for y in sql("SELECT id FROM appointments WHERE status IN ('arrived', 'booked') AND appt_date = '%s'" % TODAY): sql("UPDATE appointments SET status = 'cancelled' WHERE id = %d" % int(y['id']))
T_ = api('close_day', None, '&day=' + TODAY)[1]['totals']
api('close_day_count', {'day': TODAY, 'counted': T_['cashExp'], 'dps': T_['dpsExp'], 'note': 'test 626'}); c, r = api('close_day_lock', {'day': TODAY})
a = new('D TWELVE', HA, PD); c2, r2 = co(a, [(PD, HA, 35)], [{'m': 'Cash', 'amt': 35}])
case(12, 'close day (dem tien + khoa) roi checkout -> phai chan', 'dem tien = du kien · khoa · checkout Pedicure 35', 'khoa OK; checkout bi tu choi, khong hoa don',
     'khoa %s; checkout %s "%s"' % (c, c2, (r2 or {}).get('error', '')[:50]), c == 200 and c2 >= 400 and st(a) != 'paid')
c0, r0 = api('close_day_unlock', {'day': TODAY, 'reason': ''}); c, r = api('close_day_unlock', {'day': TODAY, 'reason': 'test 626 quen 1 khach'}); c2, r2 = co(a, [(PD, HA, 35)], [{'m': 'Cash', 'amt': 35}])
case(13, 'mo khoa co ly do', 'mo khoa khong ly do · roi co ly do · checkout lai', 'khong ly do: chan; co ly do: mo; checkout OK',
     'khong ly do %s; co ly do %s; checkout %s' % (c0, c, c2), c0 >= 400 and c == 200 and c2 == 200 and st(a) == 'paid')
# ---------- 15: close the week, then void ----------
tot_before = float(payrow(TA).get('total', 0)); c, w = api('payroll_close', {'day': TODAY, 'force': 1})
c1, r1 = api('receipt_void', {'id': int(R1[2]['id']), 'reason': 'test 626 sau chot', 'dps_done': 1})
c2, r2 = api('receipt_void', {'id': int(R1[2]['id']), 'reason': 'test 626 sau chot', 'dps_done': 1, 'ok_closed': 1})
carry = sql("SELECT amount, week_start FROM payroll_adj WHERE staff_id = %d AND reason LIKE '%%[from %%'" % TA); after = float(payrow(TA).get('total', 0))
want = -round(39 * .6 + 8, 2)
case(15, 'chot tuan roi void (hoi, chenh lech sang tuan sau)', 'chot tuan · void hoa don #2 (Gel 40 the + tip 8 TAMMY)', 'lan 1 hoi (409); dong y -> tuan da chot giu %s; tuan sau TAMMY %s' % (tot_before, want),
     'lan1 %s; void %s; tuan nay %s; sang tuan sau %s' % (c1, c2, after, carry), c == 200 and c1 == 409 and c2 == 200 and abs(after - tot_before) < .01 and len(carry) == 1 and abs(float(carry[0]['amount']) - want) < .01 and carry[0]['week_start'] > TODAY)
# ---------- table ----------
say('\n== BANG 15 TINH HUONG (so | tinh huong | so tien vao | mong doi | thuc te | ket qua)')
for row in sorted(TAB): say('%2d | %s | %s | %s | %s | %s' % row)
say('C5 (Close day tung tho vs Payroll, xem bao cao): TAMMY %s / %s · HANA %s / %s' % TAB_C5)
logs = open(D + '/php.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
