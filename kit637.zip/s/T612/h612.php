<?php require '/tmp/claude-0/FX616/inc/core.php'; settings(); require_once '/tmp/claude-0/FX616/inc/calls.php'; require_once '/tmp/claude-0/FX616/inc/calls-tx.php'; tx_table(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'tok') echo tx_token();
if ($a === 'cfg') echo json_encode(tx_cfg());
if ($a === 'save') { try { echo json_encode(tx_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
if ($a === 'setup') { require_once '/tmp/claude-0/FX616/inc/calls-agent.php'; require_once '/tmp/claude-0/FX616/inc/calls-ivr.php'; echo json_encode(tx_setup($argv[2] ?? '')); }
if ($a === 'kp') { $k = sodium_crypto_sign_keypair(); echo json_encode(['pub' => base64_encode(sodium_crypto_sign_publickey($k)), 'sec' => base64_encode(sodium_crypto_sign_secretkey($k))]); }
if ($a === 'sign') { echo base64_encode(sodium_crypto_sign_detached($argv[3] . '|' . file_get_contents($argv[4]), base64_decode($argv[2]))); }
if ($a === 'swtool') { require '/tmp/claude-0/FX616/call_tx.php.lib'; }
if ($a === 'mk') { [$_, $_, $ph, $name, $date, $start, $staff] = $argv; upsert_customer($ph, $name);
  q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt','',?)", [$date, (int)$start, 45, (int)$staff, '2', $name, $ph, now_str()]); echo (int)db()->lastInsertId(); }
