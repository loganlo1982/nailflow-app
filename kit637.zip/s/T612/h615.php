<?php require '/tmp/claude-0/FX616/inc/core.php'; settings(); require_once '/tmp/claude-0/FX616/inc/calls.php'; require_once '/tmp/claude-0/FX616/inc/calls-tx.php'; tx_table(); $a = $argv[1];
if ($a === 'wav') { $f = cl_dir() . '/.t615.mp3'; copy('/tmp/claude-0/T612/x.mp3', $f); try { echo tx_wavify($f) ? 'WAV' : 'FALSE'; } catch (Throwable $e) { echo 'ERR ' . get_class($e) . ': ' . $e->getMessage(); } @unlink($f); }
if ($a === 'fetch') { $n0 = count(glob(cl_dir() . '/.dl-*')); try { tx_fetch((int)$argv[2], 'http://127.0.0.1:19872/media/MP3X1.mp3', 'ACC1', 'MP3X1'); echo 'OK'; } catch (Throwable $e) { echo 'ERR ' . $e->getMessage(); } echo ' dl+' . (count(glob(cl_dir() . '/.dl-*')) - $n0); }
if ($a === 'cli') { tx_cli_mp3(); echo 'done'; }
