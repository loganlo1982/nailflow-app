# Fake Telnyx API for the 612 test (docs shapes): assistants, texml_applications, phone_numbers, conversations + messages, TeXML recordings (json/wav/delete). Port 19872.
import http.server, json, re, sys, os
D = '/tmp/claude-0/T612'; LOG = open(D + '/fake_tx.log', 'a'); KEY = 'KEY0123456789abcdefTEST_tx_key_99'
def log(*a): LOG.write(' '.join(str(x) for x in a) + '\n'); LOG.flush()
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def out(self, code, obj=None, raw=None, ct='application/json'):
        b = raw if raw is not None else json.dumps(obj or {}).encode()
        self.send_response(code); self.send_header('Content-Type', ct); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def auth(self): return self.headers.get('Authorization', '') == 'Bearer ' + KEY
    def body(self):
        n = int(self.headers.get('Content-Length', 0) or 0); return json.loads(self.rfile.read(n) or b'{}') if n else {}
    def do_GET(self):
        p = self.path
        if p.startswith('/media/'):
            log('GET media', p, 'auth', self.headers.get('Authorization', '')[:6]); f = '/tmp/claude-0/T586/wav/RE0003.wav'
            if 'EXPIRED' in p: return self.out(403, raw=b'expired', ct='text/plain')
            if 'MP3X' in p: return self.out(200, raw=open(D + '/x.mp3', 'rb').read(), ct='audio/mpeg')
            return self.out(200, raw=open(f, 'rb').read(), ct='audio/wav')
        if not self.auth(): log('GET 401', p); return self.out(401, {'errors': [{'title': 'Unauthorized'}]})
        log('GET', p)
        if p.startswith('/v2/phone_numbers'): return self.out(200, {'data': [{'id': 'PN-1', 'phone_number': '+15155136667'}]} if 'filter%5Bphone_number%5D=15155136667' in p else {'data': []})
        if p.startswith('/v2/text-to-speech/voices'): return self.out(200, {'voices': [{'name': 'Astra', 'voice_id': 'Telnyx.NaturalHD.astra', 'gender': 'female', 'language': 'en-US'}, {'name': 'Maeve', 'voice_id': 'Telnyx.Ultra.02a924f6-1111-2222-3333-444455556666', 'gender': 'female', 'language': 'en-US'}]})
        if p.startswith('/v2/outbound_voice_profiles'): return self.out(200, {'data': []})
        m = re.match(r'^/v2/recordings/([^/?]+)$', p)
        if m and 'MP3X' in m.group(1): return self.out(200, {'data': {'id': m.group(1), 'download_urls': {'mp3': 'http://127.0.0.1:19872/media/' + m.group(1) + '.mp3'}}})
        if m: return self.out(200, {'data': {'id': m.group(1), 'download_urls': {'wav': 'http://127.0.0.1:19872/media/' + m.group(1) + '.wav', 'mp3': 'x'}}})
        if p.startswith('/v2/ai/conversations/CONV-1/messages'):
            return self.out(200, {'data': [{'role': 'assistant', 'text': "You're all set - see you tomorrow at 2. Bye!", 'created_at': '2026-11-01T20:03:00Z'},
                {'role': 'tool', 'text': 'OK', 'created_at': '2026-11-01T20:02:30Z'},
                {'role': 'user', 'text': 'Can I get a pedicure tomorrow at 2?', 'created_at': '2026-11-01T20:02:00Z'},
                {'role': 'assistant', 'text': 'Thank you for calling American Nails. Sorry we missed you - how can I help?', 'created_at': '2026-11-01T20:01:50Z'}]})
        m = re.match(r'^/v2/ai/conversations\?metadata-%3Ecall_control_id=eq\.([^&]+)', p)
        if m:
            import hashlib, urllib.parse as _u; k = hashlib.sha1(_u.unquote(m.group(1)).encode()).hexdigest()[:16]
            if os.path.exists(D + '/conv/' + k + '.json'): return self.out(200, {'data': [{'id': 'CV-' + k}]})
        m = re.match(r'^/v2/ai/conversations/CV-([0-9a-f]+)/messages', p)
        if m and os.path.exists(D + '/conv/' + m.group(1) + '.json'): return self.out(200, {'data': json.load(open(D + '/conv/' + m.group(1) + '.json'))})
        if p.startswith('/v2/ai/conversations/CONV-0/messages'): return self.out(200, {'data': [{'role': 'assistant', 'text': 'Thank you for calling American Nails. Sorry we missed you - how can I help?', 'created_at': '2026-11-01T20:01:50Z'}]})
        if p.startswith('/v2/ai/conversations') and ('NOCONV' in p or '5155550198' in p): return self.out(200, {'data': []})
        if p.startswith('/v2/ai/conversations') and ('NOUSER' in p or '5155550197' in p): return self.out(200, {'data': [{'id': 'CONV-0'}]})
        if p.startswith('/v2/ai/conversations'): return self.out(200, {'data': [{'id': 'CONV-1'}]})
        m = re.match(r'^/v2/texml/Accounts/([^/]+)/Recordings/([^/]+)\.json$', p)
        if m: return self.out(200, {'sid': m.group(2), 'media_url': 'http://127.0.0.1:19872/media/' + m.group(2) + '.wav'})
        return self.out(404, {'errors': [{'title': 'not found'}]})
    def do_POST(self):
        p = self.path
        if p.startswith('/v2/texml/Accounts/') and self.auth():
            n = int(self.headers.get('Content-Length', 0) or 0); raw = self.rfile.read(n).decode(); log('POST', p, raw[:1200]); return self.out(200, {'sid': 'x'})
        b = self.body()
        if not self.auth(): return self.out(401, {})
        log('POST', p, json.dumps(b)[:200]); json.dump(b, open(D + '/last-' + re.sub(r'[^a-z]', '_', p) + '.json', 'w'))
        if p == '/v2/ai/assistants': return self.out(200, {'id': 'assistant-test-1', **b})
        if p.startswith('/v2/ai/assistants/'): return self.out(200, {'id': p.rsplit('/', 1)[1]})
        if p == '/v2/texml_applications': return self.out(201, {'data': {'id': 'APP-1', **b}})
        if p == '/v2/outbound_voice_profiles': return self.out(201, {'data': {'id': 'OVP-1', **b}})
        if p.startswith('/v2/texml/Accounts/'): return self.out(200, {'sid': 'x'})
        return self.out(404, {})
    def do_PATCH(self):
        p = self.path; b = self.body()
        if not self.auth(): return self.out(401, {})
        log('PATCH', p, json.dumps(b)[:200])
        return self.out(200, {'data': {'id': p.rsplit('/', 1)[1], **b}})
    def do_DELETE(self):
        log('DELETE', self.path, 'auth', self.auth()); return self.out(204 if self.auth() else 401, raw=b'')
http.server.ThreadingHTTPServer(('127.0.0.1', 19872), H).serve_forever()
