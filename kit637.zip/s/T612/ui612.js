const L = require('/tmp/claude-0/t561/lib.js');
L.run(process.argv[2] || '/tmp/claude-0/L612', 19881, '/tmp/claude-0/T612/ui', async ({ open, ok, sleep, devices, OUT }) => {
  const { ctx, p } = await open(devices['iPhone 13'], false, false, 'owner');
  await p.evaluate(async () => { if (typeof lazyMod === 'function') await lazyMod('settings'); await callsState(); }); await sleep(2500);
  const r = await p.evaluate(async () => { const b = document.createElement('div'); b.id = 'tb'; document.querySelector('main, body').prepend(b); await SET_PAGES.calls(b); await new Promise(r => setTimeout(r, 1500));
    const c = b.querySelector('.tx-card'); return { card: !!c, wrapped: !!SET_PAGES.calls.txWrapped, last: b.lastElementChild === c, txt: c ? c.textContent.slice(0, 200) : '', saveFirst: !!b.querySelector('#clSave') }; });
  ok('Settings → Calls: the Telnyx card is drawn at the END (the old card unchanged above)', r.card && r.last && r.saveFirst, r);
  await p.evaluate(async () => { const b = document.querySelector('#tb'); b.querySelector('#txKey').value = 'KEY0123456789abcdefTEST_tx_key_99'; b.querySelector('#txOn').checked = true; b.querySelector('#txSave').click(); }); await sleep(1500);
  const r2 = await p.evaluate(() => { const c = document.querySelector('#tb .tx-card'); return { txt: c.textContent, keyInput: !!c.querySelector('#txKey:not([hidden])'), setupOn: !c.querySelector('#txSetup').disabled }; });
  ok('Save: shows "Saved …y_99" (the key never shown again), "Set up automatically" active', /Saved …y_99|Đã lưu …y_99/.test(r2.txt) && !r2.keyInput && r2.setupOn && !r2.txt.includes('KEY0123'), r2);
  const t0 = Date.now(); await p.evaluate(() => document.querySelector('#tb #txSetup').click()); await p.waitForFunction(() => /❌|✅/.test(document.querySelector('#tb .tx-card').textContent) && !document.querySelector('#tb .tx-card').textContent.includes('…  '), null, { timeout: 60000 }).catch(() => {}); await sleep(1500);
  const r4 = await p.evaluate(() => { const c = document.querySelector('#tb .tx-card'); return { steps: [...c.querySelectorAll('.tx-steps p')].map(x => x.textContent.trim()), btn: !c.querySelector('#txSetup').disabled }; });
  ok('(2.99.613) "Set up automatically" step by step: no Telnyx here → "❌ API key …" with the reason, stops there, the page answers (no "connection lost")', r4.steps.length === 1 && /❌ API key/.test(r4.steps[0]) && r4.btn, { r4, ms: Date.now() - t0 });
  await p.evaluate(() => document.querySelector('#tb #clSave').click()); await sleep(2000);
  const r3 = await p.evaluate(() => !!document.querySelector('#tb .tx-card'));
  ok('Saving the old Calls form (page drawn again) keeps the Telnyx card', r3, r3);
  await p.screenshot({ path: OUT + '/settings-calls.png', fullPage: true });
  await ctx.close();
});
