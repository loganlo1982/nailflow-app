<?php // test helper: php hjob.php <app> <sid> fetch|job  (env NF_SW_BASE / NF_STT_URL / NF_OAI_URL = the fake)
declare(strict_types=1); define('NF_API_LIB', 1); [$_, $R, $sid, $what] = $argv; require "$R/inc/core.php"; require_once "$R/inc/calls.php"; settings();
foreach (['/inc/backup.php', '/inc/import.php', '/inc/totp.php', '/inc/rebook.php', '/inc/gallery.php', '/inc/birthday.php', '/inc/paypal.php', '/inc/review.php', '/inc/giftcards.php',
  '/inc/outbox.php', '/inc/logo.php', '/inc/reports.php', '/inc/checkout.php', '/inc/payroll.php', '/inc/export.php', '/inc/yearend.php', '/inc/referral.php', '/inc/promolinks.php',
  '/inc/turnq.php', '/inc/apptoffers.php', '/inc/rewards.php', '/inc/api/_auth.php', '/inc/api/_menu.php', '/inc/api/_texts.php', '/inc/api/_kiosk.php', '/inc/api/_out.php'] as $f) require_once $R . $f;
require_once "$R/api.php"; require_once "$R/inc/calls-job.php"; require_once "$R/inc/calls-ivr.php"; require_once "$R/inc/calls-agent.php"; require_once "$R/inc/replies.php";
if (!function_exists('cl_job_lib')) { function cl_job_lib(): void {} }
$c = q('SELECT * FROM calls WHERE call_sid = ?', [$sid])->fetch();
if ($what === 'fetch') { try { cl_fetch($c); } catch (Throwable $e) { echo json_encode(['err' => $e->getMessage()]); exit; } $c = q('SELECT * FROM calls WHERE id = ?', [$c['id']])->fetch();
  $w = file_get_contents(cl_path((string)$c['file'])); echo json_encode(['file' => $c['file'], 'ch' => unpack('v', substr($w, 22, 2))[1]]); }
if ($what === 'job') { q("UPDATE calls SET status = 'queued', next_at = ? WHERE id = ?", [now_str(), $c['id']]); $r = cl_job((int)$c['id']); $c = q('SELECT status, reason, text_c, text_s FROM calls WHERE id = ?', [$c['id']])->fetch(); echo json_encode(['r' => $r] + $c); }
