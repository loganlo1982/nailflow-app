# LAMWEB test 605 + 605B (2.99.606: the change lock, end_call) – the real-time AI receptionist (SignalWire AI Agent: SWML + SWAIG) on a local copy. Fake SignalWire requests in the docs' shapes; test numbers 555-01xx only.
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, re, datetime as _dt
A = sys.argv[1]; D = '/tmp/claude-0/T605B'; T5 = '/tmp/claude-0/T586'; PORT = 19877; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-605B.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SHARED_DIR': T5 + '/shared', 'NF_CALLS_DIR': D + '/calls'}
os.makedirs(D + '/calls', exist_ok=True)
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(T5 + '/shared/call-ai.json', 'w')); json.dump({}, open(T5 + '/shared/color-ai.json', 'w'))
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S, T = seed['S'], seed['T']; GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
H = D + '/h605.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/calls-agent.php'; cl_table(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'tok') echo cl_agent_token();
if ($a === 'cfg') echo json_encode(cl_cfg());
if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
if ($a === 'mk') { [$_, $_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = []; upsert_customer($ph, $name);
  for ($i = 0; $i < (int)$n; $i++) { q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)", [$date, (int)$start, 45, (int)$staff, (string)%d, $i ? ($i === 1 ? 'LILY' : $name . ' +' . $i) : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); } echo json_encode($ids); }
""" % (A, A, A, PD))
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
ALLDAY = json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)})
h('set', json.dumps({'hours': ALLDAY, 'call_engine': 'agent', 'call_owner': '5155550177', 'as_on': '1', 'as_device': 'android', 'ad_transport': 'winsms', 'salon_name': 'American Nails'}))
sh('php', '-r', "require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; set_setting('ws_key', ad_enc('WS_test_key_123456789'));" % (A, A))
TOK = h('tok')
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.2)
fk = subprocess.Popen(['python3', T5 + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
atexit.register(lambda: (sv.terminate(), fk.terminate()))
B = 'http://127.0.0.1:%d/call_agent.php' % PORT
PROJ = '11111111-2222-3333-4444-555555555555'
def post(a, body, tok=None, extra=''):
    u = B + '?a=' + a + '&t=' + (TOK if tok is None else tok) + extra
    rq = urllib.request.Request(u, data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    try: r = urllib.request.urlopen(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        b = e.read().decode(errors='replace')[:300]
        if tok is None and (body.get('call') or {}).get('project_id', PROJ) == PROJ: say('   !! %s ?a=%s -> HTTP %d: %s' % (B.rsplit('/', 1)[1], a, e.code, b.replace('\n', ' ')))  # only a request that should pass
        return e.code, {'_http': e.code, '_body': b}
def _crash(t, v, tb):  # (621-B) a crash (e.g. KeyError 'sections') says WHY: the TOKEN, the answer and the PHP log, then the traceback
    import traceback; say('✗ CRASH %s: %s · TOK=%r' % (t.__name__, v, str(TOK)[:60])); say('   php.log: ' + open(D + '/php.log').read()[-600:].replace('\n', ' | ')); traceback.print_exception(t, v, tb)
sys.excepthook = _crash
def call(cid, frm): return {'call': {'call_id': cid, 'from': frm, 'to': '+15156061616', 'project_id': PROJ, 'direction': 'inbound'}}
def tool(cid, frm, fn, **args): return post('tool', {'function': fn, 'argument': {'parsed': [args], 'raw': json.dumps(args)}, 'call_id': cid, 'caller_id_num': frm, 'project_id': PROJ, 'meta_data': {}}, extra='&sid=' + cid)
_t = _dt.date.today()
def W(k): return (_t + _dt.timedelta(days=((k - _t.weekday()) % 7) or 7) + _dt.timedelta(days=7)).isoformat()
def row(cid): x = sql("SELECT * FROM calls WHERE call_sid = '%s'" % cid); return x[0] if x else {}
def appts(ph): return sql("SELECT id, customer_name, status, appt_date, start_min, staff_id, service_ids, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
say('== LAMWEB test 2.99.605 – LENH 605 real-time AI receptionist (SWML ai + SWAIG) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire requests (docs shapes) · texts only into the SMS Server queue')
# 1. security
c, _ = post('swml', call('CA1', '+15555550101'), tok='wrong'); ok('1 a wrong secret → 403', c == 403, c)
c, _ = post('swml', {'call': {'call_id': 'CA1x', 'from': '+15555550101', 'project_id': '99999999-0000-0000-0000-000000000000'}}); ok('1 another SignalWire project → 403', c == 403, c)
# 2. in the opening hours: greeting, recording, the iPhone 20 s, then the AI
c, s = post('swml', call('CA2', '+15555550102')); m = s.get('sections', {}).get('main', []); af = s.get('sections', {}).get('after', [])
if os.environ.get('NF_DIAG'):  # (621-C) diag.sh: what ?a=swml answers here (test copy, fake SignalWire)
    say('DIAG swml CA2 -> HTTP %s · keys %s · %s' % (c, list(s.keys()) if isinstance(s, dict) else type(s).__name__, json.dumps(s)[:400]))
    say('DIAG gio PHP %s · python %s' % (sh('php', '-r', "require '%s/inc/core.php'; settings(); echo date('D H:i'), ' open=', json_encode(hours_for(date('Y-m-d')));" % A).stdout[:160], time.strftime('%a %H:%M')))
    HC = json.loads(ALLDAY); HC[str((_dt.date.today().weekday() + 1) % 7)] = None; h('set', json.dumps({'hours': json.dumps(HC)}))
    c3, s3 = post('swml', call('CA3', '+15555550103')); say('DIAG swml CA3 (dong cua hom nay) -> HTTP %s · %s' % (c3, json.dumps(s3)[:300]))
    say('DIAG hours sau khi dat dong: %s' % sh('php', '-r', "require '%s/inc/core.php'; settings(); echo date('D w'), ' today=', json_encode(hours_for(date('Y-m-d'))), ' hours=', substr((string)setting('hours'), 0, 120);" % A).stdout[:220])
    say('DIAG php.log (cuoi, bo Accepted/Closing): ' + ' | '.join([l for l in open(D + '/php.log').read().splitlines() if 'Accepted' not in l and 'Closing' not in l][-6:])[-900:])
    sys.exit(0)
ok('2 SWML: answer → "Thank you for calling American Nails. This call may be recorded." → record_call (2 channels) → connect the salon iPhone 20 s', c == 200 and 'answer' in m[0] and m[1]['play']['url'] == 'say:Thank you for calling American Nails. This call may be recorded.' and m[2]['record_call']['stereo'] is True and m[3]['connect']['to'] == '+15555550199' and m[3]['connect']['timeout'] == 20, json.dumps(m)[:600])
con = m[3]['connect'] if len(m) > 3 else {}
ok('2 (621.9 doi y: CHAT 01/11 ring - "not answered" first tells the server a=missed + the reason) iPhone leg: screening (confirm, 591) · answered → talked + hang up · not answered → a=missed&why=… then "after"', 'a=screen' in con.get('confirm', '') and con.get('result', {}).get('case', {}).get('connected', [{}])[0].get('request', {}).get('url', '').find('a=talked') > 0 and 'a=missed' in json.dumps(con['result'].get('default', [])) and 'connect_failed_reason' in json.dumps(con['result'].get('default', [])) and '"after"' in json.dumps(con['result'].get('default', [])), json.dumps(con)[:500])
ai = af[1]['ai'] if len(af) > 1 else {}
ok('2 (621.9 doi y: 2.99.606 605B - the greeting is a FIXED static_greeting said once, the prompt says it was ALREADY played) "after" = the AI agent + the menu / days / techs / the caller\'s appointments', (ai.get('params', {}).get('static_greeting') == 'Sorry we missed you – how can I help?' or 'Sorry we missed you – how can I help?' in json.dumps(ai, ensure_ascii=False)) and 'ALREADY played' in ai.get('prompt', {}).get('text', '') and 'Gel Manicure' in ai['prompt']['text'] and 'TAMMY' in ai['prompt']['text'] and "Never say a price" in ai['prompt']['text'], ai.get('prompt', {}).get('text', '')[:300])
p = ai.get('params', {})
ok('2 listening: end_of_speech_timeout 1100 ms (slow callers not cut, still fast) · barge-in on (transparent) · attention 9 s · 6 min at most · gpt-4o-mini', p.get('end_of_speech_timeout') == 1100 and p.get('enable_barge') is True and p.get('transparent_barge') is True and p.get('attention_timeout') == 9000 and p.get('hard_stop_time') == '6:00' and p.get('ai_model') == 'gpt-4o-mini', p)
fns = [f['function'] for f in ai.get('SWAIG', {}).get('functions', [])]
ok('2 voice elevenlabs.rachel:eleven_flash_v2_5 (ElevenLabs Rachel, fastest model) + fillers · 11 tools (find, check_times, book, cancel, move, add_person, change_services, late, add_note, transfer_owner, end_call) on OUR secret webhook · post_prompt_url', ai.get('languages', [{}])[0].get('voice') == 'elevenlabs.rachel:eleven_flash_v2_5' and ai['languages'][0].get('function_fillers') and fns == ['find_appointments', 'check_times', 'book', 'cancel', 'move', 'add_person', 'change_services', 'late', 'add_note', 'transfer_owner', 'end_call'] and ('a=tool&t=' + TOK) in ai['SWAIG']['defaults']['web_hook_url'] and 'a=post' in ai.get('post_prompt_url', ''), (fns, ai.get('languages')))
ok('2 the token never in the PHP log', TOK not in open(D + '/php.log').read())
# 3. closed now → still rings the owner; blocked; engine ivr → the old voicemail
HC = json.loads(ALLDAY); HC[str((_dt.date.today().weekday() + 1) % 7)] = None; h('set', json.dumps({'hours': json.dumps(HC)}))
c, s = post('swml', call('CA3', '+15555550103')); m = s['sections']['main']
ok('3 closed now → STILL rings the owner first (CHAT 07:47, anh Logan: every call rings the owner first, also after hours)', any('connect' in x for x in m), json.dumps(m)[:300])
h('set', json.dumps({'hours': ALLDAY}))
c, s = post('swml', call('CA4', 'anonymous')); m = s['sections']['main']
ok('3 a blocked / private number → the 594 sentence + hang up', 'blocked or private number' in m[1]['play']['url'] and 'hangup' in m[2], m)
h('set', json.dumps({'call_engine': 'ivr'})); c, s = post('swml', call('CA5', '+15555550105')); af = s['sections']['after']
ok('3 call_engine "ivr" (switch off) → not answered = the old free voicemail (record → read by the AI after)', not any('ai' in x for x in af) and any('record' in x for x in af), af)
h('set', json.dumps({'call_engine': 'agent'}))
c, s = post('screen', {}); mm = s['sections']['main']
ok('3 the iPhone leg screening SWML: listen 3 s, a recording ("leave a message…") → hang up that leg', 'prompt' in mm[0] and 'hangup' in json.dumps(mm[1]) and 'leave' in mm[1]['cond'][0]['when'], mm)
# 4. tools: book
post('swml', call('CB1', '+15555550111'))
c, r = tool('CB1', '+15555550111', 'check_times', date=W(4), time='14:00', persons=[{'name': 'Jessica', 'service_ids': [GM], 'tech_id': 0}])
ok('4 check_times Fri 2 PM → OPEN', r.get('response', '').startswith('OPEN '), r)
c, r = tool('CB1', '+15555550111', 'book', name='Jessica', date=W(4), time='14:00', persons=[{'name': 'Jessica', 'service_ids': [GM], 'tech_id': 0}], mani_type='gel_real', pedi_type='none', note='French tip')
a = appts('+15555550111')
ok('4 book → "BOOKED id … Jessica – a gel manicure" · the appointment (source call) · note "📞 French tip" · YOU\'RE BOOKED queued (589)', r.get('response', '').startswith('BOOKED id') and a and a[0]['service_ids'] == str(GM) and a[0]['start_min'] == 840 and '📞 French tip' in a[0]['note'] and sql("SELECT id FROM outbox WHERE phone = '+15555550111' AND kind = 'confirm'"), (r, a))
c, r = tool('CB1', '+15555550111', 'book', name='Jessica', date=W(4), time='17:00', persons=[{'name': 'Jessica', 'service_ids': [PD], 'tech_id': 0}])
ok('4 the same day again → "ALREADY_HAS … ask if this is a NEW one" (nothing booked)', r['response'].startswith('ALREADY_HAS') and len(appts('+15555550111')) == 1, r)
c, r = tool('CB1', '+15555550111', 'book', name='Jessica', date=W(4), time='17:00', persons=[{'name': 'Jessica', 'service_ids': [PD], 'tech_id': 0}], new_ok=True)
ok('4 new_ok → booked the 2nd', r['response'].startswith('BOOKED') and len(appts('+15555550111')) == 2, r)
for k, tn in enumerate(['TAMMY', 'HANA', 'SISI']): h('mk', '+1555555014%d' % k, 'BUSY%d' % k, W(2), 900, T[tn], 1)
post('swml', call('CB2', '+15555550112'))
c, r = tool('CB2', '+15555550112', 'book', name='Nia', date=W(2), time='15:00', persons=[{'name': 'Nia', 'service_ids': [GM], 'tech_id': 0}])
ok('4 a full time → "NOT_BOOKED – FULL – offer … or …" (the 2 nearest)', r['response'].startswith('NOT_BOOKED – FULL – offer ') and ' or ' in r['response'] and not appts('+15555550112'), r)
c, r = tool('CB2', '+15555550112', 'book', name='Nia', date=W(2), persons=[{'name': 'Nia', 'service_ids': [GM], 'tech_id': 0}])
ok('4 no time → "NOT_BOOKED – ask the day and the time."', 'ask the day and the time' in r['response'], r)
c, r = tool('CB2', '+15555550112', 'book', name='Nia', date=W(1), time='11:00', persons=[{'name': 'Nia', 'service_ids': [PD, GM]}, {'name': 'Mom', 'service_ids': [PD]}])
g = appts('+15555550112')
ok('4 2 people [Pedicure + Gel Manicure] (pedicure first) + [Pedicure] → BOOKED, 2 rows', r['response'].startswith('BOOKED') and len(g) == 2 and g[0]['service_ids'] == '%d,%d' % (PD, GM) and g[1]['service_ids'] == str(PD), (r, g))
# 5. cancel / cancel one / move / add person / change services / late / note
ids = h('mk', '+15555550121', 'LOVE', W(0), 720, 0, 3); post('swml', call('CC1', '+15555550121'))
c, r = tool('CC1', '+15555550121', 'find_appointments')
ok('5 find_appointments → the caller\'s own: "appt_id … 3 people: Love …, Lily …"', ('appt_id %d' % ids[0]) in r['response'] and '3 people' in r['response'], r)
c, r = tool('CC1', '+15555550121', 'cancel', appt_id=ids[0], person_name='Lily', said_date=W(0), said_time='12:00')
ok('5 cancel Lily only → "CANCELLED Lily from …" · LILY cancelled, the others stay', r['response'].startswith('CANCELLED Lily') and [x['status'] for x in appts('+15555550121')] == ['booked', 'cancelled', 'booked'], (r, appts('+15555550121')))
c, r = tool('CC1', '+15555550121', 'cancel', appt_id=ids[0], said_date=W(0), said_time='12:00')
ok('5 cancel (all) → CANCELLED · all cancelled · the call "cancelled"', r['response'].startswith('CANCELLED') and all(x['status'] == 'cancelled' for x in appts('+15555550121')) and row('CC1')['status'] == 'cancelled', (r, appts('+15555550121')))
ids = h('mk', '+15555550122', 'OLGA', W(0), 660, 0, 1); post('swml', call('CC2', '+15555550122'))
tool('CC2', '+15555550122', 'find_appointments'); c, r = tool('CC2', '+15555550122', 'move', appt_id=ids[0], date=W(0), time='16:00', said_date=W(0), said_time='11:00')
ok('5 move → "MOVED from <the real day> 11:00 AM to … 4:00 PM" · moved', r['response'].startswith('MOVED from ') and '11:00 AM to ' in r['response'] and appts('+15555550122')[0]['start_min'] == 960, (r, appts('+15555550122')))
ids2 = h('mk', '+15555550123', 'PIA', W(2), 600, 0, 1); post('swml', call('CC3', '+15555550123'))
tool('CC3', '+15555550123', 'find_appointments'); c, r = tool('CC3', '+15555550123', 'move', appt_id=ids2[0], date=W(2), time='15:00', said_date=W(2), said_time='10:00')
ok('5 move to a full time → "NOT_MOVED – FULL – offer …"', r['response'].startswith('NOT_MOVED – FULL – offer'), r)
ids = h('mk', '+15555550124', 'GIA', W(3), 720, 0, 2); post('swml', call('CC4', '+15555550124'))
tool('CC4', '+15555550124', 'find_appointments'); c, r = tool('CC4', '+15555550124', 'add_person', appt_id=ids[0], persons=[{'name': 'Ann', 'service_ids': [PD], 'tech_id': 0}], said_date=W(3), said_time='12:00')
ok('5 add_person Ann (pedicure) → "ADDED – now 3 people" · 3 rows', r['response'].startswith('ADDED – now 3 people') and len([x for x in appts('+15555550124') if x['status'] == 'booked']) == 3, (r, appts('+15555550124')))
ids = h('mk', '+15555550125', 'HAL', W(3), 600, 0, 1); post('swml', call('CC5', '+15555550125'))
tool('CC5', '+15555550125', 'find_appointments'); c, r = tool('CC5', '+15555550125', 'change_services', appt_id=ids[0], person_name='', service_ids=[GM], mode='add', said_date=W(3), said_time='10:00')
ok('5 change_services add a gel manicure → "CHANGED – Hal: Pedicure + Gel Manicure"', r['response'].startswith('CHANGED') and appts('+15555550125')[0]['service_ids'] == '%d,%d' % (PD, GM), (r, appts('+15555550125')))
today = time.strftime('%Y-%m-%d'); h('mk', '+15555550126', 'TINA', today, 1430, 0, 1); post('swml', call('CC6', '+15555550126'))
c, r = tool('CC6', '+15555550126', 'late', minutes=10)
ok('5 late 10 → "NOTED …" · note "📞 running late ~10 min" · the owner\'s push', r['response'].startswith('NOTED') and appts('+15555550126')[0]['note'].startswith('📞 running late ~10 min') and sql("SELECT title FROM push_log WHERE title LIKE '%Running late%'"), (r, appts('+15555550126')))
# 6. safety
c, r = tool('CC7', '', 'cancel', appt_id=ids[0])
ok('6 a hidden number → cancel refused: "NO_NUMBER – call transfer_owner"', r['response'].startswith('NO_NUMBER'), r)
tool('CC8', '+15555550199', 'find_appointments'); c, r = tool('CC8', '+15555550199', 'cancel', appt_id=ids[0], said_date=W(3), said_time='10:00')
ok('6 an appointment of ANOTHER number → "NOT_FOUND" (nothing cancelled)', r['response'].startswith('NOT_FOUND') and appts('+15555550125')[0]['status'] == 'booked', r)
c, r = post('tool', {'function': 'cancel', 'argument': {'parsed': [{'appt_id': ids[0]}]}, 'call_id': 'CC9', 'caller_id_num': '+15555550125', 'project_id': PROJ}, tok='bad')
ok('6 a tool call with a wrong secret → 403', c == 403, c)
post('swml', call('CD1', '+15555550131'))
c, r = tool('CD1', '+15555550131', 'transfer_owner', reason='the price')
sw = json.dumps(r.get('action', []))
ok('6 transfer_owner → "Let me connect you to the salon." + SWML connect the owner phone 25 s → not answered = the old voicemail (record, read by the AI after)', '"say": "Let me connect you to the salon."' in sw and '"to": "+15155550177"' in sw and '"timeout": 25' in sw and '"record"' in sw and '"transfer": true' in sw, sw[:500])
# 7. the end: the transcript + summary
post('post', {'call_id': 'CD1', 'caller_id_num': '+15555550131', 'project_id': PROJ, 'post_prompt_data': {'raw': 'Asked the price of a pedicure; transferred to the owner.'}, 'call_log': [{'role': 'assistant', 'content': 'Thank you for calling…'}, {'role': 'user', 'content': 'how much is a pedicure'}]}, extra='&sid=CD1')
r7 = row('CD1')
ok('7 post → transcript (caller / AI) + summary saved · a transfer = "info" (no review)', r7['text_c'] == 'how much is a pedicure' and 'Thank you' in r7['text_s'] and r7['status'] == 'info' and 'Transferred' in r7['result'], (r7['status'], r7['result']))
post('swml', call('CD2', '+15555550132'))
post('post', {'call_id': 'CD2', 'caller_id_num': '+15555550132', 'project_id': PROJ, 'post_prompt_data': {'raw': 'Wanted a pedicure, did not give a time.'}, 'call_log': [{'role': 'user', 'content': 'I want a pedicure'}]}, extra='&sid=CD2')
ok('7 nothing done → 📞 Needs review + the owner\'s push (summary)', row('CD2')['status'] == 'review' and sql("SELECT body FROM push_log WHERE body LIKE '%did not give a time%'"), row('CD2')['status'])
r1 = row('CB1'); post('post', {'call_id': 'CB1', 'caller_id_num': '+15555550111', 'project_id': PROJ, 'post_prompt_data': {'raw': 'Booked.'}, 'call_log': [{'role': 'user', 'content': 'gel manicure friday 2'}]}, extra='&sid=CB1')
ok('7 a booked call stays "booked" (kind agent) with the tools logged', row('CB1')['status'] == 'booked' and row('CB1')['kind'] == 'agent' and '"fn": "book"' in row('CB1')['ai_json'].replace('":"', '": "'), (row('CB1')['status'], row('CB1')['kind']))
# 8. answered / voicemail recordings
post('swml', call('CE1', '+15555550141')); post('talked', {}, extra='&sid=CE1')
post('rec', {'params': {'state': 'finished', 'url': 'https://nailflowapp.signalwire.com/api/v1/recordings/REC1.wav', 'duration': 62.4}}, extra='&sid=CE1')
r8 = row('CE1'); ok('8 (621.9 doi y: CHAT 01/11 606f - read AT ONCE, so it may already be "work") the iPhone answered (talked) + the recording → an answered call, queued / being read (586)', r8['kind'] == 'call' and r8['status'] in ('queued', 'work') and r8['rec_url'].endswith('REC1.wav') and r8['dur_sec'] == 62, (r8['kind'], r8['status'], r8['rec_url']))
post('swml', call('CE2', '+15555550142')); post('missed', {}, extra='&sid=CE2&vm=1'); post('rec', {'params': {'state': 'finished', 'url': 'https://nailflowapp.signalwire.com/api/v1/recordings/REC2.wav', 'duration': 20}}, extra='&sid=CE2&vm=1')
r8 = row('CE2'); ok('8 the old voicemail recording → kind vm, queued (read like today)', r8['kind'] == 'vm' and r8['status'] == 'queued', (r8['kind'], r8['status']))
# 9. Settings
cfg = h('cfg'); ok('9 Settings → Calls: "Real-time AI receptionist" offered (American Nails), on, with the SWML address for the number', cfg.get('agentOk') is True and cfg.get('agent') is True and ('call_agent.php?a=swml&t=' + TOK) in cfg.get('agentUrl', ''), cfg)
x = h('save', json.dumps({'agent': False})); ok('9 switch off → call_engine ivr', x.get('agent') is False and sql("SELECT v FROM settings WHERE k='call_engine'")[0]['v'] == 'ivr', x)
h('save', json.dumps({'agent': True}))
# 10. 605B – the change lock (01/11 07:16: "cancel 2 PM today" cancelled Tue 11/3 1 PM) + end_call
today = time.strftime('%Y-%m-%d'); tue = (_t + _dt.timedelta(days=((1 - _t.weekday()) % 7) or 7)).isoformat()
mia = h('mk', '+15555550151', 'MIA', tue, 780, 0, 1); post('swml', call('CF1', '+15555550151'))
c, r = tool('CF1', '+15555550151', 'cancel', appt_id=mia[0], said_date=today, said_time='14:00')
ok('10 cancel WITHOUT find_appointments first → "CALL find_appointments FIRST" · nothing cancelled', r['response'].startswith('CALL find_appointments FIRST') and appts('+15555550151')[0]['status'] == 'booked', r)
tool('CF1', '+15555550151', 'find_appointments')
c, r = tool('CF1', '+15555550151', 'cancel', appt_id=mia[0], said_date=today, said_time='14:00')
ok('10 replay #47: caller "cancel 2 PM today", the appointment is Tue 1 PM → "MISMATCH: appointment … is Tue … 1:00 PM. The caller said … 2:00 PM. Nothing was changed. Ask the caller which one." · still booked, no cancel text',
   r['response'].startswith('MISMATCH: appointment %d is ' % mia[0]) and '1:00 PM' in r['response'] and 'The caller said' in r['response'] and '2:00 PM' in r['response'] and appts('+15555550151')[0]['status'] == 'booked' and not sql("SELECT id FROM autosend WHERE phone = '+15555550151' AND kind LIKE '%cancel%'"), (r, appts('+15555550151')))
c, r = tool('CF1', '+15555550151', 'cancel', appt_id=mia[0], said_date=tue, said_time='14:00')
ok('10 right day, time 1 h off (> 30 min) → MISMATCH, still booked', r['response'].startswith('MISMATCH') and appts('+15555550151')[0]['status'] == 'booked', r)
c, r = tool('CF1', '+15555550151', 'cancel', appt_id=mia[0])
ok('10 no said_date → "ASK which day …" (nothing cancelled)', r['response'].startswith('ASK which day') and appts('+15555550151')[0]['status'] == 'booked', r)
c, r = tool('CF1', '+15555550151', 'cancel', appt_id=mia[0], said_date=tue, said_time='13:00')
ok('10 the right day + time → "CANCELLED <the REAL day> … 1:00 PM" · cancelled', r['response'].startswith('CANCELLED ') and tue in r['response'] and '1:00 PM' in r['response'] and appts('+15555550151')[0]['status'] == 'cancelled', (r, appts('+15555550151')))
nn = h('mk', '+15555550152', 'NINA', tue, 600, 0, 1); post('swml', call('CF2', '+15555550152'))
c, r = tool('CF2', '+15555550152', 'cancel', appt_id=nn[0], said_date=tue, said_time='')
ok('10 a NEW call: the ids found in another call do not count → CALL find_appointments FIRST', r['response'].startswith('CALL find_appointments FIRST'), r)
tool('CF2', '+15555550152', 'find_appointments')
c, r = tool('CF2', '+15555550152', 'move', appt_id=nn[0], date=tue, time='16:00', said_date=tue, said_time='10:45')
ok('10 move: said 10:45, the appointment 10:00 (45 min off) → MISMATCH, not moved', r['response'].startswith('MISMATCH') and appts('+15555550152')[0]['start_min'] == 600, r)
c, r = tool('CF2', '+15555550152', 'add_person', appt_id=nn[0], persons=[{'name': 'Zoe', 'service_ids': [PD], 'tech_id': 0}], said_date=today, said_time='10:00')
ok('10 add_person on the wrong day → MISMATCH, nobody added', r['response'].startswith('MISMATCH') and len(appts('+15555550152')) == 1, r)
c, r = tool('CF2', '+15555550152', 'change_services', appt_id=nn[0], service_ids=[GM], mode='add', said_date=today)
ok('10 change_services on the wrong day → MISMATCH, services the same', r['response'].startswith('MISMATCH') and appts('+15555550152')[0]['service_ids'] == str(PD), r)
c, r = tool('CF2', '+15555550152', 'move', appt_id=nn[0], date=tue, time='16:00', said_date=tue, said_time='10:20')
ok('10 move: only the day said + a time 20 min off (≤ 30) → MOVED from <the real day> 10:00 AM to … 4:00 PM', r['response'].startswith('MOVED from ') and '10:00 AM' in r['response'] and appts('+15555550152')[0]['start_min'] == 960, r)
c, r = tool('CF2', '+15555550152', 'end_call')
ok('10 end_call → action hangup (the caller does not have to hang up)', r.get('action') == [{'hangup': True}], r)
af = [x for x in h('swmlx', '+15555550152') if 'ai' in x] if False else None
c, sm = post('swml', call('CF3', '+15555550153')); m = sm['sections']['main']; aa = [x for x in json.dumps(sm).split('"function": ') if x.startswith('"end_call"')]
ok('10 end_call has skip_fillers (no "One moment…" before the hang-up)', aa and '"skip_fillers": true' in aa[0][:400], aa[:1])
ok('10 the SWML says "Thank you for calling … may be recorded" ONCE (the AI part only "Sorry we missed you…" – the prompt CHAT fixed 07:25)', json.dumps(m).count('Thank you for calling') == 1, json.dumps(m)[:300])
c, sm = post('swml', call('CF4', '+15555550154')); aiv = [x['ai'] for sec in sm['sections'].values() for x in sec if 'ai' in x][0]; pp = aiv['params']
ok('11 echo (AN #50): the AI greeting is static_greeting "Sorry we missed you – how can I help?" + static_greeting_no_barge (its own echo cannot cut it, and the LLM does not make it)', pp.get('static_greeting') == 'Sorry we missed you – how can I help?' and pp.get('static_greeting_no_barge') is True, pp)
ok('11 echo: barge only from 3 words (barge_min_words 3) · wait_for_user (after the greeting the AI waits for the caller)', pp.get('barge_min_words') == 3 and pp.get('wait_for_user') is True and pp.get('enable_barge') is True, pp)
ok('11 a silent caller: nothing answers itself – attention_timeout 9 s asks "still there?" (attention_timeout_prompt) · inactivity 30 s ends', pp.get('attention_timeout') == 9000 and 'still there' in pp.get('attention_timeout_prompt', '') and pp.get('inactivity_timeout') == 30000, pp)
# 12. 605B 10:06 / 10:25 – answered calls: 'talked' when a person answers the iPhone; the SWML recording from the REST file (stereo); a one-channel file → a clear review
c, scr = post('screen', {}, extra='&sid=CG1'); last = scr['sections']['main'][-1]
ok('12 (621.9 doi y: CHAT 01/11 606v - SignalWire allows NO request in a connect confirm, it broke the screening, AN #70) the iPhone-leg screening: listen, voicemail words -> hang up; NO request', 'request' not in json.dumps(scr) and 'cond' in json.dumps(scr) and 'hangup' in json.dumps(scr['sections']['main'][-1]), scr)
post('swml', call('CG1', '+15555550171')); post('talked', {}, extra='&sid=CG1')
ok('12 a=talked → the call is "talked" (kind call) right when the iPhone answers', row('CG1')['status'] == 'talked' and row('CG1')['kind'] == 'call', (row('CG1')['status'], row('CG1')['kind']))
post('rec', {'params': {'state': 'finished', 'recording_id': 'aaaaaaaa-1111-2222-3333-444444444444', 'url': 'https://files.signalwire.com/x/y/abc.wav', 'duration': 20, 'record': {'audio': {'format': 'wav', 'direction': 'both', 'stereo': True}}}}, extra='&sid=CG1')
ok('12 (621.9 doi y: 606f read at once) the answered call\'s recording → queued / being read (586)', row('CG1')['status'] in ('queued', 'work') and row('CG1')['rec_sid'] == 'aaaaaaaa-1111-2222-3333-444444444444', (row('CG1')['status'], row('CG1')['rec_sid']))
JE = {**ENV, 'NF_SW_BASE': 'http://127.0.0.1:19870', 'NF_STT_URL': 'http://127.0.0.1:19870/stt', 'NF_OAI_URL': 'http://127.0.0.1:19870/oai', 'NF_AI_URL': 'http://127.0.0.1:19870/ai'}
def hj(sid, what): r = subprocess.run(['php', D + '/hjob.php', A, sid, what], capture_output=True, text=True, env=JE); return json.loads(r.stdout or '{}') if r.stdout.strip().startswith('{') else {'out': r.stdout[-300:], 'err': r.stderr[-300:]}
fl0 = open(T5 + '/fake.log').read(); x = hj('CG1', 'fetch'); fl = open(T5 + '/fake.log').read()[len(fl0):]
ok('12 SWML recording → downloaded from the REST file /api/relay/rest/recordings/<recording_id>.wav (signed) → 2 channels (left caller, right salon)', x.get('ch') == 2 and 'GET relay aaaaaaaa-1111-2222-3333-444444444444 auth True exists True' in fl, (x, fl))
post('swml', call('CG2', '+15555550172')); post('talked', {}, extra='&sid=CG2')
post('rec', {'params': {'state': 'finished', 'recording_id': 'bbbbbbbb-1111-2222-3333-444444444444', 'url': 'http://127.0.0.1:19870/media/MONO54.wav', 'duration': 10}}, extra='&sid=CG2')
fl0 = open(T5 + '/fake.log').read(); x = hj('CG2', 'job'); fl = open(T5 + '/fake.log').read()[len(fl0):]
ok('12 not on the REST address (404) → the callback address; a ONE-channel file (AN #54) → review "One-channel recording (caller and salon mixed) – the salon\'s OK cannot be checked: listen to the call." (not "No OK heard"), nothing booked',
   x.get('status') == 'review' and x.get('reason', '').startswith('One-channel recording') and 'GET relay bbbbbbbb' in fl and 'GET media MONO54' in fl and not appts('+15555550172'), (x, fl))
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors; the secret never logged', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']) and TOK not in logs, [l for l in logs.splitlines() if 'PHP' in l][:5])
say('PASS %d/%d' % (sum(R), len(R)))
