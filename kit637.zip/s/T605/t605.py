# LAMWEB test 605 – the real-time AI receptionist (SignalWire AI Agent: SWML + SWAIG) on a local copy. Fake SignalWire requests in the docs' shapes; test numbers 555-01xx only.
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, re, datetime as _dt
A = sys.argv[1]; D = '/tmp/claude-0/T605'; T5 = '/tmp/claude-0/T586'; PORT = 19867; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-605.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SHARED_DIR': T5 + '/shared', 'NF_CALLS_DIR': D + '/calls'}
os.makedirs(D + '/calls', exist_ok=True)
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(T5 + '/shared/call-ai.json', 'w')); json.dump({}, open(T5 + '/shared/color-ai.json', 'w'))
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S, T = seed['S'], seed['T']; GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
H = D + '/h605.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/calls-agent.php'; cl_table(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'tok') echo cl_agent_token();
if ($a === 'cfg') echo json_encode(cl_cfg());
if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
if ($a === 'mk') { [$_, $_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = []; upsert_customer($ph, $name);
  for ($i = 0; $i < (int)$n; $i++) { q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)", [$date, (int)$start, 45, (int)$staff, (string)%d, $i ? ($i === 1 ? 'LILY' : $name . ' +' . $i) : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); } echo json_encode($ids); }
""" % (A, A, A, PD))
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
ALLDAY = json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)})
h('set', json.dumps({'hours': ALLDAY, 'call_engine': 'agent', 'call_owner': '5155550177', 'as_on': '1', 'as_device': 'android', 'ad_transport': 'winsms', 'salon_name': 'American Nails'}))
sh('php', '-r', "require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; set_setting('ws_key', ad_enc('WS_test_key_123456789'));" % (A, A))
TOK = h('tok')
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.2)
fk = subprocess.Popen(['python3', T5 + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
atexit.register(lambda: (sv.terminate(), fk.terminate()))
B = 'http://127.0.0.1:%d/call_agent.php' % PORT
PROJ = '11111111-2222-3333-4444-555555555555'
def post(a, body, tok=None, extra=''):
    u = B + '?a=' + a + '&t=' + (TOK if tok is None else tok) + extra
    rq = urllib.request.Request(u, data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    try: r = urllib.request.urlopen(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e: return e.code, {}
def call(cid, frm): return {'call': {'call_id': cid, 'from': frm, 'to': '+15156061616', 'project_id': PROJ, 'direction': 'inbound'}}
def tool(cid, frm, fn, **args): return post('tool', {'function': fn, 'argument': {'parsed': [args], 'raw': json.dumps(args)}, 'call_id': cid, 'caller_id_num': frm, 'project_id': PROJ, 'meta_data': {}}, extra='&sid=' + cid)
_t = _dt.date.today()
def W(k): return (_t + _dt.timedelta(days=((k - _t.weekday()) % 7) or 7) + _dt.timedelta(days=7)).isoformat()
def row(cid): x = sql("SELECT * FROM calls WHERE call_sid = '%s'" % cid); return x[0] if x else {}
def appts(ph): return sql("SELECT id, customer_name, status, appt_date, start_min, staff_id, service_ids, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)
say('== LAMWEB test 2.99.605 – LENH 605 real-time AI receptionist (SWML ai + SWAIG) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake SignalWire requests (docs shapes) · texts only into the SMS Server queue')
# 1. security
c, _ = post('swml', call('CA1', '+15555550101'), tok='wrong'); ok('1 a wrong secret → 403', c == 403, c)
c, _ = post('swml', {'call': {'call_id': 'CA1x', 'from': '+15555550101', 'project_id': '99999999-0000-0000-0000-000000000000'}}); ok('1 another SignalWire project → 403', c == 403, c)
# 2. in the opening hours: greeting, recording, the iPhone 20 s, then the AI
c, s = post('swml', call('CA2', '+15555550102')); m = s.get('sections', {}).get('main', []); af = s.get('sections', {}).get('after', [])
ok('2 SWML: answer → "Thank you for calling American Nails. This call may be recorded." → record_call (2 channels) → connect the salon iPhone 20 s', c == 200 and 'answer' in m[0] and m[1]['play']['url'] == 'say:Thank you for calling American Nails. This call may be recorded.' and m[2]['record_call']['stereo'] is True and m[3]['connect']['to'] == '+15555550199' and m[3]['connect']['timeout'] == 20, json.dumps(m)[:600])
con = m[3]['connect'] if len(m) > 3 else {}
ok('2 the iPhone leg answered → screening of its voicemail (confirm, 591) · answered → a normal call (talked, hang up) · not answered → the "after" section', 'a=screen' in con.get('confirm', '') and con.get('result', {}).get('case', {}).get('connected', [{}])[0].get('request', {}).get('url', '').find('a=talked') > 0 and con['result']['default'] == [{'execute': {'dest': 'after'}}], json.dumps(con)[:500])
ai = af[1]['ai'] if len(af) > 1 else {}
ok('2 "after" = the AI agent: prompt opens "Thank you for calling American Nails, this call may be recorded. Sorry we missed you – how can I help?" + the menu / days / techs / the caller\'s appointments', 'Sorry we missed you – how can I help?' in ai.get('prompt', {}).get('text', '') and 'Gel Manicure' in ai['prompt']['text'] and 'TAMMY' in ai['prompt']['text'] and "Never say a price" in ai['prompt']['text'], ai.get('prompt', {}).get('text', '')[:300])
p = ai.get('params', {})
ok('2 listening: end_of_speech_timeout 1100 ms (slow callers not cut, still fast) · barge-in on (transparent) · attention 9 s · 6 min at most · gpt-4o-mini', p.get('end_of_speech_timeout') == 1100 and p.get('enable_barge') is True and p.get('transparent_barge') is True and p.get('attention_timeout') == 9000 and p.get('hard_stop_time') == '6:00' and p.get('ai_model') == 'gpt-4o-mini', p)
fns = [f['function'] for f in ai.get('SWAIG', {}).get('functions', [])]
ok('2 voice elevenlabs.rachel:eleven_flash_v2_5 (ElevenLabs Rachel, fastest model) + fillers · 10 tools (find, check_times, book, cancel, move, add_person, change_services, late, add_note, transfer_owner) on OUR secret webhook · post_prompt_url', ai.get('languages', [{}])[0].get('voice') == 'elevenlabs.rachel:eleven_flash_v2_5' and ai['languages'][0].get('function_fillers') and fns == ['find_appointments', 'check_times', 'book', 'cancel', 'move', 'add_person', 'change_services', 'late', 'add_note', 'transfer_owner'] and ('a=tool&t=' + TOK) in ai['SWAIG']['defaults']['web_hook_url'] and 'a=post' in ai.get('post_prompt_url', ''), (fns, ai.get('languages')))
ok('2 the token never in the PHP log', TOK not in open(D + '/php.log').read())
# 3. closed now → no ring; blocked; engine ivr → the old voicemail
HC = json.loads(ALLDAY); HC[str((_dt.date.today().weekday() + 1) % 7)] = None; h('set', json.dumps({'hours': json.dumps(HC)}))
c, s = post('swml', call('CA3', '+15555550103')); m = s['sections']['main']
ok('3 closed now → NO connect to the iPhone: the AI at once', not any('connect' in x for x in m) and any('ai' in x for x in m), json.dumps(m)[:300])
h('set', json.dumps({'hours': ALLDAY}))
c, s = post('swml', call('CA4', 'anonymous')); m = s['sections']['main']
ok('3 a blocked / private number → the 594 sentence + hang up', 'blocked or private number' in m[1]['play']['url'] and 'hangup' in m[2], m)
h('set', json.dumps({'call_engine': 'ivr'})); c, s = post('swml', call('CA5', '+15555550105')); af = s['sections']['after']
ok('3 call_engine "ivr" (switch off) → not answered = the old free voicemail (record → read by the AI after)', not any('ai' in x for x in af) and any('record' in x for x in af), af)
h('set', json.dumps({'call_engine': 'agent'}))
c, s = post('screen', {}); mm = s['sections']['main']
ok('3 the iPhone leg screening SWML: listen 3 s, a recording ("leave a message…") → hang up that leg', 'prompt' in mm[0] and 'hangup' in json.dumps(mm[1]) and 'leave' in mm[1]['cond'][0]['when'], mm)
# 4. tools: book
post('swml', call('CB1', '+15555550111'))
c, r = tool('CB1', '+15555550111', 'check_times', date=W(4), time='14:00', persons=[{'name': 'Jessica', 'service_ids': [GM], 'tech_id': 0}])
ok('4 check_times Fri 2 PM → OPEN', r.get('response', '').startswith('OPEN '), r)
c, r = tool('CB1', '+15555550111', 'book', name='Jessica', date=W(4), time='14:00', persons=[{'name': 'Jessica', 'service_ids': [GM], 'tech_id': 0}], mani_type='gel_real', pedi_type='none', note='French tip')
a = appts('+15555550111')
ok('4 book → "BOOKED id … Jessica – a gel manicure" · the appointment (source call) · note "📞 French tip" · YOU\'RE BOOKED queued (589)', r.get('response', '').startswith('BOOKED id') and a and a[0]['service_ids'] == str(GM) and a[0]['start_min'] == 840 and '📞 French tip' in a[0]['note'] and sql("SELECT id FROM outbox WHERE phone = '+15555550111' AND kind = 'confirm'"), (r, a))
c, r = tool('CB1', '+15555550111', 'book', name='Jessica', date=W(4), time='17:00', persons=[{'name': 'Jessica', 'service_ids': [PD], 'tech_id': 0}])
ok('4 the same day again → "ALREADY_HAS … ask if this is a NEW one" (nothing booked)', r['response'].startswith('ALREADY_HAS') and len(appts('+15555550111')) == 1, r)
c, r = tool('CB1', '+15555550111', 'book', name='Jessica', date=W(4), time='17:00', persons=[{'name': 'Jessica', 'service_ids': [PD], 'tech_id': 0}], new_ok=True)
ok('4 new_ok → booked the 2nd', r['response'].startswith('BOOKED') and len(appts('+15555550111')) == 2, r)
for k, tn in enumerate(['TAMMY', 'HANA', 'SISI']): h('mk', '+1555555014%d' % k, 'BUSY%d' % k, W(2), 900, T[tn], 1)
post('swml', call('CB2', '+15555550112'))
c, r = tool('CB2', '+15555550112', 'book', name='Nia', date=W(2), time='15:00', persons=[{'name': 'Nia', 'service_ids': [GM], 'tech_id': 0}])
ok('4 a full time → "NOT_BOOKED – FULL – offer … or …" (the 2 nearest)', r['response'].startswith('NOT_BOOKED – FULL – offer ') and ' or ' in r['response'] and not appts('+15555550112'), r)
c, r = tool('CB2', '+15555550112', 'book', name='Nia', date=W(2), persons=[{'name': 'Nia', 'service_ids': [GM], 'tech_id': 0}])
ok('4 no time → "NOT_BOOKED – ask the day and the time."', 'ask the day and the time' in r['response'], r)
c, r = tool('CB2', '+15555550112', 'book', name='Nia', date=W(1), time='11:00', persons=[{'name': 'Nia', 'service_ids': [PD, GM]}, {'name': 'Mom', 'service_ids': [PD]}])
g = appts('+15555550112')
ok('4 2 people [Pedicure + Gel Manicure] (pedicure first) + [Pedicure] → BOOKED, 2 rows', r['response'].startswith('BOOKED') and len(g) == 2 and g[0]['service_ids'] == '%d,%d' % (PD, GM) and g[1]['service_ids'] == str(PD), (r, g))
# 5. cancel / cancel one / move / add person / change services / late / note
ids = h('mk', '+15555550121', 'LOVE', W(0), 720, 0, 3); post('swml', call('CC1', '+15555550121'))
c, r = tool('CC1', '+15555550121', 'find_appointments')
ok('5 find_appointments → the caller\'s own: "appt_id … 3 people: Love …, Lily …"', ('appt_id %d' % ids[0]) in r['response'] and '3 people' in r['response'], r)
c, r = tool('CC1', '+15555550121', 'cancel', appt_id=ids[0], person_name='Lily')
ok('5 cancel Lily only → "CANCELLED Lily from …" · LILY cancelled, the others stay', r['response'].startswith('CANCELLED Lily') and [x['status'] for x in appts('+15555550121')] == ['booked', 'cancelled', 'booked'], (r, appts('+15555550121')))
c, r = tool('CC1', '+15555550121', 'cancel', appt_id=ids[0])
ok('5 cancel (all) → CANCELLED · all cancelled · the call "cancelled"', r['response'].startswith('CANCELLED') and all(x['status'] == 'cancelled' for x in appts('+15555550121')) and row('CC1')['status'] == 'cancelled', (r, appts('+15555550121')))
ids = h('mk', '+15555550122', 'OLGA', W(0), 660, 0, 1); post('swml', call('CC2', '+15555550122'))
c, r = tool('CC2', '+15555550122', 'move', appt_id=ids[0], date=W(0), time='16:00')
ok('5 move → "MOVED to … 4:00 PM" · moved', r['response'].startswith('MOVED to') and appts('+15555550122')[0]['start_min'] == 960, (r, appts('+15555550122')))
ids2 = h('mk', '+15555550123', 'PIA', W(2), 600, 0, 1); post('swml', call('CC3', '+15555550123'))
c, r = tool('CC3', '+15555550123', 'move', appt_id=ids2[0], date=W(2), time='15:00')
ok('5 move to a full time → "NOT_MOVED – FULL – offer …"', r['response'].startswith('NOT_MOVED – FULL – offer'), r)
ids = h('mk', '+15555550124', 'GIA', W(3), 720, 0, 2); post('swml', call('CC4', '+15555550124'))
c, r = tool('CC4', '+15555550124', 'add_person', appt_id=ids[0], persons=[{'name': 'Ann', 'service_ids': [PD], 'tech_id': 0}])
ok('5 add_person Ann (pedicure) → "ADDED – now 3 people" · 3 rows', r['response'].startswith('ADDED – now 3 people') and len([x for x in appts('+15555550124') if x['status'] == 'booked']) == 3, (r, appts('+15555550124')))
ids = h('mk', '+15555550125', 'HAL', W(3), 600, 0, 1); post('swml', call('CC5', '+15555550125'))
c, r = tool('CC5', '+15555550125', 'change_services', appt_id=ids[0], person_name='', service_ids=[GM], mode='add')
ok('5 change_services add a gel manicure → "CHANGED – Hal: Pedicure + Gel Manicure"', r['response'].startswith('CHANGED') and appts('+15555550125')[0]['service_ids'] == '%d,%d' % (PD, GM), (r, appts('+15555550125')))
today = time.strftime('%Y-%m-%d'); h('mk', '+15555550126', 'TINA', today, 1430, 0, 1); post('swml', call('CC6', '+15555550126'))
c, r = tool('CC6', '+15555550126', 'late', minutes=10)
ok('5 late 10 → "NOTED …" · note "📞 running late ~10 min" · the owner\'s push', r['response'].startswith('NOTED') and appts('+15555550126')[0]['note'].startswith('📞 running late ~10 min') and sql("SELECT title FROM push_log WHERE title LIKE '%Running late%'"), (r, appts('+15555550126')))
# 6. safety
c, r = tool('CC7', '', 'cancel', appt_id=ids[0])
ok('6 a hidden number → cancel refused: "NO_NUMBER – call transfer_owner"', r['response'].startswith('NO_NUMBER'), r)
c, r = tool('CC8', '+15555550199', 'cancel', appt_id=ids[0])
ok('6 an appointment of ANOTHER number → "NOT_FOUND" (nothing cancelled)', r['response'].startswith('NOT_FOUND') and appts('+15555550125')[0]['status'] == 'booked', r)
c, r = post('tool', {'function': 'cancel', 'argument': {'parsed': [{'appt_id': ids[0]}]}, 'call_id': 'CC9', 'caller_id_num': '+15555550125', 'project_id': PROJ}, tok='bad')
ok('6 a tool call with a wrong secret → 403', c == 403, c)
post('swml', call('CD1', '+15555550131'))
c, r = tool('CD1', '+15555550131', 'transfer_owner', reason='the price')
sw = json.dumps(r.get('action', []))
ok('6 transfer_owner → "Let me connect you to the salon." + SWML connect the owner phone 25 s → not answered = the old voicemail (record, read by the AI after)', '"say": "Let me connect you to the salon."' in sw and '"to": "+15155550177"' in sw and '"timeout": 25' in sw and '"record"' in sw and '"transfer": true' in sw, sw[:500])
# 7. the end: the transcript + summary
post('post', {'call_id': 'CD1', 'caller_id_num': '+15555550131', 'project_id': PROJ, 'post_prompt_data': {'raw': 'Asked the price of a pedicure; transferred to the owner.'}, 'call_log': [{'role': 'assistant', 'content': 'Thank you for calling…'}, {'role': 'user', 'content': 'how much is a pedicure'}]}, extra='&sid=CD1')
r7 = row('CD1')
ok('7 post → transcript (caller / AI) + summary saved · a transfer = "info" (no review)', r7['text_c'] == 'how much is a pedicure' and 'Thank you' in r7['text_s'] and r7['status'] == 'info' and 'Transferred' in r7['result'], (r7['status'], r7['result']))
post('swml', call('CD2', '+15555550132'))
post('post', {'call_id': 'CD2', 'caller_id_num': '+15555550132', 'project_id': PROJ, 'post_prompt_data': {'raw': 'Wanted a pedicure, did not give a time.'}, 'call_log': [{'role': 'user', 'content': 'I want a pedicure'}]}, extra='&sid=CD2')
ok('7 nothing done → 📞 Needs review + the owner\'s push (summary)', row('CD2')['status'] == 'review' and sql("SELECT body FROM push_log WHERE body LIKE '%did not give a time%'"), row('CD2')['status'])
r1 = row('CB1'); post('post', {'call_id': 'CB1', 'caller_id_num': '+15555550111', 'project_id': PROJ, 'post_prompt_data': {'raw': 'Booked.'}, 'call_log': [{'role': 'user', 'content': 'gel manicure friday 2'}]}, extra='&sid=CB1')
ok('7 a booked call stays "booked" (kind agent) with the tools logged', row('CB1')['status'] == 'booked' and row('CB1')['kind'] == 'agent' and '"fn": "book"' in row('CB1')['ai_json'].replace('":"', '": "'), (row('CB1')['status'], row('CB1')['kind']))
# 8. answered / voicemail recordings
post('swml', call('CE1', '+15555550141')); post('talked', {}, extra='&sid=CE1')
post('rec', {'params': {'state': 'finished', 'url': 'https://nailflowapp.signalwire.com/api/v1/recordings/REC1.wav', 'duration': 62.4}}, extra='&sid=CE1')
r8 = row('CE1'); ok('8 the iPhone answered (talked) + the recording → an answered call, queued to be read (586)', r8['kind'] == 'call' and r8['status'] == 'queued' and r8['rec_url'].endswith('REC1.wav') and r8['dur_sec'] == 62, (r8['kind'], r8['status'], r8['rec_url']))
post('swml', call('CE2', '+15555550142')); post('missed', {}, extra='&sid=CE2&vm=1'); post('rec', {'params': {'state': 'finished', 'url': 'https://nailflowapp.signalwire.com/api/v1/recordings/REC2.wav', 'duration': 20}}, extra='&sid=CE2&vm=1')
r8 = row('CE2'); ok('8 the old voicemail recording → kind vm, queued (read like today)', r8['kind'] == 'vm' and r8['status'] == 'queued', (r8['kind'], r8['status']))
# 9. Settings
cfg = h('cfg'); ok('9 Settings → Calls: "Real-time AI receptionist" offered (American Nails), on, with the SWML address for the number', cfg.get('agentOk') is True and cfg.get('agent') is True and ('call_agent.php?a=swml&t=' + TOK) in cfg.get('agentUrl', ''), cfg)
x = h('save', json.dumps({'agent': False})); ok('9 switch off → call_engine ivr', x.get('agent') is False and sql("SELECT v FROM settings WHERE k='call_engine'")[0]['v'] == 'ivr', x)
h('save', json.dumps({'agent': True}))
logs = open(D + '/php.log').read()
ok('No PHP warnings / errors; the secret never logged', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'PHP Deprecated', 'Uncaught']) and TOK not in logs, [l for l in logs.splitlines() if 'PHP' in l][:5])
say('PASS %d/%d' % (sum(R), len(R)))
