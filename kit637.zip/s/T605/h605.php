<?php require '/tmp/claude-0/FX616/inc/core.php'; settings(); require_once '/tmp/claude-0/FX616/inc/calls.php'; require_once '/tmp/claude-0/FX616/inc/calls-agent.php'; cl_table(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'tok') echo cl_agent_token();
if ($a === 'cfg') echo json_encode(cl_cfg());
if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
if ($a === 'mk') { [$_, $_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = []; upsert_customer($ph, $name);
  for ($i = 0; $i < (int)$n; $i++) { q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)", [$date, (int)$start, 45, (int)$staff, (string)2, $i ? ($i === 1 ? 'LILY' : $name . ' +' . $i) : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); } echo json_encode($ids); }
