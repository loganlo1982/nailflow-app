# ===== LENH-615 muc 15/16: 612b..q + loi tim thay (LAMWEB) =====
say('== 615 – test them cho 612b..q (moi ban 1-2 test) + loi review')
def reqp(a, body, extra):
    raw = urllib.parse.urlencode(body).encode(); hd = {'Content-Type': 'application/x-www-form-urlencoded'}
    if SIGN:
        ts = str(int(time.time())); bf = D + '/.b-' + str(threading.get_ident()); open(bf, 'wb').write(raw); hd['telnyx-timestamp'] = ts; hd['telnyx-signature-ed25519'] = h('sign', SIGN, ts, bf)
    return hd, raw, B + '?a=' + a + '&t=' + TOK + extra
def fire(hd, raw, u):
    try: r = urllib.request.urlopen(urllib.request.Request(u, data=raw, headers=hd), timeout=60); return r.status
    except urllib.error.HTTPError as e: return e.code
def rd(sid): return open(D + '/fake_tx.log').read().count('/texml/Accounts/ACC1/Calls/' + urllib.parse.quote(sid, safe=''))
def leg(sid, frm):
    req('in', {'CallSid': sid, 'From': frm, 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True)
    return '&sid=' + urllib.parse.quote(sid, safe='')
def cb(sid, frm):
    req('in', {'CallSid': sid, 'From': frm, 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True); req('after', {'CallSid': sid, 'DialCallStatus': 'no-answer'}, form=True, extra='&sid=' + urllib.parse.quote(sid, safe=''))
def tool(sid, fn, **a):
    c, x = req('tool', a, extra='&fn=' + fn + '&ccid=' + urllib.parse.quote(sid, safe=''))
    try: return json.loads(x).get('result', '')
    except Exception: return x
# 612b
e = leg('v3:Q1', '+15555550131'); c, x = req('screened', {'SpeechResult': "You've reached Logan please leave a message after the tone", 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.4)
ok('612b hop thu iPhone (screened) → leg Hangup + 1 REST "update call" cho cuoc khach + screen vmai + kind agent', '<Hangup/>' in x and rd('v3:Q1') == 1 and row('v3:Q1').get('screen') == 'vmai' and row('v3:Q1').get('kind') == 'agent', (x, rd('v3:Q1'), row('v3:Q1').get('screen')))
fl = urllib.parse.unquote_plus(open(D + '/fake_tx.log').read()); ok('612b REST body = Texml <Connect action=aiend><AIAssistant id="assistant-test-1">', 'Texml=' in fl and 'AIAssistant id="assistant-test-1' in fl and 'a=aiend' in fl, fl[-300:])
# 612c / 612d / 612e: MP3 (mpg123 = /tmp/claude-0/T616/mpg123 stand-in, ffmpeg)
PH = D + '/h615.php'
open(PH, 'w').write("""<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/calls-tx.php'; tx_table(); $a = $argv[1];
if ($a === 'wav') { $f = cl_dir() . '/.t615.mp3'; copy('%s/x.mp3', $f); try { echo tx_wavify($f) ? 'WAV' : 'FALSE'; } catch (Throwable $e) { echo 'ERR ' . get_class($e) . ': ' . $e->getMessage(); } @unlink($f); }
if ($a === 'fetch') { $n0 = count(glob(cl_dir() . '/.dl-*')); try { tx_fetch((int)$argv[2], 'http://127.0.0.1:19872/media/MP3X1.mp3', 'ACC1', 'MP3X1'); echo 'OK'; } catch (Throwable $e) { echo 'ERR ' . $e->getMessage(); } echo ' dl+' . (count(glob(cl_dir() . '/.dl-*')) - $n0); }
if ($a === 'cli') { tx_cli_mp3(); echo 'done'; }
""" % (A, A, A, D))
def ph(*a, dis=False): return sh('php', *(['-d', 'disable_functions=exec,shell_exec,system,passthru,proc_open,popen'] if dis else []), PH, *[str(x) for x in a]).stdout
r = ph('wav'); ok('612c tx_wavify MP3 2 kenh → WAV (mpg123, CLI)', r == 'WAV', r)
r = ph('wav', dis=True); ok('L4 web (exec TAT) – tx_wavify KHONG nem Error (tra false, de cron 612d/e lam)', r == 'FALSE', r)
cb('v3:Q2', '+15555550132'); qid = int(row('v3:Q2')['id'])
r = ph('fetch', qid, dis=True); ok('L4b exec tat: tx_fetch loi KHONG de lai file tam .dl-* (MP3 moi cuoc)', r.endswith('dl+0'), r)
sql("UPDATE calls SET prov = 'tx', status = 'review', kind = 'call', reason = 'Telnyx recording: exec', rec_sid = 'MP3X2', file = '' WHERE id = %d" % qid)
r = ph('cli'); rq = row('v3:Q2'); fl = open(D + '/fake_tx.log').read()
ok('612d/e cron tx_cli_mp3: cuoc review (MP3) → GET /recordings/MP3X2 → WAV → queued', (rq.get('file') or '').endswith('.wav') and rq.get('status') != 'review', (r, rq.get('status'), rq.get('file'), rq.get('reason')))
ok('L10 (moi) cron tx_cli_mp3 … roi XOA ban ghi am tren Telnyx (DELETE recording MP3X2) nhu duong web', any(l.startswith('DELETE') and 'MP3X2' in l for l in fl.splitlines()), [l for l in fl.splitlines() if 'MP3X2' in l])
# 612f tx_guard
cb('v3:Q3', '+15555550133'); g = [tool('v3:Q3', 'find_appointments') for _ in range(3)]
ok('612f tx_guard: cung tool + cung tham so lan 3 → "STOP … transfer"', 'STOP' in g[2] and 'STOP' not in g[1], [x[:40] for x in g])
# 612h vmpart + PASSED today
e = leg('v3:Q4', '+15555550134'); req('vmpart', {'UnstableSpeechResult': 'the person you are calling is not available', 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.3)
c, x = req('screened', {'SpeechResult': 'the person you are calling is not available please leave a message after the tone', 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.3)
ok('612h vmpart "not available" → vmai + chuyen AI NGAY; screened sau → Hangup, KHONG chuyen lan 2', row('v3:Q4').get('screen') == 'vmai' and rd('v3:Q4') == 1 and '<Hangup/>' in x, (rd('v3:Q4'), row('v3:Q4').get('screen'), x))
cb('v3:Q5', '+15555550135'); _pt = time.localtime(time.time() - 300); r = tool('v3:Q5', 'check_times', date=time.strftime('%Y-%m-%d', _pt), time=time.strftime('%H:%M', _pt), persons=[{'name': 'A', 'service_ids': [S['Pedicure']], 'tech_id': 0}])
ok('612h hom nay gio da qua → "PASSED … NEXT <thu>"', r.startswith('PASSED'), r[:120])
# 612k Verizon
e = leg('v3:Q6', '+15555550136'); req('vmpart', {'UnstableSpeechResult': 'your call has been forwarded to an automated voice messaging system', 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.3)
ok('612k Verizon "has been forwarded to an automated voice messaging system" → vmai + 1 chuyen AI', row('v3:Q6').get('screen') == 'vmai' and rd('v3:Q6') == 1, (row('v3:Q6').get('screen'), rd('v3:Q6')))
# 612l cancel bye + L2
cb('v3:Q7', '+15555550137'); a1 = h('mk', '+15555550137', 'KIM', TOM, 600, 0); a2 = h('mk', '+15555550137', 'KIM', (_t + _dt.timedelta(days=2)).isoformat(), 600, 0)
tool('v3:Q7', 'find_appointments'); r = tool('v3:Q7', 'cancel', appt_id=a1, said_date=TOM, said_time='10:00')
ok('612l huy xong → "Okay, it\'s cancelled. Have a good day!" + hangup', r.startswith('CANCELLED') and 'Have a good day' in r, r[:200])
ok('L2 khach con hen KHAC → KHONG bao bye + cup ngay (con hen co the can huy tiep)', 'hang up right away' not in r, r[-200:])
# 612o
e = leg('v3:Q8', '+15555550138'); req('vmpart', {'UnstableSpeechResult': 'you call', 'AccountSid': 'ACC1'}, form=True, extra=e)
req('amd', {'AnsweredBy': 'machine_end_beep', 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.3)
c, x = req('screened', {'SpeechResult': 'you call', 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.3)
ok('612o AMD machine + Gather dung som ("you call", khong co loi chao) → AI, 1 lan chuyen', row('v3:Q8').get('screen') == 'vmai' and rd('v3:Q8') == 1, (row('v3:Q8').get('screen'), rd('v3:Q8'), x))
# 612p
e = leg('v3:Q9', '+15555550139'); req('screened', {'SpeechResult': 'Hello', 'AccountSid': 'ACC1'}, form=True, extra=e); req('amd', {'AnsweredBy': 'machine_start', 'AccountSid': 'ACC1'}, form=True, extra=e); c, x = req('after', {'CallSid': 'v3:Q9', 'DialCallStatus': 'completed', 'DialCallDuration': '40'}, form=True, extra=e)
ok('612p chu noi "Hello" → person; AMD machine sau KHONG chuyen; Dial xong → Hangup', rd('v3:Q9') == 0 and '<Hangup/>' in x and row('v3:Q9').get('kind') == 'call', (rd('v3:Q9'), x, row('v3:Q9').get('kind')))
e = leg('v3:Q10', '+15555550140'); req('vmpart', {'UnstableSpeechResult': 'hi this is the voicemail of', 'AccountSid': 'ACC1'}, form=True, extra=e); c, x = req('screened', {'SpeechResult': '', 'AccountSid': 'ACC1'}, form=True, extra=e)
req('amd', {'AnsweredBy': 'machine_end_other', 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.3)
ok('612p/q nghe 1-2 s (trong) roi AMD machine + da nghe tieng hop thu → chuyen AI', rd('v3:Q10') == 1 and row('v3:Q10').get('screen') == 'vmai', (rd('v3:Q10'), row('v3:Q10').get('screen')))
# 612q + L8 / L9
e = leg('v3:Q11', '+15555550141'); c, x0 = req('screened', {'SpeechResult': '', 'AccountSid': 'ACC1'}, form=True, extra=e); req('amd', {'AnsweredBy': 'machine_start', 'AccountSid': 'ACC1'}, form=True, extra=e)
ok('612q chu bat may IM LANG (khong nghe gi) + AMD machine → KHONG chuyen', rd('v3:Q11') == 0, rd('v3:Q11'))
c, x = req('after', {'CallSid': 'v3:Q11', 'DialCallStatus': 'completed', 'DialCallDuration': '60'}, form=True, extra=e)
ok('L8 (moi) … chu noi 60 s roi cup → after <Hangup/> (khong dua khach vao AI), kind call', '<Hangup/>' in x and '<AIAssistant' not in x and row('v3:Q11').get('kind') == 'call', (x[-120:], row('v3:Q11').get('screen'), row('v3:Q11').get('kind')))
e = leg('v3:Q12', '+15555550142'); req('amd', {'AnsweredBy': 'machine_start', 'AccountSid': 'ACC1'}, form=True, extra=e); c, x = req('screened', {'SpeechResult': '', 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.3)
ok('L9 (moi) AMD machine TRUOC, chu im lang (screened rong) → noi may (Response rong), KHONG cup leg chu', x.endswith('<Response></Response>') and rd('v3:Q12') == 0, (x, rd('v3:Q12'), row('v3:Q12').get('screen')))
# L1
e = leg('v3:Q13', '+15555550143'); c, x = req('screened', {'SpeechResult': 'Hello thank you for calling American Nails and Spa how can I help you', 'AccountSid': 'ACC1'}, form=True, extra=e); time.sleep(0.3)
ok('L1 chu chao dai 13 tu ("Hello thank you for calling American Nails and Spa…") → NGUOI, khong chuyen AI', x.endswith('<Response></Response>') and rd('v3:Q13') == 0, (x, rd('v3:Q13'), row('v3:Q13').get('screen')))
# L3 race
bad = []
for k in range(20):
    sid = 'v3:QR%d' % k; e = leg(sid, '+155555501%02d' % (50 + k)); req('vmpart', {'UnstableSpeechResult': 'hello is not', 'AccountSid': 'ACC1'}, form=True, extra=e)
    ev = threading.Event(); pre = [reqp('amd', {'AnsweredBy': 'machine_start', 'AccountSid': 'ACC1'}, e)] + [reqp('vmpart', {'UnstableSpeechResult': 'the person is not available please leave a message' + ' .' * j, 'AccountSid': 'ACC1'}, e) for j in range(3)]
    def g(p, ev=ev): ev.wait(); fire(*p)
    th = [threading.Thread(target=g, args=(p,)) for p in pre]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]; time.sleep(0.2)
    if rd(sid) != 1: bad.append((sid, rd(sid)))
ok('L3 3 vmpart + 1 amd CUNG LUC (20 vong) → moi cuoc chuyen AI DUNG 1 lan', not bad, bad)
# L5
import glob as _gl
nt = len(_gl.glob(D + '/calls/txg-*') + _gl.glob(D + '/calls/txh-*'))
code = open(A + '/inc/calls-tx.php').read() + open(A + '/inc/calls.php').read() + open(A + '/cron/turn.php').read()
ok('L5 file tam txg-*.json / txh-*.txt co duoc don (unlink / glob)', re.search(r"unlink[^;]*tx[gh]-|glob\([^)]*tx[gh]-", code) is not None, '%d file txg/txh trong thu muc ghi am, code khong xoa' % nt)
