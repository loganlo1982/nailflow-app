import sys
s = open('/tmp/claude-0/T612/t612.py').read()
s = s.replace("out = open(D + '/test-612.txt', 'w')", "out = open('/tmp/claude-0/T616/test-%s.txt'" % sys.argv[1] + ", 'w')")
s = s.replace("ok('4 AMD says machine (second net) → the AI', '<AIAssistant' in x, x)",
 "ok('4 (612p doi y) \"Hello?\" + AMD machine → KHONG chuyen (nguoi da noi), Dial completed → <Hangup/>', '<Hangup/>' in x and '<AIAssistant' not in x and row('v3:CB6').get('screen') == 'person', (x, row('v3:CB6').get('screen')))")
if sys.argv[1] != 'live':
    s = s.replace("""ok('1 tools: 9 webhook tools (same names / schemas as cl_agent_ai) + transfer (owner +15155550177) + hangup', wh == ['find_appointments', 'check_times', 'book', 'cancel', 'move', 'add_person', 'change_services', 'late', 'add_note']
   and any(t['type'] == 'transfer' and t['transfer']['targets'][0]['to'] == '+15155550177' for t in tl) and any(t['type'] == 'hangup' for t in tl), wh)""",
    """ok('1 (616 doi y) tools: 10 webhook tools (cl_agent_ai + transfer_owner CUA MINH) + hangup, KHONG co transfer Telnyx', wh == ['find_appointments', 'check_times', 'book', 'cancel', 'move', 'add_person', 'change_services', 'late', 'add_note', 'transfer_owner']
   and not any(t['type'] == 'transfer' for t in tl) and any(t['type'] == 'hangup' for t in tl), wh)""")
    s = s.replace("""ok('7 aiend service_error → <Dial> the owner phone (+15155550177)', '<Dial timeout="25">+15155550177</Dial>' in x, x)""",
    """ok('7 (616 doi y) aiend service_error → <Dial timeout="20" action=a=xfer> the owner phone (+15155550177)', '<Dial timeout="20"' in x and 'a=xfer' in x and '+15155550177</Dial>' in x, x)""")
add = open('/tmp/claude-0/T616/add.py').read() + '\n' + (open('/tmp/claude-0/T616/add616.py').read() if sys.argv[1] != 'live' else '')
i = s.rindex("say('PASS")
s = s[:i] + 'import threading, glob\n' + add + s[i:]
open('/tmp/claude-0/T616/t616full.py', 'w').write(s)
print('ok', s.count('616 doi y'))
