# ===== 2.99.616 (LENH-616-GOP: 616 + 617) =====
say('== 616 – transfer an toan (B2 / 617.2) · missed call text (617.1) · chong trung (B1) · aiend khong sleep · thoi gian AI (617.4) · don file (617.3)')
def xs(sid): return urllib.parse.quote(sid, safe='')
def flog(): return open(D + '/fake_tx.log').read()
# tools: no Telnyx transfer; transfer_owner = our webhook
st = h('setup', 'ai'); fs_ = sorted(glob.glob(D + '/last-_v__ai_assistants*.json'), key=os.path.getmtime); ab = json.load(open(fs_[-1])); tl = ab.get('tools', [])
wt = [t for t in tl if t['type'] == 'webhook' and t['webhook']['name'] == 'transfer_owner']
ok('616 B2 assistant: KHONG con tool "transfer" cua Telnyx; transfer_owner = webhook cua minh (fn=transfer_owner, ccid)', not any(t['type'] == 'transfer' for t in tl) and wt and 'fn=transfer_owner' in wt[0]['webhook']['url'] and wt[0]['webhook']['preset_query_params'] == {'ccid': '{{call_control_id}}'}, [t['type'] for t in tl])
# the account kept from ?a=in
req('in', {'CallSid': 'v3:X0', 'From': '+15555550160', 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True)
ok('616 AccountSid giu tu ?a=in (setting tx_acct) – de tool transfer goi REST', sql("SELECT v FROM settings WHERE k = 'tx_acct'") == [{'v': 'ACC1'}], sql("SELECT v FROM settings WHERE k = 'tx_acct'"))
# owner = a different phone -> REST update -> Dial 20 s action=xfer
h('set', json.dumps({'call_owner': '5155550177'})); cb('v3:X1', '+15555550161'); n0 = flog().count('Calls/v3%3AX1')
r = tool('v3:X1', 'transfer_owner', reason='price question'); fl = urllib.parse.unquote_plus(flog())
ok('616 B2 co "Owner phone" (khac iPhone) → REST update call: <Dial timeout="20" action=a=xfer>+15155550177</Dial>; AI chi noi "One moment…"', r.startswith('CONNECTING') and flog().count('Calls/v3%3AX1') == n0 + 1 and '<Dial timeout="20"' in fl and 'a=xfer' in fl and '+15155550177</Dial>' in fl, (r, fl[-260:]))
ok('616 … ket qua cuoc "📞 Transferred to the owner – price question"', 'Transferred to the owner' in (row('v3:X1').get('result') or ''), row('v3:X1').get('result'))
c, x = req('xfer', {'CallSid': 'v3:X1', 'DialCallStatus': 'no-answer'}, form=True, extra='&sid=' + xs('v3:X1'))
ok('616 B2 chu KHONG bat → <Say> "…the salon will call you back shortly" + Hangup (khong vao hop thu), status callback', 'call you back shortly' in x and '<Hangup/>' in x and '<Dial' not in x and row('v3:X1').get('status') == 'callback', (x, row('v3:X1').get('status')))
cb('v3:X2', '+15555550162'); tool('v3:X2', 'transfer_owner'); c, x = req('xfer', {'CallSid': 'v3:X2', 'DialCallStatus': 'completed'}, form=True, extra='&sid=' + xs('v3:X2'))
ok('616 B2 chu bat may → Hangup (xong), khong callback', x.endswith('<Response><Hangup/></Response>') and row('v3:X2').get('status') != 'callback', (x, row('v3:X2').get('status')))
# owner = the iPhone (AN live 22:30) / empty -> no transfer
h('set', json.dumps({'call_owner': '+15155550176'})); cb('v3:X3', '+15555550163'); n0 = flog().count('Calls/v3%3AX3')
r = tool('v3:X3', 'transfer_owner')
ok('616 B2 "Owner phone" = CHINH iPhone (nhu AN 22:30) → KHONG chuyen; AI noi "The salon will call you back shortly" + hangup; status callback', r.startswith('NO_ONE') and 'call you back shortly' in r and flog().count('Calls/v3%3AX3') == n0 and row('v3:X3').get('status') == 'callback', (r, row('v3:X3').get('status')))
h('set', json.dumps({'call_owner': ''})); cb('v3:X4', '+15555550164'); r = tool('v3:X4', 'transfer_owner')
ok('616 B2 "Owner phone" TRONG → giong tren (callback, khong goi iPhone)', r.startswith('NO_ONE') and row('v3:X4').get('status') == 'callback', (r, row('v3:X4').get('status')))
c, x = req('aiend', {'CallSid': 'v3:X4', 'Reason': 'service_error'}, form=True, extra='&sid=' + xs('v3:X4'))
ok('616 B2 aiend loi + khong co ai → <Say> call you back + Hangup (KHONG <Dial> iPhone)', '<Dial' not in x and 'call you back' in x, x)
h('set', json.dumps({'call_owner': '5155550177'})); cb('v3:X5', '+15555550165'); c, x = req('aiend', {'CallSid': 'v3:X5', 'Reason': 'stt_error'}, form=True, extra='&sid=' + xs('v3:X5'))
ok('616 B2 aiend loi + co Owner phone → <Dial timeout="20" action=a=xfer>+15155550177', '<Dial timeout="20"' in x and 'a=xfer' in x and '+15155550177</Dial>' in x, x)
pl = sql("SELECT name FROM sqlite_master WHERE name = 'push_log'")
pu = sql("SELECT title, body FROM push_log WHERE title LIKE '%Call back%' ORDER BY id") if pl else []
ok('616 B2 moi lan callback → push "📞 Call back" cho chu (so khach + ly do)', len(pu) >= 3 and any('555' in (p_['body'] or '') for p_ in pu), pu[-3:] if pu else 'push_log: ' + str(pl))
# 617.1 missed call text
open(D + '/set616.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'call_tb_on' => '1'] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set616.php')
open(D + '/tick616.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner']; cl_tick(); echo 'ticked';" % (A, A, A, A))
def tick(): return sh('php', D + '/tick616.php')
def mt(ph): return sql("SELECT kind, src, body FROM autosend WHERE phone = '%s' AND kind = 'missed' ORDER BY id" % ph) if sql("SELECT name FROM sqlite_master WHERE name='autosend'") else []
MP = '+15155550197'
cb('v3:NOUSER1', MP); c, x = req('aiend', {'CallSid': 'v3:NOUSER1', 'Reason': 'hangup'}, form=True, extra='&sid=' + xs('v3:NOUSER1')); time.sleep(0.5); tk = tick()
ok('617.1 khach cup khi AI vua chao (khong noi gi) → missed + 1 tin "Sorry we missed your call…" (outbox, khong gui that)', row('v3:NOUSER1').get('status') == 'missed' and len(mt(MP)) == 1, (row('v3:NOUSER1').get('status'), row('v3:NOUSER1').get('tb_state'), mt(MP), tk.stderr[-200:]))
cb('v3:NOUSER2', MP); req('aiend', {'CallSid': 'v3:NOUSER2', 'Reason': 'hangup'}, form=True, extra='&sid=' + xs('v3:NOUSER2')); time.sleep(0.5); tick()
ok('617.1 goi lai trong 30 phut → KHONG gui lan 2', len(mt(MP)) == 1 and row('v3:NOUSER2').get('tb_state') == 'skip', (mt(MP), row('v3:NOUSER2').get('tb_state')))
NP = '+15155550198'
cb('v3:NOCONV1', NP); sql("UPDATE calls SET created_at = '%s' WHERE call_sid = 'v3:NOCONV1'" % time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - 240)))
req('sweep', {}); time.sleep(1.5); tick()
ok('617.1 cup truoc khi AI noi (khong co conversation, > 3 phut) → cron sweep: missed + 1 tin', row('v3:NOCONV1').get('status') == 'missed' and len(mt(NP)) == 1, (row('v3:NOCONV1').get('status'), mt(NP)))
SP = '+15155550196'
req('in', {'CallSid': 'v3:ST1', 'From': SP, 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True); req('status', {'CallSid': 'v3:ST1', 'CallStatus': 'completed'}, form=True); tick()
ok('617.1 cup khi iPhone dang do chuong (status callback, chua ai bat) → missed + 1 tin', row('v3:ST1').get('status') == 'missed' and len(mt(SP)) == 1, (row('v3:ST1').get('status'), mt(SP)))
cb('v3:TALK1', '+15155550195'); c, x = req('aiend', {'CallSid': 'v3:TALK1', 'Reason': 'hangup'}, form=True, extra='&sid=' + xs('v3:TALK1')); time.sleep(0.5); tick()
ok('617.1 khach CO noi voi AI → KHONG phai missed, khong tin missed call', row('v3:TALK1').get('status') != 'missed' and not mt('+15155550195'), (row('v3:TALK1').get('status'), mt('+15155550195')))
ok('617.4 thoi gian AI noi chuyen (dur_sec tu sent_at / created_at cua messages) > 0', int(row('v3:TALK1').get('dur_sec') or 0) > 0, row('v3:TALK1').get('dur_sec'))
# aiend without the sleeps
cb('v3:NOCONV2', NP); t0 = time.time(); req('aiend', {'CallSid': 'v3:NOCONV2', 'Reason': 'hangup'}, form=True, extra='&sid=' + xs('v3:NOCONV2')); dt = time.time() - t0
ok('616 aiend khong sleep 4 + 10 s (chua co transcript → de cron) – request xong < 3 s', dt < 3, round(dt, 1))
# B1 add_person twice
cb('v3:AD1', '+15555550194'); ad = h('mk', '+15555550194', 'LAN', TOM, 780, 0); tool('v3:AD1', 'find_appointments')
ra = tool('v3:AD1', 'add_person', appt_id=ad, said_date=TOM, said_time='13:00', persons=[{'name': 'Mai', 'service_ids': [S['Pedicure']], 'tech_id': 0}])
rb = tool('v3:AD1', 'add_person', appt_id=ad, said_date=TOM, said_time='13:00', persons=[{'name': 'Mai', 'service_ids': [S['Pedicure']], 'tech_id': 0}])
nm = sql("SELECT COUNT(*) AS n FROM appointments WHERE phone = '+15555550194' AND status = 'booked'")[0]['n']
ok('616 B1 add_person 2 lan cung nguoi (model goi lai) → chi them 1 (2 hen tong)', int(nm) == 2, (nm, ra[:80], rb[:80]))
# 617.2 the hint line
js = open(A + '/assets/admin/calls-tx.js', encoding='utf-8').read()
ok('617.2 Settings → Calls: 1 dong giai thich duoi "Owner phone for questions" (tx-own-hint, sau dong hint cu, khong doi thu tu)', 'tx-own-hint' in js and "querySelector('#clOwn')" in js, '')
# 617.3 clean once an hour
cd_ = D + '/calls'; open(cd_ + '/txg-old.json', 'w').write('{}'); os.utime(cd_ + '/txg-old.json', (time.time() - 90000, time.time() - 90000)); open(cd_ + '/txh-new.txt', 'w').write('x'); os.utime(cd_ + '/txh-new.txt', (time.time(), time.time()))
try: os.remove(cd_ + '/.tx-clean')
except OSError: pass
r = sh('php', '-r', "require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/calls-tx.php'; tx_tmp_clean(); echo 'ok';" % (A, A, A)).stdout
ok('617.3 don file tam > 24 h (txg-old xoa, txh-new giu), toi da 1 lan / gio (.tx-clean)', not os.path.exists(cd_ + '/txg-old.json') and os.path.exists(cd_ + '/txh-new.txt') and os.path.exists(cd_ + '/.tx-clean'), (r, os.listdir(cd_)[:8]))
h('set', json.dumps({'call_owner': '5155550177'}))
