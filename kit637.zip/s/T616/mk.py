import sys
s = open('/tmp/claude-0/T612/t612.py').read()
s = s.replace("out = open(D + '/test-612.txt', 'w')", "out = open('/tmp/claude-0/T616/test-%s.txt'" % sys.argv[1] + ", 'w')")
s = s.replace("ok('4 AMD says machine (second net) → the AI', '<AIAssistant' in x, x)",
 "ok('4 (612p doi y) \"Hello?\" + AMD machine → KHONG chuyen (nguoi da noi), Dial completed → <Hangup/>', '<Hangup/>' in x and '<AIAssistant' not in x and row('v3:CB6').get('screen') == 'person', (x, row('v3:CB6').get('screen')))")
add = open('/tmp/claude-0/T616/add.py').read()
i = s.rindex("say('PASS")
s = s[:i] + 'import threading\n' + add + s[i:]
open('/tmp/claude-0/T616/t615b.py', 'w').write(s)
print('ok', s.count('612p doi y'))
