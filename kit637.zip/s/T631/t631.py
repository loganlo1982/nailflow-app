# LAMWEB test 605 + 605B (2.99.606: the change lock, end_call) – the real-time AI receptionist (SignalWire AI Agent: SWML + SWAIG) on a local copy. Fake SignalWire requests in the docs' shapes; test numbers 555-01xx only.
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, re, datetime as _dt
A = sys.argv[1]; D = '/tmp/claude-0/T631'; T5 = '/tmp/claude-0/T586'; PORT = 19955; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-631.txt', 'w')
def say(s): print(s); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_SHARED_DIR': T5 + '/shared', 'NF_CALLS_DIR': D + '/calls'}
os.makedirs(D + '/calls', exist_ok=True)
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
json.dump({'key': 'sk-test-0000000000000000000000000'}, open(T5 + '/shared/call-ai.json', 'w')); json.dump({}, open(T5 + '/shared/color-ai.json', 'w'))
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S, T = seed['S'], seed['T']; GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
H = D + '/h631.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/calls-agent.php'; cl_table(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'tok') echo cl_agent_token();
if ($a === 'cfg') echo json_encode(cl_cfg());
if ($a === 'save') { try { echo json_encode(cl_cfg_save(json_decode($argv[2], true))); } catch (RuntimeException $e) { echo json_encode(['err' => $e->getMessage()]); } }
if ($a === 'mk') { [$_, $_, $ph, $name, $date, $start, $staff, $n] = $argv; $g = (int)$n > 1 ? bin2hex(random_bytes(6)) : ''; $ids = []; upsert_customer($ph, $name);
  for ($i = 0; $i < (int)$n; $i++) { q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at) VALUES (?,?,?,?,?,?,?,'booked','admin','appt',?,?)", [$date, (int)$start, 45, (int)$staff, (string)%d, $i ? ($i === 1 ? 'LILY' : $name . ' +' . $i) : $name, $ph, $g, now_str()]); $ids[] = (int)db()->lastInsertId(); } echo json_encode($ids); }
""" % (A, A, A, PD))
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
ALLDAY = json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)})
h('set', json.dumps({'hours': ALLDAY, 'call_engine': 'agent', 'call_owner': '5155550177', 'as_on': '1', 'as_device': 'android', 'ad_transport': 'winsms', 'salon_name': 'American Nails'}))
sh('php', '-r', "require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; set_setting('ws_key', ad_enc('WS_test_key_123456789'));" % (A, A))
TOK = h('tok')
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w')); time.sleep(1.2)
fk = subprocess.Popen(['python3', T5 + '/fake.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
atexit.register(lambda: (sv.terminate(), fk.terminate()))
B = 'http://127.0.0.1:%d/call_agent.php' % PORT
PROJ = '11111111-2222-3333-4444-555555555555'
def post(a, body, tok=None, extra=''):
    u = B + '?a=' + a + '&t=' + (TOK if tok is None else tok) + extra
    rq = urllib.request.Request(u, data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    try: r = urllib.request.urlopen(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        b = e.read().decode(errors='replace')[:300]
        if tok is None and (body.get('call') or {}).get('project_id', PROJ) == PROJ: say('   !! %s ?a=%s -> HTTP %d: %s' % (B.rsplit('/', 1)[1], a, e.code, b.replace('\n', ' ')))  # only a request that should pass
        return e.code, {'_http': e.code, '_body': b}
def _crash(t, v, tb):  # (621-B) a crash (e.g. KeyError 'sections') says WHY: the TOKEN, the answer and the PHP log, then the traceback
    import traceback; say('✗ CRASH %s: %s · TOK=%r' % (t.__name__, v, str(TOK)[:60])); say('   php.log: ' + open(D + '/php.log').read()[-600:].replace('\n', ' | ')); traceback.print_exception(t, v, tb)
sys.excepthook = _crash
def call(cid, frm): return {'call': {'call_id': cid, 'from': frm, 'to': '+15156061616', 'project_id': PROJ, 'direction': 'inbound'}}
def tool(cid, frm, fn, **args): return post('tool', {'function': fn, 'argument': {'parsed': [args], 'raw': json.dumps(args)}, 'call_id': cid, 'caller_id_num': frm, 'project_id': PROJ, 'meta_data': {}}, extra='&sid=' + cid)
_t = _dt.date.today()
def W(k): return (_t + _dt.timedelta(days=((k - _t.weekday()) % 7) or 7) + _dt.timedelta(days=7)).isoformat()
def row(cid): x = sql("SELECT * FROM calls WHERE call_sid = '%s'" % cid); return x[0] if x else {}
def appts(ph): return sql("SELECT id, customer_name, status, appt_date, start_min, staff_id, service_ids, note FROM appointments WHERE phone = '%s' ORDER BY id" % ph)

say('== LAMWEB test 2.99.631 – LENH 631: the AI asks the MANICURE type on the call (gel / dip / acrylic / regular) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · fake requests, texts only into the queue')
for nm, du, pr in [('Manicure', 30, 20), ('Dip Powder Manicure', 45, 40), ('Acrylic Gel Full Set', 60, 55), ('Gel Pedicure', 50, 45)]:
    sql("INSERT INTO services (name, duration, price, sort, active) VALUES ('%s', %d, %d, 9, 1)" % (nm, du, pr))
SV = {x['name']: int(x['id']) for x in sql("SELECT id, name FROM services WHERE active = 1")}
MAN, DIP, ACR, GPD = SV['Manicure'], SV['Dip Powder Manicure'], SV['Acrylic Gel Full Set'], SV['Gel Pedicure']
N = [0]
def booked(mani=None, persons=None, pedi='none', day=None, tm=None):
    N[0] += 1; day = (N[0] % 7) if day is None else day; tm = tm or '%02d:00' % (9 + N[0] % 11); cid = 'C631-%02d' % N[0]; ph = '+155555502%02d' % N[0]; post('swml', call(cid, ph))
    args = dict(name='Test %d' % N[0], date=W(day), time=tm, persons=persons or [{'name': 'Test %d' % N[0], 'service_ids': [MAN], 'tech_id': 0}], pedi_type=pedi)
    if mani is not None: args['mani_type'] = mani
    c, r = tool(cid, ph, 'book', **args); a = appts(ph); cr = row(cid)
    asks = sql("SELECT src, body FROM autosend WHERE src = 'ui:callask:%s'" % cr.get('id', 0))
    return r.get('response', ''), [sorted(int(i) for i in str(x['service_ids']).split(',') if i) for x in a], asks, a
def one(r, svcs, asks, want): return r.startswith('BOOKED') and svcs == [sorted(want)] and not asks
# (1) the type said on the call -> that service, NO 1/2/3 text after
r, s, q_, a = booked('dip'); ok('1 mani_type dip -> Dip Powder Manicure, khong tin hoi 1/2/3', one(r, s, q_, [DIP]), (r, s, q_))
r, s, q_, a = booked('gel'); ok('1 mani_type gel -> Gel Manicure (= tin tra loi so 1), khong tin hoi', one(r, s, q_, [S['Gel Manicure']]), (r, s, q_))
r, s, q_, a = booked('acrylic'); ok('1 mani_type acrylic (MOI) -> Acrylic Gel Full Set (= tin tra loi so 3), khong tin hoi', one(r, s, q_, [ACR]), (r, s, q_))
r, s, q_, a = booked('regular', [{'name': 'R', 'service_ids': [S['Gel Manicure']], 'tech_id': 0}]); ok('1 mani_type regular (chi son thuong) -> Manicure co ban, khong tin hoi', one(r, s, q_, [MAN]), (r, s, q_))
r, s, q_, a = booked('dip'); ok('1 doc lai / BOOKED noi dung dung dich vu da chon (dip)', 'dip' in r.lower(), r)
# (2) not said / not sure -> basic + the text, as before
r, s, q_, a = booked('plain'); ok('2 chua noi loai (plain) -> Manicure co ban + tin hoi 1/2/3 nhu cu', r.startswith('BOOKED') and s == [[MAN]] and len(q_) == 1 and 'Reply 1' in q_[0]['body'], (r, s, q_))
r, s, q_, a = booked('unsure'); ok('2 khach "not sure" (unsure, MOI) -> Manicure co ban + tin hoi nhu cu', r.startswith('BOOKED') and s == [[MAN]] and len(q_) == 1, (r, s, q_))
r, s, q_, a = booked('none'); ok('2 khong mani_type (none) -> dung dich vu AI chon, khong tin (nhu cu)', one(r, s, q_, [MAN]), (r, s, q_))
# (3) the old values still work
r, s, q_, a = booked('gel_real'); ok('3 gia tri cu gel_real -> Gel Manicure, khong tin', one(r, s, q_, [S['Gel Manicure']]), (r, s, q_))
r, s, q_, a = booked('gel_fake'); ok('3 gia tri cu gel_fake -> Acrylic Gel Full Set, khong tin', one(r, s, q_, [ACR]), (r, s, q_))
r, s, q_, a = booked('gel_unsure'); ok('3 gia tri cu gel_unsure -> van hoi bang tin nhu cu', r.startswith('BOOKED') and len(q_) == 1, (r, s, q_))
# (4) a group
P = lambda n, ids, t=None: dict({'name': n, 'service_ids': ids, 'tech_id': 0}, **({'mani_type': t} if t else {}))
r, s, q_, a = booked('none', [P('Sofia', [MAN], 'dip'), P('Ana', [MAN], 'gel'), P('Lily', [MAN], 'acrylic')], day=2, tm='14:00')
ok('4 nhom 3 nguoi KHAC loai (tung nguoi: dip / gel / acrylic) -> dung dich vu tung nguoi, khong tin hoi', r.startswith('BOOKED') and sorted(map(tuple, s)) == sorted([(DIP,), (S['Gel Manicure'],), (ACR,)]) and not q_, (r, s, q_))
r, s, q_, a = booked('dip', [P('Sofia', [PD, MAN]), P('Ana', [PD, MAN]), P('Lily', [PD])], day=3, tm='14:00')
ok('4 nhom "same for everyone" dip: ai co mani -> Dip; nguoi CHI pedicure KHONG bi them dip; khong tin', r.startswith('BOOKED') and sorted(map(tuple, s)) == sorted([tuple(sorted([PD, DIP])), tuple(sorted([PD, DIP])), (PD,)]) and not q_, (r, s, q_))
# (5) pedicure: unchanged (plain -> the text asks the pedicure only)
r, s, q_, a = booked('dip', [P('Kim', [PD, MAN])], pedi='plain', day=5)
ok('5 mani dip + pedi chua noi loai -> mani Dip, tin chi hoi PEDICURE (nhu cu)', r.startswith('BOOKED') and s == [sorted([PD, DIP])] and len(q_) == 1 and 'pedicure' in q_[0]['body'].lower() and 'manicure' not in q_[0]['body'].lower(), (r, s, q_))
# (6) the prompt + the tool (also what Telnyx gets)
pr = sh('php', '-r', "require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/calls-agent.php'; require_once '%s/inc/calls-tx.php'; $g = cl_agent_data(''); echo json_encode(['p' => cl_agent_prompt($g), 'tx' => tx_instructions(), 'tools' => tx_tools()]);" % (A, A, A, A))
try: PR = json.loads(pr.stdout)
except Exception: PR = {'p': '', 'tx': '', 'tools': []}; say('   !! ' + (pr.stdout + pr.stderr)[-400:])
p = PR['p']
ok('6 prompt: hoi ngay 1 cau "Would you like gel, dip, or acrylic – or just regular polish?"', 'Would you like gel, dip, or acrylic' in p and 'regular polish' in p, p[-900:])
ok('6 prompt: nhom hoi 1 lan "Same for everyone?"; "not sure" -> unsure; pedicure khong hoi', 'Same for everyone?' in p and 'unsure' in p and 'Pedicure' in p, p[-900:])
ok('6 prompt: bo cau cu "book the basic one – the salon texts the choices" khi chua noi loai', 'If a manicure type (dip / gel) is not said, book the basic one' not in p, p[-900:])
ok('6 Telnyx instructions = prompt moi', 'Would you like gel, dip, or acrylic' in PR['tx'])
bk = [t for t in PR['tools'] if t.get('webhook', {}).get('name') == 'book']
props = bk[0]['webhook']['body_parameters']['properties'] if bk else {}
ok('6 tool book (Telnyx): mani_type co acrylic + regular + unsure; tung nguoi (persons[].mani_type)', 'acrylic' in props.get('mani_type', {}).get('description', '') and 'regular' in props.get('mani_type', {}).get('description', '') and 'mani_type' in props.get('persons', {}).get('items', {}).get('properties', {}), json.dumps(props)[:500])
logs = open(D + '/php.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
