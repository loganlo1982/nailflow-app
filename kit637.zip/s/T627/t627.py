# LAMWEB test 627 – L1 refund sau refund gift card · L2 void bill co ban gift card (void luon the; da dung -> chan; ban lai cung ma) · L3 tru gift co lop 2 (so du thieu -> rollback).
#   Ban sao + SQLite rieng, khach 555-01xx, gift card / the GIA.
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, threading, http.cookiejar, datetime as _dt, glob
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T627'; T5 = '/tmp/claude-0/T586'; PORT = 19949; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-627.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
A = D + '/app'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True)
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; T = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA, HA = T['TAMMY'], T['HANA']
H = D + '/h627.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'hash') { echo password_hash($argv[2], PASSWORD_DEFAULT); }
if ($a === 'sig') { $p = json_decode($argv[3], true); ksort($p); $t = ''; foreach ($p as $k => $v) $t .= $k . $v; echo base64_encode(hash_hmac('sha1', $argv[2] . $t, setting('twilio_token'), true)); }
""" % A)
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
PW = 'adm619-' + os.urandom(4).hex()
h('set', json.dumps({'admin_hash': h('hash', PW), 'gift_on': '1', 'hours': json.dumps({str(w): {'open': '09:00', 'close': '21:00'} for w in range(7)})}))
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '6'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w'))
atexit.register(lambda: sv.terminate()); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
say('== LAMWEB test 627 (sua 3 diem tien: L1 refund, L2 void bill co ban gift, L3 lop 2 tru gift) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
TODAY = time.strftime('%Y-%m-%d')
def mk(ph, name, staff, sid, start):
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', '%s', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), '%s')" % (TODAY, start, staff, sid, name, ph, os.urandom(8).hex()))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def price(sid): return float(sql("SELECT price FROM services WHERE id = %d" % sid)[0]['price'])
def pay(aid, sid, staff, pays, **k):
    b = {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid, 'price': price(sid), 'staff': staff}], 'pays': pays}; b.update(k); return api('checkout2', b)
def st(aid): return sql("SELECT status FROM appointments WHERE id = %d" % aid)[0]['status']
def nrc(): return int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n'])
P = price(PD)
FS = S['Full Set']; SI = T['SISI']
PR = {sid: price(sid) for sid in (PD, GM, FS)}   # Pedicure 35, Gel Manicure 40, Full Set 50 (test menu)
sql("UPDATE staff SET commission_pct = 60, pct_hist = '' WHERE id = %d" % TA); sql("UPDATE staff SET commission_pct = 50, pct_hist = '' WHERE id = %d" % HA)
h('set', json.dumps({'admin_fee_on': '1', 'admin_fee_staff': str(SI), 'admin_fee_min': '39', 'admin_fee_amt': '1', 'payroll_split_on': '0', 'tax_pct': '0'}))
TAB = []   # the 15 cases: no | case | money in | expected | actual | PASS/FAIL
def case(no, name, money, want, got, cond):
    TAB.append((no, name, money, want, got, 'PASS' if cond else 'FAIL')); ok('D%02d %s' % (no, name), cond, 'mong doi: %s | thuc te: %s' % (want, got))
NUM = [100]
def new(name, staff, sid):
    NUM[0] += 1; return mk('+151555501%02d' % NUM[0], name, staff, sid, 540 + NUM[0] * 5)
def co(aid, lines, pays, splits=None, **k):
    ls = [{'appt': aid, 'sid': sid, 'price': p, 'staff': st} for sid, st, p in lines]
    sp = splits if splits is not None else [{'staff': st, 'amt': p} for sid, st, p in lines]
    b = {'ids': [aid], 'lines': ls, 'pays': pays, 'splits': sp}; b.update(k); return api('checkout2', b)
def rc(rid): x = sql("SELECT * FROM receipts WHERE id = %d" % rid); return x[0] if x else {}
def rid_of(r): return int(((r or {}).get('receipt') or {}).get('id', 0))
def gbal(code): x = sql("SELECT balance FROM giftcards WHERE code = '%s'" % code); return round(float(x[0]['balance']), 2) if x else None
def shares(r): return {int(x['staff']): x for x in json.loads(r.get('pay_splits') or '[]')}
def gift(code, amt): sql("INSERT INTO giftcards (code, amount, balance, status, buyer_phone, to_phone, created_at) VALUES ('%s', %s, %s, 'active', '+15155550190', '', datetime('now'))" % (code, amt, amt))
R1 = {}
h('set', json.dumps({'gift_on': '1'}))
def cd(): return api('close_day', None, '&day=' + TODAY)[1]['totals']
def glog(code): return int(sql("SELECT COUNT(*) AS n FROM giftcard_log l JOIN giftcards g ON g.id = l.card_id WHERE g.code = '%s'" % code)[0]['n'])
def gcard(code): x = sql("SELECT * FROM giftcards WHERE code = '%s'" % code); return x[0] if x else {}
# ---------- L1: refund cash / card after a refund onto the gift card ----------
gift('GIFT-6270-0001', 20); a = new('L ONE', HA, GM); c, r = co(a, [(GM, HA, 40)], [{'m': 'Cash', 'amt': 20}], gift_code='GIFT-6270-0001', gift_amount=20); r1 = rid_of(r)
c1, x1 = api('receipt_refund', {'id': r1, 'amount': 20, 'how': 'Gift card', 'reason': 'test 627 L1 gift'})
c2, x2 = api('receipt_refund', {'id': r1, 'amount': 20, 'how': 'Cash', 'reason': 'test 627 L1 cash'})
ok('L1.1 hoa don 40 = gift 20 + tien mat 20: refund 20 ve gift card roi refund 20 TIEN MAT -> duoc (tong refund 40)', c == 200 and c1 == 200 and c2 == 200 and float(rc(r1)['refund']) == 40, (c, c1, c2, (x2 or {}).get('error'), rc(r1).get('refund')))
c3, x3 = api('receipt_refund', {'id': r1, 'amount': 0.01, 'how': 'Cash', 'reason': 'test 627 L1 them'}); c4, x4 = api('receipt_refund', {'id': r1, 'amount': 0.01, 'how': 'Gift card', 'reason': 'test 627 L1 them'})
ok('L1.2 da refund het 40 -> refund them 0.01 (tien mat hoac gift) bi chan', c3 >= 400 and c4 >= 400 and float(rc(r1)['refund']) == 40, (c3, c4, rc(r1).get('refund')))
gift('GIFT-6270-0002', 20); a = new('L ONE B', HA, GM); c, r = co(a, [(GM, HA, 40)], [{'m': 'Card', 'amt': 20}], gift_code='GIFT-6270-0002', gift_amount=20); r1b = rid_of(r)
c1, _ = api('receipt_refund', {'id': r1b, 'amount': 15, 'how': 'Gift card', 'reason': 'test 627'}); c2, x2 = api('receipt_refund', {'id': r1b, 'amount': 20.01, 'how': 'Card', 'reason': 'test 627', 'dps_done': 1})
c3, _ = api('receipt_refund', {'id': r1b, 'amount': 20, 'how': 'Card', 'reason': 'test 627', 'dps_done': 1}); c4, _ = api('receipt_refund', {'id': r1b, 'amount': 5.01, 'how': 'Gift card', 'reason': 'test 627'})
ok('L1.3 the 20 + gift 20: refund 15 ve gift -> the toi da 20 (20.01 chan, 20 duoc) -> gift con toi da 5 (5.01 chan)', c == 200 and c1 == 200 and c2 >= 400 and c3 == 200 and c4 >= 400 and float(rc(r1b)['refund']) == 35, (c1, c2, c3, c4, rc(r1b).get('refund')))
# ---------- L2: void a bill that SOLD a gift card ----------
a = new('L TWO', TA, PD); C2 = 'GIFTL2627AB'; c, r = co(a, [(PD, TA, 35)], [{'m': 'Card', 'amt': 85}], gift_sale={'amount': 50, 'phone': '5155550188', 'code': C2}); r2 = rid_of(r)
t0 = cd(); cn, xn = api('receipt_void', {'id': r2, 'reason': 'test 627 L2'})
ok('L2.1 void bill (dv 35 + ban gift 50, the 85): phai hoan $85 tren DPS (ca phan gift)', cn >= 400 and '$85' in (xn or {}).get('error', ''), (cn, (xn or {}).get('error')))
c, x = api('receipt_void', {'id': r2, 'reason': 'test 627 L2', 'dps_done': 1}); g1 = gcard(C2); t1 = cd()
ok('L2.2 void bill -> the gift ban tren bill VOID, so du 0; Close day: gift ban 50 -> 0, the 85 -> 0', c == 200 and g1.get('status') == 'void' and float(g1.get('balance', -1)) == 0 and t0['giftCard'] == 50 and t1['giftCard'] == 0 and round(t0['card'] - t1['card'], 2) == 35,
   (c, (x or {}).get('error'), g1.get('status'), g1.get('balance'), t0['giftCard'], t1['giftCard'], t0['card'], t1['card']))
ok('L2.3 hoa don void ghi ro: void gift card ...' + C2[-4:], 'void' in json.dumps(sql("SELECT note FROM giftcard_log l JOIN giftcards g ON g.id = l.card_id WHERE g.code = '%s'" % C2)).lower(), sql("SELECT kind, note FROM giftcard_log l JOIN giftcards g ON g.id = l.card_id WHERE g.code = '%s'" % C2))
cc, xc = api('gift_code_check', {'code': C2}); n0 = glog(C2)
a = new('L TWO AGAIN', TA, PD); c, r = co(a, [(PD, TA, 35)], [{'m': 'Cash', 'amt': 85}], gift_sale={'amount': 50, 'phone': '5155550188', 'code': C2}); g2 = gcard(C2)
ok('L2.4 khach mua lai: SCAN lai the da void (do void bill) -> ban duoc cung ma: active 50, CUNG 1 the (id), lich su noi tiep; Close day gift ban 50 (tien mat)',
   cc == 200 and xc.get('free') is True and c == 200 and g2.get('status') == 'active' and float(g2.get('balance', 0)) == 50 and int(g2.get('id', 0)) == int(g1.get('id', -1)) and glog(C2) > n0 and cd()['giftCash'] == 50,
   (xc, c, (r or {}).get('error'), g2.get('status'), g2.get('balance'), g2.get('id'), g1.get('id'), glog(C2), n0))
ca, xa = api('gift_code_check', {'code': C2}); c5, r5 = api('gift_create', {'amount': 25, 'paid_by': 'Cash', 'code': C2})
a = new('L TWO DUP', HA, PD); c6, r6 = co(a, [(PD, HA, 35)], [{'m': 'Cash', 'amt': 60}], gift_sale={'amount': 25, 'code': C2})
ok('L2.5 ma dang ACTIVE: KHONG ban trung (kiem ma, ban rieng, ban tren bill deu chan), the giu 50', xa.get('free') is False and c5 >= 400 and c6 >= 400 and float(gcard(C2)['balance']) == 50, (xa, c5, c6, gcard(C2).get('balance')))
gift('GIFTL2MANVOID', 30); sql("UPDATE giftcards SET status = 'void' WHERE code = 'GIFTL2MANVOID'")
cm, xm = api('gift_code_check', {'code': 'GIFTL2MANVOID'}); c7, r7 = api('gift_create', {'amount': 30, 'paid_by': 'Cash', 'code': 'GIFTL2MANVOID'})
ok('L2.6 the void BANG TAY (khong phai do void bill) van KHONG ban lai duoc (giu nhu cu)', xm.get('free') is False and c7 >= 400 and gcard('GIFTL2MANVOID')['status'] == 'void', (xm, c7))
a = new('L TWO USED', TA, PD); C3 = 'GIFTL2627CD'; c, r = co(a, [(PD, TA, 35)], [{'m': 'Card', 'amt': 85}], gift_sale={'amount': 50, 'code': C3}); r3 = rid_of(r)
b = new('L TWO SPEND', HA, PD); cs, rs = co(b, [(PD, HA, 35)], [{'m': 'Cash', 'amt': 25}], gift_code=C3, gift_amount=10)
cv, xv = api('receipt_void', {'id': r3, 'reason': 'test 627 L2 used', 'dps_done': 1})
ok('L2.7 the gift ban tren bill DA DUNG 10 -> void bill bi CHAN, bao ro "already used ($40 left) – refund instead", bill van paid, the van 40',
   c == 200 and cs == 200 and cv >= 400 and 'already used' in (xv or {}).get('error', '') and '$40' in (xv or {}).get('error', '') and rc(r3)['status'] == 'paid' and float(gcard(C3)['balance']) == 40 and gcard(C3)['status'] == 'active',
   (c, cs, cv, (xv or {}).get('error'), rc(r3).get('status'), gcard(C3).get('balance')))
a = new('L TWO OLD', TA, PD); c, r = co(a, [(PD, TA, 35)], [{'m': 'Cash', 'amt': 35}]); cv2, _ = api('receipt_void', {'id': rid_of(r), 'reason': 'test 627 bill thuong'})
ok('L2.8 bill KHONG ban gift: void nhu cu', c == 200 and cv2 == 200 and rc(rid_of(r))['status'] == 'void', (c, cv2))
# ---------- L3: the gift card deduction has a 2nd guard (balance >= amount in the UPDATE) ----------
gift('GIFT-6270-0003', 40); a = new('L THREE', TA, PD); n0 = int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n'])
sql("CREATE TRIGGER t627_drain AFTER INSERT ON receipts BEGIN UPDATE giftcards SET balance = 10 WHERE code = 'GIFT-6270-0003'; END")  # another device spends the card between the check and the deduction
c, r = co(a, [(PD, TA, 35)], [], gift_code='GIFT-6270-0003', gift_amount=35); sql("DROP TRIGGER t627_drain")
ok('L3.1 so du bi tru o noi khac GIUA luc kiem va luc tru (40 -> 10) -> tu choi + rollback: khong hoa don, the KHONG am (van 40 sau rollback), hen chua tra',
   c >= 400 and int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n']) == n0 and gbal('GIFT-6270-0003') == 40 and st(a) != 'paid', (c, (r or {}).get('error'), gbal('GIFT-6270-0003'), st(a)))
c, r = co(a, [(PD, TA, 35)], [], gift_code='GIFT-6270-0003', gift_amount=35)
ok('L3.2 binh thuong: tru gift 35 -> con 5', c == 200 and gbal('GIFT-6270-0003') == 5, (c, (r or {}).get('error'), gbal('GIFT-6270-0003')))
logs = open(D + '/php.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
