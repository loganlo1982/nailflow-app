// node t620.js CODE BASE PORT OUT – LENH 620: step 5 "✅ Book now" big (CODE) vs before (BASE): iPhone 13 / SE / Android 412, EN + ES; steps 2-4 "Next" unchanged; booking still works.
const { chromium, devices } = require('/opt/node22/lib/node_modules/playwright'); const { spawn, execFileSync } = require('child_process'); const fs = require('fs');
const [CODE, BASE, PORT, OUT] = process.argv.slice(2); fs.mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise(r => setTimeout(r, ms)); const R = []; const ok = (n, c, i) => { R.push(!!c); console.log((c ? '✓ ' : '✗ ') + n, c ? '' : JSON.stringify(i).slice(0, 400)); };
function server(code, port) { const W = `/tmp/claude-0/kp-${port}`; fs.rmSync(W, { recursive: true, force: true }); fs.mkdirSync(W, { recursive: true }); fs.copyFileSync('/tmp/claude-0/tdb/base.sqlite', W + '/db.sqlite');
  fs.writeFileSync(code + '/inc/config.php', `<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'${W}/db.sqlite','site_url'=>'http://127.0.0.1:${port}','demo'=>true,'showapp'=>true);\n`);
  const ENV = { ...process.env, TZ: 'America/Chicago' }; execFileSync('php', [code + '/cron/showapp-seed.php'], { env: ENV });
  execFileSync('php', ['-r', `$d=new PDO('sqlite:${W}/db.sqlite'); foreach (['online_booking'=>'1','dep_on'=>'0','sms_book_on'=>'0'] as $k=>$v) $d->prepare("INSERT OR REPLACE INTO settings (k, v) VALUES (?, ?)")->execute([$k,$v]);`], { env: ENV });
  return { p: spawn('php', ['-S', '127.0.0.1:' + port, '-t', code, '/tmp/claude-0/router.php'], { env: { ...ENV, PHP_CLI_SERVER_WORKERS: '3' }, stdio: 'ignore', detached: true }), W }; }
const DEV = [['iPhone13', devices['iPhone 13']], ['SE', devices['iPhone SE']], ['Android412', devices['Pixel 5']]];
(async () => { const s1 = server(CODE, +PORT), s2 = server(BASE, +PORT + 1); await sleep(1300); const br = await chromium.launch(); const pe = [];
  const look = (p) => p.evaluate(() => { const b = document.querySelector('#bGo'); if (!b || b.hidden) return null; const cs = getComputedStyle(b), r = b.getBoundingClientRect();
    const lh = parseFloat(cs.lineHeight) || parseFloat(cs.fontSize) * 1.2; const act = document.querySelector('#bAct').getBoundingClientRect();
    return { text: b.textContent, fs: parseFloat(cs.fontSize), fw: cs.fontWeight, h: r.height, lines: Math.round((b.scrollHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom)) / lh), w: r.width, sw: b.scrollWidth, cw: b.clientWidth, bg: cs.backgroundColor, inView: r.bottom <= innerHeight + 1 && r.top >= 0, actTop: act.top }; });
  const flow = async (port, dev, lang, tag) => {
    const ctx = await br.newContext({ ...dev }); await ctx.addInitScript((l) => { try { localStorage.setItem('bookLang', l); localStorage.setItem('bookNoStat', '1'); } catch (e) {} }, lang);
    const p = await ctx.newPage(); p.on('pageerror', e => pe.push(tag + ': ' + e.message)); const L = {};
    await p.goto(`http://127.0.0.1:${port}/`); await p.waitForFunction(() => typeof st !== 'undefined' && st.info); await p.evaluate(() => { const b = document.querySelector('#wOv button'); if (b) b.click(); }); await sleep(400);
    await p.evaluate(() => { const s = st.info.services.filter(x => x.main).slice(0, 1).map(x => x.id); st.people = [0]; st.services = s; st.ps = []; st.pt = []; st.design = []; st.peopleChosen = true; st.sDone = [true]; st.gDone = [true]; st.tm = []; st.tp = { 0: 1 }; st.date = null; st.slots = null; render(2, 1); });
    await sleep(600); L[2] = await look(p);
    await p.evaluate(() => render(3, 1)); await sleep(2500); await p.evaluate(() => { const x = document.querySelector('#tsSheet .tss-x'); if (x) x.click(); st.start = st.slots[0]; render(3, 1); }); await sleep(600); L[3] = await look(p);
    await p.evaluate(() => { history.pushState({ bstep: 4 }, ''); render(4, 1); }); await sleep(1200); await p.evaluate(() => { try { KP.done = null; kpClose(); } catch (e) {} }); await sleep(300); L[4] = await look(p);
    await p.evaluate(() => { const i = document.querySelector('#bPhone'); i.value = '(515) 555-0162'; i.dispatchEvent(new Event('input', { bubbles: true })); }); await sleep(1500);
    await p.evaluate(() => { const n = document.querySelector('#bName'); if (n) { n.value = 'Big Button'; n.dispatchEvent(new Event('input', { bubbles: true })); } st.name = 'Big Button'; st.phConfirmed = digits(st.phone); }); await sleep(300);
    await p.evaluate(() => primary()); await sleep(1500); await p.evaluate(() => { const b = document.querySelector('#gpNo'); if (b) b.click(); }); await sleep(2500);
    if (await p.evaluate(() => st.step) === 4) { await p.evaluate(() => { st.phConfirmed = digits(st.phone); return primary(); }); await sleep(2000); }
    await p.evaluate(() => { try { KP.done = null; kpClose(); } catch (e) {} }); await sleep(400);
    L[5] = await look(p); L.step = await p.evaluate(() => st.step); await p.screenshot({ path: `${OUT}/${tag}-step5.png` });
    return { ctx, p, L };
  };
  try {
    for (const [dn, dev] of DEV) for (const lang of ['en', 'es']) {
      const T = `${dn} ${lang}: `; const a = await flow(+PORT, dev, lang, dn + '-' + lang + '-new'), b = await flow(+PORT + 1, dev, lang, dn + '-' + lang + '-old'); const n5 = a.L[5], o5 = b.L[5];
      const want = lang === 'en' ? '✅ Book now' : '✅ Reservar';
      ok(T + 'step 5 button "' + want + '" BIG: font >= 26px (was ' + (o5 && o5.fs) + 'px), weight 800, height >= 64px', a.L.step === 5 && n5 && n5.text === want && n5.fs >= 26 && n5.fs > (o5 ? o5.fs : 99) && +n5.fw >= 800 && n5.h >= 64, { n5, o5, step: a.L.step });
      ok(T + 'ONE line, nothing cut (text fits the button), fully on screen', n5 && n5.lines === 1 && n5.sw <= n5.cw + 1 && n5.inView, n5);
      ok(T + 'same colour as before (navy)', n5 && o5 && n5.bg === o5.bg, { n: n5 && n5.bg, o: o5 && o5.bg });
      ok(T + 'steps 2-4 "Next" exactly as before (size / weight / height / text)', [2, 3, 4].every(k => { const x = a.L[k], y = b.L[k]; return (!x && !y) || (x && y && x.text === y.text && x.fs === y.fs && x.fw === y.fw && Math.abs(x.h - y.h) < 1); }), [2, 3, 4].map(k => [a.L[k] && a.L[k].fs, b.L[k] && b.L[k].fs, a.L[k] && a.L[k].text]));
      if (dn === 'iPhone13' && lang === 'en') {
        await a.p.evaluate(() => { st.busy = true; render(5, 1); }); await sleep(300); const bz = await look(a.p);
        ok(T + '"Booking…" (busy) keeps the big look, disabled', bz && bz.text.startsWith('Booking') && bz.fs >= 26, bz);
        await a.p.evaluate(() => { st.busy = false; render(5, 1); }); await sleep(300);
        await a.p.evaluate(() => document.querySelector('#bGo').click()); await sleep(3500);
        const done = await a.p.evaluate(() => st.done); const rows = execFileSync('php', ['-r', `$d=new PDO('sqlite:/tmp/claude-0/kp-${PORT}/db.sqlite'); echo $d->query("SELECT COUNT(*) FROM appointments WHERE phone = '+15155550162' AND status = 'booked'")->fetchColumn();`]).toString();
        ok(T + 'tap "Book now" → booked (1 appointment), page done', done && rows.trim() === '1', { done, rows });
      }
      await a.ctx.close(); await b.ctx.close();
    }
  } catch (e) { ok('flow error', false, String(e).slice(0, 300)); }
  ok('no page errors', pe.length === 0, pe);
  console.log('PASS ' + R.filter(Boolean).length + '/' + R.length);
  await br.close(); for (const s of [s1, s2]) { try { process.kill(-s.p.pid); } catch (e) {} }
  process.exit(0);
})();
