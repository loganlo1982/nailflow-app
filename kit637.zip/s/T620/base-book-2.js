'use strict';
/* (2.99.206 – order 407) book-2.js – part 2 of 3 of book.js (customer booking page). */
/* "6+": a small box to type the group size (number keypad). */
function askPeople() {
  const max = st.info.maxPeople, bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-labelledby="bmT"><h3 id="bmT">How many people?</h3>
    <input id="bmN" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="2" autocomplete="off" placeholder="6" aria-label="Number of people" value="${st.people.length > 5 ? st.people.length : 6}">
    ${st.info.phone ? `<p class="call6">${ES ? 'También puede llamarnos al' : 'You can also call us at'} <b>${esc(st.info.phone)}</b></p>
    <a class="btn call-btn" href="tel:${esc(st.info.phone.replace(/[^\d+]/g, ''))}">📞 ${ES ? 'Llamar' : 'Call'} ${esc(st.info.phone)}</a>
    <p class="note">${ES ? `O reserve en línea (hasta ${max} personas):` : `Or book online (up to ${max} people):`}</p>` : `<p class="note">Up to ${max} people online.</p>`}
    <p class="err" id="bmE" hidden></p>
    <div class="modal-btns"><button type="button" class="ghost" id="bmX">${ES ? 'Cancelar' : 'Cancel'}</button><button type="button" id="bmOk">${ES ? 'Reservar en línea' : 'Book online'}</button></div></div>`;
  document.body.appendChild(bg);
  const inp = $('#bmN', bg), close = () => bg.remove();
  const ok = () => {
    const n = parseInt(inp.value, 10);
    if (!(n >= 1 && n <= max)) { const e = $('#bmE', bg); e.textContent = `Please enter a number from 1 to ${max}.`; e.hidden = false; inp.focus(); return; }
    close(); setPeople(n);
  };
  inp.addEventListener('input', () => { const v = inp.value.replace(/\D/g, ''); if (v !== inp.value) inp.value = v; });
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') ok(); if (e.key === 'Escape') close(); });
  $('#bmX', bg).addEventListener('click', close);
  $('#bmOk', bg).addEventListener('click', ok);
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
}

/* Group deposit (only when the salon turned it on and set up PayPal): paid with PayPal's buttons on the confirm screen. */
const usd = (n) => '$' + (n % 1 ? n.toFixed(2) : n);
const depNeeded = () => !!st.info.deposit && st.people.length >= st.info.deposit.min;
let ppLoad = null;
const loadPayPal = () => ppLoad || (ppLoad = new Promise((ok, bad) => {
  const s = document.createElement('script');
  s.src = 'https://www.paypal.com/sdk/js?client-id=' + encodeURIComponent(st.info.deposit.clientId) + '&currency=USD&intent=capture&components=buttons&disable-funding=paylater,credit';
  s.onload = () => (window.paypal ? ok(window.paypal) : bad(new Error('PayPal could not load.')));
  s.onerror = () => { ppLoad = null; s.remove(); bad(new Error('PayPal could not load. Check your internet, or call us to book.')); };
  document.head.appendChild(s);
}));
const ppMsg = (t) => { const m = $('#ppMsg'); if (m) m.textContent = t; };
async function mountPayPal(el) {
  const box = $('#ppBtns', el); if (!box) return;
  ppMsg('Loading PayPal…');
  let lastErr = '';
  try {
    const pp = await loadPayPal();
    if (!box.isConnected) return;
    ppMsg('');
    await pp.Buttons({
      style: { layout: 'vertical', shape: 'rect', label: 'pay', height: 48 },
      createOrder: async () => { try { return (await api('dep_order', bookData())).id; } catch (e) { lastErr = e.message; throw e; } },
      onApprove: async (data) => {
        st.busy = true; ppMsg('Payment received – booking your group…');
        try { booked(await api('dep_capture', { id: data.orderID })); } catch (e) { st.busy = false; depFail(e.message); }
      },
      onCancel: () => ppMsg('Payment cancelled – your group is not booked yet.'),
      onError: () => depFail(lastErr || 'PayPal had a problem and nothing was charged. Please try again, or call us.'),
    }).render(box);
  } catch (e) { ppMsg(e.message); }
}
function depFail(msg) {
  if (/taken|later time/i.test(msg)) { st.start = null; st.slots = null; st.notice = msg; st.editing = true; history.go(3 - LAST); return; }
  st.err = msg; refresh();
}

/* The 🎁 box: texts with offers, never ticked by itself; the whole box is the tap area. offer = the birthday offer in Settings → Offers ("20% off (up to $15)"). */


/** (2.99.371 – anh Logan 23:19) a returning customer: her offers still good, one line each (the salon's own offer rules – used at Checkout, 1 per visit). */
function offLines() {
  const R = { birthday: 0, referral: 1, winback: 2, reward: 3 }, L = [...((st.lookup && st.lookup.offers) || [])].sort((a, b) => (R[a.kind] ?? 9) - (R[b.kind] ?? 9)); if (!L.length) return '';
  const u = (x) => x.until ? (ES ? ` (hasta ${x.until})` : ` (until ${x.until})`) : '';
  const one = (x) => x.kind === 'birthday' ? (ES ? `🎂 ¡Feliz cumpleaños! <b>${esc(x.amt)} de descuento</b> en su visita${u(x)}.` : `🎂 Happy birthday! <b>${esc(x.amt)} off</b> at your visit${u(x)}.`)
    : x.kind === 'winback' ? (ES ? `🎁 ¡Lo extrañamos! <b>${esc(x.amt)} de descuento</b> en su visita${u(x)}.` : `🎁 We missed you! <b>${esc(x.amt)} off</b> at your visit${u(x)}.`)
    : x.kind === 'referral' ? (ES ? `🎁 <b>${esc(x.amt)} de descuento</b> gracias a su amiga${x.who ? ' ' + esc(x.who) : ''}${u(x)}.` : `🎁 <b>${esc(x.amt)} off</b>, thanks to your friend${x.who ? ' ' + esc(x.who) : ''}${u(x)}.`)
    : x.kind === 'reward' ? (ES ? `⭐ Tiene una recompensa: <b>${esc(x.amt)} de descuento</b>.` : `⭐ You have a reward: <b>${esc(x.amt)} off</b>.`) : '';
  const h = L.map(one).filter(Boolean); return h.length ? `<div class="wb-offers">${h.map(x => `<p>${x}</p>`).join('')}</div>` : '';
}
/* Name area on "Your details": hidden until the phone has 10 digits, then a greeting (returning customer) or the Name field. */
function whoHtml() {
  if (!phoneOk()) return '';
  if (st.lookup === 'loading') return '<p class="note who">Looking you up…</p>';
  if (known()) return `<p class="welcome wb-big">👋 ${ES ? '¡Hola de nuevo' : 'Welcome back'}, ${esc(st.lookup.first || dot(st.lookup.display).split(' ')[0])}!</p>${offLines()}${st.lookup.offerNote ? `<p class="note one-offer">🎁 ${esc(ES ? '1 oferta por visita – usaremos la mejor para usted' : st.lookup.offerNote)}</p>` : ''}${st.lookup.rfCredit ? `<p class="ref-cr-line">${esc(st.lookup.rfCredit.line || '🎁 You have ' + st.lookup.rfCredit.offer + ' at your visit, thanks for referring a friend!')}</p>` : REF && !RS && REFI ? `<p class="note who ref-old">🎁 This ${esc(refAmt())} offer is for new clients only.</p>` : ''}`; // (2.99.373 – anh Logan 23:59) no "Not you? Change name"
  return `<div class="field"><label for="bName">${ES ? 'Nombre' : 'Name'}</label><input id="bName" autocomplete="name" autocapitalize="words" enterkeyhint="done" maxlength="60" value="${esc(st.name)}"></div>`;
}
function bindWho(el) {
  const nm = $('#bName', el);
  if (nm) {
    nm.addEventListener('input', () => { st.name = nm.value; });
    nm.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); toNext(nm); } }); // "done": keyboard away, Next in view
    nm.addEventListener('blur', () => setTimeout(() => { if (nm.value.trim() && phoneOk() && !known() && giftAsk() && document.activeElement !== nm) giftPop(() => autoNext()); }, 350)); // (2.75) the keyboard has gone: the 20% off pop-up
  }
  const nb = $('#bNotMe', el); if (nb) nb.addEventListener('click', () => { st.changeName = true; st.name = ''; updateWho(el); $('#bName', el)?.focus(); });
}
function updateWho(el) { const w = $('#bWho', el); if (!w) return; w.innerHTML = whoHtml(); bindWho(el); refreshGift(el); setTimeout(() => guideAfter(st.step, el), 0); }
/* (2.55.12) The 🎁 box (never ticked by itself) – hidden for a customer who already agrees ("✓ You're in…") or who said no / replied STOP.
   (2.64) Ticked (or agreed before) → the birthday: month (12 buttons), then right below "Which day in March?" (1 – 28/29/30/31), then
   "✓ Your birthday: March 15 · Change". Never the year; all optional (nothing, or only the month, is fine). On file (month + day): one line "🎂 Birthday: Mar 15 · Change";
   only the month on file: that month is picked already and only the day is asked. */
const LU = () => (st.lookup && typeof st.lookup === 'object' && st.lookup.found && !st.changeName ? st.lookup : null);
const agreedBefore = () => st.lookup && typeof st.lookup === 'object' && st.lookup.agreed;
const saidNo = () => st.lookup && typeof st.lookup === 'object' && st.lookup.saidNo;
const MONF = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MONF_ES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const pad2 = (n) => String(n).padStart(2, '0');
/** (2.75) The birthday as a card: "🎂 Your birthday" / "January 1" (big) / Change – and the gift line when they agreed. Same card on the confirm step. */
function bdCard(m, d, noBtn) {
  const off = st.sms && st.info.bdayOffer ? `<p class="bd-gift">🎁 ${esc(st.info.bdayOffer)} ${ES ? 'en el mes de su cumpleaños' : 'in your birthday month'}</p>` : '';
  return `<div class="bd-card"><div><p class="bd-t">🎂 ${ES ? 'Su cumpleaños' : 'Your birthday'}</p><p class="bd-v">${ES ? d + ' de ' + MONF_ES[m - 1] : MONF[m - 1] + ' ' + d}</p>${off}</div>${noBtn ? '' : `<button type="button" class="chg2" id="bBdChg">${ES ? 'Cambiar' : 'Change'}</button>`}</div>`;
}
/* (2.75) "🎁 Get 20% off on your birthday!" – a pop-up, asked once: a new customer after the name (keyboard closed), a returning one who never
   answered right after the number check. Nothing chosen for them; ✕ / outside = No. Yes → the birthday (month → day, "Skip birthday") in the box. */
const giftAsk = () => !!(st.info && !st.giftAns && !agreedBefore() && !saidNo() && st.step === 4);
function giftPop(after) {
  if (!giftAsk() || $('.gp-box')) return false;
  const E = ES, offer = st.info.bdayOffer || '', pct = offer.replace(/\s*\(.*\)\s*$/, '') || (E ? '20% de descuento' : '20% off');
  const bg = document.createElement('div'); bg.className = 'modal-bg gp-bg';
  bg.innerHTML = `<div class="modal gp-box" role="dialog" aria-modal="true" aria-labelledby="gpT"><button type="button" class="gp-x" id="gpX" aria-label="${E ? 'Cerrar' : 'Close'}">✕</button><div id="gpIn"></div></div>`;
  document.body.appendChild(bg); const box = $('#gpIn', bg); let done = false;
  const finish = () => { if (done) return; done = true; bg.remove(); G.hold = null; G.cur = null; const el = $('.screen:not(.leaving)', $('#bStage')); if (el) refreshGift(el); if (after) after(); };
  const no = () => { if (done) return; st.giftAns = 'no'; st.sms = false; st.smsNo = true; st.bdM = ''; st.bdD = ''; finish(); };
  const hold = (t) => { G.hold = { t }; G.cur = G.hold; }; // a box is open: the step's guide waits
  const ask = () => {
    box.innerHTML = `<h3 id="gpT">🎁 ${esc(E ? `¡Obtenga ${pct} en su cumpleaños!` : `Get ${pct} on your birthday!`)}</h3>
      <p class="gp-sub">${E ? 'Además ofertas VIP y descuentos de regreso. Hasta 4 mensajes al mes.' : 'Plus VIP deals and come-back discounts. Up to 4 texts a month.'}</p>
      <div class="gp-b"><button type="button" class="gp-yes" id="gpYes">✓ ${E ? 'Sí, inscríbame' : 'Yes, sign me up'}</button><button type="button" class="gp-no" id="gpNo">${E ? 'No, gracias' : 'No thanks'}</button></div>
      <p class="fine-sms gp-fine">${E ? `Mensajes de marketing recurrentes de ${esc(st.info.salon || 'nuestro salón')}. No es necesario para reservar. Pueden aplicar tarifas de mensajes y datos. Responda STOP para cancelar, HELP para ayuda.` : `Recurring marketing texts from ${esc(st.info.salon || 'our salon')}. Not required to book. Msg &amp; data rates may apply. Reply STOP to cancel, HELP for help.`} <a href="https://nailflowapp.com/terms" target="_blank" rel="noopener">SMS Terms</a> · <a href="https://nailflowapp.com/privacy" target="_blank" rel="noopener">Privacy</a></p>`;
    const y = $('#gpYes', box), n = $('#gpNo', box); hold(y);
    $('#gpNo', box).addEventListener('click', no);
    y.addEventListener('click', () => { st.giftAns = 'yes'; st.sms = true; st.smsNo = false; const lu = LU();
      if (!st.info.bday || (lu && lu.hasBday)) { finish(); return; } // the birthday is on file already (2.99.92: never changed here)
      months(true); });
    const say = pct.replace('%', E ? ' por ciento' : ' percent');
    setTimeout(() => { G.tourId++; gTour([[E ? `¿Quiere ${say} en su cumpleaños?` : `Would you like ${say} on your birthday?`, y], [E ? 'Toque Sí para inscribirse,' : 'Tap Yes to sign up,', y], [E ? 'o No, gracias.' : 'or No thanks.', n]],
      () => !done && $('#gpYes', box) === y); }, 0);
  };
  const months = (first) => {
    if (st.bdM) return days(first);
    box.innerHTML = `<h3 id="gpT">🎂 ${E ? '¿Cuándo es su cumpleaños?' : 'When is your birthday?'}</h3><p class="gp-sub">${E ? 'Elija el mes' : 'Pick the month'}</p>
      <div class="bm-g gp-m">${MON3.map((m, i) => `<button type="button" data-gm="${pad2(i + 1)}">${E ? MONF_ES[i].slice(0, 3) : m}</button>`).join('')}</div><button type="button" class="gp-skip" id="gpSkip">${E ? 'Omitir cumpleaños' : 'Skip birthday'}</button>`;
    $$('[data-gm]', box).forEach(b => b.addEventListener('click', () => { st.bdM = b.dataset.gm; st.bdD = ''; days(false); }));
    $('#gpSkip', box).addEventListener('click', () => { st.bdSkip = true; finish(); });
    hold($('[data-gm]', box)); setTimeout(() => gSpeak(E ? '¡Muy bien! ¿Cuándo es su cumpleaños? Elija el mes.' : 'Great! When is your birthday? Pick the month.'), 0);
  };
  const days = (first) => {
    const nd = new Date(2024, +st.bdM, 0).getDate();
    box.innerHTML = `<h3 id="gpT">🎂 ${E ? `¿Qué día de ${MONF_ES[+st.bdM - 1]}?` : `Which day in ${MONF[+st.bdM - 1]}?`}</h3>
      <div class="bd-g gp-d">${Array.from({ length: nd }, (_, i) => `<button type="button" data-gd="${pad2(i + 1)}">${i + 1}</button>`).join('')}</div>
      <div class="gp-row"><button type="button" class="gp-skip" id="gpBack">‹ ${E ? 'Otro mes' : 'Another month'}</button><button type="button" class="gp-skip" id="gpSkip">${E ? 'Omitir cumpleaños' : 'Skip birthday'}</button></div>`;
    $$('[data-gd]', box).forEach(b => b.addEventListener('click', () => { st.bdD = b.dataset.gd; G.bdJust = st.bdM + st.bdD; finish(); setTimeout(() => gSpeak(bdSay()), 0); }));
    $('#gpBack', box).addEventListener('click', () => { st.bdM = ''; months(false); });
    $('#gpSkip', box).addEventListener('click', () => { st.bdM = ''; st.bdSkip = true; finish(); });
    hold($('[data-gd]', box)); setTimeout(() => gSpeak(first ? (E ? '¡Muy bien! ¿Qué día es su cumpleaños?' : 'Great! Now pick the day of your birthday.') : (E ? 'Ahora elija el día.' : 'Now pick the day.')), 0);
  };
  $('#gpX', bg).addEventListener('click', no); bg.addEventListener('click', (e) => { if (e.target === bg) no(); });
  ask(); return true;
}
function bdayArea() {
  if (!st.info.bday) return '';
  const lu = LU();
  if (lu && lu.hasBday) return `<p class="in-line">🎂 ${ES ? 'Su cumpleaños ya está guardado ✓' : 'Your birthday is on file ✓'}</p>`; // (2.99.92) on file: shown as saved, never changed here (only the salon can)
  if (lu && lu.bdM && !lu.bdD && !st.bdM && !st.bdPre) { st.bdPre = true; st.bdM = pad2(lu.bdM); } // the month on file: picked already, only the day is asked
  if (st.bdM && st.bdD) return bdCard(+st.bdM, +st.bdD);
  if (st.bdSkip) return `<p class="in-line">✓ ${ES ? 'Está inscrito en ofertas de cumpleaños y VIP' : "You're in for birthday &amp; VIP deals"}</p>`; // (2.75) "Skip birthday" in the pop-up
  const months = `<div class="bmonths" id="bMonths"><b>🎂 Your birthday month <span class="opt">(optional)</span></b><div class="bm-g">${
    MON3.map((m, i) => { const v = pad2(i + 1); return `<button type="button" data-bm="${v}" class="${st.bdM === v ? 'on' : ''}">${m}</button>`; }).join('')}</div></div>`;
  if (!st.bdM) return months;
  const n = new Date(2024, +st.bdM, 0).getDate(); // February: 29
  return months + `<div class="bdays" id="bDays"><b>Which day in ${MONF[+st.bdM - 1]}?</b><div class="bd-g">${
    Array.from({ length: n }, (_, i) => `<button type="button" data-bd="${pad2(i + 1)}">${i + 1}</button>`).join('')}</div></div>`;
}
function giftArea() {
  if (saidNo() && !agreedBefore()) { st.sms = false; return ''; } // said no thanks / replied STOP: not asked again
  if (agreedBefore()) { st.sms = true; return bdayArea() || `<p class="in-line">✓ You're in for birthday &amp; VIP deals</p>`; }
  return st.giftAns === 'yes' ? bdayArea() : ''; // (2.75) asked in the pop-up (no tick box on the page)
}
function refreshGift(el, scroll) {
  const w = $('#bGiftWrap', el); if (!w) return; w.innerHTML = giftArea();
  const again = () => setTimeout(() => guideAfter(st.step, el), 0);
  $$('[data-bm]', w).forEach(b => b.addEventListener('click', () => { const v = b.dataset.bm; st.bdD = ''; st.bdM = st.bdM === v ? '' : v; refreshGift(el, !!st.bdM); again(); })); // a new month: the day is asked again
  $$('[data-bd]', w).forEach(b => b.addEventListener('click', () => { st.bdD = b.dataset.bd; G.bdJust = st.bdM + st.bdD; refreshGift(el); again();
    const nm = $('#bName', el); if (phoneOk() && (known() || (nm && nm.value.trim()))) autoNext(); })); // (2.73) the birthday was the last thing: on to the number check
  const ch = $('#bBdChg', w); if (ch) ch.addEventListener('click', () => { const lu = LU(); if (lu && lu.hasBday && !st.bdChange) { st.bdChange = true; st.bdM = pad2(lu.bdM); } st.bdD = ''; refreshGift(el, true); again(); });
  if (scroll) { const g = $('#bDays', w); if (g) setTimeout(() => { // the whole day grid in view, above the Next bar at the bottom
    const hd = $('.nav'), top = hd ? hd.getBoundingClientRect().bottom : 0; // the scrolling part starts under the step bar
    g.style.scrollMargin = '6px'; g.scrollIntoView({ behavior: 'auto', block: 'end' });
    if (g.getBoundingClientRect().top < top + 4) { g.style.scrollMarginTop = '8px'; g.scrollIntoView({ behavior: 'auto', block: 'start' }); } // too tall for a small phone: its title and first rows
  }, 80); }
}
/** "fifteenth" – for the voice ("Got it, January fifteenth."). */
const ORD = ['first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth', 'eleventh', 'twelfth', 'thirteenth', 'fourteenth', 'fifteenth', 'sixteenth',
  'seventeenth', 'eighteenth', 'nineteenth', 'twentieth', 'twenty-first', 'twenty-second', 'twenty-third', 'twenty-fourth', 'twenty-fifth', 'twenty-sixth', 'twenty-seventh',
  'twenty-eighth', 'twenty-ninth', 'thirtieth', 'thirty-first'];
/** (2.65) for the voice: "10 AM", "2:30 PM"; "Friday, October second" */
const sayT = (m) => tlabel(m).replace(':00', '');
const sayDate = (d) => { const x = parseD(d); return G_ES ? ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'][x.getDay()] + ', ' + x.getDate() + ' de ' + MONF_ES[x.getMonth()] : WDL[x.getDay()] + ', ' + MONF[x.getMonth()] + ' ' + ORD[x.getDate() - 1]; };
const bdSay = () => G_ES ? `Entendido, ${+st.bdD} de ${MONF_ES[+st.bdM - 1]}.` : `Got it, ${MONF[+st.bdM - 1]} ${ORD[+st.bdD - 1]}.`;
/** The keyboard goes away and the Next button comes into view (the boxes can still be tapped to change them). */
function toNext(input) {
  input.blur();
  setTimeout(() => $('#bGo').scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'end' }), 250); // after the keyboard has gone
}
/** All 10 digits typed: a returning customer – the keyboard goes away and Next comes into view; a new customer – on to the Name box. */
/* (2.55.28) Big number pad for the phone boxes (step 1 "quick booking" and step 4 "Mobile phone"): the iPhone keyboard stays closed (inputmode none);
   1 2 3 / 4 5 6 / 7 8 9 / ⌫ 0 ✓Done – big keys, a small tick + buzz; ⌫ held = clear; Done only at 10 digits (then the number is read back).
   "📱 Use iPhone keyboard" (remembered on this phone) for iPhone autofill; "Use (515) 672-7879" when this phone booked before. */
const KP = { open: false, inp: null, done: null, said: '' };
const kpMode = () => gLS('bookKb') === 'ios' ? 'ios' : 'web';
function kpSetup(inp, onDone) {
  if (!inp) return; const web = kpMode() === 'web'; inp.setAttribute('inputmode', web ? 'none' : 'tel');
  // one small switch on the label line: "📱 Use iPhone keyboard" ⇄ "🔢 Big number pad" (no room lost under the box)
  const sw = document.createElement('button'); sw.type = 'button'; sw.className = 'linkbtn kp-back'; const lbl = inp.closest('.field') && inp.closest('.field').querySelector('label');
  const txt = () => { sw.textContent = kpMode() === 'web' ? (ES ? '📱 Teclado del iPhone' : '📱 Use iPhone keyboard') : (ES ? '🔢 Teclado grande' : '🔢 Big number pad'); }; txt();
  if (lbl) { lbl.classList.add('kp-lbl'); lbl.insertAdjacentElement('afterend', sw); sw.classList.add('kp-sw-r'); } else inp.insertAdjacentElement('afterend', sw);
  sw.addEventListener('click', () => { if (kpMode() === 'web') { gLS('bookKb', 'ios'); kpClose(); inp.setAttribute('inputmode', 'tel'); inp.blur(); inp.focus(); } else { gLS('bookKb', 'web'); inp.setAttribute('inputmode', 'none'); inp.blur(); kpOpen(inp, onDone); } txt(); });
  const go = () => { if (kpMode() === 'web' && !(KP.open && KP.inp === inp)) kpOpen(inp, onDone); };
  inp.addEventListener('focus', go); inp.addEventListener('click', go);
  // (2.99.377 – anh Logan 00:35) step 4: no page with only the empty box – the number pad opens right away (number not typed yet)
  if (inp.id === 'bPhone' && kpMode() === 'web' && digits(inp.value).length < 10) setTimeout(() => { if (inp.isConnected && !KP.open) kpOpen(inp, onDone); }, 200);
}
function kpOpen(inp, onDone) {
  KP.open = true; KP.inp = inp; KP.done = onDone; KP.said = digits(inp.value).length === 10 ? digits(inp.value) : '';
  let k = $('#bKp'); if (!k) { document.body.insertAdjacentHTML('beforeend', `<div class="kp" id="bKp" role="group" aria-label="Number pad"><div class="kp-show" data-kshow aria-live="polite"></div><div class="kp-top"><button type="button" class="kp-me" data-kme hidden></button></div>
    <div class="kp-g">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button type="button" class="kp-k" data-kk="${n}">${n}<small aria-hidden="true">${['', '&nbsp;', 'ABC', 'DEF', 'GHI', 'JKL', 'MNO', 'PQRS', 'TUV', 'WXYZ'][n]}</small></button>`).join('')}<button type="button" class="kp-k kp-done" data-kk="done">✓ ${ES ? 'Listo' : 'Done'}</button><button type="button" class="kp-k" data-kk="0">0<small aria-hidden="true">&nbsp;</small></button><button type="button" class="kp-k kp-del" data-kk="del" aria-label="Delete">⌫</button></div></div>`); k = $('#bKp'); kpBind(k); } // (2.99.377 – anh Logan 00:35) laid out like the iPhone number pad: letters under the digits, ⌫ bottom right
  $$('.kp-hid').forEach(x => x.classList.remove('kp-hid')); inp.classList.add('kp-hid'); try { inp.blur(); } catch (e) {} // (2.99.371 – anh Logan 23:28) ONE number box: the big one on the pad (the page box hides, no iPhone keyboard under it)
  k.hidden = false; document.body.classList.add('kp-on'); kpSync(true); setTimeout(() => { kpFit(); if (G.el) guideAfter(st.step, G.el); }, 30);
}
function kpClose() { if (!KP.open) return; KP.open = false; $$('.kp-hid').forEach(x => x.classList.remove('kp-hid')); const k = $('#bKp'); if (k) k.hidden = true; document.body.classList.remove('kp-on'); $$('.kp-pad').forEach(x => { x.style.paddingBottom = ''; x.classList.remove('kp-pad'); }); setTimeout(() => { if (G.el && G.el.isConnected) guideAfter(st.step, G.el); }, 50); }
function kpFit() { // the box, its reminder and the pad – all on the screen
  const k = $('#bKp'), inp = KP.inp; if (!k || !inp || !KP.open) return; const sc = inp.closest('.screen'), inn = sc && $('.in', sc); if (!sc) return;
  if (inn) { inn.classList.add('kp-pad'); inn.style.paddingBottom = (k.offsetHeight + 16) + 'px'; }
  const top = ((inp.closest('.field') || inp.parentElement || inp).querySelector('label') || inp.closest('.field') || inp.parentElement || inp).getBoundingClientRect().top, st0 = sc.getBoundingClientRect().top; sc.scrollTop += top - st0 - 6;
}
function kpBind(k) {
  let lp = null, lpDone = false;
  k.addEventListener('pointerdown', (e) => { if (!e.target.closest('[data-kk="del"]')) return; lpDone = false; clearTimeout(lp); lp = setTimeout(() => { lpDone = true; kpSet(''); kpTick(); }, 650); });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(t => k.addEventListener(t, () => clearTimeout(lp)));
  k.addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b || !KP.inp) return;
    if (b.dataset.kme !== undefined) { kpSet(gLS('bookMyPhone') || ''); st.phUse = digits(KP.inp.value); kpTick(); return; }
    const v = b.dataset.kk; if (v === undefined) return;
    if (v === 'done') { if (digits(KP.inp.value).length === 10) { const f = KP.done; kpTick(); kpClose(); if (f) f(); } return; }
    if (v === 'del') { if (lpDone) { lpDone = false; return; } kpSet(digits(KP.inp.value).slice(0, -1)); }
    else { const d = digits(KP.inp.value); if (d.length >= 10) return; kpSet(d + v); }
    kpTick(); });
}
function kpSet(d) { const inp = KP.inp; inp.value = prettyPhone(digits(String(d || '')).slice(0, 10)); inp.dispatchEvent(new Event('input', { bubbles: true })); kpSync(); }
function kpSync(first) { const k = $('#bKp'); if (!k || !KP.inp) return; const d = digits(KP.inp.value), dn = $('[data-kk="done"]', k);
  const sh = $('[data-kshow]', k); if (sh) { sh.textContent = d ? prettyPhone(d) : (KP.inp.getAttribute('placeholder') || (ES ? 'Escriba su número de celular' : 'Type your mobile number')); sh.classList.toggle('ph', !d); } // (2.99.370 – anh Logan 23:16) the number big, right above the pad
  dn.disabled = d.length !== 10; dn.classList.toggle('pulse', d.length === 10);
  const me = digits(gLS('bookMyPhone') || ''), mb = $('[data-kme]', k); mb.textContent = (ES ? 'Usar ' : 'Use ') + prettyPhone(me); mb.hidden = !(me.length === 10 && me !== d); $('.kp-top', k).hidden = mb.hidden;
  if (d.length === 10 && KP.said !== d && !first) { KP.said = d; gSpeak(sayDigits(d), null, 0.85); } // the number read back
  if (d.length < 10) KP.said = '';
  if (!first && G.el) setTimeout(() => guideAfter(st.step, G.el), 0); }
function kpTick() { try { navigator.vibrate && navigator.vibrate(8); } catch (e) {} if (!G.on) return;
  try { const A = KP.ac || (KP.ac = new (window.AudioContext || window.webkitAudioContext)()); const o = A.createOscillator(), g = A.createGain(); o.type = 'square'; o.frequency.value = 1700;
    g.gain.setValueAtTime(0.04, A.currentTime); g.gain.exponentialRampToValueAtTime(0.0001, A.currentTime + 0.03); o.connect(g).connect(A.destination); o.start(); o.stop(A.currentTime + 0.035); } catch (e) {} }
document.addEventListener('focusin', (e) => { if (KP.open && e.target !== KP.inp && e.target.matches && e.target.matches('input, textarea, select')) kpClose(); });
function afterPhone(el) {
  const nm = $('#bName', el);
  if (nm && !nm.value.trim()) { nm.focus({ preventScroll: true }); nm.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'center' }); return; }
  toNext($('#bPhone', el));
}
async function lookupName(el, typed) {
  const ph = digits(st.phone); if (ph.length !== 10 || ph === st.lookedUp) return;
  st.lookedUp = ph; st.lookup = 'loading'; st.changeName = false; updateWho(el);
  let res;
  try { res = await api('lookup_name', { phone: ph }); } catch (e) { res = { found: false }; } // too many tries or offline: just ask for the name
  if (digits(st.phone) !== ph) { if (st.lookedUp === ph) { st.lookedUp = ''; st.lookup = null; } return; } // phone changed while waiting (2.55.24: never stuck on 'loading')
  st.lookup = res; updateWho(el);
  if (REF && !RS && REFI) document.querySelectorAll('.ref-hello').forEach(b => { const old = !!(res && res.found); // (2.99.51) a number already on file: no friend offer (new clients only)
    b.textContent = old ? `Welcome back! This ${refAmt()} offer is for new clients only.` : REFI.text; b.classList.toggle('ref-no', old); });
  if (typed && document.activeElement === $('#bPhone', el) && !KP.open) afterPhone(el); // (2.55.28) the pad: Done goes on
}

/** (2.55.11) "ⓘ More": everything about the service in a box (no price) – "Select this service" / "Close". */
/** An extra stays only while its main service (hands / pedicure) is picked. */
function pruneExtras(p) {
  const z = st.info.zones || {}, A = st.info.addons || [], isA = (id) => A.some(a => a.id === id), cur = p ? svcOf(p) : st.services;
  const has = (k) => cur.some(id => z[id] === k && !isA(id));
  const nx = cur.filter(id => !isA(id) || has(A.find(a => a.id === id).addon));
  if (p) st.ps[p] = nx; else st.services = nx;
}
function bind(s, el) {
  $('#bSlotRetry', el)?.addEventListener('click', () => { st.slotErr = false; loadSlots(); }); // (2.99.92)
  setTimeout(() => guideAfter(s, el), 0); // (2.55.6) the voice for this step
  $$('[data-dz]', el).forEach(b => b.addEventListener('click', () => { st.design[+b.dataset.dz] = b.dataset.v === '1'; st.start = null; st.slots = null; refresh(); }));
  if (s === 1) {
    $$('[data-p]', el).forEach(b => b.addEventListener('click', () => setPeople(+b.dataset.p)));
    $('#bAgain1', el)?.addEventListener('click', againGo); // (2.99.491 – LỆNH 488 b)
    const more = $('#bMore', el); if (more) more.addEventListener('click', askPeople);
    const qi = $('#bQr', el); if (qi) kpSetup(qi, () => {}); if (qi) qi.addEventListener('focus', () => { if (!G.said.qrph) { G.said.qrph = true; gSpeak(PH_REAL()); } });
    if (qi) qi.addEventListener('input', async () => { const pv = prettyPhone(qi.value); if (pv !== qi.value) qi.value = pv; st.qrPhone = pv; const d = digits(pv);
      if (d.length !== 10 || d === st.qrAsked) return; st.qrAsked = d; let r; try { r = await api('quick_rebook', { phone: d }); } catch (e) { r = { found: false }; }
      if (digits(st.qrPhone) !== d) return; st.qr = r; st.qrNo = false; qi.blur(); G.quiet = false; refresh(); });
    $('#qrYes', el)?.addEventListener('click', quickBook);
    $('#qrNo', el)?.addEventListener('click', () => { st.qrNo = true; st.phone = prettyPhone(st.qrPhone || ''); G.quiet = false; refresh(); });
  }
  if (s === 2) {
    const fix = (k) => { pruneExtras(k); const pid = st.people[k]; if (pid && !canDoK(st.info.staff.find(t => t.id === pid) || { skills: [] }, k)) st.people[k] = 0; if (!designK(k)) st.design[k] = false; st.start = null; st.slots = null; };
    $$('[data-cat]', el).forEach(b => b.addEventListener('click', () => { const g = b.dataset.cat; svOpen(+b.dataset.ck, g === 'x' ? 'x' : +g); })); // (2.99.72) a type of service: its sheet
    $$('[data-unpick]', el).forEach(b => b.addEventListener('click', () => { const k = +b.dataset.uk, id = +b.dataset.unpick, nx = svcOf(k).filter(x => x !== id); // ✕ on a pick: it goes
      if (k === 0) st.services = nx; else st.ps[k] = nx; svFix(k); G.quiet = false; refresh(); gSpeak((ES ? 'Quitado: ' : 'Removed: ') + chipNm(id) + '.'); }));
    $$('[data-same]', el).forEach(b => b.addEventListener('click', () => { const k = +b.dataset.same; st.ps[k] = [...st.services]; st.design[k] = !!st.design[0]; st.people[k] = 0; st.pt[k] = null; st.tm[k] = undefined; st.sDone[k] = true; delete st.tp[k]; st.addHide = false; G.quiet = false; G.pre = ES ? 'Lo mismo que la Persona 1. ' : 'Same as Person 1. '; fix(k); refresh(); })); // services copied, the tech stays Any
    // (2.67) a tech tapped: it lights up with ✓ for half a second, "Got it, Tammy.", then this person / service is done and the next one opens (no Done button)
    const picked = (x, k, label) => { $$('.tv.on', x.closest('.tb-g')).forEach(b => b.classList.remove('on')); x.classList.add('on');
      G.pre = (G_ES ? 'Entendido, ' : 'Got it, ') + label + '. '; G.quiet = false; clearTimeout(G.techT); st.start = null; st.slots = null;
      setTimeout(() => { if (st.step !== 2) return; if (pReady(k)) { if (st.gEdit === k) st.gEdit = null; gwFinish(k, el); if (st.people.length === 1 || gwOpen() < 0) setTimeout(() => $('#bGo')?.classList.add('lit'), 80); } else refresh();
        setTimeout(() => { if (G.pre) { const t = G.pre.trim(); G.pre = ''; gSpeak(t + (gwOpen() < 0 && valid(2) ? ' ' + GT.allSet : '')); } }, 250); }, 500); }; // the next line was said before: "Got it, Tammy." alone
    const tvName = (v) => v ? gName(techName(v)) : (G_ES ? 'cualquier técnico' : 'any tech');
    $$('[data-pt]', el).forEach(x => x.addEventListener('click', () => { const k = +x.dataset.pt; st.people[k] = +x.dataset.tv; st.tp[k] = 1; G.touched['t' + k] = 1; picked(x, k, tvName(+x.dataset.tv)); }));
    $$('[data-bfor]', el).forEach(b => b.addEventListener('click', () => history.go(1 - st.step))); // back to "How many people?" (choices kept)
    $$('[data-schg]', el).forEach(b => b.addEventListener('click', () => { const k = +b.dataset.schg; st.sDone[k] = false; st.tm[k] = undefined; st.gDone[k] = false; st.addHide = false; G.quiet = false; Object.keys(st.tp).filter(x => x === String(k) || x.startsWith(k + '|')).forEach(x => delete st.tp[x]); refresh(); }));
    $$('[data-gedit]', el).forEach(b => b.addEventListener('click', () => { const k = +b.dataset.gedit; st.gDone[k] = false; st.gEdit = k; G.quiet = false; G.said['gt' + k] = false; Object.keys(st.tp).filter(x => x === String(k) || x.startsWith(k + '|')).forEach(x => delete st.tp[x]); refresh(); // (2.67) Change: pick the tech again
      setTimeout(() => { $('.pp.open')?.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' }); guideAfter(st.step, el); }, 60); }));
    $$('[data-pts]', el).forEach(x => x.addEventListener('click', () => { const k = +x.dataset.pts; st.pt[k] = { ...(st.pt[k] || {}), [x.dataset.sid]: +x.dataset.tv }; st.tp[k + '|' + x.dataset.sid] = 1; G.touched['s' + k + '|' + x.dataset.sid] = 1; picked(x, k, tvName(+x.dataset.tv)); }));
    $$('[data-each]', el).forEach(b => b.addEventListener('click', () => { const k = +b.dataset.each, was = st.tm[k]; st.tm[k] = b.dataset.m; G.quiet = false; if (!was) G.touched['t' + k] = 0; if (was !== b.dataset.m) Object.keys(st.tp).filter(x => x === String(k) || x.startsWith(k + '|')).forEach(x => delete st.tp[x]);
      if ((b.dataset.m === 'each') === !!ptOf(k)) { refresh(); return; }
      st.pt[k] = ptOf(k) ? null : Object.fromEntries(svcOf(k).map(sid => [sid, st.people[k] && canDoSvc(st.info.staff.find(t => t.id === st.people[k]) || { skills: [] }, sid) ? st.people[k] : 0]));
      if (st.pt[k]) st.people[k] = 0; st.start = null; st.slots = null; refresh(); }));
  }
  if (s === 3) {
    $$('[data-d]', el).forEach(b => b.addEventListener('click', () => { G.dayTap = true; st.dayPk = true; /* (2.99.550) the customer picked this day */ tsShow(); if (b.dataset.d !== st.date) { st.date = b.dataset.d; loadSlots(); } else { refresh(); guideAfter(3, el); } })); // (2.99.180) a day → the times popup
    $$('[data-m]', el).forEach(b => b.addEventListener('click', () => { st.start = +b.dataset.m; st.notice = ''; G.timeTap = st.date + '|' + st.start; tsHide(() => { if (RS && st.rs) rsConfirm(); else autoNext(null, true); }); refresh(); })); // (2.99.369) a time picked: straight on to step 4 (no "Next step… / Stay here") // (2.65) picked: "✓ Friday, Oct 2 at 10:00 AM" over Next (no jump); (2.99.180) the popup closes first
    $$('[data-tsopen]', el).forEach(b => b.addEventListener('click', () => { G.dayTap = true; tsShow(); refresh(); guideAfter(3, el); }));
    $$('[data-tsclose]', el).forEach(b => b.addEventListener('click', () => { tsHide(); refresh(); }));
    $$('[data-dz-go]', el).forEach(b => b.addEventListener('click', () => { const dz = $('#days', el); dz.scrollBy({ left: +b.dataset.dzGo * dz.clientWidth * 0.9, behavior: reduced ? 'auto' : 'smooth' }); }));
    { const dz = $('#days', el), arr = () => { const [l, r] = $$('[data-dz-go]', el); if (l) l.disabled = dz.scrollLeft < 4; if (r) r.disabled = dz.scrollLeft + dz.clientWidth >= dz.scrollWidth - 4; };
      dz.addEventListener('scroll', arr, { passive: true }); setTimeout(arr, 0); }
    $$('[data-nx]', el).forEach(b => b.addEventListener('click', () => { const x = st.nx.list[+b.dataset.nx]; st.dayPk = true; st.date = x.date; st.slots = x.r.slots; st.techNotes = x.r.techNotes || []; st.parts = x.r.parts || {}; st.start = x.m; st.notice = ''; st.nx = null; tsHide(() => next()); refresh(); }));
    $('[data-rsany]', el)?.addEventListener('click', () => { st.rsAny = !st.rsAny; st.people = st.rsAny ? st.people.map(() => 0) : [...st.rs.staff]; st.start = null; st.notice = ''; st.nx = null; G.quiet = false; G.unlocked = true;
      gSpeak(st.rsAny ? 'Showing times with any nail tech. Now pick a time.' : 'Showing times with ' + rsTechs() + '. Now pick a time.'); G.said['s3t' + st.date] = true; loadSlots(); });
    $$('[data-anyt]', el).forEach(b => b.addEventListener('click', () => goAny(null))); // (2.99.182) every such button (the popup has 2)
    $$('[data-bany]', el).forEach(b => b.addEventListener('click', () => askAny(+b.dataset.bany))); // (2.99.183) "Busy · 👥 anyone?"
    $$('[data-backt]', el).forEach(b => b.addEventListener('click', () => { const p = st.prevTech; if (!p) return; st.prevTech = null; st.people = p.people; st.pt = p.pt; st.tm = p.tm; st.nx = null; G.quiet = false; if (st.date && dayBlocked(st.date)) prepareDay(); else loadSlots(); chrome(); }));
    const sel = $('#days .on', el), dz = $('#days', el); if (sel) { const l = sel.offsetLeft - dz.offsetLeft, r = l + sel.offsetWidth; if (l < dz.scrollLeft || r > dz.scrollLeft + dz.clientWidth) dz.scrollLeft = Math.max(0, l - 2); } // (2.65) the chosen day fully in view – never cut
    tsDock(el); // (2.99.182 – order 375) LAST: the popup goes to <body> only after ALL its buttons are bound (2.99.180/181: "See times with Any tech" and the "Next available" days were moved before – a tap did nothing)
  }
  if (s === 4) {
    const keep = () => { const n = $('#bNote', el); if (n) st.note = n.value; st.web = $('#bWeb', el).value; };
    ['#bNote', '#bWeb'].forEach(id => $(id, el)?.addEventListener('input', keep));
    const add = $('#bAddNote', el); // "+ Add a note": the note box opens (and stays open)
    if (add) add.addEventListener('click', () => { st.noteOpen = true;
      add.outerHTML = `<div class="field"><label for="bNote">${ES ? 'Nota (opcional)' : 'Note (optional)'}</label><textarea id="bNote" rows="2" placeholder="${ES ? 'Color, diseño, lo que debamos saber' : 'Color, design, anything we should know'}"></textarea></div>`;
      const n = $('#bNote', el); n.addEventListener('input', keep); n.focus(); });
    const ph = $('#bPhone', el);
    const again = $('#bReenter', el);
    // "Re-enter phone number": clears the number (and the "Welcome back"), and the keyboard opens again for a new one
    again.addEventListener('click', () => { ph.value = ''; st.phone = ''; st.lookup = null; st.lookedUp = ''; st.changeName = false; again.hidden = true; updateWho(el); ph.focus(); });
    ph.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); if (phoneOk()) afterPhone(el); } });
    ph.addEventListener('input', () => {
      const p = prettyPhone(ph.value); if (p !== ph.value) ph.value = p; st.phone = p; again.hidden = !p;
      if (phoneOk()) { if (digits(st.phone) === st.lookedUp && st.lookup && st.lookup !== 'loading') { if (!KP.open) afterPhone(el); } else lookupName(el, true); }
      else if (st.lookup !== null || st.lookedUp) { st.lookup = null; st.lookedUp = ''; st.changeName = false; updateWho(el); }
    });
    $('#bPcYes', el).addEventListener('click', () => { st.phConfirmed = digits(st.phone); G.said['pcy' + st.phConfirmed] = true; primary(); }); // (2.99.610) Yes = Next
    $('#bPcFix', el).addEventListener('click', () => { st.phConfirmed = ''; st.phUse = ''; ph.value = ''; st.phone = ''; pcInl(el); again.click(); gSpeak(ES ? 'Por favor escriba su número de celular correcto.' : 'Please type your correct mobile number.'); });
    el.addEventListener('focusin', () => pcInl(el)); el.addEventListener('focusout', (e) => setTimeout(() => { pcInl(el); if (e.target.id === 'bName' && st.step === 4) guideAfter(4, el); }, 350));
    bindWho(el); refreshGift(el);
    kpSetup(ph, () => { st.phChecked = true; const nm = $('#bName', el); if (nm && !nm.value.trim() && !known()) afterPhone(el); else primary(); }); // (2.55.28) Done = Next
    if (phoneOk() && st.lookup === null) lookupName(el);
    pcInl(el);
  }
  if (s === 5) {
    $$('[data-go]', el).forEach(b => b.addEventListener('click', () => { st.editing = true; if (b.dataset.gk !== undefined) { const k = +b.dataset.gk; st.gDone[k] = false; st.gEdit = k; } history.go(+b.dataset.go - st.step); }));
    if (depNeeded()) mountPayPal(el);
  }
}

/* ---------- chrome: back button, progress, bottom button ---------- */
function chrome() {
  const s = st.step, go = $('#bGo'), act = $('#bAct');
  document.body.classList.toggle('no-hero', !RS && (s >= LAST || !!st.done)); // (2.99.373 – anh Logan 00:08) Confirm + "You're booked!": no salon name / language / address band – the page uses the whole screen
  $('#bBack').disabled = RS ? false : s === 1 || st.done;
  $('#bStepTxt').textContent = RS ? (ES ? 'Cambiar su hora' : 'Change your time') : st.done ? (ES ? 'Reservado' : 'Booked') : (ES ? `Paso ${s} de ${LAST}` : `Step ${s} of ${LAST}`); $('#bDots').hidden = !!RS;
  $('#bDots').innerHTML = Array.from({ length: LAST }, (_, k) => `<i class="${k + 1 === s && !st.done ? 'on' : k + 1 < s || st.done ? 'past' : ''}"></i>`).join('');
  let label = '', enabled = true, techDis = false; if (s !== 4) document.body.classList.remove('pcy-on');
  if (st.done) label = '';
  else if (s === 2) { label = ES ? 'Siguiente ›' : 'Next ›'; enabled = valid(2); const k = curK(); if (!enabled) { enabled = true; techDis = !(k >= 0 && pReady(k) && !st.gDone[k]); } } // (2.67) looks off; a tap says what to do – (2.99.232) always: it goes to what is missing // (2.67) looks off; a tap says what to do
  else if (s === 3) { label = RS ? (ES ? 'Cambiar a esta hora ›' : 'Change to this time ›') : (ES ? 'Siguiente ›' : 'Next ›'); enabled = valid(3); } // (2.65) stuck at the bottom, lights up once a time is picked
  else if (s === 4) label = ES ? 'Siguiente ›' : 'Next ›';
  else if (s === 5 && !depNeeded()) { label = st.busy ? (ES ? 'Reservando…' : 'Booking…') : (ES ? '✅ Reservar' : '✅ Book now'); /* (2.99.320 – lệnh 548) */ enabled = !st.busy; } // with a deposit, PayPal's buttons book
  const combo = !st.done && s === 5 && comboOn(); smsGo(combo); // (2.99.163) on a phone: ONE button "📲 Book & text to confirm" (a real link – Messages opens with no question)
  act.hidden = !label; go.hidden = !label || combo; go.textContent = label; go.disabled = !enabled; go.classList.toggle('lit', s === 3 && enabled); go.classList.toggle('tech-dis', techDis); go.toggleAttribute('aria-disabled', techDis || go.classList.contains('soft-dis'));
  let pk = $('#bPick'); if (!pk) { go.insertAdjacentHTML('beforebegin', '<p class="pick-line" id="bPick" hidden></p>'); pk = $('#bPick'); }
  pk.hidden = !(s === 3 && valid(3) && !st.done); /* (2.99.191 – order 387) step 5: no day line here (the date card has it) */ pk.classList.toggle('pk5', s === LAST); /* (2.99.181 – order 373b) step 5: small (the date card above has it) */ if (!pk.hidden) pk.textContent = s === LAST ? [shortD(st.date), tlabel(st.start), st.people.length + ' ' + (ES ? (st.people.length > 1 ? 'personas' : 'persona') : (st.people.length > 1 ? 'people' : 'person'))].join(' · ') : '✓ ' + shortD2(st.date) + (ES ? ' a las ' : ' at ') + tlabel(st.start); // (2.74) over Book now: "Sun, Oct 4 · 4:00 PM · 2 people"
  addBar(); sumBar(); saveDraft();
}
/* (2.55.18) Summary over Next: "2 people · 3 services · TAMMY, Any tech ▴" – tap: each person with [Edit]. Hidden while "Add another service?" shows. */
function sumBar() {
  let sb = $('#bSum'); let all = st.people.map((_, k) => svcOf(k).length).reduce((a, b) => a + b, 0), add = $('#bAdd');
  const show = !st.done && st.step >= 2 && st.step <= 4 && all > 0 && !(add && !add.hidden) && !(st.step === 2 && st.sheet) && !(st.step === 2 && st.people.length === 1); // (2.99.366) one person, step 2: only the techs (no summary line) // (2.99.72) the service sheet open: the summary steps aside
  if (!show) { if (sb) sb.hidden = true; return; }
  if (!sb) { $('#bAct').insertAdjacentHTML('afterbegin', '<div class="sumbar" id="bSum"><button type="button" class="sb-line" id="bSumT" aria-expanded="false"></button><div class="sb-list" id="bSumL" hidden></div></div>'); sb = $('#bSum');
    $('#bSumT').addEventListener('click', () => { st.sumOpen = !st.sumOpen; sumBar(); });
    $('#bSumL').addEventListener('click', (e) => { const b = e.target.closest('[data-sedit]'); if (!b) return; const k = +b.dataset.sedit; st.sumOpen = false; st.gDone[k] = false; st.gEdit = k; G.quiet = false;
      if (st.step === 2) { refresh(); setTimeout(() => $('.pp.open')?.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' }), 60); } else history.go(2 - st.step); }); }
  const n = st.people.length, any = ES ? 'Cualquier técnico' : 'Any tech', tn = (id) => id ? techName(id) : any;
  const techs = [...new Set(st.people.flatMap((pid, k) => ptOf(k) ? svcOf(k).map(sid => tn(st.pt[k][sid] || 0)) : [tn(pid)]))];
  { const am = st.people.map((_, k) => mainsOf(k).length || (svcOf(k).length ? 1 : 0)).reduce((a, b) => a + b, 0); if (am) all = am; } // (2.55.29) small services are not counted
  $('#bSumT').innerHTML = `<span>${n} ${ES ? (n > 1 ? 'personas' : 'persona') : (n > 1 ? 'people' : 'person')} · ${all} ${ES ? (all > 1 ? 'servicios' : 'servicio') : (all > 1 ? 'services' : 'service')} · ${esc(techs.join(', '))}</span><b>${st.sumOpen ? '▾' : '▴'}</b>`;
  $('#bSumT').setAttribute('aria-expanded', String(!!st.sumOpen));
  $('#bSumL').innerHTML = st.people.map((pid, k) => !svcOf(k).length ? '' : `<div class="sb-row"><span>${n > 1 ? `<b>${esc(pShort(k))}:</b> ` : ''}${esc(ptOf(k) ? svcOf(k).map(sid => svcName(sid) + ' · ' + tn(st.pt[k][sid] || 0)).join(', ') : svcTextK(k) + ' · ' + tn(pid))}</span><button type="button" class="linkbtn" data-sedit="${k}">${ES ? 'Editar' : 'Edit'}</button></div>`).join('');
  $('#bSumL').hidden = !st.sumOpen; sb.hidden = false; $('#bAct').hidden = false; // step 3 has no Next: the bar still shows
}
/* (2.55.18) Unfinished booking kept on this phone for 30 minutes (no phone number): "Continue where you left off?" */
const DRAFT = 'bookDraft';
function saveDraft() {
  if (RS) return;
  if (st.done) { gLS(DRAFT, ''); return; }
  if (!st.restoring && st.step >= 2 && st.peopleChosen && st.people.some((_, k) => svcOf(k).length)) gLS(DRAFT, JSON.stringify({ t: Date.now(), people: st.people, services: st.services, ps: st.ps, pt: st.pt, design: st.design, sDone: st.sDone, gDone: st.gDone, tm: st.tm, tp: st.tp, date: st.date }));
}
/** (2.66) The unfinished booking on this phone (30 minutes), or null. */
function draftLoad() {
  let d = null; try { d = JSON.parse(gLS(DRAFT) || 'null'); } catch (e) {}
  if (!d || !d.t || Date.now() - d.t > 30 * 60000 || !Array.isArray(d.people) || !d.people.length) { gLS(DRAFT, ''); return null; }
  return d;
}
/** (2.66) Back to a first visit for the guide: nothing said yet, the hand starts over (welcome → mute tip → how many people). */
function guideReset() {
  G.said = {}; G.skipSay = ''; G.touched = {}; G.quiet = false; G.pre = ''; G.dayTap = false; G.timeTap = ''; G.bdJust = ''; G.hintShown = false;
  G.tourId++; clearTimeout(G.abT); clearTimeout(G.idleT); G.el = null; G.cur = null; G.lastT = null;
}
/* (2.55.18 / 2.66) "Continue where you left off?" – big, with what was being booked ("2 people · 2 services · Fri, Oct 2"), read out, the hand on Continue.
   Start over: everything cleared, the guide starts again as on a first visit. Continue: the step being done, its line read again. Called inside the tap. */
function askDraft(d) {
  d = d || draftLoad(); if (!d) return false;
  const okS = (id) => st.info.services.some(x => x.id === id) || (st.info.addons || []).some(x => x.id === id), okT = (id) => !id || st.info.staff.some(t => t.id === id);
  const n = d.people.length, svcN = d.people.reduce((a, _, k) => a + ((k ? (d.ps || [])[k] : d.services) || []).filter(okS).length, 0); // person 1: services, the others: ps[k]
  const what = [ES ? `${n} ${n > 1 ? 'personas' : 'persona'}` : `${n} ${n > 1 ? 'people' : 'person'}`, svcN ? (ES ? `${svcN} ${svcN > 1 ? 'servicios' : 'servicio'}` : `${svcN} ${svcN > 1 ? 'services' : 'service'}`) : '',
    d.date && st.info.days.some(x => x.date === d.date && x.open) ? shortD(d.date) : ''].filter(Boolean).join(' · ');
  const bg = document.createElement('div'); bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal draft-box" role="dialog" aria-modal="true" aria-labelledby="dfT"><h3 id="dfT">${ES ? '¿Continuar donde lo dejó?' : 'Continue where you left off?'}</h3>
    <p class="df-what">${esc(what)}</p>
    <div class="modal-btns"><button type="button" class="ghost" id="dfNo">${ES ? 'Empezar de nuevo' : 'Start over'}</button><button type="button" id="dfGo">${ES ? 'Continuar' : 'Continue'}</button></div></div>`;
  document.body.appendChild(bg);
  G.hold = { t: $('#dfGo', bg) }; G.cur = G.hold;
  gSpeak(ES ? 'Bienvenido de nuevo. ¿Quiere continuar donde lo dejó, o empezar de nuevo?' : 'Welcome back. Do you want to continue where you left off, or start over?');
  $('#dfNo', bg).addEventListener('click', () => { gLS(DRAFT, ''); bg.remove(); G.hold = null; guideReset(); // a clean start, as the first time
    const sn = ($('.hero h1')?.textContent || 'our salon').trim().toLowerCase().replace(/\b\w/g, c => c.toUpperCase()).replace(/ (And|Of|The) /g, (m) => m.toLowerCase());
    gSpeak(GT.wSay.replace('{salon}', sn)); G.skipSay = 's1'; // said right in the tap (iPhone / iPad allow the sound)
    render(1, 0); });
  $('#dfGo', bg).addEventListener('click', () => { bg.remove(); G.hold = null; guideReset();
    st.people = d.people.map(id => okT(id) ? id : 0); st.services = (d.services || []).filter(okS); st.ps = (d.ps || []).map(l => (l || []).filter(okS)); st.design = d.design || [];
    st.pt = (d.pt || []).map(m => m && typeof m === 'object' ? Object.fromEntries(Object.entries(m).map(([s, t]) => [s, okT(t) ? t : 0])) : null);
    st.sDone = d.sDone || []; st.gDone = d.gDone || []; st.tm = d.tm || []; st.tp = d.tp || {}; st.gEdit = null; st.peopleChosen = true; st.date = st.info.days.some(x => x.date === d.date && x.open) ? d.date : null; st.start = null; st.slots = null;
    st.people.forEach((_, k) => { if (!pReady(k)) st.gDone[k] = false; });
    const to = valid(2) ? 3 : 2; for (let s = 2; s <= to; s++) history.pushState({ bstep: s }, ''); render(to, 1); }); // that step's line is read and the hand shows where to tap
  return true;
}
/* (2.55.15b) A service picked: "✓ Deluxe Manicure selected. Add another service?" [+ Add more] [No, that's all ✓] – above Next. */
const abMains = (k) => svcOf(k).filter(id => !(st.info.addons || []).some(a => a.id === id));
const qaName = (id) => svcName(id).replace(/^\+\s*/, '').replace(/^(add|agregar)\s+/i, '').replace(/\s*\((hands|feet)\)$/i, '');
const abAddTxt = (k) => { const a = svcOf(k).filter(id => (st.info.addons || []).some(x => x.id === id)); return a.length ? ' + ' + a.map(qaName).join(' + ') : ''; };
function addBar() {
  let bar = $('#bAdd'); const k = st.step === 2 && !st.done ? curK() : -1;
  const show = k >= 0 && svcOf(k).length > 0 && !sDone(k) && !st.addHide && !st.sheet; // (2.99.72) after the service sheet is closed
  if (!show) { if (bar) bar.hidden = true; addBarOff(); return; }
  if (!bar) { $('#bAct').insertAdjacentHTML('afterbegin', '<div class="addbar" id="bAdd" role="status"><p class="ab-h"><span id="bAddH"></span></p><p class="ab-t"></p><div class="ab-q"><span class="ab-qs" id="bAddQ"></span><button type="button" class="ab-more" id="bAddMore"></button></div><button type="button" class="ab-no" id="bAddNo"></button></div>'); bar = $('#bAdd');
    $('#bAddQ').addEventListener('click', (e) => { const b = e.target.closest('[data-qa]'); const j = curK(); if (!b || j < 0) return; const id = +b.dataset.qa, on = svcOf(j).includes(id), nm = qaName(id); // (2.55.26) on / off
      const nx = on ? svcOf(j).filter(x => x !== id) : [...svcOf(j), id]; if (j === 0) st.services = nx; else st.ps[j] = nx;
      if (!on) { st.anc = st.anc || []; st.anc[j] = st.anc[j] || {}; const q2 = st.info.quick || {}, M = mainsOf(j); st.anc[j][id] = [...M].reverse().find(m => (q2[m] || []).includes(id)) || M[0]; } /* (2.55.29) */ st.start = null; st.slots = null; st.addHide = false; refresh();
      gSpeak(on ? (ES ? `${nm} quitado.` : `${nm} removed.`) : (ES ? `${nm} agregado.` : `${nm} added.`)); abRem(); }); // (2.55.18) [+ Gel]: added at once
    $('#bAddMore').addEventListener('click', () => { st.addHide = true; G.quiet = false; G.cur = null; chrome(); // (2.55.26 / 2.99.72) back to the service types: "Tap a type of service"
      const m = $('.pp.open .cats') || $('.pp.open') || $('.cats'); try { m && m.scrollIntoView({ block: 'start', behavior: reduced ? 'auto' : 'smooth' }); } catch (e) {}
      setTimeout(() => { if (G.el) guideAfter(st.step, G.el); }, 350); }); // choose more: the bar comes back after the next pick
    $('#bAddNo').addEventListener('click', () => { const j = curK(); if (j < 0) return; st.sDone[j] = true; st.addHide = false; G.quiet = false; G.pre = ES ? '¡Muy bien! ' : 'Great. '; refresh(); // (2.55.26) "Great." then the next thing
      setTimeout(() => { if (G.pre) { const x = G.pre.trim(); G.pre = ''; gSpeak(x); } }, 700);
      setTimeout(() => { const t = $('.pp.open'); try { t && t.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' }); } catch (e) {} }, 40); }); }
  const names = nmGroup(abMains(k)) + abAddTxt(k); // (2.55.25) "Waxing – Brow, Lip"
  const head = (st.people.length > 1 ? pShort(k) + ': ' : '') + (ES ? '¿Agregar otro servicio?' : 'Add another service?'), sig = k + '|' + abMains(k).join(','); // (2.55.26) an add-on does not pop the box again // (2.55.23) a title + "✓ Builder Gel – Fill"
  $('#bAddH').textContent = head; $('.ab-t', bar).innerHTML = '<span class="ok">✓</span> ' + esc(names);
  const A = st.info.addons || [], qa = [...new Set(svcOf(k).filter(id => !A.some(a => a.id === id)).flatMap(id => (st.info.quick || {})[id] || []))].filter(id => A.some(a => a.id === id)); // (2.55.26) picked ones stay: "✓ French"
  const qn = (id) => svcName(id).replace(/^\+\s*/, '').replace(/^(add|agregar)\s+/i, '').replace(/\s*\((hands|feet)\)$/i, '');
  $('#bAddQ').innerHTML = ''; /* (2.99.549 – anh Logan 30/10 19:58) no quick add-on buttons here any more (Collagen Gloves, French…): only + Add more and No, that's all – the voice says no add-on names either (abTour reads #bAddQ) */ 
  $('#bAddMore').innerHTML = '<span class="ab-plus" aria-hidden="true">+</span> ' + (ES ? 'Agregar más' : 'Add more'); /* (2.99.258) the same words, a bigger "+" */  $('#bAddNo').textContent = ES ? 'No, es todo ✓' : "No, that's all ✓";
  { const nv = $('.nav'); if (nv) bar.style.setProperty('--abTop', Math.round(nv.getBoundingClientRect().bottom) + 'px'); } // (2.99.366) the box: from under the Back / Sound bar to the bottom of the screen
  const fresh = bar.hidden || bar.dataset.sig !== sig; bar.dataset.sig = sig; bar.hidden = false;
  if (fresh) { bar.classList.remove('pop'); void bar.offsetWidth; bar.classList.add('pop'); } // slides up + the border flashes twice
  document.body.classList.add('ab-on'); // the list behind is a little faded
  const go = $('#bGo'); if (go.disabled) { go.disabled = false; go.classList.add('soft-dis'); go.setAttribute('aria-disabled', 'true'); } // Next looks off; a tap on it shakes the box
}
function addBarOff() { document.body.classList.remove('ab-on'); const g = $('#bGo'); if (g) { g.classList.remove('soft-dis'); g.toggleAttribute('aria-disabled', g.classList.contains('tech-dis')); } }

/* (2.73) Auto next step: the last thing of a step done → "Next step…" for 1.5 s (a bar fills; "Stay here" keeps the step), then the next step.
   Never after Back until something is changed; never on the last step (Book now), never on the phone-number check. Settings → "Auto next step". */
function autoNext(go, now) {
  clearTimeout(st.autoT); $('#bAuto')?.remove(); st.noAuto = false; // called right after a change: that change counts
  if (RS || st.done || !st.info || st.info.autoNext === false || st.step >= LAST) return;
  const s0 = st.step, act = $('#bAct'); if (!act) return;
  if (now) { st.autoT = setTimeout(() => { if (st.step === s0 && !st.done && !st.noAuto) (go || primary)(); }, 60); return; } // (2.99.369 – anh Logan 22/10 23:07) the time picked: no bar, the next step at once
  act.insertAdjacentHTML('afterbegin', `<div class="auto-bar" id="bAuto" role="status"><span class="ab-t">${G_ES ? 'Siguiente paso…' : 'Next step…'}</span><span class="ab-p"><i></i></span><button type="button" class="ab-stay" id="bStay">${G_ES ? 'Quedarme aquí' : 'Stay here'}</button></div>`);
  const bar = $('#bAuto'); requestAnimationFrame(() => bar.classList.add('run'));
  $('#bStay').addEventListener('click', () => { clearTimeout(st.autoT); bar.remove(); G.unlocked = true; });
  st.autoT = setTimeout(() => { bar.remove(); if (st.step !== s0 || st.done || st.noAuto || !$('.screen:not(.leaving)')) return; (go || primary)(); }, 1500);
}
function autoStop() { clearTimeout(st.autoT); $('#bAuto')?.remove(); }
/** (2.55.18 / 2.99.182) the same day with Any tech for everyone ("‹ Back to …" keeps the old choice); (2.99.183) $m: then pick that time if it is free */
function goAny(m) {
  if (!hasTech()) return;
  st.prevTech = { people: [...st.people], pt: st.pt.map(x => x ? { ...x } : x), tm: [...st.tm] };
  st.people = st.people.map(() => 0); st.pt = st.pt.map(() => null); st.tm = st.tm.map(t => t && 'same'); st.notice = ''; st.nx = null; G.quiet = false;
  Promise.resolve(loadSlots()).then(() => { if (m === null || !st.slots || !st.slots.includes(m) || st.step !== 3) return;
    st.start = m; G.timeTap = st.date + '|' + m; tsHide(() => autoNext(null, true)); refresh(); });
  chrome();
}
/** (2.99.183 – order 376) "Book 3:00 PM with anyone available?" – Yes: Any tech + that time. */
function askAny(m) {
  $$('.ts-ask').forEach(x => x.remove());
  const bg = document.createElement('div'); bg.className = 'modal-bg ts-ask';
  bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-labelledby="taT"><h3 id="taT">${ES ? `¿Reservar a las ${tlabel(m)} con cualquier técnico disponible?` : `Book ${tlabel(m)} with anyone available?`}</h3>
    <div class="ta-row"><button type="button" class="btn ghost ta-no">${ES ? 'No' : 'No'}</button><button type="button" class="btn primary ta-yes">${ES ? 'Sí, reservar' : 'Yes, book it'}</button></div></div>`;
  document.body.appendChild(bg);
  bg.addEventListener('click', (e) => { if (e.target === bg || e.target.closest('.ta-no')) bg.remove(); else if (e.target.closest('.ta-yes')) { bg.remove(); goAny(m); } });
  setTimeout(() => $('.ta-yes', bg)?.focus({ preventScroll: true }), 50);
}
/* (2.99.180 – order 372) the times popup: its own history entry – the phone's / browser's Back closes it (never leaves the page) */
function tsShow() { if (st.tsOpen) return; st.tsOpen = true; st.tsIn = false; document.body.classList.add('ts-on'); if (!(history.state && history.state.ts)) history.pushState({ bstep: st.step, ts: 1 }, ''); }
function tsHide(after) {
  if (!st.tsOpen) { if (after) after(); return; }
  st.tsOpen = false; st.tsIn = false; document.body.classList.remove('ts-on');
  if (history.state && history.state.ts) { st.tsBack = after || true; history.back(); } else if (after) after();
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && st.tsOpen && !st.sheet) { tsHide(); refresh(); } });
/** The popup is drawn with the step (its buttons bound there), then moved to <body> – inside the sliding step it could not cover the header / the Next bar. */
function tsDock(el) {
  $$('body > #tsSheet').forEach(x => x.remove());
  const sh = el && $('#tsSheet', el); if (!sh) return;
  document.body.appendChild(sh);
  if (!st.tsIn) { st.tsIn = true; if (reduced) sh.classList.add('in'); else requestAnimationFrame(() => requestAnimationFrame(() => sh.classList.add('in'))); setTimeout(() => $('.tss-x', sh)?.focus({ preventScroll: true }), 300); }
}
function render(step, dir) {
  if (st.tsOpen) { st.tsOpen = false; st.tsIn = false; document.body.classList.remove('ts-on'); } // another step: the times popup is gone
  tsDock(null);
  autoStop(); if (st.sheet) { st.sheet = null; svSheet(); } // (2.99.72) another step (Next / Back): the service sheet closes
  kpClose(); // (2.55.28)
  st.step = step; st.err = ''; if (step !== 3) { st.tsAutoDone = false; st.dayPk = false; } /* (2.99.493) back on step 3 later: the times open by themselves again */ if (step === 2) st.prevTech = null; if (step === 3) bstat('services'); if (step === 4) bstat('time'); // back to the services: the tech choice is theirs again
  const stage = $('#bStage'), old = $('.screen:not(.leaving)', stage);
  const el = document.createElement('section'); el.className = 'screen';
  el.innerHTML = `<div class="in">${screenHtml(step)}</div>`;
  if (dir && old && !reduced) {
    el.style.transform = `translateX(${dir * 100}%)`; stage.appendChild(el); void el.offsetWidth;
    el.style.transform = ''; old.classList.add('leaving'); old.style.transform = `translateX(${-dir * 100}%)`;
    setTimeout(() => old.remove(), 300);
  } else { stage.innerHTML = ''; stage.appendChild(el); }
  bind(step, el); chrome();
  if (step === 3 && st.slots === null) prepareDay(); else if (step === 3) setTimeout(tsAuto, 0); // (2.99.493) the times known already: open them at once
}
function refresh() { const el = $('.screen:not(.leaving)', $('#bStage')); if (!el) return; G.quiet = false; /* (2.55.26) something changed: the guide always follows */ const ty = $('#tssL')?.scrollTop || 0; $('.in', el).innerHTML = screenHtml(st.step); bind(st.step, el); if (st.step !== 3) tsDock(null); chrome(); if (ty && $('#tssL')) $('#tssL').scrollTop = ty; }

/* Forward: while editing from the confirm screen, skip steps that are still complete. History always holds one entry per step. */
function next() {
  let n = st.step + 1;
  if (st.editing) { while (n < LAST && valid(n)) n++; if (n === LAST) st.editing = false; }
  for (let s = st.step + 1; s <= n; s++) history.pushState({ bstep: s }, '');
  render(n, 1);
}
window.addEventListener('popstate', (e) => {
  if (st.tsBack) { const f = st.tsBack; st.tsBack = null; if (typeof f === 'function') f(); return; } // (2.99.180) the times popup closed by a tap: its history entry is gone
  if (st.tsOpen) { st.tsOpen = false; st.tsIn = false; document.body.classList.remove('ts-on'); refresh(); return; } // (2.99.180) Back with the times popup open: it closes, the page stays
  $$('.modal-bg').forEach(m => m.remove()); if (typeof G !== 'undefined' && G.hold) { G.hold = null; G.cur = null; } // (2.99.92) the box went with Back: the guide goes on
  if (RS) { if (st.done || !e.state) location.replace('manage.php?t=' + encodeURIComponent(RS)); return; }
  if (st.done) { location.replace('./'); return; }
  const s = e.state && e.state.bstep;
  if (s && s < st.step) st.noAuto = true; // (2.73) back: nothing goes on by itself until something is changed
  if (!s || s === st.step) return;
  render(s, s < st.step ? -1 : 1);
});
