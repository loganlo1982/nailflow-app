# LAMWEB test 633 – install Love Nails on a FAKE copy of the server layout (home/app/sites.php, releases/<v>, sites/an, public_html, public_html/lovenails).
#   python3 t633.py <app folder>     nothing real; AN = SQLite of its own here
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, hashlib, stat
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T633'; INS = D + '/install633.php'; PORT = 19959
R = []; out = open(D + '/test-633.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:600]))
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a, env=None): return subprocess.run(a, capture_output=True, text=True, env=env or ENV)
V = (sh('php', '-r', "preg_match(\"/define\\\\('APP_VERSION', '([^']+)'\\\\)/\", file_get_contents('%s/inc/core.php'), $m); echo $m[1];" % A0).stdout.strip())
H = D + '/home'; shutil.rmtree(H, ignore_errors=True); APP = H + '/app'; PUB = H + '/public_html'; LN = PUB + '/lovenails'
os.makedirs(APP + '/releases'); os.makedirs(APP + '/sites/an/data', mode=0o700); os.makedirs(LN + '/cgi-bin'); os.makedirs(PUB + '/uploads')
REL = APP + '/releases/' + V; shutil.copytree(A0, REL, symlinks=True, ignore=shutil.ignore_patterns('config.php', 'uploads', 'sessions'))
os.symlink('../../releases/' + V, APP + '/sites/an/current')
ANDB = APP + '/sites/an/data/an.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', ANDB)
open(APP + '/sites/an/config.php', 'w').write("<?php\nreturn ['driver' => 'sqlite', 'sqlite_path' => '%s', 'site_url' => 'https://american-nails-and-spa.com'];\n" % ANDB)
SITES = """<?php
// which salon each web address is (LAMWEB test copy of the server's file)
return [
    'an' => ['hosts' => ['american-nails-and-spa.com', 'www.american-nails-and-spa.com'], 'web' => '%s', 'cron' => ['turn', 'reminders', 'uptime', 'backup'], 'main' => true],
];
""" % PUB
open(APP + '/sites.php', 'w').write(SITES)
for e in os.listdir(REL):   # AN's web folder = links to sites/an/current/<name> (as rel_web_links makes them)
    if e in ('.htaccess',): shutil.copy(REL + '/' + e, PUB + '/' + e); continue
    if not os.path.exists(PUB + '/' + e): os.symlink(APP + '/sites/an/current/' + e, PUB + '/' + e)
sh('php', '-r', "$p = new PDO('sqlite:%s'); $p->exec(\"UPDATE settings SET v = 'AMERICAN NAILS AND SPA' WHERE k = 'salon_name'\");" % ANDB)
md5 = lambda p: hashlib.md5(open(p, 'rb').read()).hexdigest()
an0 = md5(ANDB); anc0 = md5(APP + '/sites/an/config.php'); sites0 = open(APP + '/sites.php').read(); publinks0 = sorted(os.listdir(PUB))
say('== LAMWEB test 633 – install Love Nails (fake server layout, release %s) %s' % (V, time.strftime('%Y-%m-%d %H:%M %Z')))
r = sh('php', INS, APP, '--web', LN); ok('1 check only: OK to install, nothing changed', r.returncode == 0 and 'OK to install' in r.stdout and open(APP + '/sites.php').read() == sites0 and not os.path.exists(APP + '/sites/lovenails'), r.stdout + r.stderr)
open(LN + '/index.html', 'w').write('x'); r = sh('php', INS, APP, '--web', LN, 'go')
ok('1 the web folder has a file -> STOP, nothing changed, nothing deleted', r.returncode == 3 and 'not empty' in r.stdout and os.path.exists(LN + '/index.html') and open(APP + '/sites.php').read() == sites0, r.stdout)
os.remove(LN + '/index.html')
r = sh('php', INS, APP, '--web', LN, '--mysql', 'go'); ok('1 --mysql without the env -> STOP (never asks for / prints a password)', r.returncode == 3 and 'NF_LN_DB_PASS' in r.stdout, r.stdout)
r = sh('php', INS, APP, '--web', LN, 'go'); say('   ' + r.stdout.replace('\n', '\n   ')[:1500])
m = json.loads(sh('php', '-r', "echo json_encode(require '%s/sites.php');" % APP).stdout or '{}')
ok('2 go: sites.php = the old list + lovenails (host, web, cron [] = no job), AN entry the same', r.returncode == 0 and m.get('lovenails') == {'hosts': ['lovenails.nailflowapp.com'], 'web': LN, 'cron': [], 'main': False} and m.get('an', {}).get('cron') == ['turn', 'reminders', 'uptime', 'backup'], (r.returncode, m))
cf = APP + '/sites/lovenails/config.php'
ok('2 own config 0600 outside the web, own SQLite under sites/lovenails/data, own sessions', os.path.exists(cf) and stat.S_IMODE(os.stat(cf).st_mode) == 0o600 and os.path.exists(APP + '/sites/lovenails/data/lovenails.sqlite') and os.path.isdir(APP + '/sites/lovenails/sessions') and 'lovenails.sqlite' in open(cf).read(), sh('ls', '-la', APP + '/sites/lovenails').stdout)
ok('2 current -> ../../releases/%s (the same release as AN)' % V, os.readlink(APP + '/sites/lovenails/current') == '../../releases/' + V, os.readlink(APP + '/sites/lovenails/current') if os.path.islink(APP + '/sites/lovenails/current') else None)
lk = [e for e in os.listdir(LN) if os.path.islink(LN + '/' + e)]
ok('2 web folder: links to sites/lovenails/current/<name> (api.php, admin, setup, inc...), .htaccess copied, cgi-bin kept', 'api.php' in lk and 'admin' in lk and 'setup' in lk and os.readlink(LN + '/api.php') == APP + '/sites/lovenails/current/api.php' and os.path.isdir(LN + '/cgi-bin'), sorted(lk)[:12])
ok('2 American Nails NOT touched: its database, config, sites line, web folder the same', md5(ANDB) == an0 and md5(APP + '/sites/an/config.php') == anc0 and sorted(os.listdir(PUB)) == sorted(publinks0) and m.get('an', {}).get('hosts') == ['american-nails-and-spa.com', 'www.american-nails-and-spa.com'], (md5(ANDB) == an0,))
q = lambda db, s: json.loads(sh('php', '-r', "$p = new PDO('sqlite:%s'); echo json_encode($p->query(\"%s\")->fetchAll(PDO::FETCH_ASSOC));" % (db, s)).stdout or '[]')
LDB = APP + '/sites/lovenails/data/lovenails.sqlite'; st = {x['k']: x['v'] for x in q(LDB, "SELECT k, v FROM settings WHERE k IN ('salon_name','sms_enabled','as_on','as_device','bday_on','review_on','admin_hash')")}
ok('3 Love Nails database: name "Love Nails", NO tech / customer / appointment / service, no owner password (setup page)', st.get('salon_name') == 'Love Nails' and q(LDB, 'SELECT COUNT(*) AS n FROM staff')[0]['n'] == 0 and q(LDB, 'SELECT COUNT(*) AS n FROM customers')[0]['n'] == 0 and q(LDB, 'SELECT COUNT(*) AS n FROM appointments')[0]['n'] == 0 and not st.get('admin_hash'), st)
ok('3 nothing is sent: sms off, auto send off, Android off, birthday / review off', st.get('sms_enabled') == '0' and st.get('as_on') == '0' and st.get('as_device') == '' and st.get('bday_on') == '0' and st.get('review_on') == '0', st)
cr = sh('php', '-r', '$m = require $argv[1]; foreach ($m as $i => $s) if (in_array($argv[2], (array)($s["cron"] ?? []), true)) echo $i, " ";', APP + '/sites.php', 'turn').stdout + '|' + sh('php', '-r', '$m = require $argv[1]; foreach ($m as $i => $s) if (in_array($argv[2], (array)($s["cron"] ?? []), true)) echo $i, " ";', APP + '/sites.php', 'reminders').stdout
ok('3 cron/all.sh (turn, reminders): only AN, never Love Nails', cr.strip() == 'an |an', cr)
# 4 the web: php -S on each web folder, the Host header says which salon
svL = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', LN, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/phpL.log', 'w'))
svA = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % (PORT - 60), '-t', PUB, '/tmp/claude-0/router.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=open(D + '/phpA.log', 'w'))
atexit.register(lambda: (svL.terminate(), svA.terminate())); time.sleep(1.3)
def get(port, path, host):
    rq = urllib.request.Request('http://127.0.0.1:%d%s' % (port, path), headers={'Host': host})
    try: r = urllib.request.urlopen(rq, timeout=30); return r.status, r.read().decode(errors='replace')
    except urllib.error.HTTPError as e: return e.code, e.read().decode(errors='replace')
c1, b1 = get(PORT, '/', 'lovenails.nailflowapp.com'); c2, b2 = get(PORT, '/admin/setup.php', 'lovenails.nailflowapp.com'); c3, b3 = get(PORT, '/api.php?action=info', 'lovenails.nailflowapp.com')
ok('4 lovenails.nailflowapp.com: home 200 · admin/setup.php 200 (create the owner password) · booking api info 200 "Love Nails"', c1 == 200 and c2 == 200 and 'Create' in b2 and c3 == 200 and json.loads(b3).get('salon') == 'Love Nails', (c1, c2, c3, b3[:200]))
c4, b4 = get(PORT, '/api.php?action=info', 'evil.example'); ok('4 an unknown address on that folder -> 404 (nothing about any salon)', c4 == 404 and 'Love' not in b4, (c4, b4[:100]))
c5, b5 = get(PORT - 60, '/api.php?action=info', 'american-nails-and-spa.com'); ok('4 AN still answers as AN (its own database)', c5 == 200 and 'AMERICAN' in json.loads(b5).get('salon', ''), (c5, b5[:200]))
c6, b6 = get(PORT, '/setup/?t=' + 'f' * 64, 'lovenails.nailflowapp.com'); ok('4 the 632 setup link page is there on Love Nails (/setup/ 200)', c6 == 200 and 'setup_info' in b6, c6)
an1 = md5(ANDB); r = sh('php', INS, APP, '--web', LN, 'go'); ok('5 run again -> STOP (already installed), nothing changed', r.returncode == 3 and "already has 'lovenails'" in r.stdout and md5(ANDB) == an1, r.stdout)
logs = open(D + '/phpL.log').read() + open(D + '/phpA.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
