# ===== LENH-618 BO SUNG: AI CALL SIMULATOR (LAMWEB) =====
# Calls the REAL endpoints of call_tx.php (no function mocked) with Telnyx-shaped payloads (TeXML form posts + AI webhook JSON), signed with a TEST
# Ed25519 key, one Call ID per call, a multi-turn conversation = the chain of tool calls a real model makes, the transcript served by the fake Telnyx API.
# Every check reads the DB (appointments / calls / customers / autosend / push_log) itself - never the app's "OK".
import threading, glob, hashlib, statistics, resource
RES = []   # (no, title, verdict, layer, evidence)
def V(no, title, verdict, layer, ev=''):
    mk_ = {'PASS': '✓', 'FAIL': '✗'}.get(verdict, '•'); RES.append((no, title, verdict, layer, str(ev)[:300]))
    say('%s %s [%s] %s%s%s' % (mk_, no, layer, verdict + ' · ' if mk_ == '•' else '', title, ('   → ' + str(ev)[:260]) if verdict != 'PASS' else ''))
    if verdict in ('PASS', 'FAIL'): R.append(verdict == 'PASS')
def xs(s): return urllib.parse.quote(s, safe='')
os.makedirs(D + '/conv', exist_ok=True)
def conv(sid, turns):  # the transcript Telnyx keeps for this call (user / assistant turns, 4 s apart)
    k = hashlib.sha1(sid.encode()).hexdigest()[:16]; t0 = time.time() - 10 * len(turns)
    json.dump([{'role': r, 'text': t, 'sent_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(t0 + 4 * i))} for i, (r, t) in enumerate(turns)], open(D + '/conv/' + k + '.json', 'w'))
def start(sid, frm, ring='no-answer'):
    c1, x1 = req('in', {'CallSid': sid, 'From': frm, 'To': '+15155136667', 'AccountSid': 'ACC1', 'ConnectionId': 'APP-1'}, form=True)
    c2, x2 = req('after', {'CallSid': sid, 'DialCallStatus': ring, 'AccountSid': 'ACC1'}, form=True, extra='&sid=' + xs(sid)); return x1, x2
def tvars(sid, frm):
    c, x = req('vars', {'data': {'event_type': 'assistant.initialization', 'payload': {'call_control_id': sid, 'telnyx_end_user_target': frm, 'telnyx_agent_target': '+15155136667'}}})
    try: return json.loads(x).get('dynamic_variables', {})
    except Exception: return {}
def tool(sid, fn, **a):
    c, x = req('tool', a, extra='&fn=' + fn + '&ccid=' + xs(sid))
    try: return json.loads(x).get('result', '')
    except Exception: return 'HTTP %s %s' % (c, x[:80])
def end(sid, reason='hangup'): return req('aiend', {'CallSid': sid, 'Reason': reason}, form=True, extra='&sid=' + xs(sid))[1]
def appts(ph, st='booked'): return sql("SELECT id, appt_date, start_min, duration, staff_id, service_ids, customer_name, status, source, group_id FROM appointments WHERE phone = '%s' AND status = '%s' ORDER BY id" % (ph, st))
def crow(sid): return row(sid)
def outbox(ph): return sql("SELECT kind, body FROM autosend WHERE phone = '%s' ORDER BY id" % ph) if sql("SELECT name FROM sqlite_master WHERE name='autosend'") else []
open(D + '/set618.php', 'w').write("<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/android.php'; foreach (['as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms', 'ws_key' => ad_enc('WS_test_key_123456789'), 'call_tb_on' => '1', 'tx_on' => '1'] as $k => $v) set_setting($k, $v); echo 'ok';" % (A, A))
sh('php', D + '/set618.php')
open(D + '/tick618.php', 'w').write("<?php require '%s/inc/core.php'; settings(); define('NF_API_LIB',1); foreach (['/inc/outbox.php','/inc/api/_auth.php','/inc/api/_menu.php','/inc/api/_texts.php','/inc/api/_kiosk.php','/inc/api/_out.php'] as $f) require_once '%s' . $f; require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor']=['admin','Owner']; cl_tick(); echo 'ticked';" % (A, A, A, A))
def tick(): return sh('php', D + '/tick618.php')
h('set', json.dumps({'call_owner': '5155550177', 'call_fwd': '+15155550176'})); h('setup', 'ai')
TA, HA, SI = seed['T']['TAMMY'], seed['T']['HANA'], seed['T']['SISI']; GM, PD, FS = S['Gel Manicure'], S['Pedicure'], S['Full Set']
DAY = lambda n: (_dt.date.today() + _dt.timedelta(days=n)).isoformat()
say('== LENH-618 AI CALL SIMULATOR – 20 tinh huong (INTEGRATION = endpoint call_tx.php that + fake Telnyx; khong goi / SMS that) ' + time.strftime('%H:%M %Z'))
P = lambda n: '+1515555%04d' % n   # (515) 555-01xx / 02xx test numbers
# 1 new customer
s, ph = 'v3:S01', P(201); x1, x2 = start(s, ph); v = tvars(s, ph)
r1 = tool(s, 'find_appointments'); r2 = tool(s, 'check_times', date=DAY(2), time='10:00', persons=[{'name': 'Nora', 'service_ids': [PD], 'tech_id': 0}])
r3 = tool(s, 'book', name='Nora Test', date=DAY(2), time='10:00', persons=[{'name': 'Nora Test', 'service_ids': [PD], 'tech_id': 0}])
conv(s, [('assistant', 'Thank you for calling. How can I help?'), ('user', 'I want a pedicure the day after tomorrow at 10'), ('assistant', "You're all set!")]); end(s); time.sleep(0.3)
a = appts(ph); cu = sql("SELECT name FROM customers WHERE phone = '%s'" % ph); cr = crow(s)
V('01', 'Khach moi dat lich', 'PASS' if v.get('caller_name') == 'none' and r3.startswith('BOOKED') and len(a) == 1 and a[0]['start_min'] == 600 and a[0]['source'] == 'call' and str(PD) == a[0]['service_ids'] and cu and cr.get('status') == 'booked' and int(cr.get('appt_id') or 0) == a[0]['id'] else 'FAIL', 'INTEGRATION', (v.get('caller_name'), r3[:60], a, cu, cr.get('status')))
# 2 returning customer
s = 'v3:S02'; start(s, ph); v = tvars(s, ph); up = v.get('upcoming', '')
r = tool(s, 'book', name='Nora Test', date=DAY(9), time='11:00', persons=[{'name': 'Nora Test', 'service_ids': [GM], 'tech_id': 0}]); a = appts(ph)
V('02', 'Khach cu goi dat lai', 'PASS' if 'NORA' in v.get('caller_name', '').upper() and up and r.startswith('BOOKED') and len(a) == 2 else 'FAIL', 'INTEGRATION', (v.get('caller_name'), up[:60], r[:60], len(a)))
# 3 specific tech  # 4 any tech
s, ph = 'v3:S03', P(203); start(s, ph); r = tool(s, 'book', name='Tia', date=DAY(2), time='13:00', persons=[{'name': 'Tia', 'service_ids': [GM], 'tech_id': HA}]); a = appts(ph)
V('03', 'Khach chon tho cu the', 'PASS' if r.startswith('BOOKED') and len(a) == 1 and a[0]['staff_id'] == HA else 'FAIL', 'INTEGRATION', (r[:60], a))
s, ph = 'v3:S04', P(204); start(s, ph); r = tool(s, 'book', name='Uma', date=DAY(2), time='13:00', persons=[{'name': 'Uma', 'service_ids': [GM], 'tech_id': 0}]); a = appts(ph)
V('04', 'Khach chon Any Tech', 'PASS' if r.startswith('BOOKED') and len(a) == 1 and a[0]['staff_id'] in (0, TA, SI) else 'FAIL', 'INTEGRATION', (r[:60], a))
# 5 several services
s, ph = 'v3:S05', P(205); start(s, ph); r = tool(s, 'book', name='Vy', date=DAY(3), time='10:00', persons=[{'name': 'Vy', 'service_ids': [PD, GM], 'tech_id': 0}]); a = appts(ph)
V('05', 'Nhieu dich vu (Pedicure + Gel Manicure)', 'PASS' if r.startswith('BOOKED') and len(a) == 1 and set(a[0]['service_ids'].split(',')) == {str(PD), str(GM)} and int(a[0]['duration']) >= 75 else 'FAIL', 'INTEGRATION', (r[:60], a))
# 6 several people
s, ph = 'v3:S06', P(206); start(s, ph); r = tool(s, 'book', name='Wen', date=DAY(3), time='14:00', persons=[{'name': 'Wen', 'service_ids': [PD], 'tech_id': 0}, {'name': 'Xia', 'service_ids': [GM], 'tech_id': 0}]); a = appts(ph)
V('06', 'Dat cho 2 nguoi', 'PASS' if r.startswith('BOOKED') and len(a) == 2 and len({x['group_id'] for x in a}) == 1 and a[0]['group_id'] else 'FAIL', 'INTEGRATION', (r[:60], a))
# 7 price / duration
v = tvars('v3:S06', ph); pr = tx_prompt = open(D + '/last-_v__ai_assistants_assistant_test__.json').read() if os.path.exists(D + '/last-_v__ai_assistants_assistant_test__.json') else ''
mn = v.get('menu', ''); hasdur = bool(re.search(r'\d+\s*min', mn)); hasprice = '$' in mn or bool(re.search(r'\b(35|40|50)\b', mn))
V('07', 'Hoi gia + thoi luong', 'PASS' if hasdur else 'FAIL', 'MOCK', 'menu: %s · co gia trong menu AI: %s' % (mn[:120], hasprice))
if not hasprice: V('07b', 'Hoi GIA: AI khong co gia -> theo thiet ke chuyen chu / goi lai', 'BY DESIGN', 'MOCK', 'menu khong co gia')
# 8 opening hours
dy = v.get('days', ''); V('08', 'Hoi gio mo cua (AI co lich mo cua 7 ngay)', 'PASS' if dy.count('\n') >= 5 and re.search(r'\d', dy) else 'FAIL', 'MOCK', dy[:160])
# 9 change mind mid-call
s, ph = 'v3:S09', P(209); start(s, ph); tool(s, 'check_times', date=DAY(4), time='10:00', persons=[{'name': 'Yen', 'service_ids': [PD], 'tech_id': 0}])
r = tool(s, 'book', name='Yen', date=DAY(4), time='15:00', persons=[{'name': 'Yen', 'service_ids': [PD], 'tech_id': 0}]); a = appts(ph)
V('09', 'Doi gio giua chung (hoi 10:00 -> dat 15:00)', 'PASS' if len(a) == 1 and a[0]['start_min'] == 900 else 'FAIL', 'INTEGRATION', (r[:60], a))
# 10 cancel / move an existing appointment
s = 'v3:S10'; start(s, ph); f = tool(s, 'find_appointments'); aid = a[0]['id']
rm = tool(s, 'move', appt_id=aid, said_date=DAY(4), said_time='15:00', date=DAY(5), time='16:00'); am = appts(ph)
s = 'v3:S10b'; start(s, ph); tool(s, 'find_appointments'); rc = tool(s, 'cancel', appt_id=am[0]['id'] if am else aid, said_date=DAY(5), said_time='16:00'); ac = appts(ph); cx = appts(ph, 'cancelled')
V('10', 'Doi lich roi huy lich da co', 'PASS' if rm.startswith('MOVED') and am and am[0]['start_min'] == 960 and am[0]['appt_date'] == DAY(5) and rc.startswith('CANCELLED') and not ac and cx else 'FAIL', 'INTEGRATION', (rm[:60], am, rc[:60], ac))
# 11 English / 12 Vietnamese
asb = json.load(open(sorted(glob.glob(D + '/last-_v__ai_assistants*.json'), key=os.path.getmtime)[-1]))
lang = json.dumps(asb.get('transcription', {})); V('11', 'Khach noi tieng Anh (STT deepgram en, prompt EN)', 'PASS' if '"en' in lang or 'en' in lang else 'FAIL', 'MOCK', lang[:120])
V('12', 'Khach noi tieng Viet', 'NOT IMPLEMENTED', 'MOCK', 'anh Logan chon AI CHI tieng Anh (CHAT 22:22); STT = en')
# 13 unclear / missing info -> no booking
s, ph = 'v3:S13', P(213); start(s, ph); r1 = tool(s, 'book', name='Zoe', date=DAY(4), time='11:00', persons=[{'name': 'Zoe', 'service_ids': [], 'tech_id': 0}])
r2 = tool(s, 'book', name='', date=DAY(4), time='11:00', persons=[{'name': '', 'service_ids': [PD], 'tech_id': 0}]); r3 = tool(s, 'book', name='Zoe', date='', time='', persons=[{'name': 'Zoe', 'service_ids': [PD], 'tech_id': 0}])
n13 = len(appts(ph)); r4 = tool(s, 'book', name='Zoe', date=DAY(4), time='11:00', persons=[{'name': 'Zoe', 'service_ids': [PD], 'tech_id': 0}])
V('13', 'Noi khong ro / thieu thong tin -> KHONG dat; noi ro -> dat', 'PASS' if n13 == 0 and all(x.startswith('NOT_BOOKED') for x in (r1, r2, r3)) and r4.startswith('BOOKED') and len(appts(ph)) == 1 else 'FAIL', 'INTEGRATION', (r1[:50], r2[:50], r3[:50], n13, r4[:40]))
# 14 silent caller
s, ph = 'v3:S14', P(214); start(s, ph); conv(s, [('assistant', 'Thank you for calling. How can I help?')]); end(s); time.sleep(0.3); tick(); cr = crow(s)
V('14', 'Khach khong noi gi -> missed + 1 tin missed call (outbox)', 'PASS' if cr.get('status') == 'missed' and len([o for o in outbox(ph) if o['kind'] == 'missed']) == 1 else 'FAIL', 'INTEGRATION', (cr.get('status'), cr.get('tb_state'), outbox(ph)))
# 15 asks for a person
s, ph = 'v3:S15', P(215); start(s, ph); n0 = open(D + '/fake_tx.log').read().count('Calls/' + xs(s)); r = tool(s, 'transfer_owner', reason='question'); n1 = open(D + '/fake_tx.log').read().count('Calls/' + xs(s))
c, xe = req('xfer', {'CallSid': s, 'DialCallStatus': 'no-answer'}, form=True, extra='&sid=' + xs(s)); cr = crow(s)
V('15', 'Xin gap nhan vien -> chuyen chu (khac iPhone); chu khong bat -> callback', 'PASS' if r.startswith('CONNECTING') and n1 == n0 + 1 and 'call you back' in xe and cr.get('status') == 'callback' else 'FAIL', 'INTEGRATION', (r[:50], n1 - n0, xe[-90:], cr.get('status')))
h('set', json.dumps({'call_owner': '+15155550176'})); s, ph = 'v3:S15c', P(218); start(s, ph); n0 = open(D + '/fake_tx.log').read().count('Calls/' + xs(s)); r = tool(s, 'transfer_owner'); n1 = open(D + '/fake_tx.log').read().count('Calls/' + xs(s)); cr = crow(s); h('set', json.dumps({'call_owner': '5155550177'}))
V('15c', '"Owner phone" = chinh iPhone vua do chuong -> KHONG chuyen ve iPhone; AI hen goi lai (callback)', 'PASS' if r.startswith('NO_ONE') and n1 == n0 and cr.get('status') == 'callback' else 'FAIL', 'INTEGRATION', (r[:50], n1 - n0, cr.get('status')))
s, ph = 'v3:S14b', P(219); req('in', {'CallSid': s, 'From': ph, 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True); req('status', {'CallSid': s, 'CallStatus': 'completed'}, form=True); tick(); cr = crow(s)
V('14b', 'Khach cup khi iPhone dang do chuong (chua toi AI) -> missed + 1 tin missed call', 'PASS' if cr.get('status') == 'missed' and len([o for o in outbox(ph) if o['kind'] == 'missed']) == 1 else 'FAIL', 'INTEGRATION', (cr.get('status'), cr.get('tb_state'), outbox(ph)))
V('15b', 'Chuyen may that (do chuong so chu, giong noi)', 'BLOCKED', 'REAL CALL', 'can cuoc goi that (anh Logan goi tay, CHAT xem log xfer)')
# 16 after hours
CLOSED = json.dumps({str(w): {'open': '09:00', 'close': '09:01'} for w in range(7)}); h('set', json.dumps({'hours': CLOSED}))
s, ph = 'v3:S16', P(216); x1, x2 = start(s, ph); r = tool(s, 'book', name='Ada', date=DAY(2), time='15:00', persons=[{'name': 'Ada', 'service_ids': [PD], 'tech_id': 0}])
h('set', json.dumps({'hours': json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)})}))
V('16', 'Goi ngoai gio: AI KHONG dat ngoai gio', 'PASS' if not appts(ph) and not r.startswith('BOOKED') else 'FAIL', 'INTEGRATION', r[:80])
V('16b', 'Goi ngoai gio: van do chuong iPhone truoc (anh Logan: "always ring the iPhone first", calls.php:203 CHAT 01/11)', 'BY DESIGN' if '<Dial' in x1 else 'PASS', 'INTEGRATION', 'Telnyx + SignalWire deu do iPhone truoc' if '<Dial' in x1 else '')
# 17 hangs up mid-call
s, ph = 'v3:S17', P(217); start(s, ph); tool(s, 'check_times', date=DAY(2), time='16:00', persons=[{'name': 'Bea', 'service_ids': [PD], 'tech_id': 0}])
conv(s, [('assistant', 'How can I help?'), ('user', 'pedicure Thursday at 4'), ('assistant', 'That time is open. What name?')]); end(s, 'hangup'); time.sleep(0.3); cr = crow(s)
pu = sql("SELECT title FROM push_log WHERE body LIKE '%%%s%%' OR body LIKE '%%%s%%'" % (ph[-4:], '555-0217')) if sql("SELECT name FROM sqlite_master WHERE name='push_log'") else []
V('17', 'Cup giua chung -> khong dat; cuoc "Needs review" + push cho chu', 'PASS' if not appts(ph) and cr.get('status') == 'review' and 'pedicure' in (cr.get('text_c') or '') else 'FAIL', 'INTEGRATION', (cr.get('status'), (cr.get('text_c') or '')[:40], pu[:2]))
# 18 two callers, same tech, same time
bad = 0
for k in range(5):
    sa, sb, pa, pb = 'v3:S18a%d' % k, 'v3:S18b%d' % k, P(230 + k), P(240 + k); start(sa, pa); start(sb, pb); ev = threading.Event(); o18 = [None, None]
    def g(i, s_, nm): ev.wait(); o18[i] = tool(s_, 'book', name=nm, date=DAY(6), time='%02d:00' % (9 + k), persons=[{'name': nm, 'service_ids': [GM], 'tech_id': SI}])
    th = [threading.Thread(target=g, args=(0, sa, 'Ca%d' % k)), threading.Thread(target=g, args=(1, sb, 'Cb%d' % k))]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
    n = sql("SELECT COUNT(*) AS n FROM appointments WHERE appt_date = '%s' AND start_min = %d AND staff_id = %d AND status = 'booked'" % (DAY(6), (9 + k) * 60, SI))[0]['n']
    bad += int(n) != 1
V('18', '2 khach cung tho cung gio cung luc (5 vong) -> 1 hen / gio', 'PASS' if bad == 0 else 'FAIL', 'INTEGRATION', 'vong sai: %d' % bad)
# 20 multi-salon (2 salons on the test machine)
B2 = A.rstrip('/') + '-salonB'; shutil.rmtree(B2, ignore_errors=True); shutil.copytree(A, B2, symlinks=True); DBB = D + '/dbB.sqlite'; shutil.copy('/tmp/claude-0/tdb/base.sqlite', DBB); PB = PORT + 40
seedB = json.loads(sh('php', T5 + '/seed.php', B2, DBB, str(PB)).stdout)
HB = D + '/hB.php'; open(HB, 'w').write(open(H).read().replace(A + '/', B2 + '/'))
def hb(*a):
    r_ = sh('php', HB, *[str(x) for x in a])
    try: return json.loads(r_.stdout)
    except Exception: return r_.stdout
hb('set', json.dumps({'hours': json.dumps({str(w): {'open': '00:00', 'close': '23:59'} for w in range(7)}), 'call_owner': '5155550188', 'call_fwd': '+15155550186', 'salon_name': 'SALON B TEST', 'call_on': '1', 'tx_on': '1'}))
hb('save', json.dumps({'key': 'KEY0123456789abcdefTEST_tx_key_99', 'number': '(515) 555-0190', 'on': True})); TOKB = hb('tok')
svB = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PB, '-t', B2, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '2'}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); atexit.register(svB.terminate); time.sleep(1.0)
def reqB(a, body, tok, extra='', form=False):
    raw = urllib.parse.urlencode(body).encode() if form else json.dumps(body).encode()
    try: r_ = urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/call_tx.php?a=%s&t=%s%s' % (PB, a, tok, extra), data=raw, headers={'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json'}), timeout=30); return r_.status, r_.read().decode()
    except urllib.error.HTTPError as e: return e.code, ''
cA, _ = reqB('in', {'CallSid': 'v3:B1', 'From': P(201), 'To': '+15155550190'}, TOK, form=True)
cB, xB = reqB('in', {'CallSid': 'v3:B1', 'From': P(201), 'To': '+15155550190'}, TOKB, form=True); reqB('after', {'CallSid': 'v3:B1', 'DialCallStatus': 'no-answer'}, TOKB, '&sid=' + xs('v3:B1'), form=True)
_, fB = reqB('tool', {}, TOKB, '&fn=find_appointments&ccid=' + xs('v3:B1')); fB = json.loads(fB or '{}').get('result', '')
_, bB = reqB('tool', {'name': 'Nora B', 'date': DAY(2), 'time': '10:00', 'persons': [{'name': 'Nora B', 'service_ids': [seedB['S']['Pedicure']], 'tech_id': 0}]}, TOKB, '&fn=book&ccid=' + xs('v3:B1')); bB = json.loads(bB or '{}').get('result', '')
inA = sql("SELECT COUNT(*) AS n FROM appointments WHERE customer_name LIKE 'NORA B%'")[0]['n']; inB = json.loads(sh('php', T5 + '/db.php', DBB, "SELECT COUNT(*) AS n FROM appointments WHERE phone = '%s' AND status = 'booked'" % P(201)).stdout or '[{"n":-1}]')[0]['n']
V('20', '2 salon: token tiem A vao tiem B -> 403; khach co 2 hen o A goi B -> B khong thay hen A; dat o B chi nam o DB B', 'PASS' if cA == 403 and cB == 200 and 'NORA' not in fB.upper() and bB.startswith('BOOKED') and int(inA) == 0 and int(inB) == 1 else 'FAIL', 'INTEGRATION', (cA, cB, fB[:70], bB[:40], inA, inB))
V('20b', 'Nhieu salon tren Telnyx that', 'BLOCKED', 'REAL CALL', 'hien chi AN dung Telnyx (1 so 513-6667)')
