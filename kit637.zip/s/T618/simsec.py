# ----- GIAI DOAN 4: bao mat / du lieu -----
say('== BAO MAT / DU LIEU')
c, _ = req('in', {'CallSid': 'v3:Z1', 'From': P(250), 'To': '+15155136667'}, form=True, tok='')
V('S1', 'Khong co secret (t) -> 403', 'PASS' if c == 403 else 'FAIL', 'INTEGRATION', c)
c, _ = req('status', {'CallSid': 'v3:Z2'}, form=True, hdr={'telnyx-timestamp': str(int(time.time())), 'telnyx-signature-ed25519': 'A' * 88})
V('S2', 'Chu ky Ed25519 sai -> 403', 'PASS' if c == 403 else 'FAIL', 'INTEGRATION', c)
raw = json.dumps({'name': 'Evil', 'date': DAY(2), 'time': '10:00', 'persons': []}).encode(); ts = str(int(time.time()) - 400); open(D + '/.bz', 'wb').write(raw); sg = h('sign', SIGN, ts, D + '/.bz')
c, _ = req('tool', json.loads(raw), extra='&fn=book&ccid=v3%3AS01', hdr={'telnyx-timestamp': ts, 'telnyx-signature-ed25519': sg})
V('S3', 'Replay: chu ky dung nhung cu > 5 phut -> 403', 'PASS' if c == 403 else 'FAIL', 'INTEGRATION', c)
c, _ = req('tool', {'name': 'X'}, extra='&fn=find_appointments&ccid=v3%3AS01', sign=False)
V('S4', 'Tool (JSON) KHONG chu ky khi da co Public Key -> ?', 'PASS' if c == 403 else 'FAIL', 'INTEGRATION', 'http %s (chi can secret t; tx_sig_strict=0 cho phep request khong ky - de TeXML cua Telnyx khong ky)' % c)
s, ph = 'v3:Z5', P(255); start(s, ph); start(s, ph)
V('S5', 'Webhook ?a=in gui lai (cung CallSid) -> 1 dong calls', 'PASS' if sql("SELECT COUNT(*) AS n FROM calls WHERE call_sid = '%s'" % s)[0]['n'] == 1 else 'FAIL', 'INTEGRATION', sql("SELECT COUNT(*) AS n FROM calls WHERE call_sid = '%s'" % s))
bk = dict(name='Gus', date=DAY(7), time='10:00', persons=[{'name': 'Gus', 'service_ids': [PD], 'tech_id': 0}], new_ok=True)
r1 = tool(s, 'book', **bk); r2 = tool(s, 'book', **bk)
V('S6', 'Tool book gui lai 2 lan (retry / duplicate, ca new_ok) -> 1 hen', 'PASS' if len(appts(ph)) == 1 else 'FAIL', 'INTEGRATION', (len(appts(ph)), r2[:50]))
s2, ph2 = 'v3:Z7', P(257); start(s2, ph2); f = tool(s2, 'find_appointments'); r = tool(s2, 'cancel', appt_id=appts(ph)[0]['id'], said_date=DAY(7), said_time='10:00')
V('S7', 'Huy hen cua SO KHAC (appt_id cua nguoi khac) -> khong huy', 'PASS' if len(appts(ph)) == 1 and not r.startswith('CANCELLED') else 'FAIL', 'INTEGRATION', r[:80])
f2 = tool(s2, 'find_appointments', phone=ph, caller_number=ph); r = tool(s2, 'cancel', appt_id=appts(ph)[0]['id'], said_date=DAY(7), said_time='10:00', phone=ph, caller_number=ph)
V('S7b', 'AI dua SO NAN NHAN trong body (find / cancel) -> khong thay, khong huy hen nguoi khac', 'PASS' if len(appts(ph)) == 1 and 'GUS' not in f2.upper() and not r.startswith('CANCELLED') else 'FAIL', 'INTEGRATION', (f2[:60], r[:60]))
r = tool(s2, 'book', name='Hal', date=DAY(7), time='11:00', persons=[{'name': 'Hal', 'service_ids': [PD], 'tech_id': 0}], phone='+15155550299', caller_number='+15155550299')
V('S8', 'AI dua so dien thoai khac trong body -> bo qua, dung so goi den', 'PASS' if not appts('+15155550299') and len(appts(ph2)) == 1 else 'FAIL', 'INTEGRATION', (r[:50], len(appts(ph2))))
c, x = req('in', {'CallSid': 'v3:Z9', 'From': P(259), 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True)
V('S9', 'Thong bao ghi am: "This call may be recorded." TRUOC khi do chuong / AI', 'PASS' if x.find('This call may be recorded') != -1 and x.find('This call may be recorded') < max(x.find('<Dial'), 0) + 10 ** 6 and x.find('may be recorded') < x.find('<Dial') else 'FAIL', 'INTEGRATION', x[:120])
V('S9b', 'Chinh sach dong y ghi am (luat bang)', 'BLOCKED', 'MOCK', 'can anh Logan / luat su xac nhan (Iowa: 1 ben dong y; khach goi tu bang 2 ben -> thong bao chung)')
logs = open(D + '/php.log').read(); nums = set(re.findall(r'\+?1?515555\d{4}', logs)); names = [n for n in ('Nora', 'NORA', 'Tia', 'Uma', 'Wen', 'Xia', 'Yen', 'Zoe', 'Gus', 'GUS', 'Hal', 'Bea') if re.search(r'\b' + n + r'\b', logs)]
V('S10', 'Log khong chua so dien thoai / TEN khach (tx_log)', 'PASS' if not nums and not names else 'FAIL', 'INTEGRATION', '%d so, ten: %s · vd %s' % (len(nums), names[:5], sorted(nums)[:3]))
V('S11', 'Key / Public Key / secret khong vao log', 'PASS' if 'KEY0123' not in logs and TOK not in logs else 'FAIL', 'INTEGRATION', '')
# ----- 19 + GIAI DOAN 5: nhieu cuoc dong thoi / tai -----
say('== TAI: 1 / 5 / 10 / 25 / 50 / 100 cuoc dong thoi (may test, PHP built-in 8 tien trinh + SQLite – live = php-fpm + MySQL)')
PL = PORT + 41; svL = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PL, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '8'}, stdout=subprocess.DEVNULL, stderr=open(D + '/phpL.log', 'w')); atexit.register(svL.terminate); time.sleep(1.2)
BL = 'http://127.0.0.1:%d/call_tx.php' % PL
import base64
def reqL(a, body, form=False, extra=''):
    raw = urllib.parse.urlencode(body).encode() if form else json.dumps(body).encode(); hd = {'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json'}
    ts = str(int(time.time())); bf = D + '/.bl-' + str(threading.get_ident()); open(bf, 'wb').write(raw); hd['telnyx-timestamp'] = ts; hd['telnyx-signature-ed25519'] = sigL(ts, raw)
    t0 = time.time()
    try: r_ = urllib.request.urlopen(urllib.request.Request(BL + '?a=' + a + '&t=' + TOK + extra, data=raw, headers=hd), timeout=30); return r_.status, r_.read().decode(), time.time() - t0
    except urllib.error.HTTPError as e: return e.code, '', time.time() - t0
    except Exception as e: return 0, str(e), time.time() - t0
import base64
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    _sk = Ed25519PrivateKey.from_private_bytes(base64.b64decode(SIGN)[:32])
    def sigL(ts, raw): return base64.b64encode(_sk.sign(ts.encode() + b'|' + raw)).decode()
except Exception:   # a server without python3-cryptography: sign with PHP sodium (slower, same signature)
    def sigL(ts, raw):
        bf = D + '/.bs-' + str(threading.get_ident()); open(bf, 'wb').write(raw); return h('sign', SIGN, ts, bf)
LOAD = []
NI = {1: 1, 5: 2, 10: 3, 25: 4, 50: 5, 100: 6}
slot = [0]
def one(i, n, lat, errs):
    sid = 'v3:L%d-%d' % (n, i); frm = '+1515%03d%04d' % (600 + NI[n], i)
    k = slot[0] + i; day = DAY(10 + k // 12); tm = '%02d:00' % (9 + k % 12)
    try:
        c1, x1, t1 = reqL('in', {'CallSid': sid, 'From': frm, 'To': '+15155136667', 'AccountSid': 'ACC1'}, form=True)
        c2, x2, t2 = reqL('after', {'CallSid': sid, 'DialCallStatus': 'no-answer'}, form=True, extra='&sid=' + xs(sid))
        c3, x3, t3 = reqL('tool', {'date': day, 'time': tm, 'persons': [{'name': 'L%d' % i, 'service_ids': [GM], 'tech_id': 0}]}, extra='&fn=check_times&ccid=' + xs(sid))
        c4, x4, t4 = reqL('tool', {'name': 'Load %d' % i, 'date': day, 'time': tm, 'persons': [{'name': 'Load %d' % i, 'service_ids': [GM], 'tech_id': 0}]}, extra='&fn=book&ccid=' + xs(sid))
        c5, x5, t5 = reqL('aiend', {'CallSid': sid, 'Reason': 'hangup'}, form=True, extra='&sid=' + xs(sid))
        lat.extend([('in', t1), ('after', t2), ('tool', t3), ('tool', t4), ('aiend', t5)])
        ok_ = all(c == 200 for c in (c1, c2, c3, c4, c5)) and 'BOOKED' in x4
        if not ok_: errs.append((i, c1, c2, c3, c4, c5, x4[:60]))
    except Exception as e: errs.append((i, str(e)[:80]))
def cpu():
    t = 0.0
    for p_ in glob.glob('/proc/[0-9]*/stat'):
        try:
            f_ = open(p_).read().split()
            if 'php' in f_[1]: t += (int(f_[13]) + int(f_[14])) / os.sysconf('SC_CLK_TCK')
        except Exception: pass
    return t
def rss():
    m = 0
    for p_ in glob.glob('/proc/[0-9]*/status'):
        try:
            s_ = open(p_).read()
            if 'Name:\tphp' in s_: m += int(re.search(r'VmRSS:\s+(\d+)', s_).group(1))
        except Exception: pass
    return m // 1024
for n in (1, 5, 10, 25, 50, 100):
    lat, errs = [], []; c0 = cpu(); t0 = time.time(); peak = [0]; stop = [False]
    def mon():
        while not stop[0]: peak[0] = max(peak[0], rss()); time.sleep(0.2)
    mt = threading.Thread(target=mon); mt.start()
    th = [threading.Thread(target=one, args=(i, n, lat, errs)) for i in range(n)]; [t.start() for t in th]; [t.join() for t in th]
    stop[0] = True; mt.join(); wall = time.time() - t0; c1_ = cpu()
    q = sql("SELECT COUNT(*) AS n, COUNT(DISTINCT appt_date || '-' || start_min || '-' || phone) AS d FROM appointments WHERE customer_name LIKE 'LOAD %%' AND status = 'booked' AND phone LIKE '+1515556%03d%%'" % (n,)) if False else None
    mine = sql("SELECT appt_date, start_min, phone FROM appointments WHERE phone LIKE '+1515%03d%%' AND status = 'booked'" % (600 + NI[n]))
    dup = len(mine) - len({(r_['appt_date'], r_['start_min'], r_['phone']) for r_ in mine})
    tl = sorted(t for k_, t in lat if k_ == 'tool'); p50 = statistics.median(tl) if tl else 0; p95 = tl[int(len(tl) * 0.95) - 1] if tl else 0
    slow = sum(1 for t in tl if t > 8)
    LOAD.append((n, len(mine), n - len(errs), dup, round(p50, 2), round(p95, 2), max(tl) if tl else 0, slow, round(wall, 1), round(c1_ - c0, 1), peak[0], errs[:2]))
    say('  %3d cuoc: xong %3d/%d · hen dat %3d · trung %d · tool p50 %.2fs p95 %.2fs max %.2fs · >8 s (Telnyx timeout) %d · %.1fs · CPU php %.1fs · RAM php max %d MB%s' % (n, n - len(errs), n, len(mine), dup, p50, p95, max(tl) if tl else 0, slow, wall, c1_ - c0, peak[0], ('  loi: ' + str(errs[:2])) if errs else ''))
    slot[0] += n
dbl = open(D + '/phpL.log').read().count('database is locked')
okL = all(x[2] == x[0] and x[1] == x[0] and x[3] == 0 for x in LOAD)
V('19', 'Nhieu cuoc dong thoi cung 1 salon (1..100): moi cuoc dat dung 1 hen, khong trung', 'PASS' if okL else 'FAIL', 'INTEGRATION', LOAD[-1][:9])
V('L1', 'Tai 100 cuoc: tool p95 < 8 s (timeout tool Telnyx)', 'PASS' if LOAD[-1][5] < 8 and LOAD[-1][7] == 0 else 'FAIL', 'INTEGRATION', 'p95 %.2fs, >8s: %d, SQLite locked: %d' % (LOAD[-1][5], LOAD[-1][7], dbl))
V('L2', 'Tai that (php-fpm + MySQL + Telnyx that, cuoc that)', 'BLOCKED', 'REAL CALL', 'may test chi do code + DB SQLite; khong do duoc STT / TTS / mang Telnyx')
