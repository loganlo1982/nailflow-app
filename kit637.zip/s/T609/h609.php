<?php // T609 harness (sqlite test DB only): php h609.php <app> <cmd> [args]
$R = $argv[1]; require "$R/inc/core.php"; settings(); ensure_schema(); $c = $argv[2]; $today = date('Y-m-d');
$sid = fn($n) => (int)q('SELECT id FROM staff WHERE name = ? AND active = 1', [$n])->fetchColumn();
$svc = fn($n) => (int)q('SELECT id FROM services WHERE name = ?', [$n])->fetchColumn();
if ($c === 'prep') {
    $h = []; for ($w = 0; $w < 7; $w++) $h[$w] = ['open' => '00:00', 'close' => '23:59']; set_setting('hours', json_encode($h)); set_setting('clock_anytime', '1');
    q("UPDATE staff SET pin_hash = ?, pin_len = 4 WHERE id = ?", [password_hash('1234', PASSWORD_DEFAULT), $sid('TAMMY')]);
    q('DELETE FROM staff_clock'); q('DELETE FROM appointments'); q('DELETE FROM login_attempts');
    q("INSERT INTO staff_clock (staff_id, work_date, clock_in, clock_out) VALUES (?, ?, ?, '')", [$sid('TAMMY'), $today, date('Y-m-d H:i:s', time() - 7200)]);
    if (!function_exists("tech_key")) { define("NF_API_LIB", 1); require_once "$R/inc/api/_auth.php"; } echo json_encode(["tk" => tech_key(), 'id' => $sid('TAMMY')]); }
if ($c === 'inserv') { // a customer in service with TAMMY, started <sec> seconds ago (name, service)
    [$_, $_, $_, $sec, $name] = $argv + [4 => 'STACY']; $st = time() - (int)$sec; q("UPDATE appointments SET status = 'paid', done_at = ?, paid_at = ? WHERE status = 'arrived'", [now_str(), now_str()]);
    q("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, arrived_at, started_at, walkin, created_at) VALUES (?,?,?,?,?,?,?,'arrived','admin','appt',?,?,1,?)",
      [$today, intdiv((int)date('G', $st) * 60 + (int)date('i', $st), 5) * 5, 60, $sid('TAMMY'), (string)$svc('Pedicure'), $name, '', date('Y-m-d H:i:s', $st - 60), date('Y-m-d H:i:s', $st), now_str()]); echo db()->lastInsertId(); }
if ($c === 'row') { echo json_encode(q('SELECT id, status, started_at, done_at FROM appointments WHERE id = ?', [(int)$argv[3]])->fetch()); }
if ($c === 'log') { echo json_encode(q("SELECT action, detail FROM appt_log WHERE appt_id = ? ORDER BY id", [(int)$argv[3]])->fetchAll()); }
