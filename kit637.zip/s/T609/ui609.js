// 2.99.609: Service done under 5 min → ask again (A) · the tech phone's buttons (B) – iPhone SE 375 / iPhone 13 / iPad
const L = require('/tmp/claude-0/t561/lib.js'); const { execSync } = require('child_process');
const A = process.argv[2], PORT = 19891, OUT = '/tmp/claude-0/T609/o';
L.run(A, PORT, OUT, async ({ ok, sleep, devices, B }) => {
  const W = `/tmp/claude-0/t561/w${PORT}/db.sqlite`, E = { env: { ...process.env, TZ: 'America/Chicago' } };
  execSync(`php /tmp/claude-0/T586/seed.php ${A} ${W} ${PORT}`, E);
  const h = (...a) => execSync(`php /tmp/claude-0/T609/h609.php ${A} ${a.map(x => `'${x}'`).join(' ')}`, E).toString();
  const P = JSON.parse(h('prep'));
  const { chromium } = require('/opt/node22/lib/node_modules/playwright'); const br = await chromium.launch(); const pe = [];
  const login = async (dev, tag) => {
    const ctx = await br.newContext({ ...devices[dev] }); const p = await ctx.newPage(); p.on('pageerror', e => pe.push(tag + ': ' + e.message));
    const r = await ctx.request.post(B + '/api.php?action=staff_login', { data: { id: P.id, pin: '1234', tk: P.tk } }); if (!r.ok()) throw new Error('login ' + r.status() + ' ' + (await r.text()));
    await p.goto(B + '/tech/?tk=' + P.tk); await sleep(3500); return { ctx, p };
  };
  const tapDone = async (p) => { await p.click('#taStatus .st-done'); await new Promise(r => setTimeout(r, 400)); if (await p.evaluate(() => { const d = document.querySelector('#taStatus .st-done'); return !!(d && d.classList.contains('sure') && !d.disabled); })) await p.click('#taStatus .st-done'); };
  const card = (p) => p.evaluate(() => { const el = document.getElementById('taStatus'); const q = (s) => el.querySelector(s); const r = (x) => x && x.getBoundingClientRect();
    const done = q('.st-done'), row = q('.st-row'), rb = row ? [...row.querySelectorAll('.ta-btn')].map(x => [Math.round(r(x).top), Math.round(r(x).height)]) : [];
    return { st: el.dataset.state, text: el.innerText.replace(/\s+/g, ' '), doneBg: done && getComputedStyle(done).backgroundColor, doneH: done && Math.round(r(done).height), doneTop: done && Math.round(r(done).top),
      rowBottom: row && Math.round(r(row).bottom), rowBtns: rb, gap: done && row ? Math.round(r(done).top - r(row).bottom) : null, last: done ? el.querySelector('.st-donewrap') === [...el.querySelectorAll('.st-btns')].pop() : false,
      w: document.documentElement.scrollWidth, vw: innerWidth }; });
  // ---- A: the server (API) ----
  let id = +h('inserv', 120, 'STACY');
  { const { ctx, p } = await login('iPhone SE', 'se');
    let r = await p.evaluate(async (id) => (await api('tech_svc_done', { id })), id);
    ok('A API: Service done 2 min after starting → {confirm:true, msg "You started only 2 min ago – is this service really done?"} · nothing written', r.confirm === true && r.ok === false && /only 2 min ago/.test(r.msg) && JSON.parse(h('row', id)).done_at === '', [r, h('row', id)]);
    // ---- B: the with-client card ----
    let s = await card(p); await p.screenshot({ path: OUT + '/609-with-se.png', fullPage: true });
    ok('B2 SE 375: with client – "Started … · 2 min in" (the real start) + "Just started" (orange) shown', /Started .+ · 2 min in/.test(s.text) && /Just started/.test(s.text), s.text);
    ok('B2 SE 375: Service done is LAST, the biggest (≥ 76 px), GREEN with white text, ≥ 24 px below the small buttons', s.last && s.doneH >= 76 && s.doneBg === 'rgb(20, 128, 60)' && s.gap >= 24, s);
    ok('B2 SE 375: the small buttons in ONE row above (Add service; Not soon / Almost done when shown), 44 px high · no sideways scroll', s.rowBtns.length >= 1 && s.rowBtns.every(x => x[0] === s.rowBtns[0][0] && x[1] >= 40 && x[1] <= 60) && s.w <= s.vw, s);
    // ---- A: the phone – tap Done twice → asked; "Not yet" → nothing
    await tapDone(p); await sleep(1500);
    let sh = await p.evaluate(() => ({ open: !document.getElementById('sheet').hidden, t: document.getElementById('sheet').innerText.replace(/\s+/g, ' ') })); await p.screenshot({ path: OUT + '/609-ask-se.png' });
    ok('A phone: Done (1 tap with Undo mode, or 2 taps) under 5 min → the app\'s own sheet "Service done? – You started only 2 min ago …" with "Yes, done" / "Not yet" (no browser dialog)', sh.open && /You started only 2 min ago/.test(sh.t) && /Yes, done/.test(sh.t) && /Not yet/.test(sh.t), sh);
    await p.click('#sheet [data-no]'); await sleep(1500);
    s = await card(p);
    ok('A phone: "Not yet" → sheet closed, still WITH CLIENT, not done in the database, buttons work again', s.st === 'with' && JSON.parse(h('row', id)).done_at === '' && await p.evaluate(() => document.getElementById('sheet').hidden && !document.querySelector('#taStatus .st-done').disabled), [s.st, h('row', id)]);
    await tapDone(p); await sleep(1500); await p.click('#sheet [data-yes]'); await sleep(2500);
    ok('A phone: "Yes, done" → done as before (done_at set, history "done · Tech phone")', JSON.parse(h('row', id)).done_at !== '' && JSON.parse(h('log', id)).some(l => l.action === 'done' && /Tech phone/.test(l.detail)), [h('row', id), h('log', id)]);
    // ≥ 5 min: no question
    id = +h('inserv', 420, 'NANCY TEST WITH A VERY LONG NAME FOR THE CARD'); await p.reload(); await sleep(3500);
    s = await card(p); await p.screenshot({ path: OUT + '/609-with-long-se.png', fullPage: true });
    ok('B2 SE 375: a long name – no sideways scroll; 7 min in → no "Just started"', s.w <= s.vw && /7 min in/.test(s.text) && !/Just started/.test(s.text), s);
    await tapDone(p); await sleep(2500);
    ok('A phone: Done after ≥ 5 min → NO question, done at once (as before)', await p.evaluate(() => document.getElementById('sheet').hidden) && JSON.parse(h('row', id)).done_at !== '', h('row', id));
    // under 1 minute (API text)
    id = +h('inserv', 20, 'LUCY'); r = await p.evaluate(async (id) => (await api('tech_svc_done', { id })), id);
    ok('A API: 20 s → "You started less than 1 min ago – is this service really done?"', r.confirm && /less than 1 min ago/.test(r.msg), r);
    r = await p.evaluate(async (id) => (await api('tech_svc_done', { id, sure: 1 })), id);
    ok('A API: sure=1 → done (ok:true)', r.ok === true && JSON.parse(h('row', id)).done_at !== '', [r, h('row', id)]);
    // ---- B1: YOUR TURN (drawn from a test offer) ----
    for (const big of [false, true]) {
      const y = await p.evaluate(async (big) => { S.board = { inService: [], next: [], coming: [], now: Math.floor(Date.now() / 1000) }; S.turn = Object.assign({}, S.turn || {}, { offer: { id: 991, kind: 'any', name: 'TEST WALKIN', services: 'Pedicure', checkedIn: '4:20 PM' } });
        drawStatus(true); const el = document.getElementById('taStatus'); if (big) el.classList.add('te-big'); await new Promise(r => setTimeout(r, 200));
        const a = el.querySelector('.st-accept'), k = el.querySelector('.st-skip'); if (!a || !k) return { st: el.dataset.state, html: el.innerHTML.slice(0, 300) }; const ra = a.getBoundingClientRect(), rk = k.getBoundingClientRect();
        return { st: el.dataset.state, aBg: getComputedStyle(a).backgroundColor, aCol: getComputedStyle(a).color, aH: Math.round(ra.height), kW: Math.round(rk.width), aW: Math.round(ra.width), gap: Math.round(rk.top - ra.bottom), kBg: getComputedStyle(k).backgroundColor, kText: k.innerText.replace(/\s+/g, ' '), w: document.documentElement.scrollWidth, vw: innerWidth }; }, big);
      await p.screenshot({ path: OUT + '/609-turn' + (big ? '-big' : '') + '-se.png', fullPage: true });
      ok('B1 SE 375' + (big ? ' (te-big)' : '') + ': YOUR TURN – Accept GREEN with white text, big' + (big ? ' (45vh)' : '') + '; Skip ~60 % wide, outline, ≥ 24 px below, "keep your place" under it', y.aBg === 'rgb(20, 128, 60)' && y.aCol === 'rgb(255, 255, 255)' && y.aH >= (big ? 250 : 70) && y.kW <= y.aW * 0.65 && y.kW >= y.aW * 0.5 && y.gap >= 24 && y.kBg === 'rgba(0, 0, 0, 0)' && /Skip/.test(y.kText) && /keep your place/.test(y.kText) && y.w <= y.vw, y);
    }
    await ctx.close(); }
  for (const [dv, tag] of [['iPhone 13', '13'], ['iPad (gen 7)', 'ipad']]) {
    id = +h('inserv', 90, 'MIA'); const { ctx, p } = await login(dv, tag); const s = await card(p); await p.screenshot({ path: OUT + '/609-with-' + tag + '.png', fullPage: true });
    ok(dv + ': with client – Done last / green / ≥ 76 px, small buttons in one row, no sideways scroll', s.last && s.doneH >= 76 && s.doneBg === 'rgb(20, 128, 60)' && s.rowBtns.every(x => x[0] === s.rowBtns[0][0]) && s.w <= s.vw, s); await ctx.close(); }
  ok('no page errors', pe.length === 0, pe);
  await br.close();
});
