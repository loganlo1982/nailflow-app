# LAMWEB test 636 – a NEW salon sets itself up: "Set up your salon" (the Getting started card) – 6 steps, each ✓ from the real data; sample menu with NO prices;
# a service with no price is not on the booking page; American Nails (no noindex) unchanged.   python3 t636.py <app folder>
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, http.cookiejar, re, datetime as _dt
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T636'; T5 = '/tmp/claude-0/T586'; PA, PB = 19962, 19963
R = []; out = open(D + '/test-636.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
X = {}
def mk(tag, port, extra):
    app = D + '/app' + tag; db = D + '/db' + tag + '.sqlite'; shutil.rmtree(app, ignore_errors=True); shutil.copytree(A0, app, symlinks=True); shutil.copy('/tmp/claude-0/tdb/base.sqlite', db)
    sh('php', T5 + '/seed.php', app, db, str(port))
    open(app + '/inc/config.php', 'w').write("<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'%s','site_url'=>'http://127.0.0.1:%d'%s);\n" % (db, port, extra))
    sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', app, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '4'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php' + tag + '.log', 'w'))
    atexit.register(sv.terminate); X[tag] = {'app': app, 'db': db, 'port': port}
mk('A', PA, ", 'noindex'=>true"); mk('B', PB, ''); time.sleep(1.3)
def sql(t, q): r = sh('php', T5 + '/db.php', X[t]['db'], q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
def api(t, action, body=None, jar=None, csrf=None, get=''):
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)) if jar is not None else urllib.request.build_opener()
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': csrf} if csrf else {})
    rq = urllib.request.Request('http://127.0.0.1:%d/api.php?action=%s%s' % (X[t]['port'], action, get), data=None if body is None else json.dumps(body).encode(), headers=hd)
    try: r = urllib.request.urlopen(rq, timeout=60) if jar is None else op.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
PW = 'adm636-' + os.urandom(4).hex()
for t in 'AB':
    h = sh('php', '-r', "echo password_hash('%s', PASSWORD_DEFAULT);" % PW).stdout
    sql(t, "INSERT INTO settings (k, v) VALUES ('admin_hash', '%s') ON CONFLICT(k) DO UPDATE SET v = excluded.v" % h)
    sql(t, "INSERT INTO settings (k, v) VALUES ('gs_done', '') ON CONFLICT(k) DO UPDATE SET v = excluded.v")
# A = a NEW salon with nothing yet (the schema's default name, no services, no techs)
sql('A', "UPDATE services SET active = 0"); sql('A', "UPDATE staff SET active = 0"); sql('A', "DELETE FROM appointments")
sql('A', "UPDATE settings SET v = 'AMERICAN NAILS AND SPA' WHERE k = 'salon_name'"); sql('A', "UPDATE settings SET v = '' WHERE k IN ('salon_phone', 'salon_address')")
def login(t): j = http.cookiejar.CookieJar(); c, r = api(t, 'login', {'password': PW}, j); return j, r.get('csrf')
JA, CA = login('A'); JB, CB = login('B')
G = lambda: api('A', 'getstarted', None, JA, CA)[1]
st = lambda g: {x['k']: x['done'] for x in g.get('items', []) if x.get('step')}
say('== LAMWEB test 2.99.636 – LENH 636 a new salon sets itself up ' + time.strftime('%Y-%m-%d %H:%M %Z'))
g = G(); ok('1 new empty salon: the card shows "Set up your salon 0 / 6" – the 6 steps first, in order (salon, hours, menu, techs, turn, texts)',
   g.get('show') is True and g.get('steps') == 0 and g.get('stepsAll') == 6 and [x['k'] for x in g.get('items', [])][:6] == ['salon', 'hours', 'menu', 'techs', 'turn', 'msgs'], g)
ok('1 each step opens the Settings page that already exists (salon, hours, services, techs, turn, sms)', [x.get('go') for x in g.get('items', [])][:6] == ['salon', 'hours', 'services', 'techs', 'turn', 'sms'], [x.get('go') for x in g.get('items', [])][:6])
ok('1 no booking-page preview yet (no service / tech / hours)', g.get('preview') is False, g.get('preview'))
c, r = api('A', 'save_settings', {'salon_name': 'LOVE NAILS TEST', 'salon_phone': '(515) 555-0177', 'salon_address': '1 Main St, Des Moines, IA'}, JA, CA)
ok('2 ① Salon info saved on its own Settings page -> ✓', c == 200 and st(G()).get('salon') is True, (c, r, st(G())))
c, r = api('A', 'save_settings', {'hours': {str(d): {'closed': d == 0, 'open': '10:00', 'close': '19:00'} for d in range(7)}}, JA, CA)
ok('2 ② Hours saved -> ✓', c == 200 and st(G()).get('hours') is True, (c, r))
c, r = api('A', 'gs_mark', {'menu': True}, JA, CA); svs = sql('A', "SELECT id, name, price, duration FROM services WHERE active = 1 ORDER BY id")
ok('3 "+ Add the sample menu": 15 common nail services, sample minutes, ALL prices empty ($0)', c == 200 and r.get('added') == 15 and len(svs) == 15 and all(float(s['price']) == 0 for s in svs) and all(int(s['duration']) > 0 for s in svs) and 'Gel-X' in [s['name'] for s in svs], (c, r.get('added'), svs[:3]))
ok('3 nothing from American Nails: none of the AN-only names (the base test menu "Full Set" stays off)', not any(s['name'] in ('Full Set',) for s in svs), [s['name'] for s in svs])
c2, r2 = api('A', 'gs_mark', {'menu': True}, JA, CA); n2 = len(sql('A', "SELECT id FROM services WHERE active = 1"))
ok('3 tapped twice -> nothing added again (still 15, no doubles)', c2 == 200 and r2.get('added') == 0 and n2 == 15, (c2, r2.get('added'), n2))
g = G(); ok('3 ③ not ✓ while services have no price; the card says "15 services with no price yet"', st(g).get('menu') is False and g.get('noPrice') == 15, (st(g), g.get('noPrice')))
c, I = api('A', 'info', get=''); names = json.dumps(I.get('services', []))
ok('3 the online booking page shows NONE of the services with no price', c == 200 and not any(s['name'] in names for s in svs), names[:300])
sid = svs[0]['id']; d = (_dt.date.today() + _dt.timedelta(days=3)).isoformat()
c, r = api('A', 'slots', get='&date=%s&services=%d&people=0' % (d, sid)); ok('3 a service with no price cannot be booked online (slots refused)', c == 400 and 'Choose a service' in r.get('error', ''), (c, r))
full = lambda price_of: [{'id': s['id'], 'name': s['name'], 'duration': s['duration'], 'price': price_of(s), 'color': '#3472B9'} for s in svs]
c, r = api('A', 'save_services', {'services': full(lambda s: 0 if s['id'] == svs[-1]['id'] else 30)}, JA, CA)
g = G(); c3, I3 = api('A', 'info')
ok('3 prices typed in Settings -> Services for 14 of 15: still not ✓ ("1 service with no price"), 14 on the booking page', c == 200 and st(g).get('menu') is False and g.get('noPrice') == 1 and json.dumps(I3.get('services')).count('"id"') >= 14 and svs[-1]['name'] not in json.dumps(I3.get('services')), (c, r, g.get('noPrice')))
c, r = api('A', 'save_services', {'services': full(lambda s: 25 if s['id'] == svs[-1]['id'] else 30)}, JA, CA)
g = G(); ok('3 the last price typed -> ③ ✓, every service on the booking page', c == 200 and st(g).get('menu') is True and g.get('noPrice') == 0 and svs[-1]['name'] in json.dumps(api('A', 'info')[1].get('services')), (c, st(g)))
c, r = api('A', 'save_staff_one', {'id': 0, 'name': 'MAI', 'skillAll': 1, 'commission': 55, 'payMethod': 'check', 'online': 1}, JA, CA)
g = G(); ok('4 ④ a tech added in Staff -> ✓ · the booking page preview button appears (service + tech + hours)', c == 200 and st(g).get('techs') is True and g.get('preview') is True and g.get('bookLink', '').startswith('http'), (c, r, st(g), g.get('preview')))
c, r = api('A', 'save_settings', {'turn_req_mode': 'none'}, JA, CA); ok('5 ⑤ a turn rule saved in Settings -> Turn rules -> ✓', c == 200 and st(G()).get('turn') is True, (c, r))
c, r = api('A', 'gs_mark', {'k': 'msgs', 'done': True}, JA, CA); g = G()
ok('6 ⑥ Customer texts: "Mark done" -> ✓ · Set up your salon 6 / 6', c == 200 and st(g).get('msgs') is True and g.get('steps') == 6, (c, g.get('steps')))
c, r = api('A', 'save_settings', {'salon_phone': '(515) 555-0188'}, JA, CA); ph = sql('A', "SELECT v FROM settings WHERE k = 'salon_phone'")[0]['v']
ok('7 changed again later in Settings -> saved, still ✓', c == 200 and '0188' in ph and st(G()).get('salon') is True, (c, ph))
# American Nails (no noindex): nothing changes
nB = len(sql('B', "SELECT id FROM services WHERE active = 1")); c, r = api('B', 'getstarted', None, JB, CB)
ok('8 American Nails (not a new salon): no card', c == 200 and r.get('show') is False, (c, r))
c, r = api('B', 'gs_mark', {'menu': True}, JB, CB); ok('8 American Nails: the sample menu is refused, nothing added', c == 403 and len(sql('B', "SELECT id FROM services WHERE active = 1")) == nB, (c, r))
sql('B', "INSERT INTO services (name, duration, price, sort, active) VALUES ('FREE CONSULT', 15, 0, 99, 1)")
c, I = api('B', 'info'); ok('8 American Nails: a $0 service it has stays on its booking page (rule only for new salons / sample services)', c == 200 and 'FREE CONSULT' in json.dumps(I.get('services')), json.dumps(I.get('services'))[:200])
# the screens
core = open(A0 + '/assets/admin-core.js', encoding='utf-8').read(); sup = re.search(r"var SUP_ONLY = new Set\(\[(.*?)\]\)", core).group(1)
ok('9 Settings: "Salon info" and "Text messages" open for the salon owner; the NailFlow-only pages (texting phone, backups, test tools) stay support-only (DUYET-636-AN-MO: apps / checkin / desk ... open)', "'salon'" not in sup and "'sms'" not in sup and all(x in sup for x in ["'asend'", "'backup'", "'test'"]), sup[:200])
ok('9 Settings -> Turn rules gets the same "VD:" examples (turn-ex.js loaded with Settings)', "'turn-ex'" in core and os.path.exists(A0 + '/assets/admin/turn-ex.js') and 'TURN_EX' in open(A0 + '/assets/admin/turn-ex.js', encoding='utf-8').read(), 'turn-ex missing')
pg = open(A0 + '/setup/index.php', encoding='utf-8').read(); ok('9 /setup/ uses the SAME example table (no 2nd copy)', 'const EX = window.TURN_EX' in pg and 'turn-ex.js' in pg and '"q1:clock"' not in pg, 'setup still has its own table')
logs = open(D + '/phpA.log').read() + open(D + '/phpB.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
