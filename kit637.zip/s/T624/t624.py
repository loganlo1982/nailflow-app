# LAMWEB test 624 – SignalWire screening of the iPhone leg (cXML call_in.php + SWML call_agent.php): the owner's long greeting = a person, the voicemail = hung up.
import subprocess, sys, json, os
A = os.path.abspath(sys.argv[1]); R = []
def ok(n, c, i=''): R.append(bool(c)); print(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:300]), flush=True)
OWNER = 'Hello thank you for calling American Nails and Spa how can I help you'
VM = "Hi you've reached Logan please leave a message after the tone"
VZ = 'the number you have dialed is not in service please check the number and try again'
SHORT = 'Hello?'
php = r"""<?php define('NF_API_LIB', 1); require '%s/inc/calls.php'; foreach (json_decode($argv[1], true) as $t) echo (str_contains(cl_screened_xml(['SpeechResult' => $t], ''), 'Hangup') ? 'HANG' : 'KEEP'), "\n";""" % A
open('/tmp/claude-0/T624/s.php', 'w').write(php)
r = subprocess.run(['php', '/tmp/claude-0/T624/s.php', json.dumps([OWNER, VM, VZ, SHORT])], capture_output=True, text=True); o = r.stdout.split()
ok('cXML (call_in.php): chu chao dai 13 tu "Hello thank you for calling American Nails…" -> KHONG cup (nguoi)', o[:1] == ['KEEP'], (o, r.stderr[-200:]))
ok('cXML: hop thu "Hi you\'ve reached Logan please leave a message…" -> cup', o[1:2] == ['HANG'], o)
ok('cXML: 15 tu khong co loi chao ("the number you have dialed is not in service…") -> cup', o[2:3] == ['HANG'], o)
ok('cXML: "Hello?" -> giu', o[3:4] == ['KEEP'], o)
php2 = r"""<?php define('NF_API_LIB', 1); require '%s/inc/calls.php'; require '%s/inc/calls-agent.php'; $s = cl_agent_screen_swml(); foreach ($s['sections']['main'] as $x) if (isset($x['cond'])) echo $x['cond'][0]['when'];""" % (A, A)
open('/tmp/claude-0/T624/w.php', 'w').write(php2)
w = subprocess.run(['php', '/tmp/claude-0/T624/w.php'], capture_output=True, text=True).stdout
js = 'const f = (prompt_value) => (%s); console.log(JSON.stringify([%s].map(f)));' % (w, ','.join(json.dumps(x) for x in [OWNER, VM, VZ, SHORT]))
import shutil as _sh
if not _sh.which('node'):  # (621-B) server: no node -> the 4 SWML checks (JS) run on LAMWEB's machine; the PHP part above still runs here
    print('– SKIP 4 test SWML (khong co node tren may nay – chay o may LAMWEB)'); print('PASS %d/%d' % (sum(R), len(R))); sys.exit(0)
r = subprocess.run(['node', '-e', js], capture_output=True, text=True)
try: v = json.loads(r.stdout)
except Exception: v = ['ERR', r.stderr[-200:], w[:200]]
ok('SWML (call_agent.php): chu chao dai -> KHONG cup', v[:1] == [False], v)
ok('SWML: hop thu -> cup', v[1:2] == [True], v)
ok('SWML: 15 tu khong loi chao -> cup', v[2:3] == [True], v)
ok('SWML: "Hello?" -> giu', v[3:4] == [False], v)
print('PASS %d/%d' % (sum(R), len(R)))
