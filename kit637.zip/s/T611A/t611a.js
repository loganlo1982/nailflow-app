// node t611a.js CODE BASE PORT OUT – LENH 611 A: one color + the painted hand on the booking page; /colors unchanged
const { chromium, devices } = require('/opt/node22/lib/node_modules/playwright'); const { spawn, execFileSync } = require('child_process'); const fs = require('fs'); const crypto = require('crypto');
const [CODE, BASE, PORT, OUT] = process.argv.slice(2); fs.mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise(r => setTimeout(r, ms)); const R = []; const ok = (n, c, i) => { R.push(!!c); console.log((c ? '✓ ' : '✗ ') + n, c ? '' : JSON.stringify(i).slice(0, 500)); };
const COLORS = [{ code: 'DC 045', name: 'Cherry Red', hex: '#B3122E', family: 'red', kind: 'gel', finish: 'cream' }, { code: 'DC 101', name: 'Ballet Pink', hex: '#F2B8C6', family: 'pink', kind: 'gel', finish: 'shimmer' }, { code: 'OPI 12', name: 'Navy', hex: '#1F2A55', family: 'blue', kind: 'dip', finish: 'cream', brand: 'OPI' }];
function server(code, port) { const W = `/tmp/claude-0/kp-${port}`; fs.rmSync(W, { recursive: true, force: true }); fs.mkdirSync(W, { recursive: true }); fs.copyFileSync('/tmp/claude-0/tdb/base.sqlite', W + '/db.sqlite');
  fs.writeFileSync(code + '/inc/config.php', `<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'${W}/db.sqlite','site_url'=>'http://127.0.0.1:${port}','demo'=>true,'showapp'=>true);\n`);
  const ENV = { ...process.env, TZ: 'America/Chicago' }; execFileSync('php', [code + '/cron/showapp-seed.php'], { env: ENV }); execFileSync('php', ['-r', `$d=new PDO('sqlite:${W}/db.sqlite'); $d->exec("INSERT OR REPLACE INTO settings (k, v) VALUES ('online_booking', '1')"); $d->exec("UPDATE staff SET online = 1");`]);
  return { p: spawn('php', ['-S', '127.0.0.1:' + port, '-t', code, '/tmp/claude-0/router.php'], { env: { ...ENV, PHP_CLI_SERVER_WORKERS: '3' }, stdio: 'ignore', detached: true }), W }; }
(async () => { const s1 = server(CODE, +PORT), s2 = server(BASE, +PORT + 1); await sleep(1200); const br = await chromium.launch(); const pe = [];
  const ctxOf = async (dev, lang, slow) => { const ctx = await br.newContext({ ...dev }); await ctx.addInitScript((l) => { try { localStorage.setItem('bookLang', l); localStorage.setItem('bookNoStat', '1'); } catch (e) {} }, lang);
    await ctx.route('**/api.php?action=colors_list*', r => r.fulfill({ contentType: 'application/json', body: JSON.stringify({ colors: COLORS }) }));
    if (slow) await ctx.route('**/assets/hands/**', async r => { await sleep(slow); r.abort(); });
    return ctx; };
  const step4 = async (p, port, q) => { await p.goto(`http://127.0.0.1:${port}/${q || ''}`); await p.waitForFunction(() => typeof st !== 'undefined' && st.info); await p.evaluate(() => { const b = document.querySelector('#wOv button'); if (b) b.click(); }); await sleep(400);
    await p.evaluate(() => { const s = st.info.services.filter(x => x.main).slice(0, 1).map(x => x.id); st.people = [0]; st.services = s; st.ps = []; st.pt = []; st.design = []; st.peopleChosen = true; st.sDone = [true]; st.gDone = [true]; st.tm = []; st.tp = { 0: 1 }; st.date = null; st.slots = null; render(3, 1); });
    await sleep(2500); await p.evaluate(() => { const x = document.querySelector('#tsSheet .tss-x'); if (x) x.click(); st.start = st.slots[0]; history.pushState({ bstep: 4 }, ''); render(4, 1); }); await sleep(1200);
    await p.evaluate(() => { try { KP.done = null; kpClose(); } catch (e) {} }); await sleep(300); };
  const chips = (p) => p.evaluate(() => [...document.querySelectorAll('#bColorWrap .bc-chip')].map(x => x.textContent.replace('✕', '').trim()));
  try {
    for (const [dn, dev] of [['iPhone13', devices['iPhone 13']], ['SE', devices['iPhone SE']], ['iPad', devices['iPad (gen 7)']]]) for (const lang of ['en', 'es']) {
      const ctx = await ctxOf(dev, lang); const p = await ctx.newPage(); p.on('pageerror', e => pe.push(dn + ': ' + e.message)); const L = dn + ' ' + lang + ': ';
      await step4(p, PORT); await p.click('#bcOpen'); await sleep(500);
      const hint = await p.textContent('.bc-hint'); ok(L + 'palette: "tap a color to see it on a hand", Done without "· N picked"', (lang === 'en' ? /see it on a hand/ : /verlo en una mano/).test(hint) && /^(Done|Listo)$/.test((await p.textContent('.bc-done .btn')).trim()), hint);
      await p.click('[data-pick="DC 045"]'); await sleep(1800);
      const h1 = await p.evaluate(() => { const h = document.querySelector('.bc-hand'); const cv = h && h.querySelector('.bh-cv'); return h && !h.hidden ? { code: h.querySelector('.bh-code').textContent, ok: h.querySelector('[data-hok]').textContent, back: h.querySelector('[data-hback]').textContent, cv: cv && !cv.hidden && cv.width > 10, hand: HandPaint.handOf('DC 045'), red: (() => { if (!cv || cv.hidden) return 0; const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data; let n = 0; for (let i = 0; i < d.length; i += 16) if (d[i] > 110 && d[i] > d[i + 1] * 2.2 && d[i] > d[i + 2] * 1.8) n++; return n; })() } : null; });
      ok(L + 'tap DC 045 → the hand painted in it (canvas, nails really Cherry Red #B3122E) + "✓ Choose this color" / "Back"', h1 && h1.code === 'DC 045' && h1.cv && h1.red > 150 && (lang === 'en' ? h1.ok.includes('Choose this color') && h1.back === 'Back' : h1.ok.includes('Elegir este color') && h1.back === 'Atrás'), h1);
      await p.screenshot({ path: `${OUT}/${dn}-${lang}-hand.png` });
      await p.click('[data-hback]'); await sleep(300);
      ok(L + 'Back → the palette again, nothing picked', !(await p.evaluate(() => document.querySelector('.bc-box').hidden)) && (await p.evaluate(() => document.querySelectorAll('.bc-cell.on').length)) === 0, '');
      await p.click('[data-pick="DC 045"]'); await sleep(900); await p.click('[data-hok]'); await sleep(500);
      let c = await chips(p); let note = await p.evaluate(() => st.note);
      ok(L + 'Choose → palette closed, back on the form: ONE chip DC 045, note "🎨 Color: DC 045 Cherry Red"', c.length === 1 && c[0].includes('DC 045') && note === '🎨 Color: DC 045 Cherry Red' && (await p.evaluate(() => document.querySelector('.bc-box').hidden)), { c, note });
      await p.click('#bcOpen'); await sleep(300); await p.click('[data-pick="DC 101"]'); await sleep(900); await p.click('[data-hok]'); await sleep(500);
      c = await chips(p); note = await p.evaluate(() => st.note);
      ok(L + 'pick DC 101 → it REPLACES DC 045 (1 chip, 1 color in the note)', c.length === 1 && c[0].includes('DC 101') && note === '🎨 Color: DC 101 Ballet Pink', { c, note });
      await p.click('#bColorWrap .bc-chip'); await sleep(900);
      ok(L + 'tap the chip → the hand of DC 101 again', await p.evaluate(() => { const h = document.querySelector('.bc-hand'); return !h.hidden && h.querySelector('.bh-code').textContent === 'DC 101'; }), '');
      await p.click('[data-hback]'); await sleep(200); c = await chips(p); note = await p.evaluate(() => st.note); ok(L + 'Back from the chip → nothing changed (1 chip DC 101, note the same)', c.length === 1 && c[0].includes('DC 101') && note === '🎨 Color: DC 101 Ballet Pink', { c, note });
      await p.click('#bcOpen'); await sleep(300); await p.click('[data-pick="DC 101"]'); await sleep(300);
      ok(L + 'tap the picked color in the palette → taken off (no hand)', (await p.evaluate(() => document.querySelectorAll('.bc-cell.on').length)) === 0 && (await p.evaluate(() => document.querySelector('.bc-hand').hidden)), '');
      await p.click('.bc-done .btn'); await sleep(300); ok(L + 'note without a color line', (await p.evaluate(() => st.note)) === '' && (await chips(p)).length === 0, await p.evaluate(() => st.note));
      await ctx.close();
    }
    { const ctx = await ctxOf(devices['iPhone 13'], 'en'); const p = await ctx.newPage(); p.on('pageerror', e => pe.push('q: ' + e.message)); await step4(p, PORT, '?color=OPI%2012');
      const c = await chips(p); ok('?color=OPI 12 (from the Our colors page) → picked already: 1 chip, note "🎨 Color: OPI 12 Navy"', c.length === 1 && c[0].includes('OPI 12') && (await p.evaluate(() => st.note)) === '🎨 Color: OPI 12 Navy', c);
      // the note goes with the booking
      await p.evaluate(() => { const i = document.querySelector('#bPhone'); i.value = '(515) 555-0161'; i.dispatchEvent(new Event('input', { bubbles: true })); }); await sleep(1500);
      await p.evaluate(() => { const n = document.querySelector('#bName'); if (n) { n.value = 'Color Test'; n.dispatchEvent(new Event('input', { bubbles: true })); } st.name = 'Color Test'; st.phConfirmed = digits(st.phone); }); await sleep(300);
      await p.evaluate(() => primary()); await sleep(1500); await p.evaluate(() => { const b = document.querySelector('#gpNo'); if (b) b.click(); }); await sleep(2500);
      if (await p.evaluate(() => st.step) === 4) { await p.evaluate(() => { st.phConfirmed = digits(st.phone); return primary(); }); await sleep(2000); }
      await p.evaluate(() => document.querySelector('#bGo').click()); await sleep(3500);
      const nt = execFileSync('php', ['-r', `$d=new PDO('sqlite:${s1.W}/db.sqlite'); echo $d->query("SELECT note FROM appointments WHERE phone LIKE '%5155550161' ORDER BY id DESC LIMIT 1")->fetchColumn();`]).toString();
      ok('the booking keeps ONE color in its note', /🎨 Color: OPI 12 Navy/.test(nt) && !/Colors:/.test(nt), nt); await ctx.close(); }
    { const ctx = await ctxOf(devices['iPhone 13'], 'en', 4000); const p = await ctx.newPage(); p.on('pageerror', e => pe.push('slow: ' + e.message)); await step4(p, PORT);
      await p.click('#bcOpen'); await sleep(300); await p.click('[data-pick="DC 045"]'); await sleep(600);
      const s = await p.evaluate(() => { const h = document.querySelector('.bc-hand'), sq = h.querySelector('.bh-sw'); return { open: !h.hidden, sq: !sq.hidden && getComputedStyle(sq).backgroundColor, cv: !h.querySelector('.bh-cv').hidden }; });
      ok('slow / no hand photos: the big color square at once (not white), no error; Choose still works', s.open && s.sq === 'rgb(179, 18, 46)' && !s.cv, s); await p.screenshot({ path: `${OUT}/slow-square.png` });
      await sleep(4500); await p.click('[data-hok]'); await sleep(400); ok('slow: Choose → picked', (await chips(p)).length === 1, ''); await ctx.close(); }
    // /colors: unchanged (before = live code, after = shared hand-paint.js) – the same picture for the same color, same hand as the booking page
    const shot = async (port, tag) => { const ctx = await br.newContext({ ...devices['iPhone 13'] }); await ctx.route('**/api.php?action=colors_list*', r => r.fulfill({ contentType: 'application/json', body: JSON.stringify({ colors: COLORS }) }));
      const p = await ctx.newPage(); p.on('pageerror', e => pe.push(tag + ': ' + e.message)); await p.goto(`http://127.0.0.1:${port}/colors/`); await sleep(1500);
      const res = {}; for (const code of ['DC 045', 'DC 101', 'OPI 12']) { await p.evaluate((code) => { const b = [...document.querySelectorAll('#list .c')].find(x => x.querySelector('b').textContent === code); b.click(); }, code); await sleep(2500);
        res[code] = await p.evaluate(() => { const cv = document.querySelector('#bHand'); if (cv.hidden) return 'square'; return cv.width + 'x' + cv.height + ':' + cv.toDataURL().length + ':' + cv.toDataURL().slice(-60); });
        await p.screenshot({ path: `${OUT}/colors-${tag}-${code.replace(' ', '')}.png` }); await p.evaluate(() => document.querySelector('#bX').click()); await sleep(300); }
      const grid = crypto.createHash('md5').update(await p.screenshot()).digest('hex'); await ctx.close(); return { res, grid }; };
    const a = await shot(+PORT + 1, 'before'), b = await shot(PORT, 'after');
    ok('/colors page: the hand pictures are the SAME pixels before / after (3 colors) and the grid page looks the same', JSON.stringify(a.res) === JSON.stringify(b.res) && a.grid === b.grid && !Object.values(b.res).includes('square'), { a: a.res, b: b.res });
  } catch (e) { console.log('ERR', e.stack); } finally { await br.close(); for (const s of [s1, s2]) try { process.kill(-s.p.pid); } catch (e) {} for (const c of [CODE, BASE]) fs.writeFileSync(c + '/inc/config.php', "<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'/tmp/x.sqlite');\n"); }
  console.log('PASS', R.filter(Boolean).length + '/' + R.length, 'pageerrors', pe.length, pe.slice(0, 3)); })();
