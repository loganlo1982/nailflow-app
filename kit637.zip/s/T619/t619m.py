# LAMWEB test 619 – modules without tests before: 5 Checkout / receipts · 6 tips + tech money · 8 gift card balance · 7 customers · 10 report totals · 12 backup.
# Local copy, SQLite of its own, nothing real (no PayPal / SMS / card). Every check reads the DB (receipts, appointments, giftcards, customers) itself.
#   python3 t619m.py <app folder>
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, threading, http.cookiejar, datetime as _dt, glob
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T619'; T5 = '/tmp/claude-0/T586'; PORT = 19941; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-619m.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
A = D + '/app'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True)
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; T = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA, HA = T['TAMMY'], T['HANA']
H = D + '/h619.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'hash') { echo password_hash($argv[2], PASSWORD_DEFAULT); }
""" % A)
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
PW = 'adm619-' + os.urandom(4).hex()
h('set', json.dumps({'admin_hash': h('hash', PW), 'gift_on': '1', 'hours': json.dumps({str(w): {'open': '09:00', 'close': '21:00'} for w in range(7)})}))
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '6'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w'))
atexit.register(lambda: sv.terminate()); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
say('== LAMWEB test 619 modules (checkout / tips / gift / customers / report / backup) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
TODAY = time.strftime('%Y-%m-%d')
def mk(ph, name, staff, sid, start):
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', '%s', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), '%s')" % (TODAY, start, staff, sid, name, ph, os.urandom(8).hex()))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def price(sid): return float(sql("SELECT price FROM services WHERE id = %d" % sid)[0]['price'])
def pay(aid, sid, staff, pays, **k):
    b = {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid, 'price': price(sid), 'staff': staff}], 'pays': pays}; b.update(k); return api('checkout2', b)
def st(aid): return sql("SELECT status FROM appointments WHERE id = %d" % aid)[0]['status']
def nrc(): return int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n'])
P = price(PD)
# ---- 5 Checkout
a1 = mk('+15155550401', 'CO ONE', TA, PD, 600); n0 = nrc(); c, r = pay(a1, PD, TA, [{'m': 'Card', 'amt': P}])
ok('5.1 Checkout dung so tien (the) -> 1 hoa don, hen = paid, tong = gia dich vu', c == 200 and r.get('ok') and nrc() == n0 + 1 and st(a1) == 'paid' and abs(float(r['receipt'].get('total', 0)) - P) < 0.01, (c, r.get('error'), st(a1)))
a2 = mk('+15155550402', 'CO TWO', TA, PD, 660); n0 = nrc(); c, r = pay(a2, PD, TA, [{'m': 'Card', 'amt': P - 5}])
ok('5.2 Tra THIEU 5$ -> tu choi, KHONG co hoa don, hen van chua tra', c >= 400 and nrc() == n0 and st(a2) != 'paid', (c, r))
a3 = mk('+15155550403', 'CO DUP', HA, PD, 700); n0 = nrc(); res = [None, None]; ev = threading.Event()
def g(k): ev.wait(); res[k] = pay(a3, PD, HA, [{'m': 'Cash', 'amt': P}])
th = [threading.Thread(target=g, args=(k,)) for k in range(2)]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
ok('5.3 2 may bam Checkout CUNG LUC cung 1 khach -> DUNG 1 hoa don, may kia "already paid"', nrc() == n0 + 1 and sorted(x[0] for x in res)[0] == 200 and any(x[0] >= 400 for x in res), [(x[0], x[1].get('error')) for x in res])
a4 = mk('+15155550404', 'CO CASH', HA, PD, 760); c, r = pay(a4, PD, HA, [{'m': 'Cash', 'amt': P, 'given': P - 1}])
ok('5.4 Tien mat dua it hon so tien -> tu choi', c >= 400 and st(a4) != 'paid', (c, r))
# ---- 6 Tips
a5 = mk('+15155550405', 'TIP ONE', TA, PD, 800); c, r = pay(a5, PD, TA, [{'m': 'Card', 'amt': P}], tips=[{'staff': TA, 'amt': 10}])
rc = r.get('receipt', {}) if isinstance(r, dict) else {}
ok('6.1 Tip the 10$ cho TAMMY -> hoa don ghi tip 10$ cua TAMMY', c == 200 and abs(sum(float(x.get('amt', 0)) for x in (rc.get('tips') or [])) - 10) < 0.01, (c, r.get('error'), rc.get('tips')))
a6 = mk('+15155550406', 'TIP NEG', TA, PD, 840); c, r = pay(a6, PD, TA, [{'m': 'Card', 'amt': P}], tips=[{'staff': TA, 'amt': -5}])
ok('6.2 Tip AM (-5$) -> tu choi', c >= 400 and st(a6) != 'paid', (c, r))
a7 = mk('+15155550407', 'TIP CASHONLY', TA, PD, 880); c, r = pay(a7, PD, TA, [{'m': 'Cash', 'amt': P}], tips=[{'staff': TA, 'amt': 5}])
ok('6.3 Tip THE ma khach tra toan tien mat -> tu choi (phai co phan the)', c >= 400 and st(a7) != 'paid', (c, r))
c, mr = api('money_report', None, '&from=%s&to=%s' % (TODAY, TODAY))
techs = mr.get('techs') or mr.get('rows') or []
txt = json.dumps(mr)
tot_db = round(sum(float(x['total']) for x in sql("SELECT total FROM receipts WHERE status <> 'void'") ), 2) if True else 0
TT = (mr.get('totals') or {}); tam = [t for t in (mr.get('techs') or []) if str(t.get('name', '')).upper() == 'TAMMY']
ok('10.1 Bao cao tien (money_report) hom nay: tong tip THE = 10$, co dong TAMMY', c == 200 and abs(float(TT.get('cardTips', -1)) - 10) < 0.01 and tam, (c, TT.get('cardTips'), [t.get('name') for t in mr.get('techs') or []]))
ok('10.2 Tong bao cao (totals.total) = tong cac hoa don trong DB (%s$)' % tot_db, c == 200 and abs(float(TT.get('total', -1)) - tot_db) < 0.01, (TT.get('total'), tot_db))
# ---- 8 Gift card balance
sql("INSERT INTO giftcards (code, amount, balance, status, buyer_phone, to_phone, created_at) VALUES ('GIFT-6190-0001', 30, 30, 'active', '+15155550410', '', datetime('now'))")
def bal(): return float(sql("SELECT balance FROM giftcards WHERE code = 'GIFT-6190-0001'")[0]['balance'])
a8 = mk('+15155550411', 'GIFT ONE', TA, PD, 920); c, r = pay(a8, PD, TA, [{'m': 'Card', 'amt': P - 20}], gift_code='GIFT-6190-0001', gift_amount=20)
ok('8.1 The qua tang 30$: tra 20$ bang the + phan con lai bang the tin dung -> so du con 10$', c == 200 and abs(bal() - 10) < 0.01, (c, r.get('error'), bal()))
a9 = mk('+15155550412', 'GIFT OVER', TA, PD, 960); c, r = pay(a9, PD, TA, [{'m': 'Card', 'amt': P - 20}], gift_code='GIFT-6190-0001', gift_amount=20)
ok('8.2 Dung 20$ khi the chi con 10$ -> tu choi, so du VAN 10$', c >= 400 and abs(bal() - 10) < 0.01 and st(a9) != 'paid', (c, r.get('error'), bal()))
b1, b2 = mk('+15155550413', 'GIFT PA', TA, PD, 1000), mk('+15155550414', 'GIFT PB', HA, PD, 1000); res = [None, None]; ev = threading.Event()
def g8(k, aid, stf): ev.wait(); res[k] = pay(aid, PD, stf, [{'m': 'Card', 'amt': P - 8}], gift_code='GIFT-6190-0001', gift_amount=8)
th = [threading.Thread(target=g8, args=(0, b1, TA)), threading.Thread(target=g8, args=(1, b2, HA))]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
ok('8.3 2 may CUNG LUC dung 8$ moi may tu the con 10$ -> chi 1 may duoc, so du 2$ (KHONG am)', abs(bal() - 2) < 0.01 and sum(1 for x in res if x[0] == 200) == 1, (bal(), [(x[0], x[1].get('error')) for x in res]))
# ---- 7 Customers
c, r = api('customers', None, '&q=5550401'); cj = json.dumps(r)
n1 = int(sql("SELECT COUNT(*) AS n FROM customers WHERE phone = '+15155550401'")[0]['n'])
sql("INSERT OR IGNORE INTO customers (phone, name, created_at) VALUES ('+15155550401', 'DUP TRY', datetime('now'))")
n2 = int(sql("SELECT COUNT(*) AS n FROM customers WHERE phone = '+15155550401'")[0]['n'])
ok('7.1 Moi so dien thoai = 1 khach (UNIQUE): them trung so -> van 1', n2 == 1 and n2 >= n1, (n1, n2))
# ---- 12 Backup
c, r = api('backup_now', {})
files = [f for f in glob.glob(A + '/**/*backup*', recursive=True) if os.path.isfile(f) and os.path.getmtime(f) > time.time() - 120] + [f for f in glob.glob('/tmp/claude-0/T619/**/*.gz', recursive=True)]
ok('12.1 Sao luu ngay (backup_now) chay khong loi (ban test: SQLite)', c == 200 and r.get('ok'), (c, r))
logs = open(D + '/php.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
