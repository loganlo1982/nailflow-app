const { chromium, devices } = require('/opt/node22/lib/node_modules/playwright');
const { spawn } = require('child_process'); const fs = require('fs');
exports.run = async (CODE, PORT, OUT, body) => {
  fs.mkdirSync(OUT, { recursive: true }); const W = `/tmp/claude-0/t561/w${PORT}`; fs.rmSync(W, { recursive: true, force: true }); fs.mkdirSync(W, { recursive: true });
  fs.copyFileSync('/tmp/claude-0/tdb/base.sqlite', W + '/db.sqlite');
  fs.writeFileSync(CODE + '/inc/config.php', `<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'${W}/db.sqlite','site_url'=>'http://127.0.0.1:${PORT}');\n`);
  const ENV = { ...process.env, TZ: 'America/Chicago' }; delete ENV.SALON_TEST_SITE;
  const B = `http://127.0.0.1:${PORT}`; const sleep = (ms) => new Promise(r => setTimeout(r, ms)); const PW = fs.readFileSync('/tmp/claude-0/qa-pass.txt', 'utf8').trim();
  const R = []; const ok = (n, c, i) => { R.push({ n, ok: !!c }); console.log((c ? '✓ ' : '✗ ') + n, c ? '' : String(JSON.stringify(i)).slice(0, 900)); };
  const CAP = `window.Capacitor = { isNativePlatform: () => true, getPlatform: () => 'ios', Plugins: { FirebaseMessaging: { addListener: () => ({ remove() {} }), checkPermissions: async () => ({ receive: 'denied' }), requestPermissions: async () => ({ receive: 'denied' }), getToken: async () => ({ token: '' }) }, Preferences: { get: async () => ({ value: null }), set: async () => {}, remove: async () => {} } } }; try { localStorage.setItem('nfDevRole', 'admin'); } catch (e) {}`;
  const srv = spawn('php', ['-d', 'session.save_path=' + W, '-S', '127.0.0.1:' + PORT, '-t', CODE, '/tmp/claude-0/router.php'], { env: { ...ENV, PHP_CLI_SERVER_WORKERS: '3' }, stdio: 'ignore', detached: true }); await sleep(1200);
  const br = await chromium.launch(); const pe = [];
  const open = async (dev, app, dark, label, path) => {
    const ctx = await br.newContext({ ...dev, colorScheme: dark ? 'dark' : 'light' }); await ctx.addInitScript(app ? CAP : `try { localStorage.setItem('nfDevRole', 'admin'); } catch (e) {}`);
    await ctx.clock.install({ time: new Date('2026-10-30T10:30:00-05:00') }); await ctx.clock.resume();
    const lr = await ctx.request.post(B + '/api.php?action=login', { data: { password: PW } }); if (!lr.ok()) throw new Error('login ' + lr.status());
    const p = await ctx.newPage(); p.on('pageerror', e => pe.push(label + ': ' + e.message)); p.on('dialog', d => d.dismiss().catch(() => {}));
    await p.goto(B + (path || '/admin/')); for (let k = 0; k < 5; k++) { try { await p.waitForLoadState('load'); await sleep(2000); await p.evaluate(() => { if (!S.csrf) throw 1; }); break; } catch (e) { await sleep(1500); } }
    await p.evaluate((d) => { try { LOOK.device(d ? 'dark' : 'light'); } catch (e) {} }, dark); await sleep(200);
    await p.evaluate(() => { closeSheet(); S.hmPage = 0; goHome(); }); await sleep(1300); return { ctx, p };
  };
  try { await body({ open, ok, sleep, devices, OUT, B, pe }); } catch (e) { console.log('ERR', e.stack); } finally { await br.close(); try { process.kill(-srv.pid); } catch (e) {} fs.writeFileSync(CODE + '/inc/config.php', "<?php\nreturn array('driver'=>'sqlite','sqlite_path'=>'/tmp/x.sqlite');\n"); }
  console.log('PASS', R.filter(x => x.ok).length + '/' + R.length, 'pageerrors', pe.length, pe.slice(0, 3));
};
