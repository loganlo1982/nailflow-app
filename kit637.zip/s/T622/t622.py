# LAMWEB test 622 – the review fixes (REVIEW-DOC-LAP-CHAT 01/11). Local copy, SQLite of its own, FAKE PayPal (127.0.0.1), nothing real.
#   python3 t622.py <app folder>
import subprocess, json, os, sys, time, urllib.request, urllib.parse, shutil, atexit, threading, http.server, http.cookiejar, re, datetime as _dt
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T622'; T5 = '/tmp/claude-0/T586'; PORT = 19931; PPP = 19932; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-622.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
A = D + '/app'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True)
p = A + '/inc/paypal.php'; s = open(p).read()   # TEST ONLY (this copy): PayPal = the fake server below
s = s.replace("function pp_base(): string { return", "function pp_base(): string { if (getenv('NF_PP_BASE')) return (string)getenv('NF_PP_BASE'); return", 1); open(p, 'w').write(s)
ENV = {**os.environ, 'TZ': 'America/Chicago', 'NF_PP_BASE': 'http://127.0.0.1:%d' % PPP}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; PD, GM = S['Pedicure'], S['Gel Manicure']
H = D + '/h622.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'hash') { echo password_hash($argv[2], PASSWORD_DEFAULT); }
if ($a === 'gfind') { require_once '%s/inc/giftcards.php'; $g = gift_find($argv[2]); echo json_encode($g ? ['id' => (int)$g['id'], 'balance' => (float)$g['balance']] : null); }
""" % (A, A))
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
ADMPW = 'adm622-' + os.urandom(4).hex(); GUPW = 'guest622-' + os.urandom(4).hex()
h('set', json.dumps({'online_booking': '1', 'dep_on': '1', 'dep_min': '2', 'dep_amount': '10', 'paypal_client_id': 'TESTCLIENT', 'paypal_secret': 'TESTSECRET', 'paypal_mode': 'sandbox',
    'admin_hash': h('hash', ADMPW), 'guest_on': '1', 'guest_hash': h('hash', GUPW), 'hours': json.dumps({str(w): {'open': '09:00', 'close': '21:00'} for w in range(7)})}))
# fake PayPal: token, order, capture (slow: 1.2 s, so two taps overlap), refund
PPLOG = []; ORD = {}
class PP(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def j(self, c, o): b = json.dumps(o).encode(); self.send_response(c); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0) or 0); body = self.rfile.read(n).decode() if n else ''; pth = self.path; PPLOG.append(('POST', pth, self.headers.get('PayPal-Request-Id', '')))
        if pth == '/v1/oauth2/token': return self.j(200, {'access_token': 'TOK', 'expires_in': 3000})
        if pth == '/v2/checkout/orders':
            b = json.loads(body); oid = 'ORD%d' % (len(ORD) + 1); ORD[oid] = b['purchase_units'][0]['amount']['value']; return self.j(201, {'id': oid, 'status': 'CREATED'})
        m = re.match(r'^/v2/checkout/orders/([^/]+)/capture$', pth)
        if m:
            time.sleep(1.2); v = ORD.get(m.group(1), '0.00')
            return self.j(201, {'id': m.group(1), 'status': 'COMPLETED', 'purchase_units': [{'payments': {'captures': [{'id': 'CAP-' + m.group(1), 'status': 'COMPLETED', 'amount': {'currency_code': 'USD', 'value': v}}]}}]})
        if '/refund' in pth: return self.j(201, {'id': 'REF1', 'status': 'COMPLETED'})
        return self.j(404, {})
pps = http.server.ThreadingHTTPServer(('127.0.0.1', PPP), PP); threading.Thread(target=pps.serve_forever, daemon=True).start()
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '6'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w'))
atexit.register(lambda: (sv.terminate(), pps.shutdown())); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT
def api(action, body=None, jar=None, csrf=None):
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)) if jar is not None else urllib.request.build_opener()
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': csrf} if csrf else {})
    rq = urllib.request.Request(B + '?action=' + action, data=json.dumps(body or {}).encode(), headers=hd)
    try: r = op.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
DAY = lambda n: (_dt.date.today() + _dt.timedelta(days=n)).isoformat()
def ins_appt(ph, name, date, start, need, state, tok, rn=0):
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token, confirm_need, confirm_state, resched_n) VALUES ('%s', %d, 45, 0, '%d', '%s', '%s', 'booked', 'online', 'appt', '', datetime('now'), '%s', %d, '%s', %d)" % (date, start, PD, name, ph, tok, need, state, rn))
    return sql("SELECT id FROM appointments WHERE token = '%s'" % tok)[0]['id']
def appt(i): return sql("SELECT * FROM appointments WHERE id = %d" % i)[0]
say('== LAMWEB test 622 (review fixes) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · app ' + A0)
# 1 (HIGH) reschedule must not confirm a "must confirm by text" booking
i1 = ins_appt('+15155550301', 'NEWC', DAY(3), 600, 1, '', 'TK622A')
c, r = api('reschedule', {'t': 'TK622A', 'date': DAY(4), 'start': 660, 'anyTech': True}); a = appt(i1)
ok('1 dat online "phai confirm bang tin" (confirm_need=1) -> doi gio bang token -> gio MOI, confirm_state van KHONG phai yes', r.get('ok') and a['appt_date'] == DAY(4) and a['start_min'] == 660 and a['confirm_state'] != 'yes', (c, r, a['appt_date'], a['start_min'], a['confirm_state']))
i2 = ins_appt('+15155550302', 'OLDC', DAY(3), 720, 0, '', 'TK622B')
c, r = api('reschedule', {'t': 'TK622B', 'date': DAY(4), 'start': 780, 'anyTech': True}); a = appt(i2)
ok('1b khach khong can confirm (confirm_need=0) -> doi gio = xac nhan nhu cu (confirm_state yes)', r.get('ok') and a['confirm_state'] == 'yes', (c, r, a['confirm_state']))
# 9 two taps at once with 1 change left -> only 1 move
bad9 = []
for k9 in range(6):
    i3 = ins_appt('+1515555%04d' % (330 + k9), 'TAPS', DAY(5 + k9), 600, 0, 'yes', 'TK622C%d' % k9, 1); res = [None, None]; ev = threading.Event()
    def g9(k, st, tk='TK622C%d' % k9, dd=DAY(12 + k9)): ev.wait(); res[k] = api('reschedule', {'t': tk, 'date': dd, 'start': st, 'anyTech': True})
    th = [threading.Thread(target=g9, args=(0, 600)), threading.Thread(target=g9, args=(1, 720))]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
    if int(appt(i3)['resched_n']) != 2: bad9.append((k9, appt(i3)['resched_n']))
ok('9 con 1 lan doi + 2 lan bam cung luc (6 vong) -> moi vong chi 1 lan doi (resched_n = 2, khong 3)', not bad9, bad9)
# 2 (HIGH) deposit: two captures of the same PayPal order at once
c, r = api('dep_order', {'date': DAY(3), 'start': 840, 'people': [0, 0], 'svcs': [[{'id': PD}], [{'id': PD}]], 'name': 'Kim Dep', 'phone': '(515) 555-0310'}); oid = r.get('id', '')
ok('2 dep_order (nhom 2 nguoi) -> PayPal order (gia)', c == 200 and oid.startswith('ORD'), (c, r))
res = [None, None]; ev = threading.Event()
def g2(k): ev.wait(); res[k] = api('dep_capture', {'id': oid})
th = [threading.Thread(target=g2, args=(k,)) for k in range(2)]; [t.start() for t in th]; time.sleep(0.2); ev.set(); [t.join() for t in th]
n2 = sql("SELECT COUNT(*) AS n FROM appointments WHERE phone = '+15155550310' AND status = 'booked'")[0]['n']; refunds = [x for x in PPLOG if '/refund' in x[1]]
dep = sql("SELECT status, appt_id FROM deposits WHERE order_id = '%s'" % oid)
ok('2 bam "Pay" 2 lan cung luc -> DUNG 1 nhom (2 hen), 0 lan hoan tien, coc = paid', int(n2) == 2 and not refunds and dep and dep[0]['status'] == 'paid', (n2, refunds, dep, [(x[0], x[1].get('error', x[1].get('ok'))) for x in res]))
ok('2b ca 2 lan bam deu nhan "ok" + cung 1 lich (khach khong thay loi)', all(x and x[0] == 200 and x[1].get('ok') for x in res) and res[0][1].get('token') == res[1][1].get('token'), [(x[0], x[1]) for x in res])
c, r = api('dep_capture', {'id': oid})
ok('2c bam lai sau khi xong -> lich cu (khong dat lan 2)', c == 200 and r.get('ok') and int(sql("SELECT COUNT(*) AS n FROM appointments WHERE phone = '+15155550310' AND status = 'booked'")[0]['n']) == 2, (c, r))
# 5 gift card by phone: no full code
sql("INSERT INTO giftcards (code, amount, balance, status, buyer_phone, to_phone, created_at) VALUES ('ABCD-EFGH-JKLM', 50, 50, 'active', '+15155550320', '', datetime('now'))")
jar = http.cookiejar.CookieJar(); c, r = api('login', {'password': ADMPW}, jar); cs = r.get('csrf')
c, r = api('gift_by_phone', {'phone': '(515) 555-0320'}, jar, cs); cards = r.get('cards', [])
ok('5 Checkout "Find by phone" -> the + so du, KHONG co ma day du', cards and 'ABCD' not in json.dumps(r) and cards[0]['balance'] == 50 and cards[0]['masked'], (c, r))
ref = cards[0]['code'] if cards else ''
c, r = api('gift_lookup', {'code': ref}, jar, cs)
ok('5b dung the vua tim (ma tham chieu) -> tim duoc the 50$ (thanh toan van chay)', c == 200 and (r.get('card') or {}).get('balance') == 50, (c, r))
g = h('gfind', ref); gx = h('gfind', re.sub(r'X.*$', 'X000000', ref) if ref else 'ID1X000000')
ok('5c ma tham chieu gia (doi so kiem) -> khong tim duoc the', g and g.get('balance') == 50 and gx is None, (g, gx))
# 8 guest login on the release api.php: no owner-only actions
jg = http.cookiejar.CookieJar(); c, r = api('login', {'password': GUPW}, jg); gcs = r.get('csrf')
c1, r1 = api('totp_setup', {}, jar, cs)
c2, r2 = api('totp_setup', {}, jg, gcs)
ok('8 dang nhap Guest (api.php release) -> viec chi chu tiem (totp_setup: chu = 200) bi chan 403 "Not in the guest login"', r.get('guest') and c1 == 200 and c2 == 403 and 'guest' in json.dumps(r2).lower(), (r.get('guest'), c1, c2, r2))
c3, r3 = api('me', {}, jg, gcs)
ok('8b Guest van xem duoc trang chu (me)', c3 == 200, (c3, r3))
logs = open(D + '/php.log').read()
ok('9 khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
