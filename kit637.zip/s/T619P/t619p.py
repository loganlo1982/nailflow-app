# LAMWEB test 619 phan 3 – staff (add / PIN / remove), commission + $1 rule, weekly payroll + close week, close day lock, SMS STOP / START.
# Local copy, SQLite of its own, nothing real (no PayPal / SMS / card). Every check reads the DB (receipts, appointments, giftcards, customers) itself.
#   python3 t619m.py <app folder>
import subprocess, json, os, sys, time, urllib.request, urllib.parse, shutil, atexit, threading, http.cookiejar, datetime as _dt, glob
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T619P'; T5 = '/tmp/claude-0/T586'; PORT = 19943; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-619p.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
A = D + '/app'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True)
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; T = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA, HA = T['TAMMY'], T['HANA']
H = D + '/h619p.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'hash') { echo password_hash($argv[2], PASSWORD_DEFAULT); }
if ($a === 'fc') { require_once '%s/inc/checkout.php'; echo json_encode(fee_cfg()); }
if ($a === 'out') { require_once '%s/inc/outbox.php'; echo json_encode([out_not_stopped($argv[2]), out_can_appt($argv[2])]); }
if ($a === 'sig') { $p = json_decode($argv[3], true); ksort($p); $t = ''; foreach ($p as $k => $v) $t .= $k . $v; echo base64_encode(hash_hmac('sha1', $argv[2] . $t, setting('twilio_token'), true)); }
""" % (A, A, A))
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
PW = 'adm619-' + os.urandom(4).hex()
h('set', json.dumps({'admin_hash': h('hash', PW), 'gift_on': '1', 'hours': json.dumps({str(w): {'open': '09:00', 'close': '21:00'} for w in range(7)})}))
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '6'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w'))
atexit.register(lambda: sv.terminate()); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
say('== LAMWEB test 619 phan 3 (staff / payroll / $1 / close day / SMS STOP) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
TODAY = time.strftime('%Y-%m-%d')
def mk(ph, name, staff, sid, start):
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', '%s', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), '%s')" % (TODAY, start, staff, sid, name, ph, os.urandom(8).hex()))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def price(sid): return float(sql("SELECT price FROM services WHERE id = %d" % sid)[0]['price'])
def pay(aid, sid, staff, pays, **k):
    b = {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid, 'price': price(sid), 'staff': staff}], 'pays': pays}; b.update(k); return api('checkout2', b)
def st(aid): return sql("SELECT status FROM appointments WHERE id = %d" % aid)[0]['status']
def nrc(): return int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n'])
P = price(PD)
def row(sid, day=None):
    c, w = api('payroll_week', None, '&day=' + (day or TODAY))
    for x in (w.get('rows') or []):
        if int(x.get('staff', -1)) == sid: return x
    return {'_w': c, '_keys': list(w.keys())[:8]}
def stf(sid): return sql("SELECT * FROM staff WHERE id = %d" % sid)[0]
# ---- 1 Staff
c, r = api('save_staff_one', {'id': 0, 'name': 'new tech619', 'commission': 55})
nt = sql("SELECT id, name, active FROM staff WHERE name = 'NEW TECH619'")
ok('1.1 Them tho moi -> 1 dong staff, ten viet HOA, active', c == 200 and len(nt) == 1 and int(nt[0]['active']) == 1, (c, r, nt))
NT = int(nt[0]['id']) if nt else 0
c, r = api('save_staff_one', {'id': NT, 'name': 'NEW TECH619', 'commission': 150})
ok('1.2 Commission 150% -> tu choi', c >= 400, (c, r))
c, r = api('staff_set_pin', {'id': NT, 'pin': '1234'}); h0 = stf(NT)['pin_hash']
ok('1.3 PIN de doan (1234) -> tu choi, KHONG luu', c >= 400 and h0 in ('', None), (c, r))
c, r = api('staff_set_pin', {'id': NT, 'pin': '7391'}); s1 = stf(NT)
ok('1.4 PIN 4 so hop le -> luu dang hash (khong luu PIN tran), pin_ver tang', c == 200 and s1['pin_hash'] not in ('', '7391') and str(s1['pin_hash']).startswith('$'), (c, r))
sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES (date('%s', '+3 days'), 600, 45, %d, '%d', 'FUT ONE', '+15155550431', 'booked', 'admin', 'appt', '', datetime('now'), 'f619a')" % (TODAY, NT, PD))
sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES (date('%s', '-3 days'), 600, 45, %d, '%d', 'OLD ONE', '+15155550432', 'paid', 'admin', 'appt', '', datetime('now'), 'f619b')" % (TODAY, NT, PD))
c, r = api('remove_staff', {'id': NT}); s2 = stf(NT)
fut = sql("SELECT staff_id FROM appointments WHERE token = 'f619a'")[0]['staff_id']; old = sql("SELECT staff_id FROM appointments WHERE token = 'f619b'")[0]['staff_id']
ok('1.5 Xoa tho -> chi TAT (active 0, PIN xoa), hen SAP TOI -> ANYONE, hen CU giu nguyen tho (lich su / luong)', c == 200 and int(s2['active']) == 0 and s2['pin_hash'] == '' and int(fut) == 0 and int(old) == NT, (c, r, s2['active'], fut, old))
# ---- 2 Commission / payroll
sql("UPDATE staff SET commission_pct = 60, pct_hist = '' WHERE id = %d" % TA); sql("UPDATE staff SET commission_pct = 50, pct_hist = '' WHERE id = %d" % HA)
h('set', json.dumps({'admin_fee_on': '0', 'payroll_split_on': '0'}))
a1 = mk('+15155550441', 'PAY ONE', TA, PD, 600); c, r = pay(a1, PD, TA, [{'m': 'Card', 'amt': P}], tips=[{'staff': TA, 'amt': 10}])
x = row(TA)
ok('2.1 Luong tuan: TAMMY doanh so = %.2f, commission 60%% = %.2f, tip the 10' % (P, round(P * .6, 2)), c == 200 and abs(float(x.get('sales', -1)) - P) < .01 and abs(float(x.get('commission', -1)) - round(P * .6, 2)) < .01 and abs(float(x.get('tips', -1)) - 10) < .01, (c, r.get('error'), {k: x.get(k) for k in ('sales', 'commission', 'tips', 'total', '_w', '_keys')}))
ok('2.2 Tong = commission + tip (chua dieu chinh)', abs(float(x.get('total', -1)) - round(round(P * .6, 2) + 10, 2)) < .01, x.get('total'))
c, w = api('payroll_adj', {'day': TODAY, 'staff': TA, 'amount': 5, 'reason': 'test bonus 619'}); x2 = row(TA)
ok('2.3 Dieu chinh +5$ (co ly do) -> tong tang dung 5$', c == 200 and abs(float(x2.get('total', -1)) - float(x.get('total', 0)) - 5) < .01, (c, x2.get('total'), x.get('total')))
c, w = api('payroll_adj', {'day': TODAY, 'staff': TA, 'amount': 5, 'reason': ''})
ok('2.4 Dieu chinh KHONG ly do -> tu choi', c >= 400 and abs(float(row(TA).get('total', -1)) - float(x2.get('total', 0))) < .01, (c, w))
# ---- 3 $1 rule (admin fee -> HANA)
h('set', json.dumps({'admin_fee_on': '1', 'admin_fee_staff': str(HA), 'admin_fee_min': '30', 'admin_fee_amt': '1'}))
xt0, xh0 = row(TA), row(HA)
a2 = mk('+15155550442', 'FEE ONE', TA, PD, 700); c, r = pay(a2, PD, TA, [{'m': 'Card', 'amt': P}], splits=[{'staff': TA, 'amt': P}])  # the Checkout page always sends the split (old payload without it: no $1 – see report)
xt1, xh1 = row(TA), row(HA)
dt = round(float(xt1.get('sales', 0)) - float(xt0.get('sales', 0)), 2); dh = round(float(xh1.get('sales', 0)) - float(xh0.get('sales', 0)), 2)
ok('3.1 Luat $1 (dv >= 30$): TAMMY doanh so +%.2f (= gia - 1), HANA (tho nhan $1) doanh so KHONG tang (the $1 khong tinh luong)' % (P - 1), c == 200 and abs(dt - (P - 1)) < .01 and abs(dh) < .01, (c, r.get('error'), dt, dh))
h('set', json.dumps({'admin_fee_on': '0'}))
# ---- 4 Close week + void after
wk = row(TA); tot_before = float(wk.get('total', 0))
c, w = api('payroll_close', {'day': TODAY, 'force': 1})
snap = sql("SELECT status FROM payroll_weeks")
ok('4.1 Chot tuan (payroll_close) -> tuan = closed', c == 200 and any(s['status'] == 'closed' for s in snap), (c, str(w)[:200], snap))
rid = int(sql("SELECT receipt_id FROM appointments WHERE id = %d" % a1)[0]['receipt_id'])
c, r = api('receipt_void', {'id': rid, 'reason': 'test void 619', 'dps_done': 1})
ok('4.2 Void hoa don cua tuan DA CHOT -> phai hoi truoc (PAYROLL_CLOSED 409)', c == 409, (c, r))
c, r = api('receipt_void', {'id': rid, 'reason': 'test void 619', 'dps_done': 1, 'ok_closed': 1})
c2, w2 = api('payroll_week', None, '&day=' + TODAY); tc = [x for x in (w2.get('rows') or []) if int(x['staff']) == TA]
nxt = sql("SELECT amount, week_start FROM payroll_adj WHERE staff_id = %d AND reason LIKE '%%[from %%'" % TA)
ok('4.3 Void sau khi chot: tuan da chot GIU nguyen tong; phan chenh lech (am) sang TUAN SAU', c == 200 and tc and abs(float(tc[0]['total']) - tot_before) < .01 and len(nxt) == 1 and float(nxt[0]['amount']) < 0 and nxt[0]['week_start'] > TODAY, (c, r.get('error'), tc and tc[0]['total'], tot_before, nxt))
sql("UPDATE appointments SET status = 'cancelled' WHERE id = %d" % a1)  # the voided visit would block Close day (checked in, not out)
# ---- 5 Close day lock
c, cd = api('close_day', None, '&day=' + TODAY)
card_db = round(sum(float(x['card_amt']) for x in sql("SELECT card_amt FROM receipts WHERE status = 'paid' AND day = '%s'" % TODAY)), 2)
ok('5.1 Close day: so tien THE = tong hoa don the trong DB (%.2f)' % card_db, c == 200 and card_db in [round(float(v), 2) for v in [cd.get('card', -1), (cd.get('totals') or {}).get('card', -1), (cd.get('money') or {}).get('card', -1)] if isinstance(v, (int, float, str))], (c, {k: cd.get(k) for k in list(cd.keys())[:12]}))
cash_db = round(sum(float(x['cash_amt']) for x in sql("SELECT cash_amt FROM receipts WHERE status = 'paid' AND day = '%s'" % TODAY)), 2)
api('close_day_count', {'day': TODAY, 'counted': cash_db, 'dps': card_db, 'note': 'test 619'}); c, r = api('close_day_lock', {'day': TODAY})
a3 = mk('+15155550443', 'LOCKED DAY', HA, PD, 900); c3, r3 = pay(a3, PD, HA, [{'m': 'Cash', 'amt': P}])
ok('5.2 Khoa ngay (Close day 🔒) -> checkout hom do bi tu choi, khong hoa don', c == 200 and c3 >= 400 and st(a3) != 'paid', (c, r, c3, r3))
c, r = api('close_day_unlock', {'day': TODAY, 'reason': ''})
ok('5.3 Mo khoa KHONG ly do -> tu choi', c >= 400, (c, r))
c, r = api('close_day_unlock', {'day': TODAY, 'reason': 'test unlock 619'}); c3, r3 = pay(a3, PD, HA, [{'m': 'Cash', 'amt': P}])
ok('5.4 Mo khoa co ly do -> checkout lai duoc', c == 200 and c3 == 200 and st(a3) == 'paid', (c, r, c3, r3.get('error')))
# ---- 6 SMS STOP / START (Twilio webhook, chu ky gia)
h('set', json.dumps({'twilio_token': 'tok-test-' + os.urandom(4).hex()}))
URL = 'http://127.0.0.1:%d/sms_in.php' % PORT
def sms(body, good=True, frm='+15155550451'):
    p = {'From': frm, 'Body': body, 'To': '+15155550299'}; sig = h('sig', URL, json.dumps(p)); sig = sig if isinstance(sig, str) else str(sig)
    rq = urllib.request.Request(URL, data=urllib.parse.urlencode(p).encode(), headers={'X-Twilio-Signature': sig if good else 'AAAA' + sig[4:]})
    try: return urllib.request.urlopen(rq, timeout=30).status
    except urllib.error.HTTPError as e: return e.code
def opt(ph='+15155550451'):
    x = sql("SELECT opted_out FROM customers WHERE phone = '%s'" % ph); return int(x[0]['opted_out']) if x else None
c = sms('STOP', good=False)
ok('6.1 Tin "STOP" chu ky SAI -> 403, khong doi gi', c == 403 and opt() in (None, 0), (c, opt()))
c = sms('Stop')
ok('6.2 Tin "Stop" (chu ky dung) -> khach opted_out = 1', c == 200 and opt() == 1, (c, opt()))
o = h('out', '+15155550451')
ok('6.3 Khach STOP -> KHONG gui khuyen mai (out_not_stopped = false) nhung VAN gui tin hen (out_can_appt = true)', o == [False, True], o)
c = sms('START')
ok('6.4 Tin "START" -> opted_out = 0', c == 200 and opt() == 0, (c, opt()))
logs = open(D + '/php.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
