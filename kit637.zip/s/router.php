<?php
// local test router for php -S: static files as they are, folders → index.php
$u = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); $f = $_SERVER['DOCUMENT_ROOT'] . $u;
if ($u !== '/' && is_file($f) && !str_ends_with($f, '.php')) return false;
if (is_dir($f)) { $i = rtrim($f, '/') . '/index.php'; if (is_file($i)) { if (!str_ends_with($u, '/')) { header('Location: ' . $u . '/'); exit; } chdir(dirname($i)); $_SERVER['SCRIPT_NAME'] = rtrim($u, '/') . '/index.php'; require $i; exit; } }
if (is_file($f)) { chdir(dirname($f)); require $f; exit; }
http_response_code(404); echo 'nf';
