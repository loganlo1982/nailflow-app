# LAMWEB test 629 – Telnyx missed call text back: the cron (cron/tx-mp3.php) sends it by itself (before: only call_in tick / the owner's page -> up to ~1 h late).
#   Ban sao + SQLite rieng, so 555-01xx, SMS Server GIA (127.0.0.1:9) – khong tin that.
import subprocess, json, os, sys, time, urllib.request, shutil, atexit, threading, http.cookiejar, datetime as _dt, glob
A0 = os.path.abspath(sys.argv[1]); D = '/tmp/claude-0/T629'; T5 = '/tmp/claude-0/T586'; PORT = 19953; DB = D + '/db.sqlite'
R = []; out = open(D + '/test-629.txt', 'w')
def say(s): print(s, flush=True); out.write(s + '\n'); out.flush()
def ok(n, c, i=''): R.append(bool(c)); say(('✓ ' if c else '✗ ') + n + ('' if c else '   → ' + str(i)[:500]))
A = D + '/app'; shutil.rmtree(A, ignore_errors=True); shutil.copytree(A0, A, symlinks=True)
ENV = {**os.environ, 'TZ': 'America/Chicago'}
def sh(*a): return subprocess.run(a, capture_output=True, text=True, env=ENV)
def sql(q): r = sh('php', T5 + '/db.php', DB, q); return json.loads(r.stdout or '[]') if r.returncode == 0 else ('ERR', r.stderr)
shutil.copy('/tmp/claude-0/tdb/base.sqlite', DB)
seed = json.loads(sh('php', T5 + '/seed.php', A, DB, str(PORT)).stdout); S = seed['S']; T = seed['T']; PD, GM = S['Pedicure'], S['Gel Manicure']; TA, HA = T['TAMMY'], T['HANA']
H = D + '/h629.php'
open(H, 'w').write("""<?php require '%s/inc/core.php'; settings(); $a = $argv[1];
if ($a === 'set') { foreach (json_decode($argv[2], true) as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'hash') { echo password_hash($argv[2], PASSWORD_DEFAULT); }
if ($a === 'sig') { $p = json_decode($argv[3], true); ksort($p); $t = ''; foreach ($p as $k => $v) $t .= $k . $v; echo base64_encode(hash_hmac('sha1', $argv[2] . $t, setting('twilio_token'), true)); }
""" % A)
def h(*a):
    r = sh('php', H, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return r.stdout
PW = 'adm619-' + os.urandom(4).hex()
h('set', json.dumps({'admin_hash': h('hash', PW), 'gift_on': '1', 'hours': json.dumps({str(w): {'open': '09:00', 'close': '21:00'} for w in range(7)})}))
sv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % PORT, '-t', A, '/tmp/claude-0/router.php'], env={**ENV, 'PHP_CLI_SERVER_WORKERS': '6'}, stdout=subprocess.DEVNULL, stderr=open(D + '/php.log', 'w'))
atexit.register(lambda: sv.terminate()); time.sleep(1.2)
B = 'http://127.0.0.1:%d/api.php' % PORT; jar = http.cookiejar.CookieJar(); OP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); CS = [None]
def api(action, body=None, get=''):
    hd = {'Content-Type': 'application/json'}; hd.update({'X-CSRF': CS[0]} if CS[0] else {})
    rq = urllib.request.Request(B + '?action=' + action + get, data=json.dumps(body).encode() if body is not None else None, headers=hd)
    try: r = OP.open(rq, timeout=60); return r.status, json.loads(r.read().decode() or '{}')
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode() or '{}')
        except Exception: return e.code, {}
c, r = api('login', {'password': PW}); CS[0] = r.get('csrf')
say('== LAMWEB test 629 (tin missed call qua cron, khong can request khac) ' + time.strftime('%Y-%m-%d %H:%M %Z') + ' · login ' + str(c))
TODAY = time.strftime('%Y-%m-%d')
def mk(ph, name, staff, sid, start):
    sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES ('%s', %d, 45, %d, '%d', '%s', '%s', 'arrived', 'admin', 'appt', '', datetime('now'), '%s')" % (TODAY, start, staff, sid, name, ph, os.urandom(8).hex()))
    return sql("SELECT id FROM appointments WHERE phone = '%s' ORDER BY id DESC LIMIT 1" % ph)[0]['id']
def price(sid): return float(sql("SELECT price FROM services WHERE id = %d" % sid)[0]['price'])
def pay(aid, sid, staff, pays, **k):
    b = {'ids': [aid], 'lines': [{'appt': aid, 'sid': sid, 'price': price(sid), 'staff': staff}], 'pays': pays}; b.update(k); return api('checkout2', b)
def st(aid): return sql("SELECT status FROM appointments WHERE id = %d" % aid)[0]['status']
def nrc(): return int(sql("SELECT COUNT(*) AS n FROM receipts")[0]['n'])
P = price(PD)
H2 = D + '/h629b.php'
open(H2, 'w').write("""<?php require '%s/inc/core.php'; settings(); require_once '%s/inc/calls.php'; require_once '%s/inc/android.php'; $a = $argv[1];
if ($a === 'init') { cl_table(); foreach (['call_on' => '1', 'call_tb_on' => '1', 'tx_on' => '1', 'tx_key' => 'test-key-not-real', 'as_on' => '1', 'as_device' => 'android', 'ad_transport' => 'winsms',
  'ws_key' => ad_enc('WS_test_key_123456789abc'), 'ws_server_url' => 'http://127.0.0.1:9', 'salon_phone' => '(515) 555-0100', 'call_fwd' => '+15155550199'] as $k => $v) set_setting($k, $v); echo '{}'; }
if ($a === 'call') { cl_table(); [$_, $_, $sid, $ph, $ago, $st, $aid] = $argv;
  q("INSERT INTO calls (call_sid, from_phone, to_phone, kind, started_at, status, result, seen, tb_state, tb_at, created_at, purge_at, appt_id) VALUES (?, ?, '+15155136667', 'call', ?, ?, 'Missed', 0, 'wait', ?, ?, '', ?)",
    [$sid, $ph, date('Y-m-d H:i:s', time() - (int)$ago - 60), $st, date('Y-m-d H:i:s', time() - (int)$ago), date('Y-m-d H:i:s', time() - (int)$ago - 60), (int)$aid]);
  echo json_encode(['id' => (int)db()->lastInsertId()]); }
if ($a === 'quick') { define('NF_API_LIB', 1); foreach (['/inc/outbox.php', '/inc/api/_auth.php', '/inc/api/_menu.php', '/inc/api/_texts.php', '/inc/api/_kiosk.php', '/inc/api/_out.php'] as $f) require_once '%s' . $f;
  require_once '%s/api.php'; require_once '%s/inc/calls-job.php'; $GLOBALS['actor'] = ['admin', 'Owner']; usleep((int)($argv[2] ?? 0)); cl_quick(); echo '{}'; }
""" % (A, A, A, A, A, A))
def h2(*a):
    r = sh('php', H2, *[str(x) for x in a])
    try: return json.loads(r.stdout)
    except Exception: return {'err': (r.stdout + r.stderr)[-300:]}
h2('init')
def cron(sec=6):
    return subprocess.run(['timeout', str(sec), 'php', A + '/cron/tx-mp3.php'], capture_output=True, text=True, env=ENV)
def tb(cid): x = sql("SELECT tb_state, status FROM calls WHERE id = %d" % cid); return x[0] if x else {}
def texts(cid): return sql("SELECT src, phone, state, body FROM autosend WHERE src IN ('ui:call:%d', 'ui:callreq:%d') AND state <> 'skip'" % (cid, cid))
# 1 a Telnyx missed call, 40 s ago, NOTHING else happens (no other call, nobody opens the admin): the cron alone
c1 = h2('call', 'v3:M629A', '+15155550151', 40, 'missed', 0)['id']; r = cron()
ok('1 missed call Telnyx, KHONG co request nao khac -> cron (tx-mp3, moi phut) gui tin trong <= 15 s: DUNG 1 tin, tb_state sent', len(texts(c1)) == 1 and tb(c1).get('tb_state') == 'sent',
   (texts(c1), tb(c1), r.stderr[-300:]))
ok('1b noi dung: "missed your call" + link dat hen', 'missed' in (texts(c1) or [{}])[0].get('body', '').lower() and 'http' in (texts(c1) or [{}])[0].get('body', ''), texts(c1))
# 2 the cron + the owner's page (cl_quick) x3 at the same moment, 2 calls waiting -> each call exactly 1 text, none marked "skip"
c2 = h2('call', 'v3:M629B', '+15155550152', 30, 'missed', 0)['id']; c3 = h2('call', 'v3:M629C', '+15155550153', 30, 'missed', 0)['id']
ps = [subprocess.Popen(['timeout', '8', 'php', A + '/cron/tx-mp3.php'], env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)] + \
     [subprocess.Popen(['php', H2, 'quick', str(k * 3000)], env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE) for k in range(3)]
[p.wait() for p in ps]
ok('2 cron + 3 trang chu cung luc, 2 cuoc missed -> moi cuoc DUNG 1 tin, ca 2 "sent" (khong "skip")', len(texts(c2)) == 1 and len(texts(c3)) == 1 and tb(c2).get('tb_state') == 'sent' and tb(c3).get('tb_state') == 'sent',
   (texts(c2), texts(c3), tb(c2), tb(c3)))
# 3 the same number again within 30 min -> no 2nd text
c4 = h2('call', 'v3:M629D', '+15155550151', 20, 'missed', 0)['id']; cron()
ok('3 cung so goi lai trong 30 phut -> KHONG tin thu 2 (skip)', not texts(c4) and tb(c4).get('tb_state') == 'skip', (texts(c4), tb(c4)))
# 4 STOP number / the salon's own number / a call that ended booked -> no text (as before)
sql("INSERT INTO customers (phone, name, opted_out, created_at) VALUES ('+15155550154', 'STOP GUY', 1, '2026-11-01 10:00:00')")
try: sh('php', '-r', "require '%s/inc/core.php'; settings(); require_once '%s/inc/stophook.php'; if (function_exists('ad_stop_add')) ad_stop_add('+15155550154', 'test');" % (A, A))
except Exception: pass
c5 = h2('call', 'v3:M629E', '+15155550154', 20, 'missed', 0)['id']; c6 = h2('call', 'v3:M629F', '+15155550100', 20, 'missed', 0)['id']
c7 = h2('call', 'v3:M629G', '+15155550157', 20, 'booked', 77)['id']; cron()
ok('4 so salon / cuoc da BOOKED -> khong tin (skip, nhu cu)', not texts(c6) and not texts(c7) and tb(c6).get('tb_state') == 'skip' and tb(c7).get('tb_state') == 'skip', (texts(c6), texts(c7), tb(c6), tb(c7)))
st5 = sql("SELECT state, note FROM autosend WHERE src = 'ui:call:%d'" % c5)
ok('4b so da STOP -> khong gui (khong co tin cho gui)', not texts(c5) and tb(c5).get('tb_state') == 'skip', (st5, tb(c5)))
# 5 YOU'RE BOOKED after the 10 minutes: the cron does it too (before: only the tick / the owner's page)
aid = int(sql("SELECT COUNT(*) AS n FROM appointments")[0]['n']) or 0
sql("INSERT INTO appointments (appt_date, start_min, duration, staff_id, service_ids, customer_name, phone, status, source, kind, group_id, created_at, token) VALUES (date('now', '+2 days'), 600, 45, %d, '%d', 'CALL BOOK', '+15155550158', 'booked', 'call', 'appt', '', datetime('now'), 'c629')" % (TA, PD))
ap = int(sql("SELECT id FROM appointments WHERE token = 'c629'")[0]['id'])
c8 = h2('call', 'v3:M629H', '+15155550158', 700, 'booked', ap)['id']; sql("UPDATE calls SET conf_at = '%s', conf_done = 0, tb_state = 'skip' WHERE id = %d" % (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - 60)), c8)); cron()
ob = sql("SELECT kind, status FROM outbox WHERE appt_id = %d" % ap)
ok('5 YOU\'RE BOOKED sau 10 phut: cron tu lam buoc nay (conf_done = 1 – tin xac nhan theo cai dat tin cua tiem, nhu duong cu)', int(sql("SELECT conf_done FROM calls WHERE id = %d" % c8)[0]['conf_done']) == 1, (ob, sql("SELECT conf_done FROM calls WHERE id = %d" % c8)))
logs = open(D + '/php.log').read()
ok('khong co PHP Warning / Fatal', not any(w in logs for w in ['PHP Warning', 'PHP Fatal', 'Uncaught']), [l for l in logs.splitlines() if 'PHP' in l][:3])
say('PASS %d/%d' % (sum(R), len(R)))
