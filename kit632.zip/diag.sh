#!/bin/bash
# LAMWEB 621-C – CHAN DOAN kit tren server (chi ban test + SQLite rieng + dich vu gia; KHONG du lieu that, KHONG mang that, KHONG push).
#   bash /root/nftest/kit/diag.sh            (ghep app GIONG nightly.sh tu nftest.conf)
#   bash /root/nftest/kit/diag.sh <app>      (app co san)
# Chay telnyx (den test "2 Public Key") + sw605b (den swml dau tien) 2 lan: A = co phpini cua kit, B = KHONG phpini (nhu lan 1). In <= 60 dong.
set -u
K=$(cd "$(dirname "$0")" && pwd); N=$(dirname "$K")
if [ $# -ge 1 ]; then APP=$(cd "$1" && pwd); else
  . "$N/nftest.conf"; APP="$N/app-diag"; rm -rf "$APP"; mkdir -p "$APP"; cp -a "$APP_LIVE/." "$APP/"
  for f in index.php api.php call_tx.php; do [ -f "$AN_PUBLIC/$f" ] && [ ! -L "$AN_PUBLIC/$f" ] && cp "$AN_PUBLIC/$f" "$APP/$f"; done
  rm -f "$APP/inc/config.php" "$APP/error_log"; find "$APP" -name '*.sqlite' -delete 2>/dev/null; PATH="$(dirname "$PHP"):$PATH"; fi
export TZ=America/Chicago
echo "== DIAG 621-C $(date '+%F %T %Z') · app $APP · $(grep -o "APP_VERSION', '[^']*" "$APP/inc/core.php" | cut -d"'" -f3) · php $(command -v php) · python3 $(python3 -V 2>&1)"
CK="$K/clock/nfclock.so"; [ -f "$CK" ] || gcc -shared -fPIC -O2 -o "$CK" "$K/clock/nfclock.c" -ldl 2>/dev/null
NOW=$(date -d '2026-11-04 10:00' +%s)
echo "gio gia (LD_PRELOAD): python $(NF_FAKE_T0=$(date +%s) NF_FAKE_NOW=$NOW LD_PRELOAD=$CK python3 -c 'import time;print(int(time.time()))') · php $(NF_FAKE_T0=$(date +%s) NF_FAKE_NOW=$NOW LD_PRELOAD=$CK php -r 'echo time();') · muon ~$NOW · that $(date +%s)"
for M in A B; do
  if [ $M = A ]; then unset NF_NO_PHPINI; else export NF_NO_PHPINI=1; fi
  echo "---- $M: $([ $M = A ] && echo 'CO phpini kit' || echo 'KHONG phpini (nhu lan 1)')"
  ( [ $M = A ] && export PHP_INI_SCAN_DIR="${PHP_INI_SCAN_DIR:-}:$K/phpini"; php -r 'echo "ini: display_errors=", ini_get("display_errors"), " error_log=", ini_get("error_log") ?: "(stderr)", " exec=", function_exists("exec") ? "co" : "TAT", " sodium=", function_exists("sodium_crypto_sign_verify_detached") ? "co" : "KHONG", " opcache_cli=", ini_get("opcache.enable_cli"), " prepend=", ini_get("auto_prepend_file") ?: "-", " scan=", getenv("PHP_INI_SCAN_DIR") ?: "-", "\n";' 2>&1 | head -2 )
  NF_DIAG=1 "$K/run-tests.sh" "$APP" telnyx sw605b > /dev/null 2>&1
  for s in telnyx sw605b; do grep -E '^(DIAG|✗|!!|   !!)' "$K/run/logs/$s.txt" 2>/dev/null | cut -c1-400 | head -12 | sed "s/^/$s: /"; done
done
unset NF_NO_PHPINI; [ $# -ge 1 ] || rm -rf "$N/app-diag"
echo "== het DIAG (gui nguyen man hinh nay cho LAMWEB)"
