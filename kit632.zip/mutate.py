#!/usr/bin/env python3
# LAMWEB 618-B.1 - "co tinh lam hong" (mutation): each mutation breaks ONE important line in a COPY of the app, then runs the suite that must catch it.
# The suite MUST show a NEW FAIL (not in baseline/). Still all old -> that test is useless (written in the report).
#   python3 mutate.py <app folder>        -> run/MUTATION.txt
import sys, os, shutil, subprocess, re, time
K = os.path.dirname(os.path.abspath(__file__)); APP = os.path.abspath(sys.argv[1]); W = K + '/mut'; os.makedirs(W, exist_ok=True)
# (id, what is broken, file, old, new, suite)
M = [
 ('M01', 'chong trung dat hen (B1) bi bo', 'inc/calls-job.php', "if ($dup) { q('UPDATE calls SET appt_id", "if (false && $dup) { q('UPDATE calls SET appt_id", 'telnyx615'),
 ('M02', 'kiem tho / gio trong (cl_free) luon "trong"', 'inc/calls-job.php', "    $busy = busy_appts($date); $out = staff_out_at($date);", "    return ''; $busy = busy_appts($date); $out = staff_out_at($date);", 'telnyx615'),
 ('M03', 'khoa dat hen (book_lock) khong khoa', 'api.php', "function book_lock(): bool {\n", "function book_lock(): bool { $GLOBALS['book_locked'] = true; return true;\n", 'telnyx615'),
 ('M04', 'kiem chu ky webhook luon OK', 'inc/calls-tx.php', "    $pub = tx_pub(); if ($pub === '') return '';", "    return ''; $pub = tx_pub();", 'aicall'),
 ('M05', 'huy theo appt_id bi bo (huy nham hen trung)', 'inc/calls-job.php', "    if ($aid > 0) foreach ($up as $a) if ((int)$a['id'] === $aid) return [$a];", "", 'telnyx615'),
 ('M06', 'chuyen AI 1 lan (tx_claim) luon true', 'inc/calls-tx.php', "(screen IS NULL OR screen NOT IN ('vmai', 'person'))\", [$sid])->rowCount() === 1;", "(screen IS NULL OR screen NOT IN ('vmai', 'person'))\", [$sid])->rowCount() >= 0;", 'telnyx'),
 ('M07', 'chuyen may ve lai iPhone (cl_ivr_owner_tx)', 'inc/calls-tx.php', "return strlen($o) === 12 && $o !== norm_phone(cl_fwd()) ? $o : ''; }", "return strlen($o) === 12 ? $o : cl_fwd(); }", 'aicall telnyx'),
 ('M08', 'tin missed call: bo luat 30 phut', 'inc/calls-job.php', "return $skip('texted < 30 min ago');", "{}", 'sw590'),
 ('M09', 'missed call Telnyx (cup truoc AI) khong hen tin', 'inc/calls-tx.php', "rowCount()) cl_tb_wait($sid, 0);", "rowCount()) {}", 'aicall telnyx'),
 ('M10', 'log lai so dien thoai day du', 'inc/calls-tx.php', "preg_replace('/\\+1\\d{6}(\\d{4})/', '+1******$1', ", "preg_replace('/^\\b$/', '', ", 'aicall'),
 ('M11', 'chon mau: mau moi KHONG thay mau cu (chon nhieu)', 'assets/book-colors.js', "if (b.hasAttribute('data-hok') && handC) { picked = [handC];", "if (b.hasAttribute('data-hok') && handC) { picked = picked.filter(p => p.code !== handC.code).concat([handC]);", 'book611a'),
 ('M12', 'Done < 5 phut khong hoi lai (609)', 'inc/api/techapp.php', "($sec = time() - (int)strtotime((string)$a['started_at'])) < 300)", "($sec = time() - (int)strtotime((string)$a['started_at'])) < 0)", 'turn609'),
 ('M13', 'so goi den lay tu body AI (khong phai CallSid)', 'inc/calls-tx.php', "'caller_id_num' => (string)$c['from_phone'],", "'caller_id_num' => (string)($body['phone'] ?? $c['from_phone']),", 'aicall'),
 ('M14', 'AI dat lich khi THIEU ten (ca 2 lop: tool + cl_decide)', 'inc/calls-agent.php', "if ($name === '') return $out('NOT_BOOKED – ask the caller\\'s name.');", "if ($name === '') $name = 'X';", 'aicall', ('inc/calls-job.php', "    if ($name === '' && $file && trim((string)$file['name']) !== '') $name = mb_strtoupper(trim((string)$file['name']));\n    if ($name === '') $why[] = 'no name';", "    if ($name === '' && $file && trim((string)$file['name']) !== '') $name = mb_strtoupper(trim((string)$file['name']));")),
 ('M15', 'checkout: bo khoa tien (app_lock money) – 2 may cung luc', 'inc/checkout.php', "    app_lock('money'); // (2.99.69)", "    // (2.99.69)", 'mod619', ('inc/api/checkout.php', "    app_lock('money'); /* (2.99.457", "    /* (2.99.457")),
 ('M16', 'the qua tang: bo kiem so du', 'inc/checkout.php', "if ($giftAmt > (float)$gift['balance'] + 0.001) fail(", "if (false) fail(", 'mod619'),
 ('M17', 'checkout: bo kiem tong tien tra = so phai tra', 'inc/checkout.php', "if ((int)round(($card + $cash + $other) * 100) !== (int)round($collectAll * 100)) fail(", "if (false) fail(", 'mod619'),
 ('M18', 'tip am duoc nhan', 'inc/checkout-receipts.php', "if ($amt < 0) fail('Check the ' . $kind . ' tip.');", "", 'mod619'),
 ('M19', 'PIN de doan (1234) van nhan', 'inc/api/staffadmin.php', "    if (weak_pin($pin)) fail('That PIN is too easy", "    if (false) fail('That PIN is too easy", 'pay619'),
 ('M20', 'xoa tho: hen sap toi KHONG chuyen ANYONE', 'inc/api/staffadmin.php', "q('UPDATE appointments SET staff_id = 0, auto_tech = 0 WHERE id = ?', [$a['id']]); appt_log($a, 'tech_out'", "appt_log($a, 'tech_out'", 'pay619'),
 ('M21', 'void sau khi chot tuan: chenh lech KHONG sang tuan sau', 'inc/api/checkout.php', "{ receipt_void($r, $reason); $carry = payroll_carry(", "{ receipt_void($r, $reason); $carry = []; if (0) $carry = payroll_carry(", 'pay619'),
 ('M22', 'ngay da khoa (Close day) van checkout duoc (ca 2 lop)', 'inc/checkout.php', "    if ($d === $today) { day_open_or_fail($today, 'no new checkouts');", "    if ($d === $today) {", 'pay619', ('inc/checkout.php', "))) day_open_or_fail(date('Y-m-d'), 'no new checkouts');", ")));")),
 ('M23', 'SMS den (STOP): bo kiem chu ky Twilio', 'sms_in.php', "if (!twilio_valid()) {", "if (false) {", 'pay619'),
 ('M24', 'luat $1: tho KHONG bi tru $1', 'inc/checkout.php', "$pay[$rw['staff']]['amt'] = round($pay[$rw['staff']]['amt'] - $fa, 2);", "", 'pay619'),
 ('M25', 'checkout KHONG transaction (loi giua chung -> do dang)', 'inc/api/checkout.php', "    db()->beginTransaction();\n    try { $rc = checkout_save($in);", "    try { $rc = checkout_save($in);", 'money626'),
 ('M26', 'void duoc hoa don DA refund', 'inc/checkout-receipts.php', "    if ((float)$r['refund'] > 0) fail('Money was already refunded", "    if (false) fail('Money was already refunded", 'money626'),
 ('M27', 'refund duoc hoa don DA void', 'inc/checkout-receipts.php', "    if ($r['status'] !== 'paid') fail('This receipt is void.');", "", 'money626'),
 ('M28', 'gift card: tru so du 2 lan (khong khoa tien)', 'inc/checkout.php', "    app_lock('money'); // (2.99.69)", "    // (2.99.69)", 'money626', ('inc/api/checkout.php', "    app_lock('money'); /* (2.99.457", "    /* (2.99.457")),
 ('M29', 'tru gift card KHONG co lop 2 (so du co the am)', 'inc/checkout.php', "if (q('UPDATE giftcards SET balance = balance - ? WHERE id = ? AND balance >= ? - 0.001', [$giftAmt, $gift['id'], $giftAmt])->rowCount() !== 1)", "if (q('UPDATE giftcards SET balance = balance - ? WHERE id = ?', [$giftAmt, $gift['id']]) && false)", 'money627'),
 ('M30', 'void bill KHONG void the gift ban tren bill', 'inc/checkout-receipts.php', "    $gsc = receipt_gift_sale_card($r);", "    $gsc = null;", 'money627'),
 ('M31', 'the void do void bill KHONG ban lai duoc', 'inc/giftcards.php', "return is_array($g) && $g['status'] === 'void' &&", "return false &&", 'money627'),
 ('M32', 'refund tien mat van bi chan sau refund gift (L1 cu)', 'inc/checkout-receipts.php', "min($all, round(receipt_collect($r) - $real, 2))", "round(receipt_collect($r) - (float)$r['refund'], 2)", 'money627'),
 ('M33', 'cron tx-mp3 KHONG gui tin missed call (629 cu)', 'cron/tx-mp3.php', "    if (time() >= $nextCalls) {", "    if (false) {", 'calls629'),
]
only = sys.argv[2:]
out = []; t0 = time.time()
for mm in M:
    mid, what, f, old, new, suite = mm[:6]; extra = mm[6:]
    if only and mid not in only: continue
    d = W + '/app'; shutil.rmtree(d, ignore_errors=True); shutil.copytree(APP, d, symlinks=True)
    p = d + '/' + f; s = open(p, encoding='utf-8').read(); n = s.count(old)
    if n != 1: out.append('%s  ?? ANCHOR %d lan – khong chay (%s)' % (mid, n, what)); print(out[-1]); continue
    open(p, 'w', encoding='utf-8').write(s.replace(old, new))
    for f2, o2, n2 in extra:
        p2 = d + '/' + f2; s2 = open(p2, encoding='utf-8').read(); assert s2.count(o2) == 1, (mid, f2); open(p2, 'w', encoding='utf-8').write(s2.replace(o2, n2))
    r = subprocess.run([K + '/run-tests.sh', d] + suite.split(), capture_output=True, text=True); sm = r.stdout
    nm = sum(int(x) for x in re.findall(r'FAIL MOI (\d+)\)', sm)) if 'FAIL MOI' in sm else -1
    caught = [l.strip()[5:90] for l in sm.splitlines() if l.strip().startswith('MOI:')][:3]
    out.append('%s  %-6s %-45s bo %-9s FAIL MOI %2d  %s' % (mid, 'BAT DUOC' if nm > 0 else 'LOT !!', what, suite, nm, ' | '.join(caught)))
    print(out[-1], flush=True)
shutil.rmtree(W, ignore_errors=True)
txt = '== MUTATION (618-B.1) %s · app %s · %ds\n' % (time.strftime('%Y-%m-%d %H:%M'), APP, time.time() - t0) + '\n'.join(out) + '\n== BAT DUOC %d / %d\n' % (sum('BAT DUOC' in x for x in out), len(out))
os.makedirs(K + '/run', exist_ok=True); open(K + '/MUTATION.txt', 'w').write(txt); print(txt.splitlines()[-1])
